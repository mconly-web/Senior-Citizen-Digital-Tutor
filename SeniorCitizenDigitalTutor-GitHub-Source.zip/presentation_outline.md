# Presentation Outline & Slide Walkthrough
## Senior Citizen Digital Tutor: Production-Ready Desktop Solution

**Project Name:** Senior Citizen Digital Tutor  
**Tagline:** *"Learn. Practice. Use. Stay Connected."*  
**Presentation Deck:** `Senior_Citizen_Digital_Tutor_Presentation.pptx` (15 Widescreen 16:9 Slides)  
**Visual Identity:** Warm Cream (`#FAF8F5`), Forest Green (`#173F35`), Terracotta (`#C97855`), Muted Gold (`#D6A84F`), Soft Sage (`#6F8068`).

---

## Slide-by-Slide Outline & Overview

### Slide 1: Title & Overview
- **Title:** Senior Citizen Digital Tutor
- **Subtitle:** "Learn. Practice. Use. Stay Connected."
- **Overview:** A Production-Ready Standalone Desktop Literacy & Fraud Prevention Tutor for Elders
- **Technology:** Java 21 LTS • JavaFX • SQLite 3.45 • JUnit 5 • Offline Multilingual Voice Synthesis • jpackage Native Installer
- **Summary:**
  > An offline-first, highly accessible desktop software designed to empower senior citizens to learn essential smartphone, internet, and digital banking tasks without anxiety, confusion, or fear. 100% private, self-contained, and free of cloud dependencies.

---

### Slide 2: Problem Statement — The Senior Digital Divide
- **Key Points:**
  - **Interface Inaccessibility:** Microscopic touch targets, dense layouts, rapid animation transitions that confuse older eyes and trembling fingers.
  - **The Paralysis of Fear:** Elders dread losing life savings, sending accidental messages, or breaking devices; they hesitate to ask busy children repeatedly.
  - **Rampant Cyber Scams in India:** Elders are actively targeted by fake electricity cut notices, "Digital Arrest" Skype calls, courier narcotics traps, and QR "receive money" fraud.
- **Speaker Note:**
  > *"Over 70% of senior citizens report anxiety when using smartphones. They hesitate to ask their busy children repeatedly for basic tasks. Furthermore, cyber fraudsters deliberately prey on this unfamiliarity with urgent threats. We built this application to turn fear into confidence."*

---

### Slide 3: Motivation & Core Philosophy
- **Key Points:**
  - **The Patient Family Member Metaphor:** Unlimited repetition, zero judgment, calm respectful tone.
  - **7 Safe Practice Sandboxes:** Interactive simulations of WhatsApp, Phone Dialer, UPI, Maps, Email, DigiLocker, and Bill Payment.
  - **Privacy-First & 100% Offline:** Local SQLite database, local Windows speech synthesis, and local speech recognition; zero cloud servers, tracking, or paid APIs.
- **Speaker Note:**
  > *"We deliberately rejected corporate LMS paradigms. There are no intimidating countdown timers, failing grades, or confusing error messages. The UI uses an editorial cream-and-forest-green palette designed specifically for elder calm."*

---

### Slide 4: Proposed Solution — 4-Pillar Architecture
- **Key Points:**
  1. **LEARN:** 42 guided lessons with visual UI mockups, multilingual voice narration, end-of-lesson recaps, and interactive quizzes.
  2. **PRACTICE:** 7 sandboxed simulations (WhatsApp, Phone Dialer, UPI, Google Maps, Email, Aadhaar/DigiLocker, Online Bill Payment).
  3. **STAY SAFE:** Weighted scam engine, "Why this is risky" explanations, 1930 Cyber Helpline card, and the "Scam Spotter" mini-game.
  4. **STAY CONNECTED:** Configurable Emergency help with Senior Medical Card, family caregiver analytics, and PIN-protected helper mode.

---

### Slide 5: Comprehensive 42-Lesson Curriculum (12 Categories)
- **Categories Covered:**
  1. 📱 Smartphone Basics (Power, volume, screen brightness, battery care)
  2. 📞 Phone Calls & Contacts (Dialing, saving numbers, speakerphone, blocking spam)
  3. 💬 WhatsApp & Messaging (Chat, voice notes, photos, video calls, groups)
  4. 📹 Calls & Video Calling (Front camera, clear audio, quiet rooms, WhatsApp calls)
  5. 💳 UPI & Digital Payments (GPay, PhonePe, QR code scanning, never entering PIN to receive)
  6. 🏦 Online Banking & ATM Safety (ATM PIN covering, statement checking, OTP secrecy)
  7. 🗺️ Google Maps & Navigation (Searching clinics, hospitals, turn-by-turn directions)
  8. 📧 Email Communication (Composing, reading attachments, spotting fake emails)
  9. 📄 Aadhaar & DigiLocker (Government identity, vaccine certificates, driving license)
  10. ⚡ Online Shopping & Bill Payments (Electricity bills, mobile recharge, cash on delivery)
  11. 🔐 Digital Safety & Scam Awareness (6 Golden Rules, fake electricity cuts, digital arrest, parcel traps)
  12. 🩺 Entertainment & Telemedicine (Spiritual YouTube videos, doctor video consults, 112/1930 helplines)

---

### Slide 6: Trilingual Localization & Voice Tutor
- **Key Points:**
  - Complete curriculum translated into **English**, **Hindi (हिंदी)**, and **Marathi (मराठी)**.
  - Integrated offline voice tutor dynamically selects native Indian SAPI voices (`hi-IN` Kalpana/Hemant, `mr-IN` Marathi, or English) with graceful fallback.
  - Adjustable voice pace in Settings: *Calm & Slow* (-2.0), *Normal* (-1.0), or *Brisk* (0.0).
  - Cross-platform voice fallbacks for macOS (`say`) and Linux (`espeak`).

---

### Slide 7: Real Voice Search & Onboarding
- **Key Points:**
  - **"🎤 Teach Me Anything" Search:** Seniors can speak directly into their microphone using Windows Speech Recognition to find lessons, with fallback to typing.
  - **Typo-Tolerant Search:** Automatically matches common senior misspellings (e.g. "whatapp", "vidio", "pension") and multilingual keywords.
  - **First-Run Welcome Wizard:** Guides seniors through name selection, language choice, text scaling preview, and a 1-minute guided tour.
  - **Daily Digital Tip & Weekly Progress Summary:** Encouraging daily safety advice and streak metrics on the Home dashboard.

---

### Slide 8: 7 Risk-Free Practice Simulators
- **Interactive Sandboxes:**
  1. **WhatsApp:** Message bubbles, double-ticks, voice notes, photo sharing, live location, and full video call with timer.
  2. **Phone Dialer:** 3x4 dialpad, family speed-dial chips, ringing and connected call screens.
  3. **UPI Payments:** Shop QR scan, merchant verification, safety warning box, secret PIN pad, and audio soundbox receipt.
  4. **Google Maps:** Interactive canvas, clinic/hospital pins, route drawing, and spoken turn-by-turn voice directions.
  5. **Email:** Senior-friendly Gmail composer, recipient autofill, PDF attachment chip, sent folder, and received inbox messages.
  6. **Aadhaar & DigiLocker:** Document fetching, masked 12-digit number entry, simulated SMS OTP verification, and e-Aadhaar PDF password formula (`RAME1952`).
  7. **Online Bill Payment:** Electricity and mobile recharge simulation, verified due date reminder (15-day notice vs scam 1-hour threats), and PDF receipt.

---

### Slide 9: Digital Safety Hub & "Scam Spotter" Mini-Game
- **Key Points:**
  - Weighted heuristic scoring engine detecting Indian scam patterns (Digital Arrest, QR receive-money deception, fake electricity disconnection, AnyDesk remote control, loan apps).
  - Regex detection for suspicious shortlinks, IP addresses, `.apk` files, and spoofed country codes.
  - **"Why This Is Risky" Explanations:** Teaches the psychological trap behind every warning sign.
  - **Official 1930 Cyber Helpline & cybercrime.gov.in Card:** Step-by-step instructions for reporting financial cybercrime within the Golden Hour.
  - **"Scam Spotter" Mini-Game:** 10 real-world Indian scenarios where elders tap **SAFE** or **SCAM** to test their instincts and receive instant educational scoring.

---

### Slide 10: Knowledge Retention — Quizzes & Milestone Badges
- **Key Points:**
  - 3 to 5 touch-friendly multiple-choice questions per lesson with immediate explanations.
  - End-of-lesson key takeaway recaps.
  - Learning streak tracking (daily consecutive days).
  - 8 unlockable milestone badges celebrating user progress.

---

### Slide 11: Family Caregiver Mode & Emergency Medical Card
- **Key Points:**
  - Helper mode for adult children / caregivers (Anita Sharma) protected by an optional 4-digit PIN.
  - Category breakdown and automatic weak-topic identification.
  - Lesson recommender tool: caregiver pins a lesson with an encouraging note to the senior's Home screen.
  - **One-Touch Emergency Assistance:** Giant buttons (Family, 108 Ambulance, 112 Police) with confirmation safeguards.
  - **Senior Medical Card:** Displays blood group (`O+`), daily medications, and family doctor phone for first responders.

---

### Slide 12: Accessibility, Ergonomics & Quality Engineering
- **Key Points:**
  - WCAG AAA minimum **48px touch targets** for all interactive elements.
  - Full keyboard navigation with high-visibility focus outlines (`Tab`, `Shift+Tab`, `Enter`).
  - Resilient text scaling and layouts resizing cleanly down to **1024x700**.
  - Colorblind-safe indicators (icons paired with colors for all states).
  - **Zero Stack Traces:** Senior-friendly error dialogs that reassure users their progress is safe.
  - Full JSON backup and restore for learning progress and settings.

---

### Slide 13: System Architecture & Data Layer
- **Architecture Layers:**
  1. **Presentation Layer (JavaFX):** MainLayout, NavigationBar, view controllers, and custom visual illustration nodes.
  2. **Service Layer:** SafetyCheckerService, ProgressService, SearchService, LessonService, QuizService, LocalizationService, BackupService, WindowsSpeechService.
  3. **Repository Layer:** Data access objects with parameterized JDBC SQL queries.
  4. **Persistence Layer (SQLite):** Embedded database (`database/seniortutor.db`) with automated migrations tracked via `schema_version`.

---

### Slide 14: Automated Verification & Delivery
- **21 Automated JUnit 5 Tests:** 100% pass rate across scam detection, progress tracking, localization, search, and backup services.
- **Backend Smoke Test Suite:** Automated verification of database integrity, curriculum seeding, and speech synthesis.
- **Packaging & Delivery:**
  - Self-contained Fat JAR (`SeniorCitizenDigitalTutor.jar`).
  - Native Windows standalone app bundled via `jpackage` (`dist\SeniorCitizenDigitalTutor\SeniorCitizenDigitalTutor.exe`) with embedded runtime (users do not need Java installed).
  - One-click build script: `build-installer.bat`.

---

### Slide 15: Conclusion & Social Impact
- **Project Conclusion:** Successfully delivers an empowering, privacy-preserving, accessible desktop tutor that bridges the digital generational divide, fosters independence, and protects our elders from financial cybercrime.
