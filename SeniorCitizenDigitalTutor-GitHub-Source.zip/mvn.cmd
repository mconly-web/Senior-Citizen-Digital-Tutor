@echo off
"C:\Users\souri\.maven\apache-maven-3.9.6\bin\mvn.cmd" %*
