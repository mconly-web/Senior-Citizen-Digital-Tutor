package com.seniortutor;

import com.seniortutor.database.DatabaseManager;
import com.seniortutor.model.*;
import com.seniortutor.repository.*;
import com.seniortutor.service.*;

import java.util.List;

public class AppSmokeTest {

    public static void main(String[] args) {
        System.out.println("========== RUNNING SENIOR TUTOR BACKEND & DB SMOKE TEST ==========");

        // 1. Test Database Initialization & Seeding
        DatabaseManager.getInstance();
        System.out.println("[PASS] Database connected and schema initialized.");

        // 2. Test User Repository
        UserRepository userRepo = new UserRepository();
        List<User> users = userRepo.getAllUsers();
        System.out.println("[PASS] Users found: " + users.size());
        for (User u : users) {
            System.out.println("   -> User: " + u.getName() + " (" + u.getRole() + ")");
        }
        if (users.size() < 2) throw new RuntimeException("Expected at least 2 users");

        // 3. Test Categories
        CategoryRepository catRepo = new CategoryRepository();
        List<Category> cats = catRepo.getAllCategories(1);
        System.out.println("[PASS] Categories found: " + cats.size());
        if (cats.size() < 12) throw new RuntimeException("Expected at least 12 categories, found: " + cats.size());
        // Verify multilingual fields on Category
        Category c1 = cats.get(0);
        if (c1.getNameHi() == null || c1.getNameMr() == null) {
            throw new RuntimeException("Expected Category to have Hindi and Marathi names populated");
        }
        System.out.println("   -> Category 1: EN=" + c1.getName() + " | HI=" + c1.getNameHi() + " | MR=" + c1.getNameMr());

        // 4. Test Lessons
        LessonRepository lessonRepo = new LessonRepository();
        List<Lesson> lessons = lessonRepo.getLessonsByCategory(1, 1);
        System.out.println("[PASS] Category 1 lessons found: " + lessons.size());
        if (lessons.isEmpty()) throw new RuntimeException("Expected lessons in category 1");

        Lesson l1 = lessonRepo.getLessonById(lessons.get(0).getId(), 1);
        System.out.println("[PASS] Lesson 1 has " + l1.getSteps().size() + " steps.");
        if (l1.getSteps().isEmpty()) throw new RuntimeException("Expected lesson steps");
        if (l1.getTitleHi() == null || l1.getTitleMr() == null) {
            throw new RuntimeException("Expected Lesson to have Hindi and Marathi titles populated");
        }
        System.out.println("   -> Lesson 1: EN=" + l1.getTitle() + " | HI=" + l1.getTitleHi() + " | MR=" + l1.getTitleMr());

        // 5. Test Quizzes
        QuizRepository quizRepo = new QuizRepository();
        List<QuizQuestion> questions = quizRepo.getQuizQuestionsForLesson(l1.getId());
        System.out.println("[PASS] Quiz questions for lesson 1: " + questions.size());
        if (questions.isEmpty()) throw new RuntimeException("Expected quiz questions");
        QuizQuestion q1 = questions.get(0);
        System.out.println("   -> Question: " + q1.getQuestionText());
        System.out.println("   -> Question HI: " + q1.getQuestionTextHi());
        System.out.println("   -> Options count: " + q1.getOptions().size());
        if (q1.getQuestionTextHi() == null || q1.getQuestionTextMr() == null) {
            throw new RuntimeException("Expected QuizQuestion to have Hindi and Marathi text populated");
        }

        // 6. Test Safety Checker Rule Engine & Multilingual Advice
        SafetyCheckerService safety = SafetyCheckerService.getInstance();
        SafetyCheckResult r1 = safety.analyzeMessage("Congratulations! You won ₹25,000 lottery! Click bit.ly/prize to claim now.", 1);
        System.out.println("[PASS] Lottery scam check verdict: " + r1.getRiskLevel() + " (Score: " + r1.getScore() + ")");
        if (r1.getRiskLevel() != SafetyCheckResult.RiskLevel.HIGH_RISK) throw new RuntimeException("Expected lottery scam to be flagged as HIGH_RISK");

        SafetyCheckResult r2 = safety.analyzeMessage("Dear customer, please send your 6-digit OTP to prevent your bank account from getting blocked immediately.", 1);
        System.out.println("[PASS] OTP scam check verdict: " + r2.getRiskLevel() + " (Score: " + r2.getScore() + ")");
        if (r2.getRiskLevel() != SafetyCheckResult.RiskLevel.HIGH_RISK) throw new RuntimeException("Expected OTP request to be flagged as HIGH_RISK");

        SafetyCheckResult r3 = safety.analyzeMessage("Hi Mom, I am reaching home at 7 PM for dinner.", 1);
        System.out.println("[PASS] Safe message check verdict: " + r3.getRiskLevel() + " (Score: " + r3.getScore() + ")");
        if (r3.getRiskLevel() != SafetyCheckResult.RiskLevel.APPEARS_SAFE) throw new RuntimeException("Expected friendly message to be APPEARS_SAFE");

        // Test Hindi & Marathi advice generation
        SafetyCheckResult rHi = safety.analyzeMessage("बिजली कट जाएगी, ओटीपी बताओ", 1, "hi");
        if (rHi.getDetectedFlags().isEmpty() || rHi.getRecommendations().isEmpty()) {
            throw new RuntimeException("Expected Hindi flags and advice to be generated");
        }
        System.out.println("[PASS] Hindi Scam Checker Advice: " + rHi.getRecommendations().get(0));

        // 7. Test Search Service
        SearchService search = SearchService.getInstance();
        List<Lesson> sResults = search.search("How do I make a video call?", 1);
        System.out.println("[PASS] Search for 'video call' found: " + sResults.size() + " matches.");
        if (sResults.isEmpty()) throw new RuntimeException("Expected search results for video call");

        // 8. Test Settings & Speech Pace
        SettingsRepository setRepo = new SettingsRepository();
        AppSettings s = setRepo.getSettingsForUser(1);
        System.out.println("[PASS] Settings loaded for user 1: Contact 1 = " + s.getEmergencyContact1Name() + " (" + s.getEmergencyContact1Phone() + ")");
        System.out.println("[PASS] Speech pace rate: " + s.getSpeechRate());

        // 9. Test Localization Service
        LocalizationService loc = LocalizationService.getInstance();
        loc.setLanguage("hi");
        String hiHome = loc.getString("nav.home");
        loc.setLanguage("mr");
        String mrHome = loc.getString("nav.home");
        loc.setLanguage("en");
        String enHome = loc.getString("nav.home");
        System.out.println("[PASS] Localization: EN=" + enHome + " | HI=" + hiHome + " | MR=" + mrHome);
        if ("Home".equals(hiHome) || "Home".equals(mrHome)) {
            throw new RuntimeException("Expected localized translations for nav.home");
        }

        // 10. Test Speech Service availability
        WindowsSpeechService speech = WindowsSpeechService.getInstance();
        if (!speech.isAvailable()) {
            throw new RuntimeException("Speech service should be available");
        }
        System.out.println("[PASS] WindowsSpeechService is active and available.");

        // 11. Test Achievements
        AchievementRepository achRepo = new AchievementRepository();
        List<Achievement> achs = achRepo.getAllAchievements(1);
        System.out.println("[PASS] Achievements found: " + achs.size());
        if (achs.isEmpty()) throw new RuntimeException("Expected achievements");

        // 12. Test Family Helper Service
        FamilyHelperService family = FamilyHelperService.getInstance();
        List<Recommendation> recs = family.getActiveRecommendations(1);
        System.out.println("[PASS] Family recommendations for Senior: " + recs.size());

        System.out.println("========== ALL BACKEND & DATABASE TESTS PASSED SUCCESSFULLY! ==========");
    }
}
