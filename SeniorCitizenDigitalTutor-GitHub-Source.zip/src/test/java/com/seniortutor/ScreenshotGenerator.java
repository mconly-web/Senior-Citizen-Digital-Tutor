package com.seniortutor;

import com.seniortutor.database.DatabaseManager;
import com.seniortutor.model.Lesson;
import com.seniortutor.service.LessonService;
import com.seniortutor.ui.MainLayout;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.concurrent.CountDownLatch;

/**
 * Automates rendering and capturing clean screenshots of each view in the Senior Citizen Digital Tutor.
 */
public class ScreenshotGenerator extends Application {

    @Override
    public void start(Stage primaryStage) {
        new Thread(() -> {
            try {
                DatabaseManager.getInstance();

                File dir = new File("screenshots");
                if (!dir.exists()) dir.mkdirs();

                Platform.runLater(() -> {
                    MainLayout layout = new MainLayout();
                    Scene scene = new Scene(layout, 1280, 800);
                    primaryStage.setScene(scene);
                    primaryStage.setTitle("Capturing Screenshots...");
                    primaryStage.show();

                    // Sequence of screenshot captures
                    new Thread(() -> {
                        try {
                            Thread.sleep(1200);

                            // 1. Home Screen
                            capture(layout, "01_home_screen.png");

                            // 2. Lesson Detail Screen
                            Platform.runLater(() -> {
                                Lesson l = LessonService.getInstance().getLesson(5, 1); // WhatsApp Video Call
                                if (l != null) layout.launchLesson(l);
                            });
                            Thread.sleep(800);
                            capture(layout, "02_lesson_viewer.png");

                            // 3. Quiz Interface
                            Platform.runLater(() -> {
                                Lesson l = LessonService.getInstance().getLesson(5, 1);
                                if (l != null) layout.launchQuiz(l);
                            });
                            Thread.sleep(800);
                            capture(layout, "03_quiz_interface.png");

                            // 4. Safe Practice Mode (WhatsApp Simulation)
                            Platform.runLater(() -> layout.navigateTo("practice"));
                            Thread.sleep(800);
                            capture(layout, "04_practice_whatsapp.png");

                            // 5. Practice UPI Simulation
                            Platform.runLater(() -> layout.launchPractice("UPI"));
                            Thread.sleep(800);
                            capture(layout, "05_practice_upi.png");

                            // 6. Practice Maps Simulation
                            Platform.runLater(() -> layout.launchPractice("MAPS"));
                            Thread.sleep(800);
                            capture(layout, "06_practice_maps.png");

                            // 7. Safety Center & Scam Checker
                            Platform.runLater(() -> layout.navigateTo("safety"));
                            Thread.sleep(800);
                            capture(layout, "07_safety_checker.png");

                            // 8. Progress Dashboard
                            Platform.runLater(() -> layout.navigateTo("progress"));
                            Thread.sleep(800);
                            capture(layout, "08_progress_dashboard.png");

                            // 9. Achievements Badges
                            Platform.runLater(() -> layout.navigateTo("achievements"));
                            Thread.sleep(800);
                            capture(layout, "09_achievements_milestones.png");

                            // 10. Family Caregiver Mode
                            Platform.runLater(() -> layout.navigateTo("family"));
                            Thread.sleep(800);
                            capture(layout, "10_family_helper_mode.png");

                            // 11. Emergency Help Screen
                            Platform.runLater(() -> layout.navigateTo("emergency"));
                            Thread.sleep(800);
                            capture(layout, "11_emergency_assistance.png");

                            // 12. Settings & Accessibility
                            Platform.runLater(() -> layout.navigateTo("settings"));
                            Thread.sleep(800);
                            capture(layout, "12_accessibility_settings.png");

                            // 13. Practice Aadhaar / DigiLocker
                            Platform.runLater(() -> layout.launchPractice("AADHAAR"));
                            Thread.sleep(800);
                            capture(layout, "13_practice_aadhaar.png");

                            // 14. Practice Online Bill Payment
                            Platform.runLater(() -> layout.launchPractice("BILL"));
                            Thread.sleep(800);
                            capture(layout, "14_practice_bill.png");

                            // 15. Scam Spotter Mini-Game
                            Platform.runLater(() -> layout.navigateTo("scamspotter"));
                            Thread.sleep(800);
                            capture(layout, "15_scam_spotter_game.png");

                            System.out.println("ALL SCREENSHOTS SUCCESSFULLY CAPTURED!");
                            Platform.runLater(primaryStage::close);
                            System.exit(0);

                        } catch (Exception e) {
                            e.printStackTrace();
                            System.exit(1);
                        }
                    }).start();
                });

            } catch (Exception e) {
                e.printStackTrace();
                System.exit(1);
            }
        }).start();
    }

    private void capture(MainLayout layout, String filename) {
        CountDownLatch latch = new CountDownLatch(1);
        Platform.runLater(() -> {
            try {
                SnapshotParameters params = new SnapshotParameters();
                params.setFill(Color.web("#F3EDE2"));
                WritableImage img = layout.snapshot(params, null);

                int w = (int) img.getWidth();
                int h = (int) img.getHeight();
                BufferedImage bImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
                PixelReader pr = img.getPixelReader();

                for (int y = 0; y < h; y++) {
                    for (int x = 0; x < w; x++) {
                        bImg.setRGB(x, y, pr.getArgb(x, y));
                    }
                }

                File out = new File("screenshots/" + filename);
                ImageIO.write(bImg, "png", out);
                System.out.println("Captured: " + out.getAbsolutePath() + " (" + w + "x" + h + ")");
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                latch.countDown();
            }
        });

        try {
            latch.await();
        } catch (InterruptedException ignored) {}
    }

    public static void main(String[] args) {
        launch(args);
    }
}
