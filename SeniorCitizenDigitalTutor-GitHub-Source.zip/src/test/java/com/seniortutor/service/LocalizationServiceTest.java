package com.seniortutor.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class LocalizationServiceTest {

    private LocalizationService loc;

    @BeforeEach
    public void setup() {
        loc = LocalizationService.getInstance();
        loc.setLanguage("en");
    }

    @Test
    @DisplayName("Default language is initialized and resolves common navigation keys")
    public void testEnglishDefaultStrings() {
        assertEquals("en", loc.getLanguage());
        assertEquals("Home", loc.getString("nav.home"));
        assertEquals("Learn", loc.getString("nav.learn"));
        assertEquals("Stay Safe", loc.getString("nav.safety"));
    }

    @Test
    @DisplayName("Switching to Hindi updates string lookups")
    public void testHindiTranslationLookup() {
        loc.setLanguage("hi");
        assertEquals("hi", loc.getLanguage());
        assertEquals("मुख्य पृष्ठ", loc.getString("nav.home"));
        assertEquals("सुरक्षा", loc.getString("nav.safety"));
        assertTrue(loc.getString("home.greeting").contains("नमस्ते"));
    }

    @Test
    @DisplayName("Switching to Marathi updates string lookups")
    public void testMarathiTranslationLookup() {
        loc.setLanguage("mr");
        assertEquals("mr", loc.getLanguage());
        assertEquals("मुख्य पान", loc.getString("nav.home"));
        assertEquals("सुरक्षित राहा", loc.getString("nav.safety"));
        assertTrue(loc.getString("home.greeting").contains("शुभ प्रभात"));
    }

    @Test
    @DisplayName("Fallback behavior returns key when translation is missing")
    public void testMissingKeyFallback() {
        String missing = loc.getString("completely.nonexistent.key.xyz");
        assertEquals("completely.nonexistent.key.xyz", missing);
    }

    @Test
    @DisplayName("Formatted parameter strings resolve correctly")
    public void testParameterizedStringResolution() {
        loc.setLanguage("en");
        String formatted = loc.getString("learn.lessons_count", 3, 5, 60);
        assertEquals("3 of 5 lessons (60%)", formatted);
    }
}
