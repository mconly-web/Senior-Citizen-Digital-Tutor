package com.seniortutor.service;

import com.seniortutor.database.DatabaseManager;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

public class BackupServiceTest {

    @BeforeAll
    public static void setup() {
        DatabaseManager.getInstance();
    }

    @Test
    @DisplayName("Exports and restores user progress backup JSON file successfully")
    public void testExportAndRestoreBackup(@TempDir Path tempDir) {
        BackupService backupService = BackupService.getInstance();
        int testUserId = 1;

        File backupFile = tempDir.resolve("seniortutor_backup_test.json").toFile();

        // 1. Export
        boolean exported = backupService.exportBackup(testUserId, backupFile);
        assertTrue(exported, "Backup export should succeed");
        assertTrue(backupFile.exists(), "Backup file should exist on disk");
        assertTrue(backupFile.length() > 0, "Backup file should not be empty");

        // 2. Restore
        boolean restored = backupService.restoreBackup(testUserId, backupFile);
        assertTrue(restored, "Backup restore should succeed");
    }

    @Test
    @DisplayName("Fails gracefully when restoring from null or nonexistent file")
    public void testRestoreInvalidFile() {
        BackupService backupService = BackupService.getInstance();
        assertFalse(backupService.restoreBackup(1, null));
        assertFalse(backupService.restoreBackup(1, new File("nonexistent_backup_file_xyz.json")));
    }
}
