package com.seniortutor.service;

import com.seniortutor.database.DatabaseManager;
import com.seniortutor.model.Lesson;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class SearchServiceTest {

    @BeforeAll
    public static void setup() {
        DatabaseManager.getInstance();
    }

    @Test
    @DisplayName("Searches lessons by exact English keyword")
    public void testExactSearch() {
        SearchService search = SearchService.getInstance();
        List<Lesson> results = search.search("video call", 1);
        assertNotNull(results);
        assertFalse(results.isEmpty());
        assertTrue(results.stream().anyMatch(l -> l.getTitle().toLowerCase().contains("video call") ||
                                                  l.getDescription().toLowerCase().contains("video call")));
    }

    @Test
    @DisplayName("Tolerates common senior typos via fuzzy matching")
    public void testTypoTolerantSearch() {
        SearchService search = SearchService.getInstance();
        // User mistypes "whatapp" instead of "WhatsApp"
        List<Lesson> results = search.search("whatapp", 1);
        assertNotNull(results);
        assertFalse(results.isEmpty(), "Fuzzy search should find WhatsApp lessons despite typo");
    }

    @Test
    @DisplayName("Supports multilingual search queries in Hindi and Marathi")
    public void testMultilingualSearch() {
        SearchService search = SearchService.getInstance();
        List<Lesson> resultsHindi = search.search("वीडियो कॉल", 1);
        assertNotNull(resultsHindi);
        assertFalse(resultsHindi.isEmpty(), "Search should find lessons matching Hindi keywords");

        List<Lesson> resultsMarathi = search.search("कॉल", 1);
        assertNotNull(resultsMarathi);
        assertFalse(resultsMarathi.isEmpty(), "Search should find lessons matching Marathi keywords");
    }

    @Test
    @DisplayName("Safely handles blank or null queries without exceptions")
    public void testEmptyQuerySafety() {
        SearchService search = SearchService.getInstance();
        assertTrue(search.search("", 1).isEmpty());
        assertTrue(search.search("   ", 1).isEmpty());
        assertTrue(search.search(null, 1).isEmpty());
    }
}
