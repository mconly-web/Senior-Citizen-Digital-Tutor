package com.seniortutor.service;

import com.seniortutor.database.DatabaseManager;
import com.seniortutor.model.SafetyCheckResult;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class SafetyCheckerServiceTest {

    @BeforeAll
    public static void setup() {
        DatabaseManager.getInstance();
    }

    @Test
    @DisplayName("Detects critical OTP fraud attempts with high risk score")
    public void testOtpFraudDetection() {
        SafetyCheckerService service = SafetyCheckerService.getInstance();
        String message = "Dear SBI user, please share the 6-digit OTP sent to your phone to unblock your card.";
        SafetyCheckResult result = service.analyzeMessage(message, 1, "en");

        assertEquals(SafetyCheckResult.RiskLevel.HIGH_RISK, result.getRiskLevel());
        assertTrue(result.getScore() >= 50);
        assertFalse(result.getDetectedFlags().isEmpty());
        assertFalse(result.getRiskExplanations().isEmpty());
    }

    @Test
    @DisplayName("Detects electricity cut threat scams with urgent phone numbers")
    public void testElectricityThreatScam() {
        SafetyCheckerService service = SafetyCheckerService.getInstance();
        String msg = "Electricity power will be disconnected tonight at 9:30 PM due to unpaid bill. Call officer on 9876543210 immediately.";
        SafetyCheckResult result = service.analyzeMessage(msg, 1, "en");

        assertEquals(SafetyCheckResult.RiskLevel.HIGH_RISK, result.getRiskLevel());
        assertTrue(result.getScore() >= 40);
        assertTrue(result.getDetectedFlags().stream().anyMatch(f -> f.contains("Electricity") || f.contains("Power")));
    }

    @Test
    @DisplayName("Detects Digital Arrest and fake customs threats")
    public void testDigitalArrestScam() {
        SafetyCheckerService service = SafetyCheckerService.getInstance();
        String msg = "Delhi Cyber Crime Police: You are placed under digital arrest for illegal FedEx parcel containing expired passports. Connect on Skype.";
        SafetyCheckResult result = service.analyzeMessage(msg, 1, "en");

        assertEquals(SafetyCheckResult.RiskLevel.HIGH_RISK, result.getRiskLevel());
        assertTrue(result.getDetectedFlags().stream().anyMatch(f -> f.contains("Digital Arrest") || f.contains("Arrest")));
    }

    @Test
    @DisplayName("Detects QR code receive money trick")
    public void testQrCodeReceiveMoneyTrick() {
        SafetyCheckerService service = SafetyCheckerService.getInstance();
        String msg = "To receive payment of ₹5,000 for your old sofa, please scan this QR code and enter your UPI PIN.";
        SafetyCheckResult result = service.analyzeMessage(msg, 1, "en");

        assertEquals(SafetyCheckResult.RiskLevel.HIGH_RISK, result.getRiskLevel());
        assertTrue(result.getDetectedFlags().stream().anyMatch(f -> f.contains("QR Code")));
    }

    @Test
    @DisplayName("Confirms safe friendly family messages as safe")
    public void testSafeFamilyMessage() {
        SafetyCheckerService service = SafetyCheckerService.getInstance();
        String msg = "Hi Mom, I am reaching home at 7 PM for dinner. Please keep hot tea ready!";
        SafetyCheckResult result = service.analyzeMessage(msg, 1, "en");

        assertEquals(SafetyCheckResult.RiskLevel.APPEARS_SAFE, result.getRiskLevel());
        assertEquals(0, result.getScore());
    }

    @Test
    @DisplayName("Provides localized Hindi advice when language is 'hi'")
    public void testHindiLocalizedSafetyAdvice() {
        SafetyCheckerService service = SafetyCheckerService.getInstance();
        String msg = "अपना 6 अंकों का ओटीपी तुरंत बताएं नहीं तो बैंक खाता बंद हो जाएगा।";
        SafetyCheckResult result = service.analyzeMessage(msg, 1, "hi");

        assertEquals(SafetyCheckResult.RiskLevel.HIGH_RISK, result.getRiskLevel());
        assertTrue(result.getRiskLevel().getLocalizedDisplayName("hi").contains("खतरा") ||
                   result.getRiskLevel().getLocalizedDisplayName("hi").contains("सावधान"));
    }
}
