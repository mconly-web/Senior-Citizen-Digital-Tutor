package com.seniortutor.service;

import com.seniortutor.database.DatabaseManager;
import com.seniortutor.repository.ProgressRepository;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ProgressServiceTest {

    @BeforeAll
    public static void setup() {
        DatabaseManager.getInstance();
    }

    @Test
    @DisplayName("Total lessons count is at least 40 lessons")
    public void testTotalLessonCount() {
        ProgressService service = ProgressService.getInstance();
        int total = service.getTotalCount();
        assertTrue(total >= 40, "Total curriculum lessons should be at least 40, found: " + total);
    }

    @Test
    @DisplayName("Updates lesson progress step and marks completion")
    public void testProgressTracking() {
        ProgressService service = ProgressService.getInstance();
        int testUserId = 1;

        service.updateStep(testUserId, 1, 2);
        service.completeLesson(testUserId, 1);

        int completed = service.getCompletedCount(testUserId);
        assertTrue(completed >= 1, "Completed count should be at least 1");
    }

    @Test
    @DisplayName("Calculates weekly progress and streak correctly")
    public void testWeeklyAndStreakCalculations() {
        ProgressService service = ProgressService.getInstance();
        int testUserId = 1;

        int weekly = service.getWeeklyCompletedCount(testUserId);
        assertTrue(weekly >= 0);

        int streak = service.getUserStreak(testUserId);
        assertTrue(streak >= 1, "User streak should default to at least 1 day");
    }

    @Test
    @DisplayName("Records quiz score and computes average quiz score")
    public void testQuizScoreRecording() {
        ProgressRepository repo = new ProgressRepository();
        int testUserId = 1;

        repo.recordQuizResult(testUserId, 1, 100, true);

        ProgressService service = ProgressService.getInstance();
        double avg = service.getAverageQuizScore(testUserId);
        assertTrue(avg > 0.0, "Average quiz score should be positive");
    }
}
