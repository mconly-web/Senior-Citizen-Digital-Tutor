package com.seniortutor;

public class ScreenshotRunner {
    public static void main(String[] args) {
        ScreenshotGenerator.main(args);
    }
}
