package com.seniortutor.simulation;

import com.seniortutor.service.ProgressService;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.animation.PauseTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.util.Duration;

/**
 * Interactive e-Aadhaar and DigiLocker download practice simulation.
 * Teaches seniors how to safely request an OTP, verify credentials, and open
 * password-protected government PDFs without real-world identity risks.
 */
public class AadhaarDigiLockerSimulationView extends VBox {

    private final StackPane workflowContainer = new StackPane();
    private String selectedDocType = "e-Aadhaar Card";
    private final String demoOtp = "482910";

    public AadhaarDigiLockerSimulationView() {
        setSpacing(0);
        setStyle("-fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");
        setFillWidth(true);

        // 1. Safety Banner
        getChildren().add(createSafetyBanner());

        // 2. Start at Step 1: Document Selection
        showSelectDocScreen();

        VBox.setVgrow(workflowContainer, Priority.ALWAYS);
        getChildren().add(workflowContainer);
    }

    private VBox createSafetyBanner() {
        VBox banner = new VBox(4);
        banner.setAlignment(Pos.CENTER);
        banner.setStyle(
            "-fx-background-color: #FEF3C7;" +
            "-fx-border-color: #FCD34D;" +
            "-fx-border-width: 0 0 2px 0;" +
            "-fx-padding: 10px 24px;"
        );

        Label title = new Label("🛡️ SAFE PRACTICE SIMULATION • NO REAL AADHAAR DATA IS STORED OR SENT");
        title.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #92400E;");

        Label warning = new Label("💡 Golden Security Rule: Only enter your Aadhaar on official government websites ending with '.gov.in' or '.nic.in'.");
        warning.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: #B45309;");

        banner.getChildren().addAll(title, warning);
        return banner;
    }

    private void showSelectDocScreen() {
        workflowContainer.getChildren().clear();

        VBox card = UiUtils.createCard();
        card.setMaxWidth(720);
        card.setAlignment(Pos.CENTER);
        card.setSpacing(20);
        card.setPadding(new Insets(28));

        Label heading = UiUtils.createTitle("Step 1: Choose Document from DigiLocker / UIDAI");
        Label desc = UiUtils.createSubtitle("DigiLocker is the Indian Government's secure digital wallet for official certificates.");

        ToggleGroup group = new ToggleGroup();

        VBox optionsBox = new VBox(12);
        optionsBox.setMaxWidth(580);

        RadioButton r1 = createDocOption("🪪 e-Aadhaar Card (UIDAI Digital Identity)", "e-Aadhaar Card", group, true);
        RadioButton r2 = createDocOption("💉 COVID-19 Vaccine Certificate (CoWIN / MoHFW)", "COVID-19 Vaccine Certificate", group, false);
        RadioButton r3 = createDocOption("🚗 Motor Driving License (MoRTH)", "Motor Driving License", group, false);
        RadioButton r4 = createDocOption("📜 Permanent Account Number (PAN Verification)", "PAN Verification Record", group, false);

        optionsBox.getChildren().addAll(r1, r2, r3, r4);

        Button nextBtn = UiUtils.createPrimaryButton("Proceed to Verification →", "");
        nextBtn.setStyle(nextBtn.getStyle() + "-fx-font-size: 17px; -fx-padding: 12px 32px;");
        nextBtn.setOnAction(e -> {
            RadioButton selected = (RadioButton) group.getSelectedToggle();
            if (selected != null && selected.getUserData() != null) {
                this.selectedDocType = selected.getUserData().toString();
            }
            SoundUtil.playClick();
            showAadhaarInputScreen();
        });

        card.getChildren().addAll(heading, desc, optionsBox, nextBtn);
        workflowContainer.getChildren().add(card);
    }

    private RadioButton createDocOption(String label, String data, ToggleGroup group, boolean selected) {
        RadioButton rb = new RadioButton(label);
        rb.setToggleGroup(group);
        rb.setUserData(data);
        rb.setSelected(selected);
        rb.setStyle(
            "-fx-font-size: 16px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";" +
            "-fx-padding: 10px 16px;" +
            "-fx-background-color: white;" +
            "-fx-background-radius: 10px;" +
            "-fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + ";" +
            "-fx-border-radius: 10px;" +
            "-fx-cursor: hand;"
        );
        rb.setMaxWidth(Double.MAX_VALUE);
        return rb;
    }

    private void showAadhaarInputScreen() {
        workflowContainer.getChildren().clear();

        VBox card = UiUtils.createCard();
        card.setMaxWidth(720);
        card.setAlignment(Pos.CENTER);
        card.setSpacing(18);
        card.setPadding(new Insets(28));

        Label heading = UiUtils.createTitle("Step 2: Enter Aadhaar Number & Captcha");
        Label desc = UiUtils.createSubtitle("Downloading: " + selectedDocType);

        VBox form = new VBox(14);
        form.setMaxWidth(500);

        Label aadhaarLbl = new Label("12-Digit Aadhaar Number:");
        aadhaarLbl.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        TextField aadhaarField = new TextField();
        aadhaarField.setPromptText("e.g. 5489 2145 9012");
        aadhaarField.setStyle(
            "-fx-font-size: 17px;" +
            "-fx-padding: 10px 14px;" +
            "-fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + ";" +
            "-fx-border-radius: 8px;" +
            "-fx-background-radius: 8px;"
        );

        Button fillDemoBtn = new Button("💡 Fill Demo Aadhaar Number");
        fillDemoBtn.setStyle(
            "-fx-background-color: #F1F5F9;" +
            "-fx-text-fill: #334155;" +
            "-fx-font-size: 13px;" +
            "-fx-font-weight: bold;" +
            "-fx-cursor: hand;" +
            "-fx-padding: 6px 12px;" +
            "-fx-background-radius: 6px;"
        );
        fillDemoBtn.setOnAction(e -> {
            SoundUtil.playClick();
            aadhaarField.setText("5489 2145 9012");
        });

        // Captcha Box
        Label captchaLbl = new Label("Security Captcha Code:");
        captchaLbl.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        HBox captchaRow = new HBox(12);
        captchaRow.setAlignment(Pos.CENTER_LEFT);

        Label captchaCode = new Label("7  K  2  M");
        captchaCode.setStyle(
            "-fx-background-color: #E2E8F0;" +
            "-fx-font-size: 18px;" +
            "-fx-font-weight: bold;" +
            "-fx-font-family: monospace;" +
            "-fx-text-fill: #1E293B;" +
            "-fx-padding: 10px 18px;" +
            "-fx-border-color: #94A3B8;" +
            "-fx-border-radius: 8px;" +
            "-fx-background-radius: 8px;"
        );

        TextField captchaInput = new TextField();
        captchaInput.setPromptText("Type letters here");
        captchaInput.setStyle(aadhaarField.getStyle());
        captchaInput.setText("7K2M");
        HBox.setHgrow(captchaInput, Priority.ALWAYS);

        captchaRow.getChildren().addAll(captchaCode, captchaInput);

        form.getChildren().addAll(aadhaarLbl, aadhaarField, fillDemoBtn, captchaLbl, captchaRow);

        HBox btnRow = new HBox(14);
        btnRow.setAlignment(Pos.CENTER);

        Button backBtn = UiUtils.createSecondaryButton("← Back", "");
        backBtn.setOnAction(e -> showSelectDocScreen());

        Button sendOtpBtn = UiUtils.createPrimaryButton("Send OTP to Registered Mobile →", "📩");
        sendOtpBtn.setStyle(sendOtpBtn.getStyle() + "-fx-font-size: 16px; -fx-padding: 12px 28px;");
        sendOtpBtn.setOnAction(e -> {
            String text = aadhaarField.getText().trim();
            if (text.isEmpty()) {
                UiUtils.showInfoDialog("Missing Details", "Please enter an Aadhaar number or tap 'Fill Demo Aadhaar Number'.", "");
                return;
            }
            SoundUtil.playClick();
            showOtpScreen();
        });

        btnRow.getChildren().addAll(backBtn, sendOtpBtn);

        card.getChildren().addAll(heading, desc, form, btnRow);
        workflowContainer.getChildren().add(card);
    }

    private void showOtpScreen() {
        workflowContainer.getChildren().clear();

        VBox card = UiUtils.createCard();
        card.setMaxWidth(680);
        card.setAlignment(Pos.CENTER);
        card.setSpacing(18);
        card.setPadding(new Insets(28));

        Label heading = UiUtils.createTitle("Step 3: Enter Verification OTP");
        Label desc = UiUtils.createSubtitle("A 6-digit OTP was sent to your registered mobile ending with •••• 9012.");

        // Simulated SMS banner
        VBox smsBubble = new VBox(4);
        smsBubble.setStyle(
            "-fx-background-color: #EFF6FF;" +
            "-fx-border-color: #BFDBFE;" +
            "-fx-border-radius: 10px;" +
            "-fx-background-radius: 10px;" +
            "-fx-padding: 12px 18px;"
        );
        smsBubble.setMaxWidth(480);

        Label smsSender = new Label("📩 Incoming SMS from 'VK-UIDAI':");
        smsSender.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-text-fill: #1E40AF;");

        Label smsText = new Label("Your Aadhaar OTP for downloading " + selectedDocType + " is " + demoOtp + ". Do NOT share this OTP with anyone calling you.");
        smsText.setWrapText(true);
        smsText.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #1E3A8A;");

        smsBubble.getChildren().addAll(smsSender, smsText);

        VBox form = new VBox(12);
        form.setMaxWidth(480);
        form.setAlignment(Pos.CENTER);

        TextField otpInput = new TextField();
        otpInput.setPromptText("Enter 6-digit OTP");
        otpInput.setAlignment(Pos.CENTER);
        otpInput.setStyle(
            "-fx-font-size: 24px;" +
            "-fx-font-weight: bold;" +
            "-fx-letter-spacing: 6px;" +
            "-fx-padding: 10px 14px;" +
            "-fx-border-color: " + UiUtils.COLOR_FOREST_GREEN + ";" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 8px;" +
            "-fx-background-radius: 8px;"
        );

        Button autoFillBtn = new Button("💡 Auto-Fill Demo OTP (" + demoOtp + ")");
        autoFillBtn.setStyle(
            "-fx-background-color: #ECFDF5;" +
            "-fx-text-fill: #065F46;" +
            "-fx-border-color: #A7F3D0;" +
            "-fx-font-size: 14px;" +
            "-fx-font-weight: bold;" +
            "-fx-cursor: hand;" +
            "-fx-padding: 8px 16px;" +
            "-fx-background-radius: 8px;" +
            "-fx-border-radius: 8px;"
        );
        autoFillBtn.setOnAction(e -> {
            SoundUtil.playClick();
            otpInput.setText(demoOtp);
        });

        form.getChildren().addAll(otpInput, autoFillBtn);

        HBox btnRow = new HBox(14);
        btnRow.setAlignment(Pos.CENTER);

        Button backBtn = UiUtils.createSecondaryButton("← Back", "");
        backBtn.setOnAction(e -> showAadhaarInputScreen());

        Button verifyBtn = UiUtils.createPrimaryButton("Verify & Download Document", "📥");
        verifyBtn.setStyle(verifyBtn.getStyle() + "-fx-font-size: 17px; -fx-padding: 12px 30px;");
        verifyBtn.setOnAction(e -> {
            String entered = otpInput.getText().trim();
            if (!entered.equals(demoOtp)) {
                SoundUtil.playClick();
                UiUtils.showErrorDialog("Incorrect OTP", "The OTP entered does not match.", "Please type " + demoOtp + " or tap 'Auto-Fill Demo OTP'.");
                return;
            }
            SoundUtil.playSuccess();
            showSuccessDocumentScreen();
        });

        btnRow.getChildren().addAll(backBtn, verifyBtn);

        card.getChildren().addAll(heading, desc, smsBubble, form, btnRow);
        workflowContainer.getChildren().add(card);
    }

    private void showSuccessDocumentScreen() {
        workflowContainer.getChildren().clear();

        int userId = AppConfig.getInstance().getCurrentUser().getId();
        ProgressService.getInstance().unlockAchievementDirect(userId, "FIRST_PRACTICE");

        VBox card = UiUtils.createCard();
        card.setMaxWidth(760);
        card.setAlignment(Pos.CENTER);
        card.setSpacing(18);
        card.setPadding(new Insets(24));

        Label successBadge = new Label("✅ DOCUMENT DOWNLOADED SUCCESSFULLY");
        successBadge.setStyle(
            "-fx-background-color: #DCFCE7;" +
            "-fx-text-fill: #166534;" +
            "-fx-font-size: 18px;" +
            "-fx-font-weight: bold;" +
            "-fx-padding: 8px 20px;" +
            "-fx-background-radius: 12px;"
        );

        // Simulated DigiLocker Official Document Preview Card
        VBox docCard = new VBox(12);
        docCard.setMaxWidth(620);
        docCard.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #0369A1;" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 14px;" +
            "-fx-background-radius: 14px;" +
            "-fx-padding: 20px;"
        );

        HBox docTop = new HBox(12);
        docTop.setAlignment(Pos.CENTER_LEFT);
        Label govEmblem = new Label("🏛️");
        govEmblem.setStyle("-fx-font-size: 32px;");

        VBox govTitle = new VBox(2);
        Label gov1 = new Label("भारत सरकार • GOVERNMENT OF INDIA");
        gov1.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-text-fill: #334155;");
        Label gov2 = new Label("भारतीय विशिष्ट पहचान प्राधिकरण • UIDAI");
        gov2.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #0369A1;");
        govTitle.getChildren().addAll(gov1, gov2);

        Label digiTag = new Label("DigiLocker Verified ✔");
        digiTag.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-text-fill: #15803D; -fx-background-color: #F0FDF4; -fx-padding: 4px 8px; -fx-background-radius: 6px;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        docTop.getChildren().addAll(govEmblem, govTitle, spacer, digiTag);

        Separator sep = new Separator();

        // Details Row
        HBox detailsRow = new HBox(20);
        detailsRow.setAlignment(Pos.CENTER_LEFT);

        Label photoBox = new Label("👤\n[Photo]");
        photoBox.setAlignment(Pos.CENTER);
        photoBox.setStyle(
            "-fx-background-color: #F1F5F9;" +
            "-fx-border-color: #CBD5E1;" +
            "-fx-border-radius: 8px;" +
            "-fx-background-radius: 8px;" +
            "-fx-padding: 16px 20px;" +
            "-fx-font-size: 16px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-alignment: center;"
        );

        VBox personDetails = new VBox(6);
        Label nameLbl = new Label("Name: Rameshwar Sharma (रामेश्वर शर्मा)");
        nameLbl.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #0F172A;");

        Label dobLbl = new Label("DOB / जन्म तारीख: 15/08/1952   •   Gender: Male");
        dobLbl.setStyle("-fx-font-size: 14px; -fx-text-fill: #334155;");

        Label numLbl = new Label("Aadhaar Number: XXXX XXXX 9012");
        numLbl.setStyle("-fx-font-size: 17px; -fx-font-weight: bold; -fx-text-fill: #B91C1C;");

        Label addrLbl = new Label("Address: Flat 402, Shanti Kunj, Pune, Maharashtra - 411038");
        addrLbl.setWrapText(true);
        addrLbl.setStyle("-fx-font-size: 13px; -fx-text-fill: #64748B;");

        personDetails.getChildren().addAll(nameLbl, dobLbl, numLbl, addrLbl);
        detailsRow.getChildren().addAll(photoBox, personDetails);

        docCard.getChildren().addAll(docTop, sep, detailsRow);

        // Essential Senior Tip Card regarding PDF password
        VBox passwordTipBox = new VBox(6);
        passwordTipBox.setStyle(
            "-fx-background-color: #FEF3C7;" +
            "-fx-border-color: #FDE68A;" +
            "-fx-border-radius: 10px;" +
            "-fx-background-radius: 10px;" +
            "-fx-padding: 12px 18px;"
        );
        passwordTipBox.setMaxWidth(620);

        Label tipTitle = new Label("🔑 Golden Knowledge: e-Aadhaar PDF Password Format");
        tipTitle.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #92400E;");

        Label tipBody = new Label("Every official e-Aadhaar PDF is protected by an 8-character password:\n" +
            "• First 4 letters of your name in CAPITAL letters\n" +
            "• Followed by your 4-digit Year of Birth\n" +
            "Example: For Rameshwar Sharma born in 1952, the password is: RAME1952");
        tipBody.setStyle("-fx-font-size: 13px; -fx-text-fill: #78350F;");

        passwordTipBox.getChildren().addAll(tipTitle, tipBody);

        // Action Buttons
        HBox actionsRow = new HBox(16);
        actionsRow.setAlignment(Pos.CENTER);

        Button openPdfBtn = UiUtils.createPrimaryButton("Open Simulated PDF Viewer", "📄");
        openPdfBtn.setOnAction(e -> {
            SoundUtil.playSuccess();
            UiUtils.showInfoDialog("Simulated Document Preview", "e-Aadhaar PDF: Rameshwar_Aadhaar.pdf", "Password Verified (RAME1952).\nDocument is legally valid under the IT Act 2000 for all Indian government services.");
        });

        Button restartBtn = UiUtils.createSecondaryButton("Practice Another Document 🔁", "");
        restartBtn.setOnAction(e -> {
            SoundUtil.playClick();
            showSelectDocScreen();
        });

        actionsRow.getChildren().addAll(openPdfBtn, restartBtn);

        card.getChildren().addAll(successBadge, docCard, passwordTipBox, actionsRow);
        workflowContainer.getChildren().add(card);
    }
}
