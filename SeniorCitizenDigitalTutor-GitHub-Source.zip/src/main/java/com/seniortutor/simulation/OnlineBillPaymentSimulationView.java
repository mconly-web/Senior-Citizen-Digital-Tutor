package com.seniortutor.simulation;

import com.seniortutor.service.ProgressService;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Interactive Safe Online Bill Payment simulation.
 * Teaches seniors how to fetch utility bills (electricity, mobile recharge)
 * and pay them securely via simulated UPI without fear of financial loss.
 */
public class OnlineBillPaymentSimulationView extends VBox {

    private final StackPane workflowContainer = new StackPane();
    private String selectedCategory = "ELECTRICITY";
    private String selectedProvider = "Mahavitaran (MSEDCL) - Maharashtra";
    private String enteredAccount = "028491829012";
    private final int billAmount = 840;

    public OnlineBillPaymentSimulationView() {
        setSpacing(0);
        setStyle("-fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");
        setFillWidth(true);

        // 1. Safety Banner
        getChildren().add(createSafetyBanner());

        // 2. Start at Step 1: Select Category & Provider
        showCategorySelectionScreen();

        VBox.setVgrow(workflowContainer, Priority.ALWAYS);
        getChildren().add(workflowContainer);
    }

    private VBox createSafetyBanner() {
        VBox banner = new VBox(4);
        banner.setAlignment(Pos.CENTER);
        banner.setStyle(
            "-fx-background-color: #FEF3C7;" +
            "-fx-border-color: #FCD34D;" +
            "-fx-border-width: 0 0 2px 0;" +
            "-fx-padding: 10px 24px;"
        );

        Label title = new Label("🛡️ SAFE BILL PAYMENT SANDBOX • ZERO REAL MONEY USED • PRACTICE FREELY");
        title.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #92400E;");

        Label warning = new Label("⚡ Security Rule: Real utility providers give you 15+ days to pay. Urgent 1-hour SMS threats are scams!");
        warning.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: #B45309;");

        banner.getChildren().addAll(title, warning);
        return banner;
    }

    private void showCategorySelectionScreen() {
        workflowContainer.getChildren().clear();

        VBox card = UiUtils.createCard();
        card.setMaxWidth(720);
        card.setAlignment(Pos.CENTER);
        card.setSpacing(20);
        card.setPadding(new Insets(28));

        Label heading = UiUtils.createTitle("Step 1: Select Utility Bill to Pay");
        Label desc = UiUtils.createSubtitle("Practice paying electricity, water, gas, or recharging your mobile safely.");

        HBox catRow = new HBox(20);
        catRow.setAlignment(Pos.CENTER);

        VBox elecCard = createCategoryBox("⚡", "Electricity Bill", "State & Private Power Boards", "ELECTRICITY");
        VBox mobCard = createCategoryBox("📱", "Mobile Recharge", "Prepaid & Postpaid Plans", "MOBILE");

        catRow.getChildren().addAll(elecCard, mobCard);

        card.getChildren().addAll(heading, desc, catRow);
        workflowContainer.getChildren().add(card);
    }

    private VBox createCategoryBox(String icon, String title, String sub, String mode) {
        VBox box = new VBox(8);
        box.setAlignment(Pos.CENTER);
        box.setPrefSize(260, 160);
        box.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + ";" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 14px;" +
            "-fx-background-radius: 14px;" +
            "-fx-padding: 20px;" +
            "-fx-cursor: hand;"
        );

        Label iconLbl = new Label(icon);
        iconLbl.setStyle("-fx-font-size: 36px;");

        Label titleLbl = new Label(title);
        titleLbl.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        Label subLbl = new Label(sub);
        subLbl.setStyle("-fx-font-size: 13px; -fx-text-fill: #64748B;");

        box.getChildren().addAll(iconLbl, titleLbl, subLbl);

        box.setOnMouseClicked(e -> {
            SoundUtil.playClick();
            this.selectedCategory = mode;
            showDetailsInputScreen();
        });

        return box;
    }

    private void showDetailsInputScreen() {
        workflowContainer.getChildren().clear();

        VBox card = UiUtils.createCard();
        card.setMaxWidth(720);
        card.setAlignment(Pos.CENTER);
        card.setSpacing(18);
        card.setPadding(new Insets(28));

        boolean isElec = "ELECTRICITY".equals(selectedCategory);
        Label heading = UiUtils.createTitle(isElec ? "Step 2: Enter Electricity Consumer Details" : "Step 2: Enter Mobile Recharge Details");
        Label desc = UiUtils.createSubtitle("Choose your provider and enter your account number.");

        VBox form = new VBox(14);
        form.setMaxWidth(520);

        Label provLbl = new Label(isElec ? "Electricity Board / Provider:" : "Telecom Operator:");
        provLbl.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        ComboBox<String> providerCombo = new ComboBox<>();
        if (isElec) {
            providerCombo.getItems().addAll(
                "Mahavitaran (MSEDCL) - Maharashtra",
                "Tata Power - Mumbai / Delhi",
                "BSES Rajdhani Power - Delhi",
                "UPPCL (Urban / Rural) - Uttar Pradesh",
                "BESCOM - Bengaluru Karnataka"
            );
        } else {
            providerCombo.getItems().addAll(
                "Reliance Jio Prepaid",
                "Bharti Airtel",
                "Vodafone Idea (Vi)",
                "BSNL Mobile"
            );
        }
        providerCombo.setValue(providerCombo.getItems().get(0));
        providerCombo.setMaxWidth(Double.MAX_VALUE);
        providerCombo.setStyle("-fx-font-size: 15px; -fx-padding: 8px;");

        Label accLbl = new Label(isElec ? "Consumer Number (found on paper bill):" : "10-Digit Mobile Number:");
        accLbl.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        TextField accField = new TextField();
        accField.setPromptText(isElec ? "e.g. 028491829012" : "e.g. 98765 43210");
        accField.setStyle("-fx-font-size: 16px; -fx-padding: 10px 14px; -fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + "; -fx-border-radius: 8px; -fx-background-radius: 8px;");

        Button fillSampleBtn = new Button(isElec ? "💡 Fill Sample Consumer # (028491829012)" : "💡 Fill Sample Phone (98765 43210)");
        fillSampleBtn.setStyle("-fx-background-color: #F1F5F9; -fx-text-fill: #334155; -fx-font-size: 13px; -fx-font-weight: bold; -fx-cursor: hand; -fx-padding: 6px 12px; -fx-background-radius: 6px;");
        fillSampleBtn.setOnAction(e -> {
            SoundUtil.playClick();
            accField.setText(isElec ? "028491829012" : "98765 43210");
        });

        form.getChildren().addAll(provLbl, providerCombo, accLbl, accField, fillSampleBtn);

        HBox btnRow = new HBox(14);
        btnRow.setAlignment(Pos.CENTER);

        Button backBtn = UiUtils.createSecondaryButton("← Back", "");
        backBtn.setOnAction(e -> showCategorySelectionScreen());

        Button fetchBtn = UiUtils.createPrimaryButton("Fetch Official Bill Details →", "🔍");
        fetchBtn.setStyle(fetchBtn.getStyle() + "-fx-font-size: 16px; -fx-padding: 12px 28px;");
        fetchBtn.setOnAction(e -> {
            String text = accField.getText().trim();
            if (text.isEmpty()) {
                UiUtils.showInfoDialog("Missing Details", "Please enter an account number or tap the demo fill button.", "");
                return;
            }
            this.selectedProvider = providerCombo.getValue();
            this.enteredAccount = text;
            SoundUtil.playSuccess();
            showBillReviewScreen();
        });

        btnRow.getChildren().addAll(backBtn, fetchBtn);

        card.getChildren().addAll(heading, desc, form, btnRow);
        workflowContainer.getChildren().add(card);
    }

    private void showBillReviewScreen() {
        workflowContainer.getChildren().clear();

        VBox card = UiUtils.createCard();
        card.setMaxWidth(720);
        card.setAlignment(Pos.CENTER);
        card.setSpacing(18);
        card.setPadding(new Insets(28));

        Label heading = UiUtils.createTitle("Step 3: Review Verified Bill Details");
        Label desc = UiUtils.createSubtitle("Always verify consumer name and amount before confirming payment.");

        // Bill Summary Box
        VBox billBox = new VBox(12);
        billBox.setMaxWidth(580);
        billBox.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #CBD5E1;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 20px;"
        );

        HBox bRow1 = createBillRow("Provider:", selectedProvider, false);
        HBox bRow2 = createBillRow("Consumer Account:", enteredAccount, false);
        HBox bRow3 = createBillRow("Registered Name:", "Smt. Sunita Devi (सुनीता देवी)", true);
        String dueDateStr = LocalDate.now().plusDays(15).format(DateTimeFormatter.ofPattern("dd-MMM-yyyy"));
        HBox bRow4 = createBillRow("Bill Due Date:", dueDateStr + " (15 Days Remaining ✔)", false);
        HBox bRow5 = createBillRow("Total Bill Amount:", "₹" + billAmount + ".00", true);

        billBox.getChildren().addAll(bRow1, bRow2, bRow3, bRow4, new Separator(), bRow5);

        // Security Notice Box
        VBox securityTip = new VBox(6);
        securityTip.setStyle(
            "-fx-background-color: #EFF6FF;" +
            "-fx-border-color: #BFDBFE;" +
            "-fx-border-radius: 10px;" +
            "-fx-background-radius: 10px;" +
            "-fx-padding: 12px 18px;"
        );
        securityTip.setMaxWidth(580);

        Label tipTitle = new Label("💡 Fraud Prevention Fact:");
        tipTitle.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #1E40AF;");

        Label tipBody = new Label("Notice the due date gives you 15 days of calm advance notice. Real electricity boards NEVER threaten to disconnect power within 1-2 hours via an SMS message.");
        tipBody.setWrapText(true);
        tipBody.setStyle("-fx-font-size: 13px; -fx-text-fill: #1E3A8A;");

        securityTip.getChildren().addAll(tipTitle, tipBody);

        HBox btnRow = new HBox(14);
        btnRow.setAlignment(Pos.CENTER);

        Button backBtn = UiUtils.createSecondaryButton("← Change Details", "");
        backBtn.setOnAction(e -> showDetailsInputScreen());

        Button payBtn = UiUtils.createPrimaryButton("Proceed to Safe Payment →", "💳");
        payBtn.setStyle(payBtn.getStyle() + "-fx-font-size: 17px; -fx-padding: 12px 30px;");
        payBtn.setOnAction(e -> {
            SoundUtil.playClick();
            showPaymentScreen();
        });

        btnRow.getChildren().addAll(backBtn, payBtn);

        card.getChildren().addAll(heading, desc, billBox, securityTip, btnRow);
        workflowContainer.getChildren().add(card);
    }

    private HBox createBillRow(String label, String value, boolean isBold) {
        HBox row = new HBox(12);
        row.setAlignment(Pos.CENTER_LEFT);

        Label l = new Label(label);
        l.setStyle("-fx-font-size: 14px; -fx-text-fill: #64748B;");
        l.setPrefWidth(160);

        Label v = new Label(value);
        v.setStyle("-fx-font-size: 15px; " + (isBold ? "-fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";" : "-fx-text-fill: #1E293B;"));

        row.getChildren().addAll(l, v);
        return row;
    }

    private void showPaymentScreen() {
        workflowContainer.getChildren().clear();

        VBox card = UiUtils.createCard();
        card.setMaxWidth(680);
        card.setAlignment(Pos.CENTER);
        card.setSpacing(18);
        card.setPadding(new Insets(28));

        Label heading = UiUtils.createTitle("Step 4: Select Payment Method");
        Label desc = UiUtils.createSubtitle("Paying ₹" + billAmount + ".00 to " + selectedProvider);

        ToggleGroup group = new ToggleGroup();

        VBox options = new VBox(12);
        options.setMaxWidth(520);

        RadioButton r1 = createPayOption("🟢 UPI App (Google Pay / PhonePe / Paytm / BHIM)", "UPI", group, true);
        RadioButton r2 = createPayOption("🏦 Internet Banking (State Bank of India / HDFC)", "NETBANKING", group, false);
        RadioButton r3 = createPayOption("💳 Debit Card (ATM RuPay / Visa / MasterCard)", "CARD", group, false);

        options.getChildren().addAll(r1, r2, r3);

        Label pinReminder = new Label("🔒 Security Reminder: You only enter your UPI PIN when PAYING money, never when receiving money.");
        pinReminder.setWrapText(true);
        pinReminder.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: #991B1B;");

        HBox btnRow = new HBox(14);
        btnRow.setAlignment(Pos.CENTER);

        Button backBtn = UiUtils.createSecondaryButton("← Back", "");
        backBtn.setOnAction(e -> showBillReviewScreen());

        Button confirmPayBtn = UiUtils.createPrimaryButton("Confirm & Pay ₹" + billAmount + " (Simulated)", "✅");
        confirmPayBtn.setStyle(confirmPayBtn.getStyle() + "-fx-font-size: 17px; -fx-padding: 12px 30px;");
        confirmPayBtn.setOnAction(e -> {
            SoundUtil.playSuccess();
            showReceiptScreen();
        });

        btnRow.getChildren().addAll(backBtn, confirmPayBtn);

        card.getChildren().addAll(heading, desc, options, pinReminder, btnRow);
        workflowContainer.getChildren().add(card);
    }

    private RadioButton createPayOption(String label, String data, ToggleGroup group, boolean selected) {
        RadioButton rb = new RadioButton(label);
        rb.setToggleGroup(group);
        rb.setUserData(data);
        rb.setSelected(selected);
        rb.setStyle(
            "-fx-font-size: 15px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: #1E293B;" +
            "-fx-padding: 10px 16px;" +
            "-fx-background-color: white;" +
            "-fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + ";" +
            "-fx-border-radius: 8px;" +
            "-fx-background-radius: 8px;" +
            "-fx-cursor: hand;"
        );
        rb.setMaxWidth(Double.MAX_VALUE);
        return rb;
    }

    private void showReceiptScreen() {
        workflowContainer.getChildren().clear();

        int userId = AppConfig.getInstance().getCurrentUser().getId();
        ProgressService.getInstance().unlockAchievementDirect(userId, "FIRST_PRACTICE");

        VBox card = UiUtils.createCard();
        card.setMaxWidth(720);
        card.setAlignment(Pos.CENTER);
        card.setSpacing(18);
        card.setPadding(new Insets(28));

        Label checkIcon = new Label("✅");
        checkIcon.setStyle("-fx-font-size: 48px;");

        Label heading = new Label("BILL PAYMENT SUCCESSFUL!");
        heading.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #15803D;");

        Label sub = new Label("Your simulated utility payment has been accepted by " + selectedProvider + ".");
        sub.setStyle("-fx-font-size: 15px; -fx-text-fill: #334155;");

        // Receipt Card
        VBox receipt = new VBox(10);
        receipt.setMaxWidth(560);
        receipt.setStyle(
            "-fx-background-color: #F8FAFC;" +
            "-fx-border-color: #CBD5E1;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 18px 24px;"
        );

        receipt.getChildren().addAll(
            createBillRow("Transaction ID:", "TXN-ELEC-2026-981240", false),
            createBillRow("Amount Paid:", "₹" + billAmount + ".00", true),
            createBillRow("Consumer Account:", enteredAccount, false),
            createBillRow("Billed To:", "Smt. Sunita Devi", false),
            createBillRow("Payment Status:", "SUCCESSFUL (PAID) ✔", true),
            createBillRow("Timestamp:", LocalDate.now().toString() + " • Real-Time Receipt", false)
        );

        HBox btnRow = new HBox(16);
        btnRow.setAlignment(Pos.CENTER);

        Button downloadReceiptBtn = UiUtils.createPrimaryButton("Download Receipt (Simulated PDF)", "📥");
        downloadReceiptBtn.setOnAction(e -> {
            SoundUtil.playClick();
            UiUtils.showInfoDialog("Payment Receipt Saved", "Receipt #TXN-ELEC-2026-981240", "A copy of your payment receipt has been saved into your simulated Downloads folder.");
        });

        Button payAnotherBtn = UiUtils.createSecondaryButton("Pay Another Bill 🔁", "");
        payAnotherBtn.setOnAction(e -> {
            SoundUtil.playClick();
            showCategorySelectionScreen();
        });

        btnRow.getChildren().addAll(downloadReceiptBtn, payAnotherBtn);

        card.getChildren().addAll(checkIcon, heading, sub, receipt, btnRow);
        workflowContainer.getChildren().add(card);
    }
}
