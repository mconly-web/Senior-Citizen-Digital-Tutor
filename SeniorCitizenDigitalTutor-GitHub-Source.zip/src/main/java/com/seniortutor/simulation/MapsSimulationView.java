package com.seniortutor.simulation;

import com.seniortutor.service.ProgressService;
import com.seniortutor.service.WindowsSpeechService;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;

import java.util.ArrayList;
import java.util.List;

/**
 * Interactive offline Google Maps practice simulation.
 * Teaches seniors how to search for nearby hospitals, pharmacies, view routes, and start voice navigation.
 */
public class MapsSimulationView extends VBox {

    private final Pane mapCanvas = new Pane();
    private final Label destinationTitle = new Label("Select a place to see directions");
    private final Label routeDetailsLabel = new Label("Distance & travel time will appear here.");
    private final VBox turnByTurnBox = new VBox(8);
    private Button startNavBtn;

    private static class Landmark {
        String name;
        String icon;
        String category;
        double x;
        double y;
        String distance;
        String walkTime;
        List<String> directions;

        Landmark(String name, String icon, String category, double x, double y, String distance, String walkTime, List<String> directions) {
            this.name = name;
            this.icon = icon;
            this.category = category;
            this.x = x;
            this.y = y;
            this.distance = distance;
            this.walkTime = walkTime;
            this.directions = directions;
        }
    }

    private final List<Landmark> landmarks = new ArrayList<>();
    private Landmark selectedLandmark;

    public MapsSimulationView() {
        setSpacing(0);
        setStyle("-fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");
        setFillWidth(true);

        initLandmarks();

        // 1. Safety Banner
        getChildren().add(createSafetyBanner());

        // 2. Main Layout (Search Top, Map Left, Route Details Right)
        VBox contentBox = new VBox(12);
        contentBox.setPadding(new Insets(16));

        HBox searchRow = createSearchBar();
        HBox mapAndPanel = createMapAndDirectionsPanel();

        contentBox.getChildren().addAll(searchRow, mapAndPanel);
        VBox.setVgrow(contentBox, Priority.ALWAYS);

        getChildren().add(contentBox);

        // Select Hospital by default
        selectLandmark(landmarks.get(0));
    }

    private void initLandmarks() {
        landmarks.add(new Landmark(
            "City Civil Hospital", "🏥", "Hospital", 540, 90, "850 meters", "11 min walk",
            List.of("Head north on MG Road towards Green Park (300m)", "Turn right at the traffic circle onto Civil Lines (450m)", "City Civil Hospital will be on your left")
        ));
        landmarks.add(new Landmark(
            "MedPlus Pharmacy & Chemist", "💊", "Pharmacy", 380, 180, "350 meters", "4 min walk",
            List.of("Walk straight north on MG Road (200m)", "Turn left at the Corner Bakery (150m)", "MedPlus Chemist is next to the post office")
        ));
        landmarks.add(new Landmark(
            "Mother Dairy & Grocery", "🥛", "Grocery", 180, 260, "500 meters", "6 min walk",
            List.of("Head west along Temple Road (400m)", "Turn right onto Market Lane (100m)", "Mother Dairy will be on your right")
        ));
        landmarks.add(new Landmark(
            "Central Metro Station", "🚆", "Metro", 620, 310, "1.4 km", "18 min walk / 5 min auto",
            List.of("Head east on Main Road (800m)", "Cross pedestrian flyover (200m)", "Central Metro entrance is on Platform 1")
        ));
    }

    private HBox createSafetyBanner() {
        HBox banner = new HBox(12);
        banner.setAlignment(Pos.CENTER);
        banner.setStyle(
            "-fx-background-color: #E8F5E9;" +
            "-fx-border-color: #C8E6C9;" +
            "-fx-border-width: 0 0 2px 0;" +
            "-fx-padding: 10px 20px;"
        );

        Label icon = new Label("🗺️");
        icon.setStyle("-fx-font-size: 20px;");

        Label text = new Label("SAFE MAP SIMULATION: Simulated offline map. No GPS or API key needed. Practice navigating safely!");
        text.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #1B5E20;");

        banner.getChildren().addAll(icon, text);
        return banner;
    }

    private HBox createSearchBar() {
        HBox bar = new HBox(12);
        bar.setAlignment(Pos.CENTER_LEFT);

        TextField searchField = new TextField();
        searchField.setPromptText("🔍 Search nearby (e.g. Hospital, Pharmacy)...");
        searchField.setStyle(
            "-fx-font-size: 16px;" +
            "-fx-background-color: white;" +
            "-fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + ";" +
            "-fx-border-radius: 20px;" +
            "-fx-background-radius: 20px;" +
            "-fx-padding: 8px 16px;" +
            "-fx-pref-width: 320px;"
        );

        // Filter chips
        HBox chips = new HBox(8);
        chips.setAlignment(Pos.CENTER_LEFT);

        for (Landmark lm : landmarks) {
            Button chip = new Button(lm.icon + " " + lm.category);
            chip.setStyle(
                "-fx-background-color: white;" +
                "-fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + ";" +
                "-fx-border-radius: 16px;" +
                "-fx-background-radius: 16px;" +
                "-fx-font-size: 14px;" +
                "-fx-font-weight: bold;" +
                "-fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";" +
                "-fx-cursor: hand;"
            );
            chip.setOnAction(e -> {
                SoundUtil.playClick();
                searchField.setText(lm.name);
                selectLandmark(lm);
            });
            chips.getChildren().add(chip);
        }

        bar.getChildren().addAll(searchField, chips);
        return bar;
    }

    private HBox createMapAndDirectionsPanel() {
        HBox box = new HBox(16);
        box.setAlignment(Pos.CENTER);
        VBox.setVgrow(box, Priority.ALWAYS);

        // Map Canvas Box
        mapCanvas.setPrefSize(720, 460);
        mapCanvas.setMinSize(720, 460);
        mapCanvas.setStyle(
            "-fx-background-color: #E5E9E0;" +
            "-fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + ";" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 16px;" +
            "-fx-background-radius: 16px;"
        );

        drawMockMapBase();

        // Right Directions Card
        VBox directionsPanel = createDirectionsPanel();
        directionsPanel.setPrefWidth(420);
        HBox.setHgrow(directionsPanel, Priority.ALWAYS);

        box.getChildren().addAll(mapCanvas, directionsPanel);
        return box;
    }

    private void drawMockMapBase() {
        mapCanvas.getChildren().clear();

        // Green Park
        Rectangle park = new Rectangle(60, 60, 180, 140);
        park.setFill(Color.web("#C8D8C3"));
        park.setArcWidth(12);
        park.setArcHeight(12);
        Label parkLbl = new Label("🌳 Public Gardens & Park");
        parkLbl.setLayoutX(75);
        parkLbl.setLayoutY(115);
        parkLbl.setStyle("-fx-font-size: 13px; -fx-text-fill: #44603B; -fx-font-weight: bold;");

        // Main Roads (Grey lines)
        Line roadMg = new Line(300, 20, 300, 440);
        roadMg.setStroke(Color.web("#D1D5DB"));
        roadMg.setStrokeWidth(32);

        Line roadCross = new Line(20, 240, 700, 240);
        roadCross.setStroke(Color.web("#D1D5DB"));
        roadCross.setStrokeWidth(28);

        Line roadEast = new Line(520, 20, 520, 440);
        roadEast.setStroke(Color.web("#D1D5DB"));
        roadEast.setStrokeWidth(24);

        Label mgRoadLabel = new Label("MG ROAD");
        mgRoadLabel.setLayoutX(308);
        mgRoadLabel.setLayoutY(360);
        mgRoadLabel.setStyle("-fx-font-size: 11px; -fx-text-fill: #64748B; -fx-font-weight: bold;");

        mapCanvas.getChildren().addAll(roadMg, roadCross, roadEast, park, parkLbl, mgRoadLabel);

        // User's Home Pin (Origin at 300, 320)
        VBox homePin = new VBox(2);
        homePin.setAlignment(Pos.CENTER);
        Label homeIcon = new Label("🏠");
        homeIcon.setStyle("-fx-font-size: 24px;");
        Label homeLbl = new Label("Your Home");
        homeLbl.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-background-color: white; -fx-padding: 2px 6px; -fx-background-radius: 4px;");
        homePin.getChildren().addAll(homeIcon, homeLbl);
        homePin.setLayoutX(270);
        homePin.setLayoutY(295);

        mapCanvas.getChildren().add(homePin);

        // Landmark Pins
        for (Landmark lm : landmarks) {
            VBox pin = new VBox(2);
            pin.setAlignment(Pos.CENTER);
            pin.setStyle("-fx-cursor: hand;");

            Label pIcon = new Label(lm.icon);
            pIcon.setStyle("-fx-font-size: 26px;");

            Label pName = new Label(lm.name);
            pName.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-background-color: white; -fx-padding: 2px 6px; -fx-background-radius: 4px; -fx-border-color: #CBD5E1; -fx-border-radius: 4px;");

            pin.getChildren().addAll(pIcon, pName);
            pin.setLayoutX(lm.x - 40);
            pin.setLayoutY(lm.y);

            pin.setOnMouseClicked(e -> {
                SoundUtil.playClick();
                selectLandmark(lm);
            });

            mapCanvas.getChildren().add(pin);
        }
    }

    private VBox createDirectionsPanel() {
        VBox panel = UiUtils.createCard();
        panel.setSpacing(14);
        panel.setPadding(new Insets(20));

        destinationTitle.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");
        destinationTitle.setWrapText(true);

        routeDetailsLabel.setStyle("-fx-font-size: 15px; -fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";");
        routeDetailsLabel.setWrapText(true);

        // Turn-by-turn guidance box
        turnByTurnBox.setStyle(
            "-fx-background-color: #F8FAFC;" +
            "-fx-border-color: #E2E8F0;" +
            "-fx-border-radius: 10px;" +
            "-fx-background-radius: 10px;" +
            "-fx-padding: 12px;"
        );
        VBox.setVgrow(turnByTurnBox, Priority.ALWAYS);

        // Start Navigation Voice Button
        startNavBtn = UiUtils.createPrimaryButton("▶ Start Voice Navigation", "");
        startNavBtn.setOnAction(e -> startNavigationVoice());

        panel.getChildren().addAll(destinationTitle, routeDetailsLabel, new Label("Step-by-step route:"), turnByTurnBox, startNavBtn);
        return panel;
    }

    private void selectLandmark(Landmark lm) {
        this.selectedLandmark = lm;

        drawMockMapBase();

        // Draw highlighted blue route line from Home (300, 310) to landmark (lm.x, lm.y + 20)
        Line routeLine = new Line(300, 310, lm.x, lm.y + 20);
        routeLine.setStroke(Color.web("#2563EB"));
        routeLine.setStrokeWidth(5);
        routeLine.getStrokeDashArray().addAll(10d, 8d);

        Circle targetHighlight = new Circle(lm.x, lm.y + 20, 24);
        targetHighlight.setFill(Color.TRANSPARENT);
        targetHighlight.setStroke(Color.web("#2563EB"));
        targetHighlight.setStrokeWidth(3);

        mapCanvas.getChildren().addAll(routeLine, targetHighlight);

        // Update Panel details
        destinationTitle.setText(lm.icon + " " + lm.name);
        routeDetailsLabel.setText("📍 " + lm.distance + " • " + lm.walkTime + " • Fastest route via MG Road");

        turnByTurnBox.getChildren().clear();
        int stepNum = 1;
        for (String step : lm.directions) {
            Label sl = new Label(stepNum + ". " + step);
            sl.setWrapText(true);
            sl.setStyle("-fx-font-size: 14px; -fx-text-fill: #1E293B;");
            turnByTurnBox.getChildren().add(sl);
            stepNum++;
        }

        ProgressService.getInstance().unlockAchievementDirect(AppConfig.getInstance().getCurrentUser().getId(), "MAPS_NAVIGATOR");
    }

    private void startNavigationVoice() {
        if (selectedLandmark == null) return;

        SoundUtil.playSuccess();
        String spoken = "Starting navigation to " + selectedLandmark.name + ". In 300 meters, turn right onto Civil Lines. Distance is " + selectedLandmark.distance + ".";
        WindowsSpeechService.getInstance().speak(spoken);

        UiUtils.showInfoDialog(
            "Voice Navigation Started",
            "Navigating to " + selectedLandmark.name,
            "🔊 Voice Guidance Active:\n\n" +
            "\"In 300 meters, turn right on Civil Lines. Your destination is " + selectedLandmark.distance + " away.\"\n\n" +
            "In real life, your phone will speak directions through your car speaker or headphones as you walk."
        );
    }
}
