package com.seniortutor.simulation;

import com.seniortutor.service.ProgressService;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Interactive Email practice simulation.
 * Lets seniors safely compose emails, add attachments, inspect inbox messages, and understand email safety.
 */
public class EmailSimulationView extends VBox {

    private final StackPane mainPanel = new StackPane();
    private final TextField toField = new TextField();
    private final TextField subjectField = new TextField();
    private final TextArea bodyArea = new TextArea();
    private final HBox attachmentRow = new HBox(8);
    private boolean hasAttachment = false;

    private static class MockEmail {
        String from;
        String subject;
        String date;
        String preview;
        String fullBody;
        boolean hasAttachment;

        MockEmail(String from, String subject, String date, String preview, String fullBody, boolean hasAttachment) {
            this.from = from;
            this.subject = subject;
            this.date = date;
            this.preview = preview;
            this.fullBody = fullBody;
            this.hasAttachment = hasAttachment;
        }
    }

    private final List<MockEmail> inboxEmails = new ArrayList<>();
    private final List<MockEmail> sentEmails = new ArrayList<>();

    public EmailSimulationView() {
        setSpacing(0);
        setStyle("-fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");
        setFillWidth(true);

        initSampleEmails();

        // 1. Safety Banner
        getChildren().add(createSafetyBanner());

        // 2. Email Client Split View (Folder Nav on left, Content on right)
        HBox clientBox = new HBox(16);
        clientBox.setPadding(new Insets(16));
        VBox.setVgrow(clientBox, Priority.ALWAYS);

        VBox navSidebar = createSidebar();
        navSidebar.setPrefWidth(220);

        mainPanel.setStyle("-fx-background-color: transparent;");
        HBox.setHgrow(mainPanel, Priority.ALWAYS);

        clientBox.getChildren().addAll(navSidebar, mainPanel);
        getChildren().add(clientBox);

        // Open Compose by default
        showComposeView();
    }

    private void initSampleEmails() {
        inboxEmails.add(new MockEmail(
            "Dr. K. S. Verma <dr.verma@healthclinic.org>",
            "Routine Health & Blood Pressure Report",
            "Yesterday, 4:30 PM",
            "Dear Shanti Ji, your recent test results look very positive...",
            "Dear Shanti Ji,\n\nYour blood pressure is well controlled at 125/80. Please continue your morning walk and current dosage. Take care!\n\nWarm regards,\nDr. K. S. Verma",
            true
        ));
        inboxEmails.add(new MockEmail(
            "State Bank of India <alerts@sbi.co.in>",
            "Monthly Account E-Statement for September",
            "3 days ago",
            "Dear Customer, your password-protected monthly e-statement is attached...",
            "Dear Customer,\n\nAttached is your monthly transaction e-statement for account ending in 1042.\n\nNote: SBI NEVER asks for your secret PIN or OTP.",
            true
        ));
    }

    private HBox createSafetyBanner() {
        HBox banner = new HBox(12);
        banner.setAlignment(Pos.CENTER);
        banner.setStyle(
            "-fx-background-color: #E0F2FE;" +
            "-fx-border-color: #BAE6FD;" +
            "-fx-border-width: 0 0 2px 0;" +
            "-fx-padding: 10px 20px;"
        );

        Label icon = new Label("📧");
        icon.setStyle("-fx-font-size: 20px;");

        Label text = new Label("SAFE EMAIL PRACTICE: Safe offline mock email client. Practice writing and attaching photos with confidence!");
        text.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #0369A1;");

        banner.getChildren().addAll(icon, text);
        return banner;
    }

    private VBox createSidebar() {
        VBox sidebar = UiUtils.createCard();
        sidebar.setSpacing(12);
        sidebar.setPadding(new Insets(16));

        Button composeBtn = UiUtils.createAccentButton("✏️ Compose", "");
        composeBtn.setMaxWidth(Double.MAX_VALUE);
        composeBtn.setOnAction(e -> showComposeView());

        Button inboxBtn = new Button("📥 Inbox (" + inboxEmails.size() + ")");
        styleSidebarButton(inboxBtn);
        inboxBtn.setOnAction(e -> showInboxView());

        Button sentBtn = new Button("📤 Sent (" + sentEmails.size() + ")");
        styleSidebarButton(sentBtn);
        sentBtn.setOnAction(e -> showSentView());

        sidebar.getChildren().addAll(composeBtn, new Separator(), inboxBtn, sentBtn);
        return sidebar;
    }

    private void styleSidebarButton(Button btn) {
        btn.setMaxWidth(Double.MAX_VALUE);
        btn.setStyle(
            "-fx-font-size: 16px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";" +
            "-fx-background-color: transparent;" +
            "-fx-padding: 10px 14px;" +
            "-fx-alignment: center-left;" +
            "-fx-cursor: hand;"
        );
    }

    private void showComposeView() {
        mainPanel.getChildren().clear();

        VBox composeCard = UiUtils.createCard();
        composeCard.setSpacing(14);
        composeCard.setPadding(new Insets(20));

        Label heading = UiUtils.createTitle("Compose New Email");

        // Quick contacts row
        HBox quickContacts = new HBox(8);
        quickContacts.setAlignment(Pos.CENTER_LEFT);
        Label quickLbl = new Label("Quick recipient:");
        quickLbl.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        Button daughterChip = new Button("👩 Anita (Daughter)");
        daughterChip.setOnAction(e -> toField.setText("anita.sharma@gmail.com"));

        Button sonChip = new Button("👨 Rohan (Son)");
        sonChip.setOnAction(e -> toField.setText("rohan.sharma@gmail.com"));

        Button docChip = new Button("🩺 Dr. Verma");
        docChip.setOnAction(e -> toField.setText("dr.verma@healthclinic.org"));

        quickContacts.getChildren().addAll(quickLbl, daughterChip, sonChip, docChip);

        // "To" Row
        HBox toRow = new HBox(12);
        toRow.setAlignment(Pos.CENTER_LEFT);
        Label toLabel = new Label("To:");
        toLabel.setPrefWidth(70);
        toLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        toField.setPromptText("Recipient's email address...");
        toField.setStyle("-fx-font-size: 15px; -fx-background-radius: 8px; -fx-padding: 8px;");
        HBox.setHgrow(toField, Priority.ALWAYS);
        toRow.getChildren().addAll(toLabel, toField);

        // "Subject" Row
        HBox subRow = new HBox(12);
        subRow.setAlignment(Pos.CENTER_LEFT);
        Label subLabel = new Label("Subject:");
        subLabel.setPrefWidth(70);
        subLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        subjectField.setPromptText("What is this email about?");
        subjectField.setStyle("-fx-font-size: 15px; -fx-background-radius: 8px; -fx-padding: 8px;");
        HBox.setHgrow(subjectField, Priority.ALWAYS);
        subRow.getChildren().addAll(subLabel, subjectField);

        // Attachment Toolbar
        HBox attachBar = new HBox(12);
        attachBar.setAlignment(Pos.CENTER_LEFT);

        Button attachBtn = new Button("📎 Attach Photo / File");
        attachBtn.setStyle(
            "-fx-font-size: 14px;" +
            "-fx-background-color: #E2E8F0;" +
            "-fx-background-radius: 8px;" +
            "-fx-padding: 6px 14px;" +
            "-fx-cursor: hand;"
        );
        attachBtn.setOnAction(e -> {
            hasAttachment = true;
            attachmentRow.getChildren().clear();
            Label chip = new Label("📄 Medical_Report_Sept.pdf (142 KB) ✕");
            chip.setStyle("-fx-background-color: #DBEAFE; -fx-text-fill: #1E40AF; -fx-padding: 4px 10px; -fx-background-radius: 12px;");
            chip.setOnMouseClicked(ev -> {
                hasAttachment = false;
                attachmentRow.getChildren().clear();
            });
            attachmentRow.getChildren().add(chip);
            SoundUtil.playClick();
        });

        attachBar.getChildren().addAll(attachBtn, attachmentRow);

        // Body TextArea
        bodyArea.setPromptText("Type your email message here...");
        bodyArea.setStyle("-fx-font-size: 16px; -fx-background-radius: 8px; -fx-padding: 8px;");
        bodyArea.setWrapText(true);
        VBox.setVgrow(bodyArea, Priority.ALWAYS);

        // Send Button Row
        HBox sendBar = new HBox(16);
        sendBar.setAlignment(Pos.CENTER_RIGHT);

        Button sendBtn = UiUtils.createPrimaryButton("➤ Send Email", "");
        sendBtn.setOnAction(e -> sendMockEmail());

        sendBar.getChildren().add(sendBtn);

        composeCard.getChildren().addAll(heading, quickContacts, toRow, subRow, attachBar, bodyArea, sendBar);
        mainPanel.getChildren().add(composeCard);
    }

    private void sendMockEmail() {
        String to = toField.getText().trim();
        String sub = subjectField.getText().trim();
        String body = bodyArea.getText().trim();

        if (to.isEmpty() || body.isEmpty()) {
            UiUtils.showInfoDialog("Email Incomplete", "Please enter recipient and message", "An email requires at least a recipient address and message content.");
            return;
        }

        SoundUtil.playSuccess();
        sentEmails.add(0, new MockEmail(
            "To: " + to,
            sub.isEmpty() ? "(No Subject)" : sub,
            "Just now",
            body.length() > 60 ? body.substring(0, 57) + "..." : body,
            body,
            hasAttachment
        ));

        toField.clear();
        subjectField.clear();
        bodyArea.clear();
        attachmentRow.getChildren().clear();
        hasAttachment = false;

        UiUtils.showInfoDialog(
            "Email Sent",
            "Your email has been sent successfully!",
            "✅ In real life, Gmail or Yahoo delivers your email within seconds to the recipient.\n\nYou can see your dispatched email in the 'Sent' folder on the left."
        );

        ProgressService.getInstance().unlockAchievementDirect(AppConfig.getInstance().getCurrentUser().getId(), "FIRST_LESSON");
    }

    private void showInboxView() {
        mainPanel.getChildren().clear();

        VBox inboxCard = UiUtils.createCard();
        inboxCard.setSpacing(14);
        inboxCard.setPadding(new Insets(20));

        Label heading = UiUtils.createTitle("📥 Inbox");

        VBox emailListBox = new VBox(10);
        for (MockEmail mail : inboxEmails) {
            emailListBox.getChildren().add(createEmailRow(mail));
        }

        inboxCard.getChildren().addAll(heading, emailListBox);
        mainPanel.getChildren().add(inboxCard);
    }

    private void showSentView() {
        mainPanel.getChildren().clear();

        VBox sentCard = UiUtils.createCard();
        sentCard.setSpacing(14);
        sentCard.setPadding(new Insets(20));

        Label heading = UiUtils.createTitle("📤 Sent Emails");

        if (sentEmails.isEmpty()) {
            Label emptyLbl = new Label("No sent emails yet. Tap 'Compose' to send your first practice email!");
            emptyLbl.setStyle("-fx-font-size: 16px; -fx-text-fill: #64748B; -fx-padding: 20px;");
            sentCard.getChildren().addAll(heading, emptyLbl);
        } else {
            VBox emailListBox = new VBox(10);
            for (MockEmail mail : sentEmails) {
                emailListBox.getChildren().add(createEmailRow(mail));
            }
            sentCard.getChildren().addAll(heading, emailListBox);
        }

        mainPanel.getChildren().add(sentCard);
    }

    private VBox createEmailRow(MockEmail mail) {
        VBox row = new VBox(4);
        row.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #E2E8F0;" +
            "-fx-border-radius: 10px;" +
            "-fx-background-radius: 10px;" +
            "-fx-padding: 12px 16px;" +
            "-fx-cursor: hand;"
        );

        HBox top = new HBox(12);
        top.setAlignment(Pos.CENTER_LEFT);

        Label fromLbl = new Label(mail.from);
        fromLbl.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");
        HBox.setHgrow(fromLbl, Priority.ALWAYS);

        Label dateLbl = new Label(mail.date);
        dateLbl.setStyle("-fx-font-size: 13px; -fx-text-fill: #94A3B8;");

        top.getChildren().addAll(fromLbl, dateLbl);

        Label subLbl = new Label(mail.subject + (mail.hasAttachment ? " 📎" : ""));
        subLbl.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #1E293B;");

        Label prevLbl = new Label(mail.preview);
        prevLbl.setStyle("-fx-font-size: 14px; -fx-text-fill: #64748B;");

        row.getChildren().addAll(top, subLbl, prevLbl);

        row.setOnMouseClicked(e -> {
            SoundUtil.playClick();
            UiUtils.showInfoDialog(
                mail.subject,
                "From: " + mail.from + "\nDate: " + mail.date,
                mail.fullBody + (mail.hasAttachment ? "\n\n📎 Attachment: Medical_Report.pdf (Safe to view)" : "")
            );
        });

        return row;
    }
}
