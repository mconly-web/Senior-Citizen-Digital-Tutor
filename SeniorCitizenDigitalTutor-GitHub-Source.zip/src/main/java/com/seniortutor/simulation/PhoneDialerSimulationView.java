package com.seniortutor.simulation;

import com.seniortutor.service.ProgressService;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.util.Duration;

/**
 * Interactive Phone Dialer practice simulation.
 * Features large accessible dialpad keys, instant backspace, contact shortcuts, and live call screen with speaker toggle.
 */
public class PhoneDialerSimulationView extends VBox {

    private final TextField numberDisplay = new TextField();
    private final StackPane container = new StackPane();
    private VBox activeCallOverlay;
    private Label callStatusLabel;
    private Timeline callTimer;
    private int callSeconds = 0;
    private boolean speakerOn = false;

    public PhoneDialerSimulationView() {
        setSpacing(0);
        setStyle("-fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");
        setFillWidth(true);

        // 1. Safety Banner
        getChildren().add(createSafetyBanner());

        // 2. Dialer Card
        VBox dialerBox = createDialerInterface();
        container.getChildren().add(dialerBox);
        VBox.setVgrow(container, Priority.ALWAYS);

        getChildren().add(container);
    }

    private HBox createSafetyBanner() {
        HBox banner = new HBox(12);
        banner.setAlignment(Pos.CENTER);
        banner.setStyle(
            "-fx-background-color: #FFF3CD;" +
            "-fx-border-color: #FFEEBA;" +
            "-fx-border-width: 0 0 2px 0;" +
            "-fx-padding: 10px 20px;"
        );

        Label icon = new Label("🛡️");
        icon.setStyle("-fx-font-size: 20px;");

        Label text = new Label("SAFE PRACTICE SIMULATION: No actual phone calls are placed. Practice dialing and answering freely!");
        text.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #856404;");

        banner.getChildren().addAll(icon, text);
        return banner;
    }

    private VBox createDialerInterface() {
        VBox box = new VBox(16);
        box.setAlignment(Pos.TOP_CENTER);
        box.setPadding(new Insets(24));
        box.setMaxWidth(600);

        // Quick Family Contacts Row
        Label contactsHeading = new Label("Quick Family Contacts (Tap to autofill):");
        contactsHeading.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        HBox quickContacts = new HBox(12);
        quickContacts.setAlignment(Pos.CENTER);

        quickContacts.getChildren().addAll(
            createContactChip("👩 Anita (Daughter)", "9876543210"),
            createContactChip("👨 Rohan (Son)", "9812345678"),
            createContactChip("🩺 Dr. Verma", "9422011223")
        );

        // Display Area with Backspace
        HBox displayRow = new HBox(10);
        displayRow.setAlignment(Pos.CENTER);

        numberDisplay.setPromptText("Enter phone number...");
        numberDisplay.setEditable(false);
        numberDisplay.setAlignment(Pos.CENTER);
        numberDisplay.setStyle(
            "-fx-font-size: 28px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-color: white;" +
            "-fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + ";" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 10px 16px;" +
            "-fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";"
        );
        HBox.setHgrow(numberDisplay, Priority.ALWAYS);

        Button backspaceBtn = new Button("⌫");
        backspaceBtn.setStyle(
            "-fx-font-size: 22px;" +
            "-fx-background-color: #E2E8F0;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 10px 18px;" +
            "-fx-cursor: hand;"
        );
        backspaceBtn.setOnAction(e -> {
            SoundUtil.playClick();
            String current = numberDisplay.getText();
            if (!current.isEmpty()) {
                numberDisplay.setText(current.substring(0, current.length() - 1));
            }
        });

        displayRow.getChildren().addAll(numberDisplay, backspaceBtn);

        // 3x4 Dialpad Grid
        GridPane dialpad = new GridPane();
        dialpad.setAlignment(Pos.CENTER);
        dialpad.setHgap(16);
        dialpad.setVgap(14);

        String[][] keys = {
            {"1", "2\nABC", "3\nDEF"},
            {"4\nGHI", "5\nJKL", "6\nMNO"},
            {"7\nPQRS", "8\nTUV", "9\nWXYZ"},
            {"*", "0\n+", "#"}
        };

        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 3; c++) {
                String label = keys[r][c];
                String digit = label.split("\n")[0];
                Button keyBtn = createDialpadButton(label, digit);
                dialpad.add(keyBtn, c, r);
            }
        }

        // Giant Green Call Button
        Button callBtn = new Button("📞 Call");
        callBtn.setStyle(
            "-fx-background-color: #28A745;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 22px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-radius: 30px;" +
            "-fx-padding: 14px 60px;" +
            "-fx-cursor: hand;" +
            "-fx-effect: dropshadow(gaussian, rgba(40,167,69,0.35), 8, 0, 0, 3);"
        );
        callBtn.setOnAction(e -> initiateCall());

        box.getChildren().addAll(contactsHeading, quickContacts, displayRow, dialpad, callBtn);

        VBox outer = new VBox(box);
        outer.setAlignment(Pos.CENTER);
        return outer;
    }

    private Button createContactChip(String name, String number) {
        Button btn = new Button(name);
        btn.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + ";" +
            "-fx-border-radius: 16px;" +
            "-fx-background-radius: 16px;" +
            "-fx-font-size: 14px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";" +
            "-fx-padding: 6px 14px;" +
            "-fx-cursor: hand;"
        );
        btn.setOnAction(e -> {
            SoundUtil.playClick();
            numberDisplay.setText(number);
        });
        return btn;
    }

    private Button createDialpadButton(String fullText, String digit) {
        Button btn = new Button(fullText);
        btn.setAlignment(Pos.CENTER);
        btn.setStyle(
            "-fx-background-color: white;" +
            "-fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";" +
            "-fx-font-size: 18px;" +
            "-fx-font-weight: bold;" +
            "-fx-border-color: #E2E8F0;" +
            "-fx-border-width: 1.5px;" +
            "-fx-border-radius: 14px;" +
            "-fx-background-radius: 14px;" +
            "-fx-cursor: hand;"
        );
        btn.setPrefSize(95, 68);

        btn.setOnAction(e -> {
            SoundUtil.playClick();
            numberDisplay.setText(numberDisplay.getText() + digit);
        });

        return btn;
    }

    private void initiateCall() {
        String num = numberDisplay.getText().trim();
        if (num.isEmpty()) {
            UiUtils.showInfoDialog("Dialer", "Please dial a number", "Tap the numbers on the keypad or select a contact above first.");
            return;
        }

        SoundUtil.playSuccess();
        activeCallOverlay = new VBox(24);
        activeCallOverlay.setAlignment(Pos.CENTER);
        activeCallOverlay.setStyle(
            "-fx-background-color: " + UiUtils.COLOR_FOREST_GREEN + ";" +
            "-fx-padding: 40px;"
        );

        Label avatar = new Label("👤");
        avatar.setStyle(
            "-fx-font-size: 60px;" +
            "-fx-background-color: rgba(255,255,255,0.2);" +
            "-fx-background-radius: 50px;" +
            "-fx-padding: 10px 20px;"
        );

        String contactMatch = num.contains("9876543210") ? "Anita (Daughter)" : (num.contains("9812345678") ? "Rohan (Son)" : "Dialed Number");
        Label nameLbl = new Label(contactMatch);
        nameLbl.setStyle("-fx-font-size: 26px; -fx-font-weight: bold; -fx-text-fill: white;");

        Label numLbl = new Label(num);
        numLbl.setStyle("-fx-font-size: 19px; -fx-text-fill: #E0EAE5;");

        callSeconds = 0;
        callStatusLabel = new Label("Ringing...");
        callStatusLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: " + UiUtils.COLOR_MUTED_GOLD + ";");

        // Simulate connecting after 2 seconds
        callTimer = new Timeline(new KeyFrame(Duration.seconds(1), e -> {
            callSeconds++;
            if (callSeconds < 3) {
                callStatusLabel.setText("Ringing... 📳");
            } else {
                int mins = (callSeconds - 3) / 60;
                int secs = (callSeconds - 3) % 60;
                callStatusLabel.setText(String.format("Call Connected • %02d:%02d", mins, secs));
            }
        }));
        callTimer.setCycleCount(Animation.INDEFINITE);
        callTimer.play();

        // Control buttons (Speaker, Mute, End)
        HBox controls = new HBox(20);
        controls.setAlignment(Pos.CENTER);

        Button speakerBtn = new Button("📢 Speaker OFF");
        speakerBtn.setStyle("-fx-font-size: 16px; -fx-background-radius: 12px; -fx-padding: 10px 20px;");
        speakerBtn.setOnAction(e -> {
            speakerOn = !speakerOn;
            speakerBtn.setText(speakerOn ? "🔊 Speaker ON" : "📢 Speaker OFF");
            speakerBtn.setStyle(speakerOn
                ? "-fx-font-size: 16px; -fx-background-color: " + UiUtils.COLOR_MUTED_GOLD + "; -fx-text-fill: black; -fx-background-radius: 12px; -fx-padding: 10px 20px;"
                : "-fx-font-size: 16px; -fx-background-radius: 12px; -fx-padding: 10px 20px;");
            SoundUtil.playClick();
        });

        Button endBtn = new Button("🔴 End Call");
        endBtn.setStyle(
            "-fx-background-color: #DC3545;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 19px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 12px 36px;" +
            "-fx-cursor: hand;"
        );
        endBtn.setOnAction(e -> endCall());

        controls.getChildren().addAll(speakerBtn, endBtn);

        Label advice = new Label("💡 Hint: Tap 'Speaker' if you want to put the phone down on the table while speaking.");
        advice.setStyle("-fx-font-size: 15px; -fx-text-fill: #FFF3CD;");

        activeCallOverlay.getChildren().addAll(avatar, nameLbl, numLbl, callStatusLabel, controls, advice);
        container.getChildren().add(activeCallOverlay);

        ProgressService.getInstance().unlockAchievementDirect(AppConfig.getInstance().getCurrentUser().getId(), "FIRST_LESSON");
    }

    private void endCall() {
        SoundUtil.playClick();
        if (callTimer != null) {
            callTimer.stop();
        }
        container.getChildren().remove(activeCallOverlay);
        numberDisplay.clear();
    }
}
