package com.seniortutor.simulation;

import com.seniortutor.service.ProgressService;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.animation.PauseTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.List;

/**
 * Interactive UPI and Digital Payment practice simulation.
 * Teaches QR code scanning, amount verification, and PIN safety without real financial risk.
 */
public class UpiPaymentSimulationView extends VBox {

    private final StackPane workflowContainer = new StackPane();
    private String currentMerchant = "Sharma Fresh Groceries";
    private String currentUpiId = "sharma.groceries@upi";
    private int currentAmount = 150;
    private final StringBuilder pinBuffer = new StringBuilder();
    private Label pinDisplayLabel;

    private final List<String> mockHistory = new ArrayList<>();

    public UpiPaymentSimulationView() {
        setSpacing(0);
        setStyle("-fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");
        setFillWidth(true);

        mockHistory.add("₹240 paid to Sharma Fresh Groceries (Yesterday)");
        mockHistory.add("₹500 paid to Apollo Pharmacy (3 days ago)");

        // 1. Prominent Safety Banner with Red Warning Rules
        getChildren().add(createSafetyBanner());

        // 2. Main Workflow Step (starts at Scan / Select Merchant)
        showScanScreen();

        VBox.setVgrow(workflowContainer, Priority.ALWAYS);
        getChildren().add(workflowContainer);
    }

    private VBox createSafetyBanner() {
        VBox banner = new VBox(6);
        banner.setAlignment(Pos.CENTER);
        banner.setStyle(
            "-fx-background-color: #F8D7DA;" +
            "-fx-border-color: #F5C6CB;" +
            "-fx-border-width: 0 0 2px 0;" +
            "-fx-padding: 12px 24px;"
        );

        Label title = new Label("🛡️ SAFE PRACTICE MODE • NO REAL MONEY IS USED");
        title.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #721C24;");

        Label warning = new Label("🚨 GOLDEN RULE: Entering your PIN DEDUCTS money from your bank account. NEVER enter your PIN to receive money!");
        warning.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #B02A37;");

        banner.getChildren().addAll(title, warning);
        return banner;
    }

    private void showScanScreen() {
        workflowContainer.getChildren().clear();

        VBox card = UiUtils.createCard();
        card.setMaxWidth(680);
        card.setAlignment(Pos.CENTER);
        card.setSpacing(18);

        Label heading = UiUtils.createTitle("Step 1: Scan Shopkeeper's QR Code");
        Label desc = UiUtils.createSubtitle("At the counter, point your phone at the printed QR stand.");

        // Simulated Camera Viewfinder with QR pattern
        StackPane viewfinder = new StackPane();
        viewfinder.setPrefSize(260, 260);
        viewfinder.setMaxSize(260, 260);
        viewfinder.setStyle(
            "-fx-background-color: #242424;" +
            "-fx-background-radius: 16px;" +
            "-fx-border-color: " + UiUtils.COLOR_MUTED_GOLD + ";" +
            "-fx-border-width: 3px;" +
            "-fx-border-style: dashed;"
        );

        VBox qrContent = new VBox(8);
        qrContent.setAlignment(Pos.CENTER);
        Label qrIcon = new Label("🏁 [ QR CODE ]");
        qrIcon.setStyle("-fx-font-size: 26px; -fx-text-fill: white; -fx-font-weight: bold;");

        Label shopLabel = new Label("Sharma Fresh Groceries\n(Verified Merchant)");
        shopLabel.setStyle("-fx-font-size: 15px; -fx-text-fill: #D2E3D8; -fx-text-alignment: center;");

        qrContent.getChildren().addAll(qrIcon, shopLabel);
        viewfinder.getChildren().add(qrContent);

        // Simulated Scan Button
        Button scanBtn = UiUtils.createPrimaryButton("📷 Scan QR Code Now", "");
        scanBtn.setOnAction(e -> {
            SoundUtil.playSuccess();
            showAmountScreen();
        });

        // Or Quick Pre-set Merchant Choices
        HBox presets = new HBox(10);
        presets.setAlignment(Pos.CENTER);
        Label orLbl = new Label("Or practice paying:");
        orLbl.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        Button medPlusBtn = new Button("💊 MedPlus Chemist");
        medPlusBtn.setOnAction(e -> {
            currentMerchant = "MedPlus Chemist & Pharmacy";
            currentUpiId = "medplus@icici";
            SoundUtil.playClick();
            showAmountScreen();
        });

        Button groceryBtn = new Button("🥛 Mother Dairy Milk");
        groceryBtn.setOnAction(e -> {
            currentMerchant = "Mother Dairy Booth #42";
            currentUpiId = "motherdairy@sbi";
            SoundUtil.playClick();
            showAmountScreen();
        });

        presets.getChildren().addAll(orLbl, medPlusBtn, groceryBtn);

        card.getChildren().addAll(heading, desc, viewfinder, scanBtn, presets);
        VBox wrapper = new VBox(card);
        wrapper.setAlignment(Pos.CENTER);
        wrapper.setPadding(new Insets(20));
        workflowContainer.getChildren().add(wrapper);
    }

    private void showAmountScreen() {
        workflowContainer.getChildren().clear();

        VBox card = UiUtils.createCard();
        card.setMaxWidth(680);
        card.setAlignment(Pos.CENTER);
        card.setSpacing(20);

        Label stepLbl = UiUtils.createTitle("Step 2: Verify Merchant & Enter Amount");

        // Merchant Verified Header Card
        HBox merchantCard = new HBox(16);
        merchantCard.setAlignment(Pos.CENTER_LEFT);
        merchantCard.setStyle(
            "-fx-background-color: #E8F5E9;" +
            "-fx-border-color: #C8E6C9;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 16px 20px;"
        );

        Label mIcon = new Label("🏪");
        mIcon.setStyle("-fx-font-size: 32px;");

        VBox mDetails = new VBox(4);
        Label mName = new Label("Paying to: " + currentMerchant);
        mName.setStyle("-fx-font-size: 19px; -fx-font-weight: bold; -fx-text-fill: #1B5E20;");
        Label mUpi = new Label("UPI ID: " + currentUpiId + " • Verified Business ✓");
        mUpi.setStyle("-fx-font-size: 14px; -fx-text-fill: #2E7D32;");
        mDetails.getChildren().addAll(mName, mUpi);
        merchantCard.getChildren().addAll(mIcon, mDetails);

        // Amount Input Row
        HBox amountRow = new HBox(12);
        amountRow.setAlignment(Pos.CENTER);

        Label rupeeSym = new Label("₹");
        rupeeSym.setStyle("-fx-font-size: 36px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        TextField amountField = new TextField("150");
        amountField.setStyle(
            "-fx-font-size: 32px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";" +
            "-fx-background-radius: 12px;" +
            "-fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + ";" +
            "-fx-border-radius: 12px;" +
            "-fx-padding: 8px 16px;" +
            "-fx-pref-width: 180px;" +
            "-fx-alignment: center;"
        );

        amountRow.getChildren().addAll(rupeeSym, amountField);

        // Quick amount chips
        HBox chips = new HBox(10);
        chips.setAlignment(Pos.CENTER);
        for (int val : new int[]{50, 100, 250, 500}) {
            Button chip = new Button("₹" + val);
            chip.setStyle("-fx-font-size: 15px; -fx-background-radius: 16px; -fx-padding: 6px 14px; -fx-cursor: hand;");
            chip.setOnAction(e -> {
                amountField.setText(String.valueOf(val));
                SoundUtil.playClick();
            });
            chips.getChildren().add(chip);
        }

        // Proceed to PIN Button
        Button proceedBtn = UiUtils.createAccentButton("Proceed to Safe PIN Entry →", "");
        proceedBtn.setOnAction(e -> {
            try {
                currentAmount = Integer.parseInt(amountField.getText().trim());
            } catch (Exception ex) {
                currentAmount = 150;
            }
            SoundUtil.playClick();
            showPinScreen();
        });

        Button backBtn = UiUtils.createSecondaryButton("← Scan Different QR", "");
        backBtn.setOnAction(e -> showScanScreen());

        HBox btnRow = new HBox(16, backBtn, proceedBtn);
        btnRow.setAlignment(Pos.CENTER);

        card.getChildren().addAll(stepLbl, merchantCard, amountRow, chips, btnRow);
        VBox wrapper = new VBox(card);
        wrapper.setAlignment(Pos.CENTER);
        wrapper.setPadding(new Insets(20));
        workflowContainer.getChildren().add(wrapper);
    }

    private void showPinScreen() {
        workflowContainer.getChildren().clear();
        pinBuffer.setLength(0);

        VBox card = UiUtils.createCard();
        card.setMaxWidth(600);
        card.setAlignment(Pos.CENTER);
        card.setSpacing(18);

        Label stepLbl = UiUtils.createTitle("Step 3: Enter Your Secret UPI PIN");

        // High Contrast Safety Box
        VBox alertBox = new VBox(6);
        alertBox.setStyle(
            "-fx-background-color: #FFF3CD;" +
            "-fx-border-color: #FFEEBA;" +
            "-fx-border-radius: 10px;" +
            "-fx-background-radius: 10px;" +
            "-fx-padding: 12px 18px;"
        );
        Label a1 = new Label("⚠️ EDUCATIONAL CHECK: You are paying ₹" + currentAmount + " to " + currentMerchant + ".");
        a1.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #856404;");
        Label a2 = new Label("Never speak your PIN out loud. Keep your screen covered.");
        a2.setStyle("-fx-font-size: 14px; -fx-text-fill: #856404;");
        alertBox.getChildren().addAll(a1, a2);

        // PIN display (● ● ● ●)
        pinDisplayLabel = new Label("○ ○ ○ ○");
        pinDisplayLabel.setStyle(
            "-fx-font-size: 32px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";" +
            "-fx-padding: 10px 20px;" +
            "-fx-background-color: #F8F9FA;" +
            "-fx-background-radius: 12px;"
        );

        // Numeric Keypad for PIN
        GridPane pad = new GridPane();
        pad.setAlignment(Pos.CENTER);
        pad.setHgap(14);
        pad.setVgap(12);

        String[] digits = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "✓ Pay"};
        int idx = 0;
        for (int r = 0; r < 4; r++) {
            for (int c = 0; c < 3; c++) {
                String d = digits[idx++];
                Button b = new Button(d);
                b.setPrefSize(90, 60);
                b.setStyle(
                    "-fx-font-size: 18px;" +
                    "-fx-font-weight: bold;" +
                    "-fx-background-color: white;" +
                    "-fx-border-color: #CBD5E1;" +
                    "-fx-border-radius: 10px;" +
                    "-fx-background-radius: 10px;" +
                    "-fx-cursor: hand;"
                );

                if (d.equals("✓ Pay")) {
                    b.setStyle(
                        "-fx-font-size: 16px;" +
                        "-fx-font-weight: bold;" +
                        "-fx-background-color: #28A745;" +
                        "-fx-text-fill: white;" +
                        "-fx-background-radius: 10px;" +
                        "-fx-cursor: hand;"
                    );
                    b.setOnAction(e -> submitPin());
                } else if (d.equals("⌫")) {
                    b.setOnAction(e -> {
                        SoundUtil.playClick();
                        if (pinBuffer.length() > 0) {
                            pinBuffer.deleteCharAt(pinBuffer.length() - 1);
                            updatePinDisplay();
                        }
                    });
                } else {
                    b.setOnAction(e -> {
                        SoundUtil.playClick();
                        if (pinBuffer.length() < 4) {
                            pinBuffer.append(d);
                            updatePinDisplay();
                        }
                    });
                }
                pad.add(b, c, r);
            }
        }

        card.getChildren().addAll(stepLbl, alertBox, pinDisplayLabel, pad);
        VBox wrapper = new VBox(card);
        wrapper.setAlignment(Pos.CENTER);
        wrapper.setPadding(new Insets(20));
        workflowContainer.getChildren().add(wrapper);
    }

    private void updatePinDisplay() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            if (i < pinBuffer.length()) {
                sb.append("● ");
            } else {
                sb.append("○ ");
            }
        }
        pinDisplayLabel.setText(sb.toString().trim());
    }

    private void submitPin() {
        if (pinBuffer.length() < 4) {
            UiUtils.showInfoDialog("PIN Incomplete", "Please enter 4 digits", "In real life, your UPI PIN is 4 or 6 digits long.");
            return;
        }

        // Show animated processing -> Success
        SoundUtil.playSuccess();
        showSuccessScreen();
    }

    private void showSuccessScreen() {
        workflowContainer.getChildren().clear();

        VBox card = UiUtils.createCard();
        card.setMaxWidth(680);
        card.setAlignment(Pos.CENTER);
        card.setSpacing(18);

        Label checkmark = new Label("✅");
        checkmark.setStyle("-fx-font-size: 64px;");

        Label paidLbl = new Label("Payment Successful!");
        paidLbl.setStyle("-fx-font-size: 26px; -fx-font-weight: bold; -fx-text-fill: #28A745;");

        Label amountLbl = new Label("₹" + currentAmount + ".00");
        amountLbl.setStyle("-fx-font-size: 34px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        Label toLbl = new Label("Paid to " + currentMerchant);
        toLbl.setStyle("-fx-font-size: 18px; -fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";");

        // Receipt Card
        VBox receipt = new VBox(8);
        receipt.setStyle(
            "-fx-background-color: #F8F9FA;" +
            "-fx-border-color: #E2E8F0;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 16px 24px;"
        );
        receipt.setMaxWidth(480);

        Label utr = new Label("UPI Transaction ID: UPI/49204810294/P2M (SIMULATED)");
        utr.setStyle("-fx-font-size: 13px; -fx-text-fill: #64748B;");
        Label bankNote = new Label("Debited from: State Bank of India •••• 1042");
        bankNote.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #334155;");
        Label audioBoxNote = new Label("🔊 Shop Soundbox: 'PhonePe par " + currentAmount + " rupaye prapt hue!'");
        audioBoxNote.setStyle("-fx-font-size: 14px; -fx-font-style: italic; -fx-text-fill: #1E3A8A;");

        receipt.getChildren().addAll(utr, bankNote, audioBoxNote);

        // Record to mock history
        mockHistory.add(0, "₹" + currentAmount + " paid to " + currentMerchant + " (Just now)");

        // Finish & practice more buttons
        Button practiceAgainBtn = UiUtils.createPrimaryButton("Practice Another Payment", "🔁");
        practiceAgainBtn.setOnAction(e -> showScanScreen());

        card.getChildren().addAll(checkmark, paidLbl, amountLbl, toLbl, receipt, practiceAgainBtn);

        VBox wrapper = new VBox(card);
        wrapper.setAlignment(Pos.CENTER);
        wrapper.setPadding(new Insets(20));
        workflowContainer.getChildren().add(wrapper);

        ProgressService.getInstance().unlockAchievementDirect(AppConfig.getInstance().getCurrentUser().getId(), "UPI_SMART");
    }
}
