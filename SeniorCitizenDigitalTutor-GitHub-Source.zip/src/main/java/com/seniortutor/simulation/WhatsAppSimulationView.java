package com.seniortutor.simulation;

import com.seniortutor.service.ProgressService;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.animation.PauseTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.util.Duration;

/**
 * Interactive WhatsApp practice simulation.
 * Allows seniors to safely practice texting, photo sharing, voice notes, and video calls.
 */
public class WhatsAppSimulationView extends VBox {

    private final VBox chatMessagesBox = new VBox(12);
    private final ScrollPane scrollPane = new ScrollPane();
    private final TextField messageInput = new TextField();
    private final StackPane mainContainer = new StackPane();
    private VBox videoCallOverlay;
    private Label callTimerLabel;
    private int callSeconds = 0;
    private javafx.animation.Timeline callTimeline;

    public WhatsAppSimulationView() {
        setSpacing(0);
        setStyle("-fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");
        setFillWidth(true);

        // 1. Prominent Safety Disclaimer Banner
        HBox safetyBanner = createSafetyBanner();

        // 2. Main Chat Interface
        VBox chatView = createChatInterface();

        mainContainer.getChildren().add(chatView);
        VBox.setVgrow(mainContainer, Priority.ALWAYS);

        getChildren().addAll(safetyBanner, mainContainer);

        // Seed initial friendly message from daughter
        addMessageBubble("Good morning Maa! How are you feeling today?", false, "09:15 AM");
    }

    private HBox createSafetyBanner() {
        HBox banner = new HBox(12);
        banner.setAlignment(Pos.CENTER);
        banner.setStyle(
            "-fx-background-color: #FFF3CD;" +
            "-fx-border-color: #FFEEBA;" +
            "-fx-border-width: 0 0 2px 0;" +
            "-fx-padding: 10px 20px;"
        );

        Label icon = new Label("🛡️");
        icon.setStyle("-fx-font-size: 20px;");

        Label text = new Label("SAFE PRACTICE SIMULATION: Nothing here sends real messages or makes real calls. Practice fearlessly!");
        text.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #856404;");

        banner.getChildren().addAll(icon, text);
        return banner;
    }

    private VBox createChatInterface() {
        VBox box = new VBox();
        box.setStyle("-fx-background-color: #EFEAE2;");

        // WhatsApp Top Bar
        HBox topBar = new HBox(16);
        topBar.setAlignment(Pos.CENTER_LEFT);
        topBar.setStyle(
            "-fx-background-color: " + UiUtils.COLOR_FOREST_GREEN + ";" +
            "-fx-padding: 12px 20px;"
        );

        Label avatar = new Label("👩");
        avatar.setStyle(
            "-fx-font-size: 24px;" +
            "-fx-background-color: #E0E7E3;" +
            "-fx-background-radius: 30px;" +
            "-fx-padding: 6px 10px;"
        );

        VBox contactInfo = new VBox(2);
        Label nameLbl = new Label("Anita (Daughter)");
        nameLbl.setStyle("-fx-font-size: 19px; -fx-font-weight: bold; -fx-text-fill: white;");
        Label statusLbl = new Label("Online • Family");
        statusLbl.setStyle("-fx-font-size: 13px; -fx-text-fill: #D2E3D8;");
        contactInfo.getChildren().addAll(nameLbl, statusLbl);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Audio Call button
        Button callBtn = new Button("📞 Call");
        styleTopButton(callBtn);
        callBtn.setOnAction(e -> startMockCall(false));

        // Video Call button
        Button videoBtn = new Button("📹 Video Call");
        styleTopButton(videoBtn);
        videoBtn.setStyle(videoBtn.getStyle() + "-fx-background-color: " + UiUtils.COLOR_MUTED_TERRACOTTA + "; -fx-text-fill: white;");
        videoBtn.setOnAction(e -> startMockCall(true));

        topBar.getChildren().addAll(avatar, contactInfo, spacer, callBtn, videoBtn);

        // Scrollable Messages Box
        chatMessagesBox.setPadding(new Insets(20));
        chatMessagesBox.setFillWidth(true);

        scrollPane.setContent(chatMessagesBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        VBox.setVgrow(scrollPane, Priority.ALWAYS);

        // Bottom Message Input Row
        HBox inputBar = createInputBar();

        box.getChildren().addAll(topBar, scrollPane, inputBar);
        VBox.setVgrow(box, Priority.ALWAYS);
        return box;
    }

    private void styleTopButton(Button btn) {
        btn.setStyle(
            "-fx-background-color: rgba(255, 255, 255, 0.15);" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 15px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-radius: 8px;" +
            "-fx-padding: 8px 16px;" +
            "-fx-cursor: hand;"
        );
    }

    private HBox createInputBar() {
        HBox bar = new HBox(12);
        bar.setAlignment(Pos.CENTER);
        bar.setStyle(
            "-fx-background-color: #F0F2F5;" +
            "-fx-padding: 12px 18px;" +
            "-fx-border-color: #D1D7DB;" +
            "-fx-border-width: 1px 0 0 0;"
        );

        // Attach Button (Photos / Location)
        MenuButton attachBtn = new MenuButton("📎");
        attachBtn.setStyle(
            "-fx-font-size: 18px;" +
            "-fx-background-color: white;" +
            "-fx-background-radius: 20px;" +
            "-fx-padding: 6px 12px;" +
            "-fx-cursor: hand;"
        );

        MenuItem photoItem = new MenuItem("📸 Send Photo (Garden Flowers)");
        photoItem.setStyle("-fx-font-size: 15px;");
        photoItem.setOnAction(e -> {
            addMessageBubble("📷 [Sent Photo: Garden Flowers.jpg] 🌺", true, "Just now");
            triggerAutoReply("Such beautiful flowers Maa! 🌺 You take such clear photos now!");
            recordPractice();
        });

        MenuItem locItem = new MenuItem("📍 Share Live Location (Home)");
        locItem.setStyle("-fx-font-size: 15px;");
        locItem.setOnAction(e -> {
            addMessageBubble("📍 Live Location Shared: Home (Active for 1 hour)", true, "Just now");
            triggerAutoReply("Thank you for sharing your location Maa! I can see you are safely at home.");
            recordPractice();
        });

        attachBtn.getItems().addAll(photoItem, locItem);

        // Message text input
        messageInput.setPromptText("Type your message here (e.g. 'I had tea')...");
        messageInput.setStyle(
            "-fx-font-size: 16px;" +
            "-fx-background-color: white;" +
            "-fx-background-radius: 20px;" +
            "-fx-padding: 10px 16px;" +
            "-fx-border-color: #E2E8F0;" +
            "-fx-border-radius: 20px;"
        );
        HBox.setHgrow(messageInput, Priority.ALWAYS);
        messageInput.setOnAction(e -> sendMessage());

        // Voice Note button
        Button voiceNoteBtn = new Button("🎤 Voice");
        voiceNoteBtn.setStyle(
            "-fx-background-color: white;" +
            "-fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";" +
            "-fx-font-size: 15px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-radius: 20px;" +
            "-fx-padding: 8px 14px;" +
            "-fx-cursor: hand;"
        );
        voiceNoteBtn.setOnAction(e -> {
            SoundUtil.playClick();
            addMessageBubble("🎤 Voice message (0:12) ▶ ılıılı", true, "Just now");
            triggerAutoReply("I heard your voice message loud and clear Maa! ❤️");
            recordPractice();
        });

        // Send Button
        Button sendBtn = new Button("➤ Send");
        sendBtn.setStyle(
            "-fx-background-color: #00A884;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 16px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-radius: 20px;" +
            "-fx-padding: 8px 18px;" +
            "-fx-cursor: hand;"
        );
        sendBtn.setOnAction(e -> sendMessage());

        bar.getChildren().addAll(attachBtn, messageInput, voiceNoteBtn, sendBtn);
        return bar;
    }

    private void sendMessage() {
        String txt = messageInput.getText().trim();
        if (txt.isEmpty()) return;

        SoundUtil.playClick();
        addMessageBubble(txt, true, "Just now");
        messageInput.clear();
        recordPractice();

        // Simulate reply from Anita
        triggerAutoReply("Received! I'm so proud of how easily you are texting now! ❤️");
    }

    private void triggerAutoReply(String reply) {
        PauseTransition pt = new PauseTransition(Duration.seconds(1.4));
        pt.setOnFinished(e -> {
            SoundUtil.playSuccess();
            addMessageBubble(reply, false, "Just now");
        });
        pt.play();
    }

    private void addMessageBubble(String text, boolean isUser, String time) {
        HBox row = new HBox();
        row.setAlignment(isUser ? Pos.CENTER_RIGHT : Pos.CENTER_LEFT);

        VBox bubble = new VBox(4);
        bubble.setMaxWidth(480);
        bubble.setStyle(
            (isUser
                ? "-fx-background-color: #D9FDD3; -fx-border-color: #C1E7B8;"
                : "-fx-background-color: white; -fx-border-color: #E2E8F0;") +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 10px 14px;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.06), 4, 0, 0, 1);"
        );

        Label msgLbl = new Label(text);
        msgLbl.setWrapText(true);
        msgLbl.setStyle("-fx-font-size: 16px; -fx-text-fill: #111B21;");

        HBox meta = new HBox(6);
        meta.setAlignment(Pos.BOTTOM_RIGHT);
        Label timeLbl = new Label(time);
        timeLbl.setStyle("-fx-font-size: 12px; -fx-text-fill: #667781;");
        meta.getChildren().add(timeLbl);

        if (isUser) {
            Label ticks = new Label("✓✓");
            ticks.setStyle("-fx-font-size: 12px; -fx-text-fill: #53BDEB; -fx-font-weight: bold;");
            meta.getChildren().add(ticks);
        }

        bubble.getChildren().addAll(msgLbl, meta);
        row.getChildren().add(bubble);
        chatMessagesBox.getChildren().add(row);

        // Scroll to bottom
        scrollPane.layout();
        scrollPane.setVvalue(1.0);
    }

    private void startMockCall(boolean isVideo) {
        SoundUtil.playSuccess();
        videoCallOverlay = new VBox(20);
        videoCallOverlay.setAlignment(Pos.CENTER);
        videoCallOverlay.setStyle(
            "-fx-background-color: rgba(23, 63, 53, 0.95);" +
            "-fx-padding: 40px;"
        );

        Label title = new Label(isVideo ? "📹 WhatsApp Video Call" : "📞 WhatsApp Voice Call");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: white;");

        Label avatarLarge = new Label("👩");
        avatarLarge.setStyle(
            "-fx-font-size: 70px;" +
            "-fx-background-color: white;" +
            "-fx-background-radius: 60px;" +
            "-fx-padding: 10px 20px;"
        );

        Label callerName = new Label("Anita (Daughter)");
        callerName.setStyle("-fx-font-size: 26px; -fx-font-weight: bold; -fx-text-fill: white;");

        callSeconds = 0;
        callTimerLabel = new Label("Connected • 00:00");
        callTimerLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: #A0C2B7;");

        // Timer simulation
        callTimeline = new javafx.animation.Timeline(
            new javafx.animation.KeyFrame(Duration.seconds(1), e -> {
                callSeconds++;
                int mins = callSeconds / 60;
                int secs = callSeconds % 60;
                callTimerLabel.setText(String.format("Connected • %02d:%02d", mins, secs));
            })
        );
        callTimeline.setCycleCount(javafx.animation.Animation.INDEFINITE);
        callTimeline.play();

        Label tip = new Label("💡 Hint: Look straight at your phone's front camera so they can see your smile!");
        tip.setStyle("-fx-font-size: 16px; -fx-text-fill: #FFF3CD; -fx-background-color: rgba(0,0,0,0.3); -fx-padding: 8px 16px; -fx-background-radius: 8px;");

        // Action buttons (Mute, Speaker, End)
        HBox callControls = new HBox(20);
        callControls.setAlignment(Pos.CENTER);

        Button muteBtn = new Button("🎤 Mute");
        muteBtn.setStyle("-fx-font-size: 16px; -fx-background-radius: 12px; -fx-padding: 10px 20px;");

        Button endBtn = new Button("🔴 End Call");
        endBtn.setStyle(
            "-fx-background-color: #DC3545;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 18px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 12px 30px;" +
            "-fx-cursor: hand;"
        );
        endBtn.setOnAction(e -> endMockCall());

        callControls.getChildren().addAll(muteBtn, endBtn);

        videoCallOverlay.getChildren().addAll(title, avatarLarge, callerName, callTimerLabel, tip, callControls);
        mainContainer.getChildren().add(videoCallOverlay);
        recordPractice();
    }

    private void endMockCall() {
        SoundUtil.playClick();
        if (callTimeline != null) {
            callTimeline.stop();
        }
        mainContainer.getChildren().remove(videoCallOverlay);
        addMessageBubble("📞 Call ended (" + callSeconds + " seconds)", true, "Just now");
    }

    private void recordPractice() {
        ProgressService.getInstance().unlockAchievementDirect(AppConfig.getInstance().getCurrentUser().getId(), "WHATSAPP_STAR");
    }
}
