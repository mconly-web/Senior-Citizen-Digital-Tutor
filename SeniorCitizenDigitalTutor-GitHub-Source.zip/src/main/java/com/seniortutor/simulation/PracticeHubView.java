package com.seniortutor.simulation;

import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.*;

/**
 * Interactive Safe Practice Hub allowing senior citizens to switch between
 * simulated WhatsApp, Phone Dialer, UPI Payments, Google Maps, Email,
 * Aadhaar/DigiLocker downloads, and Online Bill Payments.
 */
public class PracticeHubView extends VBox {

    private final StackPane simDisplayArea = new StackPane();
    private Button btnWa;
    private Button btnPhone;
    private Button btnUpi;
    private Button btnMaps;
    private Button btnEmail;
    private Button btnAadhaar;
    private Button btnBill;

    public PracticeHubView() {
        this("WHATSAPP");
    }

    public PracticeHubView(String initialMode) {
        setSpacing(0);
        setStyle("-fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");
        setFillWidth(true);

        // Header & Selector Bar
        VBox topSection = createHeaderAndBar();
        getChildren().add(topSection);

        simDisplayArea.setStyle("-fx-background-color: transparent;");
        VBox.setVgrow(simDisplayArea, Priority.ALWAYS);
        getChildren().add(simDisplayArea);

        selectSimulation(initialMode != null ? initialMode.toUpperCase() : "WHATSAPP");
    }

    private VBox createHeaderAndBar() {
        VBox box = new VBox(12);
        box.setPadding(new Insets(16, 24, 10, 24));

        HBox titleRow = new HBox(12);
        titleRow.setAlignment(Pos.CENTER_LEFT);

        Label title = UiUtils.createTitle("🎮 Safe Practice Sandbox");
        Label subtitle = UiUtils.createSubtitle("Practice messaging, calling, UPI scanning, maps, email, DigiLocker, and bill payments fearlessly.");

        VBox titleCol = new VBox(2, title, subtitle);
        titleRow.getChildren().add(titleCol);

        // Simulation Switcher Buttons inside a scrollable or wrapping bar
        FlowPane switchBar = new FlowPane();
        switchBar.setHgap(10);
        switchBar.setVgap(8);
        switchBar.setAlignment(Pos.CENTER_LEFT);

        btnWa = createSimTabButton("💬 WhatsApp", "WHATSAPP");
        btnPhone = createSimTabButton("📞 Dialer", "PHONE");
        btnUpi = createSimTabButton("💳 UPI Payments", "UPI");
        btnMaps = createSimTabButton("🗺️ Maps & Directions", "MAPS");
        btnEmail = createSimTabButton("📧 Email", "EMAIL");
        btnAadhaar = createSimTabButton("📄 Aadhaar & DigiLocker", "AADHAAR");
        btnBill = createSimTabButton("⚡ Bill Payment", "BILL");

        switchBar.getChildren().addAll(btnWa, btnPhone, btnUpi, btnMaps, btnEmail, btnAadhaar, btnBill);

        box.getChildren().addAll(titleRow, switchBar);
        return box;
    }

    private Button createSimTabButton(String label, String mode) {
        Button btn = new Button(label);
        btn.setStyle(
            "-fx-font-size: 15px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-color: white;" +
            "-fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";" +
            "-fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + ";" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 8px 16px;" +
            "-fx-cursor: hand;"
        );
        btn.setOnAction(e -> {
            SoundUtil.playClick();
            selectSimulation(mode);
        });
        return btn;
    }

    public void selectSimulation(String mode) {
        resetButtonStyles();
        simDisplayArea.getChildren().clear();

        switch (mode) {
            case "PHONE" -> {
                highlightButton(btnPhone);
                simDisplayArea.getChildren().add(new PhoneDialerSimulationView());
            }
            case "UPI" -> {
                highlightButton(btnUpi);
                simDisplayArea.getChildren().add(new UpiPaymentSimulationView());
            }
            case "MAPS" -> {
                highlightButton(btnMaps);
                simDisplayArea.getChildren().add(new MapsSimulationView());
            }
            case "EMAIL" -> {
                highlightButton(btnEmail);
                simDisplayArea.getChildren().add(new EmailSimulationView());
            }
            case "AADHAAR", "DIGILOCKER" -> {
                highlightButton(btnAadhaar);
                simDisplayArea.getChildren().add(new AadhaarDigiLockerSimulationView());
            }
            case "BILL", "BILLPAY", "BILL_PAYMENT", "ELECTRICITY" -> {
                highlightButton(btnBill);
                simDisplayArea.getChildren().add(new OnlineBillPaymentSimulationView());
            }
            default -> {
                highlightButton(btnWa);
                simDisplayArea.getChildren().add(new WhatsAppSimulationView());
            }
        }
    }

    private void resetButtonStyles() {
        String base = "-fx-font-size: 15px; -fx-font-weight: bold; -fx-background-color: white; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + "; -fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + "; -fx-border-radius: 12px; -fx-background-radius: 12px; -fx-padding: 8px 16px; -fx-cursor: hand;";
        if (btnWa != null) btnWa.setStyle(base);
        if (btnPhone != null) btnPhone.setStyle(base);
        if (btnUpi != null) btnUpi.setStyle(base);
        if (btnMaps != null) btnMaps.setStyle(base);
        if (btnEmail != null) btnEmail.setStyle(base);
        if (btnAadhaar != null) btnAadhaar.setStyle(base);
        if (btnBill != null) btnBill.setStyle(base);
    }

    private void highlightButton(Button btn) {
        if (btn == null) return;
        btn.setStyle(
            "-fx-font-size: 15px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-color: " + UiUtils.COLOR_FOREST_GREEN + ";" +
            "-fx-text-fill: white;" +
            "-fx-border-color: " + UiUtils.COLOR_FOREST_GREEN + ";" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 8px 16px;" +
            "-fx-cursor: hand;"
        );
    }
}
