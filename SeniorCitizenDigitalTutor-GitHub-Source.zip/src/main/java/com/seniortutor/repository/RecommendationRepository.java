package com.seniortutor.repository;

import com.seniortutor.database.DatabaseManager;
import com.seniortutor.model.Recommendation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class RecommendationRepository {

    public List<Recommendation> getActiveRecommendations(int seniorUserId) {
        List<Recommendation> list = new ArrayList<>();
        String sql = """
            SELECT r.id, r.senior_user_id, r.helper_user_id, r.lesson_id, r.note, r.is_completed, r.created_at,
                   l.title AS lesson_title, c.icon AS cat_icon
            FROM recommendations r
            JOIN lessons l ON r.lesson_id = l.id
            JOIN categories c ON l.category_id = c.id
            WHERE r.senior_user_id = ? AND r.is_completed = 0
            ORDER BY r.id DESC;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, seniorUserId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Recommendation rec = new Recommendation(
                        rs.getInt("id"),
                        rs.getInt("senior_user_id"),
                        rs.getInt("helper_user_id"),
                        rs.getInt("lesson_id"),
                        rs.getString("note"),
                        rs.getInt("is_completed") == 1,
                        null
                    );
                    rec.setLessonTitle(rs.getString("lesson_title"));
                    rec.setCategoryIcon(rs.getString("cat_icon"));
                    list.add(rec);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void addRecommendation(int seniorUserId, int helperUserId, int lessonId, String note) {
        String sql = """
            INSERT INTO recommendations (senior_user_id, helper_user_id, lesson_id, note, is_completed)
            VALUES (?, ?, ?, ?, 0);
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, seniorUserId);
            ps.setInt(2, helperUserId);
            ps.setInt(3, lessonId);
            ps.setString(4, note);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void markCompleted(int recommendationId) {
        String sql = "UPDATE recommendations SET is_completed = 1 WHERE id = ?";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, recommendationId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
