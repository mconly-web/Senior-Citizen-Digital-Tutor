package com.seniortutor.repository;

import com.seniortutor.database.DatabaseManager;
import com.seniortutor.model.QuizOption;
import com.seniortutor.model.QuizQuestion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class QuizRepository {

    public List<QuizQuestion> getQuizQuestionsForLesson(int lessonId) {
        List<QuizQuestion> questions = new ArrayList<>();
        String sql = """
            SELECT id, lesson_id, question_text, question_text_hi, question_text_mr,
                   explanation, explanation_hi, explanation_mr
            FROM quiz_questions
            WHERE lesson_id = ?
            ORDER BY id ASC;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, lessonId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    QuizQuestion q = new QuizQuestion(
                        rs.getInt("id"),
                        rs.getInt("lesson_id"),
                        rs.getString("question_text"),
                        rs.getString("explanation")
                    );
                    try {
                        q.setQuestionTextHi(rs.getString("question_text_hi"));
                        q.setQuestionTextMr(rs.getString("question_text_mr"));
                        q.setExplanationHi(rs.getString("explanation_hi"));
                        q.setExplanationMr(rs.getString("explanation_mr"));
                    } catch (Exception ignored) {}
                    q.setOptions(getOptionsForQuestion(q.getId()));
                    questions.add(q);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return questions;
    }

    private List<QuizOption> getOptionsForQuestion(int questionId) {
        List<QuizOption> options = new ArrayList<>();
        String sql = """
            SELECT id, question_id, option_text, option_text_hi, option_text_mr, is_correct
            FROM quiz_options
            WHERE question_id = ?
            ORDER BY id ASC;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, questionId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    QuizOption opt = new QuizOption(
                        rs.getInt("id"),
                        rs.getInt("question_id"),
                        rs.getString("option_text"),
                        rs.getInt("is_correct") == 1
                    );
                    try {
                        opt.setOptionTextHi(rs.getString("option_text_hi"));
                        opt.setOptionTextMr(rs.getString("option_text_mr"));
                    } catch (Exception ignored) {}
                    options.add(opt);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return options;
    }
}
