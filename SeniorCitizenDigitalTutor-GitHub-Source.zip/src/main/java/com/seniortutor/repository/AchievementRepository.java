package com.seniortutor.repository;

import com.seniortutor.database.DatabaseManager;
import com.seniortutor.model.Achievement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class AchievementRepository {

    public List<Achievement> getAllAchievements(int userId) {
        List<Achievement> list = new ArrayList<>();
        String sql = """
            SELECT a.id, a.code, a.title, a.description, a.icon, a.req_type, a.req_value,
                   CASE WHEN ua.achievement_id IS NOT NULL THEN 1 ELSE 0 END AS is_unlocked,
                   ua.unlocked_at
            FROM achievements a
            LEFT JOIN user_achievements ua ON a.id = ua.achievement_id AND ua.user_id = ?
            ORDER BY a.id ASC;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Achievement ach = new Achievement(
                        rs.getInt("id"),
                        rs.getString("code"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getString("icon"),
                        rs.getString("req_type"),
                        rs.getInt("req_value")
                    );
                    ach.setUnlocked(rs.getInt("is_unlocked") == 1);
                    list.add(ach);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean unlockAchievement(int userId, String code) {
        String sql = """
            INSERT OR IGNORE INTO user_achievements (user_id, achievement_id, unlocked_at)
            SELECT ?, id, CURRENT_TIMESTAMP FROM achievements WHERE code = ?;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setString(2, code);
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
