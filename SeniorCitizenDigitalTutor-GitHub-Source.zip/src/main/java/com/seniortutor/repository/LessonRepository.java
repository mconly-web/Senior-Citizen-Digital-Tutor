package com.seniortutor.repository;

import com.seniortutor.database.DatabaseManager;
import com.seniortutor.model.Lesson;
import com.seniortutor.model.LessonStep;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class LessonRepository {

    public List<Lesson> getLessonsByCategory(int categoryId, int userId) {
        List<Lesson> list = new ArrayList<>();
        String sql = """
            SELECT l.id, l.category_id, l.title, l.title_hi, l.title_mr,
                   l.description, l.description_hi, l.description_mr,
                   l.difficulty, l.estimated_minutes, l.practice_type, l.order_index,
                   l.recap, l.recap_hi, l.recap_mr,
                   c.name AS cat_name, c.icon AS cat_icon,
                   COALESCE(up.is_completed, 0) AS is_completed,
                   COALESCE(up.last_step, 1) AS last_step,
                   COALESCE(up.quiz_score, 0) AS quiz_score
            FROM lessons l
            JOIN categories c ON l.category_id = c.id
            LEFT JOIN user_progress up ON l.id = up.lesson_id AND up.user_id = ?
            WHERE l.category_id = ?
            ORDER BY l.order_index ASC;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, categoryId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Lesson lesson = extractLesson(rs);
                    list.add(lesson);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public Lesson getLessonById(int lessonId, int userId) {
        String sql = """
            SELECT l.id, l.category_id, l.title, l.title_hi, l.title_mr,
                   l.description, l.description_hi, l.description_mr,
                   l.difficulty, l.estimated_minutes, l.practice_type, l.order_index,
                   l.recap, l.recap_hi, l.recap_mr,
                   c.name AS cat_name, c.icon AS cat_icon,
                   COALESCE(up.is_completed, 0) AS is_completed,
                   COALESCE(up.last_step, 1) AS last_step,
                   COALESCE(up.quiz_score, 0) AS quiz_score
            FROM lessons l
            JOIN categories c ON l.category_id = c.id
            LEFT JOIN user_progress up ON l.id = up.lesson_id AND up.user_id = ?
            WHERE l.id = ?;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, lessonId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Lesson lesson = extractLesson(rs);
                    lesson.setSteps(getLessonSteps(lessonId));
                    return lesson;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<LessonStep> getLessonSteps(int lessonId) {
        List<LessonStep> steps = new ArrayList<>();
        String sql = """
            SELECT id, lesson_id, step_number, title, title_hi, title_mr,
                   explanation, explanation_hi, explanation_mr,
                   visual_type, visual_data, voice_text, voice_text_hi, voice_text_mr
            FROM lesson_steps
            WHERE lesson_id = ?
            ORDER BY step_number ASC;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, lessonId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    LessonStep step = new LessonStep(
                        rs.getInt("id"),
                        rs.getInt("lesson_id"),
                        rs.getInt("step_number"),
                        rs.getString("title"),
                        rs.getString("explanation"),
                        rs.getString("visual_type"),
                        rs.getString("visual_data"),
                        rs.getString("voice_text")
                    );
                    try {
                        step.setTitleHi(rs.getString("title_hi"));
                        step.setTitleMr(rs.getString("title_mr"));
                        step.setExplanationHi(rs.getString("explanation_hi"));
                        step.setExplanationMr(rs.getString("explanation_mr"));
                        step.setVoiceTextHi(rs.getString("voice_text_hi"));
                        step.setVoiceTextMr(rs.getString("voice_text_mr"));
                    } catch (Exception ignored) {}
                    steps.add(step);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return steps;
    }

    public Lesson getLatestUnfinishedLesson(int userId) {
        String sqlInProgress = """
            SELECT l.id, l.category_id, l.title, l.title_hi, l.title_mr,
                   l.description, l.description_hi, l.description_mr,
                   l.difficulty, l.estimated_minutes, l.practice_type, l.order_index,
                   l.recap, l.recap_hi, l.recap_mr,
                   c.name AS cat_name, c.icon AS cat_icon,
                   up.is_completed, up.last_step, up.quiz_score
            FROM user_progress up
            JOIN lessons l ON up.lesson_id = l.id
            JOIN categories c ON l.category_id = c.id
            WHERE up.user_id = ? AND up.is_completed = 0
            ORDER BY up.id DESC
            LIMIT 1;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sqlInProgress)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Lesson lesson = extractLesson(rs);
                    lesson.setSteps(getLessonSteps(lesson.getId()));
                    return lesson;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        String sqlNextUnstarted = """
            SELECT l.id, l.category_id, l.title, l.title_hi, l.title_mr,
                   l.description, l.description_hi, l.description_mr,
                   l.difficulty, l.estimated_minutes, l.practice_type, l.order_index,
                   l.recap, l.recap_hi, l.recap_mr,
                   c.name AS cat_name, c.icon AS cat_icon,
                   0 AS is_completed, 1 AS last_step, 0 AS quiz_score
            FROM lessons l
            JOIN categories c ON l.category_id = c.id
            WHERE l.id NOT IN (
                SELECT lesson_id FROM user_progress WHERE user_id = ? AND is_completed = 1
            )
            ORDER BY c.display_order ASC, l.order_index ASC
            LIMIT 1;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sqlNextUnstarted)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Lesson lesson = extractLesson(rs);
                    lesson.setSteps(getLessonSteps(lesson.getId()));
                    return lesson;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return getLessonById(1, userId);
    }

    public List<Lesson> searchLessons(String query, int userId) {
        List<Lesson> list = new ArrayList<>();
        String pattern = "%" + query.toLowerCase().trim() + "%";
        String sql = """
            SELECT DISTINCT l.id, l.category_id, l.title, l.title_hi, l.title_mr,
                            l.description, l.description_hi, l.description_mr,
                            l.difficulty, l.estimated_minutes, l.practice_type, l.order_index,
                            l.recap, l.recap_hi, l.recap_mr,
                            c.name AS cat_name, c.icon AS cat_icon,
                            COALESCE(up.is_completed, 0) AS is_completed,
                            COALESCE(up.last_step, 1) AS last_step,
                            COALESCE(up.quiz_score, 0) AS quiz_score
            FROM lessons l
            JOIN categories c ON l.category_id = c.id
            LEFT JOIN lesson_steps ls ON l.id = ls.lesson_id
            LEFT JOIN user_progress up ON l.id = up.lesson_id AND up.user_id = ?
            WHERE LOWER(l.title) LIKE ?
               OR LOWER(COALESCE(l.title_hi, '')) LIKE ?
               OR LOWER(COALESCE(l.title_mr, '')) LIKE ?
               OR LOWER(l.description) LIKE ?
               OR LOWER(c.name) LIKE ?
               OR LOWER(ls.title) LIKE ?
               OR LOWER(ls.explanation) LIKE ?
            ORDER BY l.id ASC;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setString(2, pattern);
            ps.setString(3, pattern);
            ps.setString(4, pattern);
            ps.setString(5, pattern);
            ps.setString(6, pattern);
            ps.setString(7, pattern);
            ps.setString(8, pattern);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(extractLesson(rs));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    private Lesson extractLesson(ResultSet rs) throws Exception {
        Lesson l = new Lesson(
            rs.getInt("id"),
            rs.getInt("category_id"),
            rs.getString("title"),
            rs.getString("description"),
            rs.getString("difficulty"),
            rs.getInt("estimated_minutes"),
            rs.getString("practice_type"),
            rs.getInt("order_index")
        );
        l.setCategoryName(rs.getString("cat_name"));
        l.setCategoryIcon(rs.getString("cat_icon"));
        l.setCompleted(rs.getInt("is_completed") == 1);
        l.setLastCompletedStep(rs.getInt("last_step"));
        l.setQuizScore(rs.getInt("quiz_score"));
        try {
            l.setTitleHi(rs.getString("title_hi"));
            l.setTitleMr(rs.getString("title_mr"));
            l.setDescriptionHi(rs.getString("description_hi"));
            l.setDescriptionMr(rs.getString("description_mr"));
            l.setRecap(rs.getString("recap"));
            l.setRecapHi(rs.getString("recap_hi"));
            l.setRecapMr(rs.getString("recap_mr"));
        } catch (Exception ignored) {}
        return l;
    }
}
