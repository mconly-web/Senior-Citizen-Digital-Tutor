package com.seniortutor.repository;

import com.seniortutor.database.DatabaseManager;
import com.seniortutor.model.AppSettings;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SettingsRepository {

    public AppSettings getSettingsForUser(int userId) {
        String sql = """
            SELECT user_id, font_scale, high_contrast, voice_enabled, sound_effects, reduced_animations,
                   language, speech_rate, helper_pin, emergency_blood_group, emergency_medications,
                   contact1_name, contact1_phone, contact2_name, contact2_phone, doctor_name, doctor_phone
            FROM settings
            WHERE user_id = ?;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    AppSettings s = new AppSettings();
                    s.setUserId(rs.getInt("user_id"));
                    s.setFontScale(rs.getDouble("font_scale"));
                    s.setHighContrast(rs.getInt("high_contrast") == 1);
                    s.setVoiceEnabled(rs.getInt("voice_enabled") == 1);
                    s.setSoundEffects(rs.getInt("sound_effects") == 1);
                    s.setReducedAnimations(rs.getInt("reduced_animations") == 1);
                    s.setLanguage(rs.getString("language"));
                    s.setSpeechRate(rs.getDouble("speech_rate"));
                    s.setHelperPin(rs.getString("helper_pin") != null ? rs.getString("helper_pin") : "");
                    s.setEmergencyBloodGroup(rs.getString("emergency_blood_group") != null ? rs.getString("emergency_blood_group") : "O+");
                    s.setEmergencyMedications(rs.getString("emergency_medications") != null ? rs.getString("emergency_medications") : "");
                    s.setEmergencyContact1Name(rs.getString("contact1_name"));
                    s.setEmergencyContact1Phone(rs.getString("contact1_phone"));
                    s.setEmergencyContact2Name(rs.getString("contact2_name"));
                    s.setEmergencyContact2Phone(rs.getString("contact2_phone"));
                    s.setDoctorName(rs.getString("doctor_name"));
                    s.setDoctorPhone(rs.getString("doctor_phone"));
                    return s;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Return default if not found
        AppSettings def = new AppSettings();
        def.setUserId(userId);
        return def;
    }

    public void saveSettings(AppSettings s) {
        String sql = """
            INSERT INTO settings (user_id, font_scale, high_contrast, voice_enabled, sound_effects,
                                  reduced_animations, language, speech_rate, helper_pin,
                                  emergency_blood_group, emergency_medications,
                                  contact1_name, contact1_phone, contact2_name, contact2_phone, doctor_name, doctor_phone)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                font_scale = excluded.font_scale,
                high_contrast = excluded.high_contrast,
                voice_enabled = excluded.voice_enabled,
                sound_effects = excluded.sound_effects,
                reduced_animations = excluded.reduced_animations,
                language = excluded.language,
                speech_rate = excluded.speech_rate,
                helper_pin = excluded.helper_pin,
                emergency_blood_group = excluded.emergency_blood_group,
                emergency_medications = excluded.emergency_medications,
                contact1_name = excluded.contact1_name,
                contact1_phone = excluded.contact1_phone,
                contact2_name = excluded.contact2_name,
                contact2_phone = excluded.contact2_phone,
                doctor_name = excluded.doctor_name,
                doctor_phone = excluded.doctor_phone;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, s.getUserId());
            ps.setDouble(2, s.getFontScale());
            ps.setInt(3, s.isHighContrast() ? 1 : 0);
            ps.setInt(4, s.isVoiceEnabled() ? 1 : 0);
            ps.setInt(5, s.isSoundEffects() ? 1 : 0);
            ps.setInt(6, s.isReducedAnimations() ? 1 : 0);
            ps.setString(7, s.getLanguage());
            ps.setDouble(8, s.getSpeechRate());
            ps.setString(9, s.getHelperPin());
            ps.setString(10, s.getEmergencyBloodGroup());
            ps.setString(11, s.getEmergencyMedications());
            ps.setString(12, s.getEmergencyContact1Name());
            ps.setString(13, s.getEmergencyContact1Phone());
            ps.setString(14, s.getEmergencyContact2Name());
            ps.setString(15, s.getEmergencyContact2Phone());
            ps.setString(16, s.getDoctorName());
            ps.setString(17, s.getDoctorPhone());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
