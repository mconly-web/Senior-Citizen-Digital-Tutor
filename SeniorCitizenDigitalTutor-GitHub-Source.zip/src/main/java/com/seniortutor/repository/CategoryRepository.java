package com.seniortutor.repository;

import com.seniortutor.database.DatabaseManager;
import com.seniortutor.model.Category;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CategoryRepository {

    public List<Category> getAllCategories(int userId) {
        List<Category> list = new ArrayList<>();
        String sql = """
            SELECT c.id, c.name, c.name_hi, c.name_mr, c.icon, c.description, c.description_hi, c.description_mr, c.display_order,
                   COUNT(DISTINCT l.id) AS total_lessons,
                   COUNT(DISTINCT CASE WHEN up.is_completed = 1 THEN up.lesson_id END) AS completed_lessons
            FROM categories c
            LEFT JOIN lessons l ON c.id = l.category_id
            LEFT JOIN user_progress up ON l.id = up.lesson_id AND up.user_id = ?
            GROUP BY c.id
            ORDER BY c.display_order ASC;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(extractCategory(rs));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public Category getCategoryById(int id, int userId) {
        String sql = """
            SELECT c.id, c.name, c.name_hi, c.name_mr, c.icon, c.description, c.description_hi, c.description_mr, c.display_order,
                   COUNT(DISTINCT l.id) AS total_lessons,
                   COUNT(DISTINCT CASE WHEN up.is_completed = 1 THEN up.lesson_id END) AS completed_lessons
            FROM categories c
            LEFT JOIN lessons l ON c.id = l.category_id
            LEFT JOIN user_progress up ON l.id = up.lesson_id AND up.user_id = ?
            WHERE c.id = ?
            GROUP BY c.id;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return extractCategory(rs);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private Category extractCategory(ResultSet rs) throws Exception {
        Category cat = new Category(
            rs.getInt("id"),
            rs.getString("name"),
            rs.getString("icon"),
            rs.getString("description"),
            rs.getInt("display_order")
        );
        cat.setLessonCount(rs.getInt("total_lessons"));
        cat.setCompletedLessonCount(rs.getInt("completed_lessons"));
        try {
            cat.setNameHi(rs.getString("name_hi"));
            cat.setNameMr(rs.getString("name_mr"));
            cat.setDescriptionHi(rs.getString("description_hi"));
            cat.setDescriptionMr(rs.getString("description_mr"));
        } catch (Exception ignored) {}
        return cat;
    }
}
