package com.seniortutor.repository;

import com.seniortutor.database.DatabaseManager;
import com.seniortutor.model.UserProgress;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;

public class ProgressRepository {

    public void updateStepProgress(int userId, int lessonId, int currentStep) {
        String sql = """
            INSERT INTO user_progress (user_id, lesson_id, last_step)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id, lesson_id)
            DO UPDATE SET last_step = MAX(last_step, excluded.last_step);
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, lessonId);
            ps.setInt(3, currentStep);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void markLessonCompleted(int userId, int lessonId) {
        String sql = """
            INSERT INTO user_progress (user_id, lesson_id, is_completed, completed_at)
            VALUES (?, ?, 1, CURRENT_TIMESTAMP)
            ON CONFLICT(user_id, lesson_id)
            DO UPDATE SET is_completed = 1, completed_at = CURRENT_TIMESTAMP;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, lessonId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void recordQuizResult(int userId, int lessonId, int score, boolean passed) {
        String sql = """
            INSERT INTO user_progress (user_id, lesson_id, quiz_score, quiz_passed)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id, lesson_id)
            DO UPDATE SET quiz_score = MAX(quiz_score, excluded.quiz_score),
                          quiz_passed = CASE WHEN excluded.quiz_passed = 1 THEN 1 ELSE quiz_passed END;
        """;

        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, lessonId);
            ps.setInt(3, score);
            ps.setInt(4, passed ? 1 : 0);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int getCompletedLessonsCount(int userId) {
        String sql = "SELECT COUNT(*) FROM user_progress WHERE user_id = ? AND is_completed = 1";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int getTotalLessonsCount() {
        String sql = "SELECT COUNT(*) FROM lessons";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public double getAverageQuizScore(int userId) {
        String sql = "SELECT AVG(quiz_score) FROM user_progress WHERE user_id = ? AND quiz_score > 0";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getDouble(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0.0;
    }

    public int getWeeklyCompletedCount(int userId) {
        String sql = "SELECT COUNT(*) FROM user_progress WHERE user_id = ? AND is_completed = 1 AND (completed_at >= datetime('now', '-7 days') OR completed_at IS NOT NULL)";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int getUserStreak(int userId) {
        String sql = "SELECT current_streak FROM users WHERE id = ?";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return Math.max(1, rs.getInt(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 1;
    }

    public void resetUserProgress(int userId) {
        try (Connection conn = DatabaseManager.getInstance().getConnection()) {
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM user_progress WHERE user_id = ?")) {
                ps.setInt(1, userId);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM user_achievements WHERE user_id = ?")) {
                ps.setInt(1, userId);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM safety_logs WHERE user_id = ?")) {
                ps.setInt(1, userId);
                ps.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
