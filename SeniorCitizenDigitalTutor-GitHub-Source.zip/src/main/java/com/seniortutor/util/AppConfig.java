package com.seniortutor.util;

import com.seniortutor.model.AppSettings;
import com.seniortutor.model.User;
import com.seniortutor.repository.SettingsRepository;
import com.seniortutor.repository.UserRepository;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Global configuration and state management for active user, font scale, theme,
 * and first-run detection.
 */
public class AppConfig {
    private static AppConfig instance;
    private final UserRepository userRepository = new UserRepository();
    private final SettingsRepository settingsRepository = new SettingsRepository();

    private User currentUser;
    private AppSettings currentSettings;
    private final List<Consumer<AppSettings>> settingsListeners = new ArrayList<>();
    private final List<Consumer<User>> userListeners = new ArrayList<>();

    private AppConfig() {
        // Default to Senior User (ID 1)
        this.currentUser = userRepository.getUserById(1);
        if (this.currentUser == null) {
            this.currentUser = new User(1, "Shanti Sharma", "SENIOR", "👵", 3, null);
        }
        this.currentSettings = settingsRepository.getSettingsForUser(currentUser.getId());
    }

    public static synchronized AppConfig getInstance() {
        if (instance == null) {
            instance = new AppConfig();
        }
        return instance;
    }

    public boolean isFirstRun() {
        File f = new File("database/.onboarded");
        return !f.exists();
    }

    public void setFirstRunCompleted() {
        try {
            File dbDir = new File("database");
            if (!dbDir.exists()) dbDir.mkdirs();
            new File("database/.onboarded").createNewFile();
        } catch (Exception ignored) {}
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User user) {
        this.currentUser = user;
        this.currentSettings = settingsRepository.getSettingsForUser(user.getId());
        notifyUserListeners();
        notifySettingsListeners();
    }

    public AppSettings getCurrentSettings() {
        return currentSettings;
    }

    public void saveCurrentSettings(AppSettings settings) {
        this.currentSettings = settings;
        settingsRepository.saveSettings(settings);
        notifySettingsListeners();
    }

    public void addSettingsListener(Consumer<AppSettings> listener) {
        this.settingsListeners.add(listener);
    }

    public void addUserListener(Consumer<User> listener) {
        this.userListeners.add(listener);
    }

    private void notifySettingsListeners() {
        for (Consumer<AppSettings> l : settingsListeners) {
            l.accept(currentSettings);
        }
    }

    private void notifyUserListeners() {
        for (Consumer<User> l : userListeners) {
            l.accept(currentUser);
        }
    }
}
