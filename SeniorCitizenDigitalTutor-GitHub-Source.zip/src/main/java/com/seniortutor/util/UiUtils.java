package com.seniortutor.util;

import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

/**
 * Senior-Friendly UI utilities adhering strictly to the warm cream, forest green,
 * and muted terracotta design palette with minimum 48px touch targets and high-visibility typography.
 */
public class UiUtils {

    // Warm, respectful, senior-friendly color palette
    public static final String COLOR_WARM_CREAM = "#FAF8F5";
    public static final String COLOR_CREAM_LIGHT = "#F4EFE6";
    public static final String COLOR_FOREST_GREEN = "#173F35";
    public static final String COLOR_FOREST_HOVER = "#1E5044";
    public static final String COLOR_SOFT_SAGE = "#6F8068";
    public static final String COLOR_MUTED_TERRACOTTA = "#C97855";
    public static final String COLOR_TERRACOTTA_HOVER = "#B86744";
    public static final String COLOR_MUTED_GOLD = "#D6A84F";
    public static final String COLOR_CHARCOAL = "#2C3E35";

    public static Button createPrimaryButton(String text, String icon) {
        Button btn = new Button((icon != null && !icon.isEmpty() ? icon + "  " : "") + text);
        btn.setStyle(
            "-fx-background-color: " + COLOR_FOREST_GREEN + ";" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 17px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 12px 24px;" +
            "-fx-cursor: hand;"
        );
        btn.setMinHeight(52);

        btn.setOnMouseEntered(e -> btn.setStyle(
            "-fx-background-color: " + COLOR_FOREST_HOVER + ";" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 17px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 12px 24px;" +
            "-fx-cursor: hand;"
        ));

        btn.setOnMouseExited(e -> btn.setStyle(
            "-fx-background-color: " + COLOR_FOREST_GREEN + ";" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 17px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 12px 24px;" +
            "-fx-cursor: hand;"
        ));

        btn.setOnAction(e -> SoundUtil.playClick());
        return btn;
    }

    public static Button createSecondaryButton(String text, String icon) {
        Button btn = new Button((icon != null && !icon.isEmpty() ? icon + "  " : "") + text);
        btn.setStyle(
            "-fx-background-color: white;" +
            "-fx-text-fill: " + COLOR_FOREST_GREEN + ";" +
            "-fx-font-size: 17px;" +
            "-fx-font-weight: bold;" +
            "-fx-border-color: " + COLOR_SOFT_SAGE + ";" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 12px 24px;" +
            "-fx-cursor: hand;"
        );
        btn.setMinHeight(52);

        btn.setOnMouseEntered(e -> btn.setStyle(
            "-fx-background-color: " + COLOR_CREAM_LIGHT + ";" +
            "-fx-text-fill: " + COLOR_FOREST_GREEN + ";" +
            "-fx-font-size: 17px;" +
            "-fx-font-weight: bold;" +
            "-fx-border-color: " + COLOR_FOREST_GREEN + ";" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 12px 24px;" +
            "-fx-cursor: hand;"
        ));

        btn.setOnMouseExited(e -> btn.setStyle(
            "-fx-background-color: white;" +
            "-fx-text-fill: " + COLOR_FOREST_GREEN + ";" +
            "-fx-font-size: 17px;" +
            "-fx-font-weight: bold;" +
            "-fx-border-color: " + COLOR_SOFT_SAGE + ";" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 12px 24px;" +
            "-fx-cursor: hand;"
        ));

        btn.setOnAction(e -> SoundUtil.playClick());
        return btn;
    }

    public static Button createAccentButton(String text, String icon) {
        Button btn = new Button((icon != null && !icon.isEmpty() ? icon + "  " : "") + text);
        btn.setStyle(
            "-fx-background-color: " + COLOR_MUTED_TERRACOTTA + ";" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 17px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 12px 24px;" +
            "-fx-cursor: hand;"
        );
        btn.setMinHeight(52);

        btn.setOnMouseEntered(e -> btn.setStyle(
            "-fx-background-color: " + COLOR_TERRACOTTA_HOVER + ";" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 17px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 12px 24px;" +
            "-fx-cursor: hand;"
        ));

        btn.setOnMouseExited(e -> btn.setStyle(
            "-fx-background-color: " + COLOR_MUTED_TERRACOTTA + ";" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 17px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 12px 24px;" +
            "-fx-cursor: hand;"
        ));

        btn.setOnAction(e -> SoundUtil.playClick());
        return btn;
    }

    public static VBox createCard() {
        VBox card = new VBox();
        card.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 16px;" +
            "-fx-border-color: rgba(111, 128, 104, 0.25);" +
            "-fx-border-width: 1.5px;" +
            "-fx-border-radius: 16px;" +
            "-fx-padding: 24px;"
        );
        DropShadow shadow = new DropShadow();
        shadow.setColor(Color.rgb(23, 63, 53, 0.08));
        shadow.setRadius(12);
        shadow.setOffsetY(4);
        card.setEffect(shadow);
        return card;
    }

    public static Label createTitle(String text) {
        Label lbl = new Label(text);
        lbl.setStyle(
            "-fx-font-size: 26px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + COLOR_FOREST_GREEN + ";"
        );
        return lbl;
    }

    public static Label createSubtitle(String text) {
        Label lbl = new Label(text);
        lbl.setStyle(
            "-fx-font-size: 17px;" +
            "-fx-text-fill: " + COLOR_CHARCOAL + ";" +
            "-fx-opacity: 0.85;"
        );
        return lbl;
    }

    public static void showInfoDialog(String title, String header, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(message);
        alert.getDialogPane().setStyle("-fx-font-size: 16px; -fx-padding: 16px;");
        alert.showAndWait();
    }

    public static void showErrorDialog(String title, String header, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(message);
        alert.getDialogPane().setStyle("-fx-font-size: 16px; -fx-padding: 16px;");
        alert.showAndWait();
    }

    public static void showWarningDialog(String title, String header, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(message);
        alert.getDialogPane().setStyle("-fx-font-size: 16px; -fx-padding: 16px;");
        alert.showAndWait();
    }
}
