package com.seniortutor.util;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import java.awt.Toolkit;

/**
 * Utility for friendly acoustic feedback (button click, success chime, warning beep).
 * Completely offline and self-contained.
 */
public class SoundUtil {

    public static void playClick() {
        if (!isSoundEnabled()) return;
        new Thread(() -> playTone(440, 50, 0.2)).start(); // Gentle pleasant click
    }

    public static void playSuccess() {
        if (!isSoundEnabled()) return;
        new Thread(() -> {
            playTone(523, 100, 0.3); // C5
            try { Thread.sleep(60); } catch (InterruptedException ignored) {}
            playTone(659, 120, 0.3); // E5
            try { Thread.sleep(60); } catch (InterruptedException ignored) {}
            playTone(784, 180, 0.4); // G5
        }).start();
    }

    public static void playWarning() {
        if (!isSoundEnabled()) return;
        new Thread(() -> {
            playTone(280, 150, 0.4);
            try { Thread.sleep(80); } catch (InterruptedException ignored) {}
            playTone(240, 200, 0.4);
        }).start();
    }

    private static boolean isSoundEnabled() {
        try {
            return AppConfig.getInstance().getCurrentSettings().isSoundEffects();
        } catch (Exception e) {
            return true;
        }
    }

    private static void playTone(int hz, int msecs, double vol) {
        try {
            byte[] buf = new byte[msecs * 8];
            for (int i = 0; i < buf.length; i++) {
                double angle = i / (8000.0 / hz) * 2.0 * Math.PI;
                buf[i] = (byte) (Math.sin(angle) * 127.0 * vol);
            }
            AudioFormat af = new AudioFormat(8000f, 8, 1, true, false);
            SourceDataLine sdl = AudioSystem.getSourceDataLine(af);
            sdl.open(af);
            sdl.start();
            sdl.write(buf, 0, buf.length);
            sdl.drain();
            sdl.close();
        } catch (Exception e) {
            // Fallback to system beep
            try {
                Toolkit.getDefaultToolkit().beep();
            } catch (Exception ignored) {}
        }
    }
}
