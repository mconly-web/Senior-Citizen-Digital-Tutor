package com.seniortutor.model;

import java.time.LocalDateTime;

/**
 * Represents an unlockable milestone/badge.
 */
public class Achievement {
    private int id;
    private String code;
    private String title;
    private String description;
    private String icon;
    private String requirementType; // "LESSON_COUNT", "CATEGORY_COMPLETE", "PERFECT_QUIZ", "SAFETY_CHECK", "PRACTICE"
    private int requirementValue;
    private boolean unlocked;
    private LocalDateTime unlockedAt;

    public Achievement() {}

    public Achievement(int id, String code, String title, String description, String icon,
                       String requirementType, int requirementValue) {
        this.id = id;
        this.code = code;
        this.title = title;
        this.description = description;
        this.icon = icon;
        this.requirementType = requirementType;
        this.requirementValue = requirementValue;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }

    public String getRequirementType() { return requirementType; }
    public void setRequirementType(String requirementType) { this.requirementType = requirementType; }

    public int getRequirementValue() { return requirementValue; }
    public void setRequirementValue(int requirementValue) { this.requirementValue = requirementValue; }

    public boolean isUnlocked() { return unlocked; }
    public void setUnlocked(boolean unlocked) { this.unlocked = unlocked; }

    public LocalDateTime getUnlockedAt() { return unlockedAt; }
    public void setUnlockedAt(LocalDateTime unlockedAt) { this.unlockedAt = unlockedAt; }
}
