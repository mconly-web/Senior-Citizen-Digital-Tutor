package com.seniortutor.model;

/**
 * Represents a single step within a lesson.
 */
public class LessonStep {
    private int id;
    private int lessonId;
    private int stepNumber;
    private String title;
    private String titleHi;
    private String titleMr;
    private String explanation;
    private String explanationHi;
    private String explanationMr;
    private String visualType; // "PHONE_UI", "WHATSAPP_UI", "UPI_UI", "MAPS_UI", "WARNING_BOX", "ICON_LARGE"
    private String visualData; // Configuration or JSON-like metadata for what the step node draws
    private String voiceText;
    private String voiceTextHi;
    private String voiceTextMr;

    public LessonStep() {}

    public LessonStep(int id, int lessonId, int stepNumber, String title, String explanation,
                      String visualType, String visualData, String voiceText) {
        this.id = id;
        this.lessonId = lessonId;
        this.stepNumber = stepNumber;
        this.title = title;
        this.explanation = explanation;
        this.visualType = visualType;
        this.visualData = visualData;
        this.voiceText = voiceText;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getLessonId() { return lessonId; }
    public void setLessonId(int lessonId) { this.lessonId = lessonId; }

    public int getStepNumber() { return stepNumber; }
    public void setStepNumber(int stepNumber) { this.stepNumber = stepNumber; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getTitleHi() { return titleHi; }
    public void setTitleHi(String titleHi) { this.titleHi = titleHi; }

    public String getTitleMr() { return titleMr; }
    public void setTitleMr(String titleMr) { this.titleMr = titleMr; }

    public String getLocalizedTitle(String lang) {
        if ("hi".equalsIgnoreCase(lang) && titleHi != null && !titleHi.isBlank()) return titleHi;
        if ("mr".equalsIgnoreCase(lang) && titleMr != null && !titleMr.isBlank()) return titleMr;
        return title;
    }

    public String getExplanation() { return explanation; }
    public void setExplanation(String explanation) { this.explanation = explanation; }

    public String getExplanationHi() { return explanationHi; }
    public void setExplanationHi(String explanationHi) { this.explanationHi = explanationHi; }

    public String getExplanationMr() { return explanationMr; }
    public void setExplanationMr(String explanationMr) { this.explanationMr = explanationMr; }

    public String getLocalizedExplanation(String lang) {
        if ("hi".equalsIgnoreCase(lang) && explanationHi != null && !explanationHi.isBlank()) return explanationHi;
        if ("mr".equalsIgnoreCase(lang) && explanationMr != null && !explanationMr.isBlank()) return explanationMr;
        return explanation;
    }

    public String getVisualType() { return visualType; }
    public void setVisualType(String visualType) { this.visualType = visualType; }

    public String getVisualData() { return visualData; }
    public void setVisualData(String visualData) { this.visualData = visualData; }

    public String getVoiceText() {
        if (voiceText == null || voiceText.isBlank()) {
            return title + ". " + explanation;
        }
        return voiceText;
    }
    public void setVoiceText(String voiceText) { this.voiceText = voiceText; }

    public String getVoiceTextHi() { return voiceTextHi; }
    public void setVoiceTextHi(String voiceTextHi) { this.voiceTextHi = voiceTextHi; }

    public String getVoiceTextMr() { return voiceTextMr; }
    public void setVoiceTextMr(String voiceTextMr) { this.voiceTextMr = voiceTextMr; }

    public String getLocalizedVoiceText(String lang) {
        if ("hi".equalsIgnoreCase(lang) && voiceTextHi != null && !voiceTextHi.isBlank()) return voiceTextHi;
        if ("mr".equalsIgnoreCase(lang) && voiceTextMr != null && !voiceTextMr.isBlank()) return voiceTextMr;
        return getVoiceText();
    }
}
