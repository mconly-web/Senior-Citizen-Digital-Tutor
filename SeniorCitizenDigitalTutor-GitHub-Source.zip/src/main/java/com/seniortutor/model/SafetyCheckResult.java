package com.seniortutor.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Result of rule-based digital safety evaluation for suspicious messages.
 */
public class SafetyCheckResult {
    public enum RiskLevel {
        HIGH_RISK("🔴 HIGH RISK / DANGER", "#C97855", "Do NOT interact with this message!"),
        SUSPICIOUS("🟡 POSSIBLY SUSPICIOUS", "#D6A84F", "Exercise caution. Verify before taking any action."),
        APPEARS_SAFE("🟢 APPEARS SAFE", "#6F8068", "No obvious scam patterns detected. Still remain mindful.");

        private final String displayName;
        private final String colorHex;
        private final String adviceSummary;

        RiskLevel(String displayName, String colorHex, String adviceSummary) {
            this.displayName = displayName;
            this.colorHex = colorHex;
            this.adviceSummary = adviceSummary;
        }

        public String getDisplayName() { return displayName; }
        public String getColorHex() { return colorHex; }
        public String getAdviceSummary() { return adviceSummary; }

        public String getLocalizedDisplayName(String lang) {
            if ("hi".equalsIgnoreCase(lang)) {
                return switch (this) {
                    case HIGH_RISK -> "🔴 गंभीर खतरा / धोखाधड़ी";
                    case SUSPICIOUS -> "🟡 संदेहास्पद संदेश";
                    case APPEARS_SAFE -> "🟢 सुरक्षित प्रतीत होता है";
                };
            }
            if ("mr".equalsIgnoreCase(lang)) {
                return switch (this) {
                    case HIGH_RISK -> "🔴 मोठा धोका / फसवणूक";
                    case SUSPICIOUS -> "🟡 संशयास्पद मेसेज";
                    case APPEARS_SAFE -> "🟢 सुरक्षित वाटते";
                };
            }
            return displayName;
        }
    }

    private String analyzedText;
    private RiskLevel riskLevel;
    private int score; // 0 to 100
    private List<String> detectedFlags = new ArrayList<>();
    private List<String> riskExplanations = new ArrayList<>();
    private List<String> recommendations = new ArrayList<>();

    public SafetyCheckResult() {}

    public SafetyCheckResult(String analyzedText, RiskLevel riskLevel, int score) {
        this.analyzedText = analyzedText;
        this.riskLevel = riskLevel;
        this.score = score;
    }

    public String getAnalyzedText() { return analyzedText; }
    public void setAnalyzedText(String analyzedText) { this.analyzedText = analyzedText; }

    public RiskLevel getRiskLevel() { return riskLevel; }
    public void setRiskLevel(RiskLevel riskLevel) { this.riskLevel = riskLevel; }

    public int getScore() { return score; }
    public void setScore(int score) { this.score = score; }

    public List<String> getDetectedFlags() { return detectedFlags; }
    public void setDetectedFlags(List<String> detectedFlags) { this.detectedFlags = detectedFlags; }

    public List<String> getRiskExplanations() { return riskExplanations; }
    public void setRiskExplanations(List<String> riskExplanations) { this.riskExplanations = riskExplanations; }

    public List<String> getRecommendations() { return recommendations; }
    public void setRecommendations(List<String> recommendations) { this.recommendations = recommendations; }
}
