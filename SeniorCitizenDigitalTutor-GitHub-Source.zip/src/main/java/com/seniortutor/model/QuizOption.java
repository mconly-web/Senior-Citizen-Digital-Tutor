package com.seniortutor.model;

/**
 * Represents a selectable option within a quiz question.
 */
public class QuizOption {
    private int id;
    private int questionId;
    private String optionText;
    private String optionTextHi;
    private String optionTextMr;
    private boolean correct;

    public QuizOption() {}

    public QuizOption(int id, int questionId, String optionText, boolean correct) {
        this.id = id;
        this.questionId = questionId;
        this.optionText = optionText;
        this.correct = correct;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getQuestionId() { return questionId; }
    public void setQuestionId(int questionId) { this.questionId = questionId; }

    public String getOptionText() { return optionText; }
    public void setOptionText(String optionText) { this.optionText = optionText; }

    public String getOptionTextHi() { return optionTextHi; }
    public void setOptionTextHi(String optionTextHi) { this.optionTextHi = optionTextHi; }

    public String getOptionTextMr() { return optionTextMr; }
    public void setOptionTextMr(String optionTextMr) { this.optionTextMr = optionTextMr; }

    public String getLocalizedOptionText(String lang) {
        if ("hi".equalsIgnoreCase(lang) && optionTextHi != null && !optionTextHi.isBlank()) return optionTextHi;
        if ("mr".equalsIgnoreCase(lang) && optionTextMr != null && !optionTextMr.isBlank()) return optionTextMr;
        return optionText;
    }

    public boolean isCorrect() { return correct; }
    public void setCorrect(boolean correct) { this.correct = correct; }

    @Override
    public String toString() {
        return optionText;
    }
}
