package com.seniortutor.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a specific digital lesson.
 */
public class Lesson {
    private int id;
    private int categoryId;
    private String categoryName;
    private String categoryIcon;
    private String title;
    private String titleHi;
    private String titleMr;
    private String description;
    private String descriptionHi;
    private String descriptionMr;
    private String difficulty; // "BEGINNER", "INTERMEDIATE"
    private int estimatedMinutes;
    private String practiceType; // "WHATSAPP", "PHONE", "UPI", "MAPS", "EMAIL", "AADHAAR", "BILLPAY", "NONE"
    private int orderIndex;
    private String recap;
    private String recapHi;
    private String recapMr;
    private boolean completed;
    private int lastCompletedStep;
    private int quizScore;
    private List<LessonStep> steps = new ArrayList<>();

    public Lesson() {}

    public Lesson(int id, int categoryId, String title, String description, String difficulty,
                  int estimatedMinutes, String practiceType, int orderIndex) {
        this.id = id;
        this.categoryId = categoryId;
        this.title = title;
        this.description = description;
        this.difficulty = difficulty;
        this.estimatedMinutes = estimatedMinutes;
        this.practiceType = practiceType;
        this.orderIndex = orderIndex;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getCategoryId() { return categoryId; }
    public void setCategoryId(int categoryId) { this.categoryId = categoryId; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

    public String getCategoryIcon() { return categoryIcon; }
    public void setCategoryIcon(String categoryIcon) { this.categoryIcon = categoryIcon; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getTitleHi() { return titleHi; }
    public void setTitleHi(String titleHi) { this.titleHi = titleHi; }

    public String getTitleMr() { return titleMr; }
    public void setTitleMr(String titleMr) { this.titleMr = titleMr; }

    public String getLocalizedTitle(String lang) {
        if ("hi".equalsIgnoreCase(lang) && titleHi != null && !titleHi.isBlank()) return titleHi;
        if ("mr".equalsIgnoreCase(lang) && titleMr != null && !titleMr.isBlank()) return titleMr;
        return title;
    }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getDescriptionHi() { return descriptionHi; }
    public void setDescriptionHi(String descriptionHi) { this.descriptionHi = descriptionHi; }

    public String getDescriptionMr() { return descriptionMr; }
    public void setDescriptionMr(String descriptionMr) { this.descriptionMr = descriptionMr; }

    public String getLocalizedDescription(String lang) {
        if ("hi".equalsIgnoreCase(lang) && descriptionHi != null && !descriptionHi.isBlank()) return descriptionHi;
        if ("mr".equalsIgnoreCase(lang) && descriptionMr != null && !descriptionMr.isBlank()) return descriptionMr;
        return description;
    }

    public String getDifficulty() { return difficulty; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }

    public int getEstimatedMinutes() { return estimatedMinutes; }
    public void setEstimatedMinutes(int estimatedMinutes) { this.estimatedMinutes = estimatedMinutes; }

    public String getPracticeType() { return practiceType; }
    public void setPracticeType(String practiceType) { this.practiceType = practiceType; }

    public int getOrderIndex() { return orderIndex; }
    public void setOrderIndex(int orderIndex) { this.orderIndex = orderIndex; }

    public String getRecap() { return recap; }
    public void setRecap(String recap) { this.recap = recap; }

    public String getRecapHi() { return recapHi; }
    public void setRecapHi(String recapHi) { this.recapHi = recapHi; }

    public String getRecapMr() { return recapMr; }
    public void setRecapMr(String recapMr) { this.recapMr = recapMr; }

    public String getLocalizedRecap(String lang) {
        if ("hi".equalsIgnoreCase(lang) && recapHi != null && !recapHi.isBlank()) return recapHi;
        if ("mr".equalsIgnoreCase(lang) && recapMr != null && !recapMr.isBlank()) return recapMr;
        return recap;
    }

    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }

    public int getLastCompletedStep() { return lastCompletedStep; }
    public void setLastCompletedStep(int lastCompletedStep) { this.lastCompletedStep = lastCompletedStep; }

    public int getQuizScore() { return quizScore; }
    public void setQuizScore(int quizScore) { this.quizScore = quizScore; }

    public List<LessonStep> getSteps() { return steps; }
    public void setSteps(List<LessonStep> steps) { this.steps = steps; }

    public boolean hasSimulation() {
        return practiceType != null && !practiceType.equalsIgnoreCase("NONE") && !practiceType.isEmpty();
    }

    @Override
    public String toString() {
        return title;
    }
}
