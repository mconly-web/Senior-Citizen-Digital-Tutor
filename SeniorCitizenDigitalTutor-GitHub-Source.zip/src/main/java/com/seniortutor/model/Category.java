package com.seniortutor.model;

/**
 * Represents a digital learning category (e.g. Smartphone Basics, WhatsApp, UPI, Digital Safety).
 */
public class Category {
    private int id;
    private String name;
    private String nameHi;
    private String nameMr;
    private String icon;
    private String description;
    private String descriptionHi;
    private String descriptionMr;
    private int displayOrder;
    private int lessonCount;
    private int completedLessonCount;

    public Category() {}

    public Category(int id, String name, String icon, String description, int displayOrder) {
        this.id = id;
        this.name = name;
        this.icon = icon;
        this.description = description;
        this.displayOrder = displayOrder;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getNameHi() { return nameHi; }
    public void setNameHi(String nameHi) { this.nameHi = nameHi; }

    public String getNameMr() { return nameMr; }
    public void setNameMr(String nameMr) { this.nameMr = nameMr; }

    public String getLocalizedName(String lang) {
        if ("hi".equalsIgnoreCase(lang) && nameHi != null && !nameHi.isBlank()) return nameHi;
        if ("mr".equalsIgnoreCase(lang) && nameMr != null && !nameMr.isBlank()) return nameMr;
        return name;
    }

    public String getIcon() { return icon; }
    public void setIcon(String icon) { this.icon = icon; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getDescriptionHi() { return descriptionHi; }
    public void setDescriptionHi(String descriptionHi) { this.descriptionHi = descriptionHi; }

    public String getDescriptionMr() { return descriptionMr; }
    public void setDescriptionMr(String descriptionMr) { this.descriptionMr = descriptionMr; }

    public String getLocalizedDescription(String lang) {
        if ("hi".equalsIgnoreCase(lang) && descriptionHi != null && !descriptionHi.isBlank()) return descriptionHi;
        if ("mr".equalsIgnoreCase(lang) && descriptionMr != null && !descriptionMr.isBlank()) return descriptionMr;
        return description;
    }

    public int getDisplayOrder() { return displayOrder; }
    public void setDisplayOrder(int displayOrder) { this.displayOrder = displayOrder; }

    public int getLessonCount() { return lessonCount; }
    public void setLessonCount(int lessonCount) { this.lessonCount = lessonCount; }

    public int getCompletedLessonCount() { return completedLessonCount; }
    public void setCompletedLessonCount(int completedLessonCount) { this.completedLessonCount = completedLessonCount; }

    public double getProgressPercentage() {
        if (lessonCount == 0) return 0.0;
        return (double) completedLessonCount / lessonCount;
    }

    @Override
    public String toString() {
        return icon + " " + name;
    }
}
