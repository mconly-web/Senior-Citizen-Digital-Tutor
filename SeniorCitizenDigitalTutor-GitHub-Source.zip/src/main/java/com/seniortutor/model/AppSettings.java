package com.seniortutor.model;

/**
 * User application settings, accessibility, voice control, and emergency info.
 */
public class AppSettings {
    private int userId;
    private double fontScale = 1.0; // 0.9 (Standard), 1.15 (Large), 1.3 (Extra Large)
    private boolean highContrast = false;
    private boolean voiceEnabled = true;
    private boolean soundEffects = true;
    private boolean reducedAnimations = false;
    private String language = "en"; // "en", "hi", "mr"
    private double speechRate = -1.0; // -2.0 (Slow), -1.0 (Normal), 0.0 (Brisk)
    private String helperPin = "";
    private String emergencyBloodGroup = "O+";
    private String emergencyMedications = "Aspirin, BP medication";
    private String emergencyContact1Name = "Anita (Daughter)";
    private String emergencyContact1Phone = "+91 98765 43210";
    private String emergencyContact2Name = "Rohan (Son)";
    private String emergencyContact2Phone = "+91 98123 45678";
    private String doctorName = "Dr. K. S. Verma";
    private String doctorPhone = "+91 94220 11223";

    public AppSettings() {}

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public double getFontScale() { return fontScale; }
    public void setFontScale(double fontScale) { this.fontScale = fontScale; }

    public boolean isHighContrast() { return highContrast; }
    public void setHighContrast(boolean highContrast) { this.highContrast = highContrast; }

    public boolean isVoiceEnabled() { return voiceEnabled; }
    public void setVoiceEnabled(boolean voiceEnabled) { this.voiceEnabled = voiceEnabled; }

    public boolean isSoundEffects() { return soundEffects; }
    public void setSoundEffects(boolean soundEffects) { this.soundEffects = soundEffects; }

    public boolean isReducedAnimations() { return reducedAnimations; }
    public void setReducedAnimations(boolean reducedAnimations) { this.reducedAnimations = reducedAnimations; }

    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }

    public double getSpeechRate() { return speechRate; }
    public void setSpeechRate(double speechRate) { this.speechRate = speechRate; }

    public String getHelperPin() { return helperPin; }
    public void setHelperPin(String helperPin) { this.helperPin = helperPin; }

    public String getEmergencyBloodGroup() { return emergencyBloodGroup; }
    public void setEmergencyBloodGroup(String emergencyBloodGroup) { this.emergencyBloodGroup = emergencyBloodGroup; }

    public String getEmergencyMedications() { return emergencyMedications; }
    public void setEmergencyMedications(String emergencyMedications) { this.emergencyMedications = emergencyMedications; }

    public String getEmergencyContact1Name() { return emergencyContact1Name; }
    public void setEmergencyContact1Name(String emergencyContact1Name) { this.emergencyContact1Name = emergencyContact1Name; }

    public String getEmergencyContact1Phone() { return emergencyContact1Phone; }
    public void setEmergencyContact1Phone(String emergencyContact1Phone) { this.emergencyContact1Phone = emergencyContact1Phone; }

    public String getEmergencyContact2Name() { return emergencyContact2Name; }
    public void setEmergencyContact2Name(String emergencyContact2Name) { this.emergencyContact2Name = emergencyContact2Name; }

    public String getEmergencyContact2Phone() { return emergencyContact2Phone; }
    public void setEmergencyContact2Phone(String emergencyContact2Phone) { this.emergencyContact2Phone = emergencyContact2Phone; }

    public String getDoctorName() { return doctorName; }
    public void setDoctorName(String doctorName) { this.doctorName = doctorName; }

    public String getDoctorPhone() { return doctorPhone; }
    public void setDoctorPhone(String doctorPhone) { this.doctorPhone = doctorPhone; }
}
