package com.seniortutor.model;

import java.time.LocalDateTime;

/**
 * Represents a recommendation given by a family helper to the senior.
 */
public class Recommendation {
    private int id;
    private int seniorUserId;
    private int helperUserId;
    private int lessonId;
    private String lessonTitle;
    private String categoryIcon;
    private String note;
    private boolean completed;
    private LocalDateTime createdAt;

    public Recommendation() {}

    public Recommendation(int id, int seniorUserId, int helperUserId, int lessonId, String note,
                          boolean completed, LocalDateTime createdAt) {
        this.id = id;
        this.seniorUserId = seniorUserId;
        this.helperUserId = helperUserId;
        this.lessonId = lessonId;
        this.note = note;
        this.completed = completed;
        this.createdAt = createdAt;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getSeniorUserId() { return seniorUserId; }
    public void setSeniorUserId(int seniorUserId) { this.seniorUserId = seniorUserId; }

    public int getHelperUserId() { return helperUserId; }
    public void setHelperUserId(int helperUserId) { this.helperUserId = helperUserId; }

    public int getLessonId() { return lessonId; }
    public void setLessonId(int lessonId) { this.lessonId = lessonId; }

    public String getLessonTitle() { return lessonTitle; }
    public void setLessonTitle(String lessonTitle) { this.lessonTitle = lessonTitle; }

    public String getCategoryIcon() { return categoryIcon; }
    public void setCategoryIcon(String categoryIcon) { this.categoryIcon = categoryIcon; }

    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }

    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
