package com.seniortutor.model;

import java.time.LocalDateTime;

/**
 * Tracks lesson completion and scores per user.
 */
public class UserProgress {
    private int id;
    private int userId;
    private int lessonId;
    private boolean completed;
    private int lastStep;
    private int quizScore;
    private boolean quizPassed;
    private LocalDateTime completedAt;

    public UserProgress() {}

    public UserProgress(int id, int userId, int lessonId, boolean completed, int lastStep,
                        int quizScore, boolean quizPassed, LocalDateTime completedAt) {
        this.id = id;
        this.userId = userId;
        this.lessonId = lessonId;
        this.completed = completed;
        this.lastStep = lastStep;
        this.quizScore = quizScore;
        this.quizPassed = quizPassed;
        this.completedAt = completedAt;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public int getLessonId() { return lessonId; }
    public void setLessonId(int lessonId) { this.lessonId = lessonId; }

    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }

    public int getLastStep() { return lastStep; }
    public void setLastStep(int lastStep) { this.lastStep = lastStep; }

    public int getQuizScore() { return quizScore; }
    public void setQuizScore(int quizScore) { this.quizScore = quizScore; }

    public boolean isQuizPassed() { return quizPassed; }
    public void setQuizPassed(boolean quizPassed) { this.quizPassed = quizPassed; }

    public LocalDateTime getCompletedAt() { return completedAt; }
    public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }
}
