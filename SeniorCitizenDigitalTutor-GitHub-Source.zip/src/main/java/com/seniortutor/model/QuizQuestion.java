package com.seniortutor.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a quiz question associated with a lesson.
 */
public class QuizQuestion {
    private int id;
    private int lessonId;
    private String questionText;
    private String questionTextHi;
    private String questionTextMr;
    private String explanation;
    private String explanationHi;
    private String explanationMr;
    private List<QuizOption> options = new ArrayList<>();

    public QuizQuestion() {}

    public QuizQuestion(int id, int lessonId, String questionText, String explanation) {
        this.id = id;
        this.lessonId = lessonId;
        this.questionText = questionText;
        this.explanation = explanation;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getLessonId() { return lessonId; }
    public void setLessonId(int lessonId) { this.lessonId = lessonId; }

    public String getQuestionText() { return questionText; }
    public void setQuestionText(String questionText) { this.questionText = questionText; }

    public String getQuestionTextHi() { return questionTextHi; }
    public void setQuestionTextHi(String questionTextHi) { this.questionTextHi = questionTextHi; }

    public String getQuestionTextMr() { return questionTextMr; }
    public void setQuestionTextMr(String questionTextMr) { this.questionTextMr = questionTextMr; }

    public String getLocalizedQuestionText(String lang) {
        if ("hi".equalsIgnoreCase(lang) && questionTextHi != null && !questionTextHi.isBlank()) return questionTextHi;
        if ("mr".equalsIgnoreCase(lang) && questionTextMr != null && !questionTextMr.isBlank()) return questionTextMr;
        return questionText;
    }

    public String getExplanation() { return explanation; }
    public void setExplanation(String explanation) { this.explanation = explanation; }

    public String getExplanationHi() { return explanationHi; }
    public void setExplanationHi(String explanationHi) { this.explanationHi = explanationHi; }

    public String getExplanationMr() { return explanationMr; }
    public void setExplanationMr(String explanationMr) { this.explanationMr = explanationMr; }

    public String getLocalizedExplanation(String lang) {
        if ("hi".equalsIgnoreCase(lang) && explanationHi != null && !explanationHi.isBlank()) return explanationHi;
        if ("mr".equalsIgnoreCase(lang) && explanationMr != null && !explanationMr.isBlank()) return explanationMr;
        return explanation;
    }

    public List<QuizOption> getOptions() { return options; }
    public void setOptions(List<QuizOption> options) { this.options = options; }

    public void addOption(QuizOption option) {
        this.options.add(option);
    }
}
