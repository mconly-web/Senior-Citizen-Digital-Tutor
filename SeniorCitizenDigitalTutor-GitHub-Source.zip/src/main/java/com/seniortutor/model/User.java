package com.seniortutor.model;

import java.time.LocalDateTime;

/**
 * Represents an application user (e.g. Senior Citizen or Family Helper).
 */
public class User {
    private int id;
    private String name;
    private String role; // "SENIOR" or "HELPER"
    private String avatar;
    private int currentStreak;
    private LocalDateTime createdAt;

    public User() {}

    public User(int id, String name, String role, String avatar, int currentStreak, LocalDateTime createdAt) {
        this.id = id;
        this.name = name;
        this.role = role;
        this.avatar = avatar;
        this.currentStreak = currentStreak;
        this.createdAt = createdAt;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getAvatar() { return avatar; }
    public void setAvatar(String avatar) { this.avatar = avatar; }

    public int getCurrentStreak() { return currentStreak; }
    public void setCurrentStreak(int currentStreak) { this.currentStreak = currentStreak; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public boolean isSenior() {
        return "SENIOR".equalsIgnoreCase(role);
    }

    public boolean isHelper() {
        return "HELPER".equalsIgnoreCase(role);
    }

    @Override
    public String toString() {
        return name + " (" + role + ")";
    }
}
