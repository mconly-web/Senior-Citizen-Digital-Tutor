package com.seniortutor;

import com.seniortutor.database.DatabaseManager;
import com.seniortutor.service.WindowsSpeechService;
import com.seniortutor.ui.MainLayout;
import com.seniortutor.ui.dialog.WelcomeWizardDialog;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.UiUtils;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.InputStream;
import java.net.URL;

/**
 * Main JavaFX Application class for Senior Citizen Digital Tutor.
 */
public class SeniorTutorApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Safe global exception handling - never show stack traces to seniors
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            System.err.println("Handled uncaught exception: " + throwable.getMessage());
            Platform.runLater(() -> {
                UiUtils.showInfoDialog(
                    "Notice",
                    "Everything is Safe",
                    "A brief pause occurred, but your lesson progress and saved badges are completely safe. You may resume learning comfortably."
                );
            });
        });

        // Initialize SQLite database and seed records
        DatabaseManager.getInstance();

        MainLayout mainLayout = new MainLayout();
        Scene scene = new Scene(mainLayout, 1280, 800);

        // Load custom styling
        URL cssResource = getClass().getResource("/css/style.css");
        if (cssResource != null) {
            scene.getStylesheets().add(cssResource.toExternalForm());
        }

        // Set App Icon
        try (InputStream iconStream = getClass().getResourceAsStream("/icons/app_icon.png")) {
            if (iconStream != null) {
                primaryStage.getIcons().add(new Image(iconStream));
            }
        } catch (Exception ignored) {}

        primaryStage.setTitle("Senior Citizen Digital Tutor — \"Learn. Practice. Use. Stay Connected.\"");
        primaryStage.setScene(scene);
        primaryStage.setMinWidth(1024);
        primaryStage.setMinHeight(700);

        primaryStage.setOnCloseRequest(e -> {
            WindowsSpeechService.getInstance().stop();
        });

        primaryStage.show();

        // Launch first-run wizard if this is a fresh setup
        if (AppConfig.getInstance().isFirstRun()) {
            Platform.runLater(() -> {
                WelcomeWizardDialog.showWizard(primaryStage, () -> {
                    AppConfig.getInstance().setFirstRunCompleted();
                    mainLayout.navigateTo("home");
                });
            });
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
