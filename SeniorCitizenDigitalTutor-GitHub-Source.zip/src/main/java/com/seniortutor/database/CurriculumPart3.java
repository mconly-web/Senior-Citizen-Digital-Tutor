package com.seniortutor.database;

import java.sql.Connection;

/**
 * Seeds Categories 9 to 12 (Lessons 28 to 42) with 3-5 quiz questions, explanations,
 * recaps, and English/Hindi/Marathi translations.
 */
public class CurriculumPart3 {

    public static void seed(Connection conn) throws Exception {
        seedCat9OnlineServices(conn);
        seedCat10Email(conn);
        seedCat11Safety(conn);
        seedCat12Emergency(conn);
    }

    // ==========================================
    // CAT 9: ONLINE SERVICES (Lessons 28 - 31)
    // ==========================================
    private static void seedCat9OnlineServices(Connection conn) throws Exception {
        // L28: Booking an Auto or Cab Safely
        int l28 = DatabaseSeeder.insertLesson(conn, 28, 9, "Booking an Auto or Cab Safely", "ऑटो या कैब बुक करना और सुरक्षित सफर", "रिक्षा किंवा कॅब सुरक्षित बुक करणे",
                "Learn how ride apps like Uber and Ola work without fear.",
                "उबर या ओला से ऑटो और कैब बुक करना और सुरक्षित यात्रा करना सीखें।",
                "उबर किंवा ओलावरून सुरक्षित रिक्षा/टॅक्सी बुक करणे आणि प्रवास करणे शिका.",
                "BEGINNER", 5, "NONE", 1,
                "• Type your destination in the search bar.\n• Check vehicle options (Auto, Mini Cab) and estimated fare.\n• Verify driver name and license plate before getting inside.\n• Share Ride START OTP only after sitting in the vehicle.",
                "• जहां जाना है उस जगह का नाम लिखें।\n• ऑटो या कार और किराया देखें।\n• बैठने से पहले गाड़ी का नंबर और ड्राइवर का नाम मिलाएं।\n• गाड़ी में बैठने के बाद ही राइड का 4 अंकों का ओटीपी बताएं।",
                "• जिथे जायचे आहे त्या ठिकाणाचे नाव लिहा.\n• रिक्षा किंवा टॅक्सीचा अंदाजे खर्च तपासा.\n• गाडीत बसण्यापूर्वी वाहनाचा नंबर आणि नाव खात्री करा.\n• गाडीत बसल्यानंतरच प्रवासाचा ४ अंकी ओटीपी सांगा.");

        DatabaseSeeder.insertStep(conn, l28, 1, "Enter Your Destination", "अपनी मंजिल का नाम लिखें", "आपल्या ठिकाणाचे नाव लिहा",
                "Open Uber or Ola. The app knows where you are. Tap 'Where to?' and speak or type your destination (e.g. 'Apollo Hospital').",
                "ऐप खोलें। 'Where to?' पर टैप करके जहां जाना है उसका नाम बोलें (जैसे 'अपोलो अस्पताल')।",
                "अॅप उघडा. 'Where to?' वर दाबा आणि जिथे जायचे आहे ते नाव बोला (उदा. 'दीनानाथ मंगेशकर रुग्णालय').",
                "PHONE_UI", "CAB_SEARCH",
                "Enter your destination in the ride-booking application.",
                "अपनी मंजिल का नाम ऐप में दर्ज करें।",
                "जाण्याच्या ठिकाणाचे नाव अॅपमध्ये टाका.");

        DatabaseSeeder.insertStep(conn, l28, 2, "Choose Vehicle & Review Estimated Fare", "गाड़ी चुनें और किराया देखें", "वाहन निवडा आणि भाडे तपासा",
                "Review the options: Auto (affordable), Mini Cab, or Sedan. Check the fixed price before tapping 'Book Auto'.",
                "ऑटो या कैब का विकल्प देखें। तय किराया पहले ही स्क्रीन पर दिख जाता है। 'Book Auto' पर टैप करें।",
                "रिक्षा किंवा कारचा पर्याय निवडा. स्क्रीनवर निश्चित भाडे आधीच दिसते. 'Book Auto' वर दाबा.",
                "PHONE_UI", "CAB_OPTIONS",
                "Review vehicle choices and estimated prices before confirming.",
                "गाड़ी का प्रकार और किराया देखकर बुकिंग की पुष्टि करें।",
                "गाडीचा प्रकार आणि भाडे तपासून बुकिंग करा.");

        DatabaseSeeder.insertStep(conn, l28, 3, "Match the Vehicle License Plate Number", "गाड़ी का नंबर प्लेट मिलाएं", "गाडीचा नंबर प्लेट तपासा",
                "When the driver arrives, check the number plate (e.g., MH 12 AB 1234) on the car. Never sit in the wrong car!",
                "जब गाड़ी दरवाजे पर आए, तो नंबर प्लेट पर लिखा नंबर (जैसे MH 12 AB 1234) ऐप से मिलाएं। कभी अनजान गाड़ी में न बैठें!",
                "गाडी दारात आल्यावर वाहनाचा नंबर (उदा. MH 12 AB 1234) अॅपमधील नंबरशी जुळवून पहा. चुकीच्या गाडीत बसू नका!",
                "PHONE_UI", "MATCH_PLATE",
                "Always check that the vehicle license plate matches what is displayed on your screen.",
                "गाड़ी का नंबर ऐप में दिखाए नंबर से जरूर मिलाएं।",
                "गाडीचा नंबर अॅपमधील नंबरशी तपासून पहा.");

        DatabaseSeeder.insertStep(conn, l28, 4, "Share Ride START OTP After Sitting Inside", "बैठने के बाद ही राइड ओटीपी बताएं", "आत बसल्यावरच राइड ओटीपी सांगा",
                "After you sit comfortably inside the vehicle, tell the 4-digit Ride START OTP shown on your screen to the driver so they can start the meter.",
                "आराम से अंदर बैठने के बाद ही स्क्रीन पर दिख रहा 4 अंकों का 'Ride OTP' ड्राइवर को बताएं ताकि वह यात्रा शुरू कर सके।",
                "गाडीत नीट बसल्यानंतरच स्क्रीनवर दिसणारा ४ अंकी 'Ride OTP' ड्रायव्हरला सांगा जेणेकरून तो ट्रिप सुरू करेल.",
                "PHONE_UI", "CAB_OTP",
                "Share the 4-digit ride OTP with the driver only after getting seated inside.",
                "गाड़ी में बैठने के बाद 4 अंकों का राइड ओटीपी ड्राइवर को बताएं।",
                "गाडीत बसल्यावर ४ अंकी राइड ओटीपी ड्रायव्हरला सांगा.");

        DatabaseSeeder.insertQuiz(conn, l28, "What should you ALWAYS check before stepping inside a booked auto or cab?",
                "बुक किए गए ऑटो या कैब में बैठने से पहले सबसे पहले क्या जांचना जरूरी है?",
                "बुक केलेल्या रिक्षात किंवा टॅक्सीत बसण्यापूर्वी सर्वात आधी काय तपासणे आवश्यक आहे?",
                "Verify that the car's license plate number matches the vehicle number shown on your phone screen.",
                "जांचें कि गाड़ी का नंबर प्लेट वही है जो आपके फोन की स्क्रीन पर दिख रहा है।",
                "गाडीचा नंबर प्लेट आणि स्क्रीनवरील नंबर एकच आहे ना याची खात्री करा.",
                new String[]{"The driver's shoes", "The vehicle license plate number matches your screen", "The brand of car tyres", "The radio music"},
                new String[]{"ड्राइवर के जूते", "गाड़ी का नंबर प्लेट फोन स्क्रीन से मेल खाता हो", "गाड़ी के टायर की कंपनी", "रेडियो पर बजने वाला गाना"},
                new String[]{"ड्रायव्हरचे कपडे", "गाडीचा नंबर प्लेट फोन स्क्रीनशी जुळतो", "टायरची कंपनी", "रेडिओवरील गाणे"}, 1);

        DatabaseSeeder.insertQuiz(conn, l28, "When should you tell the 4-digit Ride START OTP to the driver?",
                "ड्राइवर को 4 अंकों का राइड स्टार्ट ओटीपी कब बताना चाहिए?",
                "ड्रायव्हरला ४ अंकी राइड ओटीपी कधी सांगावा?",
                "Only after you have verified the vehicle and sat safely inside.",
                "गाड़ी का नंबर मिलाने और आराम से अंदर बैठने के बाद ही बताएं।",
                "गाडीचा नंबर तपासून आणि आत व्यवस्थित बसल्यानंतरच सांगावा.",
                new String[]{"Before the driver even arrives while you are at home", "Only after verifying the car and getting seated safely inside", "Never tell the OTP to anyone", "Send it by post"},
                new String[]{"ड्राइवर के आने से पहले जब आप घर पर हों", "गाड़ी मिलाने और सुरक्षित अंदर बैठने के बाद ही", "ओटीपी कभी न बताएं", "डाक से भेजें"},
                new String[]{"ड्रायव्हर येण्यापूर्वीच घरातून", "गाडी तपासून आणि आत सुरक्षित बसल्यानंतरच", "ओटीपी कधीच सांगू नये", "पोस्टाने पाठवावा"}, 1);

        DatabaseSeeder.insertQuiz(conn, l28, "Can you pay for your Uber or Ola ride in cash if you prefer?",
                "क्या आप अपनी ऑटो या कैब का किराया नकद (कैश) में भी दे सकते हैं?",
                "उबर किंवा ओलाचे भाडे रोख पैशात (कॅश) देता येते का?",
                "Yes! You can choose 'Cash' as payment method and pay the driver in physical cash at the end of the trip.",
                "हां! आप पेमेंट में 'Cash' चुन सकते हैं और सफर पूरा होने पर ड्राइवर को हाथ से नकद दे सकते हैं।",
                "होय! तुम्ही 'Cash' पर्याय निवडून प्रवास संपल्यावर ड्रायव्हरला थेट रोख पैसे देऊ शकता.",
                new String[]{"No, cash is banned everywhere", "Yes, you can choose 'Cash' payment and hand cash to the driver when trip ends", "Only with gold coins", "Only if you have a credit card"},
                new String[]{"नहीं, कैश बिल्कुल बंद है", "हां, 'Cash' चुनकर सफर पूरा होने पर ड्राइवर को नकद दे सकते हैं", "केवल सोने के सिक्कों से", "क्रेडिट कार्ड जरूरी है"},
                new String[]{"नाही, रोख पैसे बंद आहेत", "होय, 'Cash' निवडून प्रवास पूर्ण झाल्यावर ड्रायव्हरला रोख पैसे देऊ शकता", "फक्त सोन्याच्या नाण्यांनी", "क्रेडिट कार्ड लागते"}, 1);

        // L29: Ordering Medicines Online with Prescription
        int l29 = DatabaseSeeder.insertLesson(conn, 29, 9, "Ordering Medicines Online with Prescription", "घर बैठे ऑनलाइन दवाइयां मंगवाना", "घरी बसून ऑनलाइन औषधे मागवणे",
                "Order regular BP, diabetes, or joint pain medicines with doorstep home delivery.",
                "बीपी और शुगर की नियमित दवाइयां घर बैठे मंगवाना और पर्चा अपलोड करना सीखें।",
                "बीपी आणि मधुमेहाची औषधे घरपोच मागवणे आणि डॉक्टरांची चिठ्ठी जोडणे शिका.",
                "BEGINNER", 5, "NONE", 2,
                "• Open pharmacy app (1mg, PharmEasy, or Apollo 24/7).\n• Take a clear photo of doctor's prescription slip.\n• Choose 'Cash on Delivery' for peace of mind.\n• Delivery arrives at your doorstep in sealed packaging.",
                "• दवाई ऐप (1mg, PharmEasy या Apollo) खोलें।\n• डॉक्टर के पर्चे की साफ फोटो खींचकर अपलोड करें।\n• डिलीवरी पर नकद (Cash on Delivery) का विकल्प चुनें।\n• सील पैक दवाई घर पर पहुंच जाएगी।",
                "• फार्मसी अॅप (1mg, PharmEasy किंवा Apollo) उघडा.\n• डॉक्टरांच्या चिठ्ठीचा स्पष्ट फोटो काढून जोडा.\n• विश्वासू राहण्यासाठी 'Cash on Delivery' निवडा.\n• सील बंद औषधे थेट घराच्या दारात पोहोचतील.");

        DatabaseSeeder.insertStep(conn, l29, 1, "Open a Trusted Pharmacy App", "प्रमाणित दवाई ऐप खोलें", "विश्वासू फार्मसी अॅप उघडा",
                "Open 1mg, PharmEasy, Apollo 24/7, or Netmeds. These apps provide genuine medicines directly from certified pharmacists.",
                "टाटा 1mg, फार्मईज़ी या अपोलो ऐप खोलें। ये ऐप असली और प्रमाणित दवाइयां सीधे घर पहुंचाते हैं।",
                "1mg, PharmEasy किंवा Apollo अॅप उघडा. हे अॅप्स प्रमाणित औषधे थेट घरी पोहोचवतात.",
                "PHONE_UI", "MEDICINE_APP",
                "Open your trusted medicine delivery application.",
                "प्रमाणित दवाई ऐप खोलें।",
                "विश्वासू औषध अॅप उघडा.");

        DatabaseSeeder.insertStep(conn, l29, 2, "Upload Doctor's Prescription Photo", "डॉक्टर के पर्चे की फोटो अपलोड करें", "डॉक्टरांच्या चिठ्ठीचा फोटो जोडा",
                "Tap 'Upload Prescription'. Take a steady, well-lit photo of your doctor's latest prescription paper.",
                "'Upload Prescription' दबाएं। डॉक्टर के पर्चे की साफ और उजली फोटो खींचकर अपलोड करें।",
                "'Upload Prescription' दाबा. डॉक्टरांच्या कागदाचा स्पष्ट आणि उजेडातील फोटो काढून जोडा.",
                "PHONE_UI", "PRESCRIPTION_UPLOAD",
                "Take a clear photo of the doctor's prescription.",
                "डॉक्टर के पर्चे की साफ फोटो अपलोड करें।",
                "डॉक्टरांच्या प्रिस्क्रिप्शनचा स्पष्ट फोटो अपलोड करा.");

        DatabaseSeeder.insertStep(conn, l29, 3, "Select Duration (e.g. 1 Month Supply)", "महीने की जरूरत चुनें", "१ महिन्याचा साठा निवडा",
                "A certified pharmacist reviews your slip and prepares your 30-day or 60-day supply of daily medicines.",
                "सरकारी फार्मासिस्ट पर्चा देखकर आपकी 1 या 2 महीने की बीपी-शुगर की नियमित दवाइयां कार्ट में जोड़ देगा।",
                "फार्मासिस्ट चिठ्ठी तपासून तुमची १ किंवा २ महिन्यांची नियमित औषधे कार्टमध्ये जोडेल.",
                "PHONE_UI", "MEDICINE_CART",
                "Review the medicine list and dosage prepared by the pharmacist.",
                "फार्मासिस्ट द्वारा तैयार की गई दवाइयों की सूची जांचें।",
                "तयार केलेली औषधांची यादी तपासून पहा.");

        DatabaseSeeder.insertStep(conn, l29, 4, "Choose 'Cash on Delivery' (COD)", "'Cash on Delivery' चुनें", "'Cash on Delivery' निवडा",
                "Choose 'Cash on Delivery'. You pay only when the delivery agent hands the sealed box to you at your front door.",
                "'Cash on Delivery' (डिलीवरी पर नकद) चुनें। जब दवाई का पैकेट आपके हाथ में आए, तभी नकद पैसे दें।",
                "'Cash on Delivery' (घरी आल्यावर पैसे) निवडा. औषधांचे पाकीट हातात आल्यावरच पैसे द्या.",
                "PHONE_UI", "PAY_COD",
                "Pay cash at your doorstep only after receiving the sealed medicine box.",
                "दवाई का डिब्बा हाथ में मिलने के बाद ही नकद भुगतान करें।",
                "औषधांचा डबा हातात मिळाल्यावरच रोख पैसे द्या.");

        DatabaseSeeder.insertQuiz(conn, l29, "Why is 'Cash on Delivery' (COD) a reassuring payment option for senior citizens ordering medicines?",
                "दवाइयां मंगवाते समय 'Cash on Delivery' वरिष्ठ नागरिकों के लिए सबसे सुरक्षित क्यों है?",
                "औषधे मागवताना 'Cash on Delivery' वृद्धांसाठी सर्वात विश्वासू का ठरते?",
                "You inspect the sealed medicine package in your hand before giving any money.",
                "हाथ में सीलबंद डिब्बा मिलने और देखने के बाद ही पैसे देने होते हैं, पहले कोई जोखिम नहीं होता।",
                "औषधांचे सील बंद पाकीट हातात आल्यावरच पैसे द्यायचे असल्याने कसलीही भीती वाटत नाही.",
                new String[]{"You get free medicine forever", "You only pay in cash after receiving and inspecting the package at your door", "It requires giving your bank password", "Medicine becomes twice as expensive"},
                new String[]{"दवा हमेशा के लिए मुफ्त मिलती है", "घर पर डिब्बा मिलने और जांचने के बाद ही हाथ से पैसे देने होते हैं", "बैंक का पासवर्ड देना पड़ता है", "दवा दुगनी महंगी हो जाती है"},
                new String[]{"औषध कायमचे मोफत मिळते", "घरी पाकीट हातात मिळाल्यावर आणि तपासल्यावरच पैसे द्यावे लागतात", "बँक पासवर्ड द्यावा लागतो", "औषध दुप्पट महाग होते"}, 1);

        DatabaseSeeder.insertQuiz(conn, l29, "What must be clearly visible in the photo when uploading a doctor's prescription?",
                "डॉक्टर के पर्चे की फोटो अपलोड करते समय क्या साफ-साफ दिखना जरूरी है?",
                "डॉक्टरांच्या चिठ्ठीचा फोटो जोडताना काय स्पष्ट दिसणे गरजेचे असते?",
                "The doctor's name, patient name, date, and medicine names with dosages.",
                "डॉक्टर का नाम, मरीज का नाम, तारीख और दवाई का नाम व खुराक साफ दिखनी चाहिए।",
                "डॉक्टरांचे नाव, रुग्णाचे नाव, तारीख आणि औषधांची नावे स्पष्ट दिसली पाहिजेत.",
                new String[]{"The doctor's car", "Patient name, doctor name, date, and medicine names with dosage", "The clinic wall color", "The pharmacy signboard"},
                new String[]{"डॉक्टर की गाड़ी", "मरीज का नाम, डॉक्टर का नाम, तारीख और दवाइयों के नाम व मात्रा", "कमरे की दीवार का रंग", "दुकान का बोर्ड"},
                new String[]{"डॉक्टरांची गाडी", "रुग्णाचे नाव, डॉक्टरांचे नाव, तारीख आणि औषधांची नावे", "भिंतीचा रंग", "दुकानाची पाटी"}, 1);

        DatabaseSeeder.insertQuiz(conn, l29, "Should you take sealed medicines if the outer packaging is torn or opened?",
                "यदि दवाई का पैकेट फटा हुआ या पहले से खुला हुआ हो, तो क्या उसे स्वीकार करना चाहिए?",
                "औषधाचे पाकीट फाटलेले किंवा आधीच उघडलेले असल्यास ते स्वीकारायचे का?",
                "No, reject damaged packages and ask the delivery person for a replacement.",
                "नहीं, खुला या फटा हुआ डिब्बा न लें और डिलीवरी वाले को बदलकर लाने को कहें।",
                "नाही, उघडलेले पाकीट घेऊ नका आणि बदलून आणण्यास सांगा.",
                new String[]{"Yes, it is fine", "No, refuse delivery of open packages and request an intact sealed box", "Eat it immediately", "Throw it in the garden"},
                new String[]{"हां, कोई बात नहीं", "नहीं, खुले पैकेट को लेने से मना करें और नया सीलबंद डिब्बा मांगें", "तुरंत खा लें", "बगीचे में फेंक दें"},
                new String[]{"होय, काही हरकत नाही", "नाही, उघडलेले पाकीट नाकारा आणि नवीन सील बंद पाकीट मागा", "लगेच खाऊन टाका", "बागेत फेकून द्या"}, 1);

        // L30: Paying Electricity & Mobile Bills Online
        int l30 = DatabaseSeeder.insertLesson(conn, 30, 9, "Paying Electricity & Mobile Bills Online", "बिजली और मोबाइल का बिल ऑनलाइन भरना", "वीज आणि मोबाईलचे बिल ऑनलाइन भरणे",
                "Pay your home electricity bill (MSEB / Tata Power) and recharge phone without standing in queue.",
                "धूप में लंबी लाइन में लगे बिना घर बैठे बिजली और मोबाइल का बिल भरना सीखें।",
                "उन्हात रांगेत उभे न राहता घरी बसून वीज बिल (MSEB) आणि मोबाईल रिचार्ज करणे शिका.",
                "BEGINNER", 5, "BILLPAY", 3,
                "• Open PhonePe/GPay and tap 'Electricity' or 'Mobile Recharge'.\n• Select your electricity board (e.g. Mahavitaran MSEB).\n• Enter your Consumer Number from your printed paper bill.\n• Verify bill amount and tap Pay using UPI PIN.",
                "• फोनपे या गूगल पे खोलकर 'Electricity' पर जाएं।\n• अपना बिजली बोर्ड (जैसे MSEB / Tata Power) चुनें।\n• पुराने कागजी बिल से अपना 'Consumer Number' लिखें।\n• बिजली का सही बिल देखकर यूपीआई पिन से भुगतान करें।",
                "• PhonePe किंवा GPay उघडून 'Electricity' वर जा.\n• आपले वीज मंडळ (उदा. महावितरण MSEB) निवडा.\n• कागदी बिलावरून आपला 'Consumer Number' टाका.\n• बिलाची रक्कम तपासून यूपीआय पिनने पैसे भरा.");

        DatabaseSeeder.insertStep(conn, l30, 1, "Tap 'Electricity' or 'Recharge'", "'Electricity' या 'Recharge' पर टैप करें", "'Electricity' किंवा 'Recharge' वर दाबा",
                "In PhonePe, Google Pay, or Paytm, scroll down to the 'Recharge & Pay Bills' section. Tap 'Electricity'.",
                "पेमेंट ऐप में 'Recharge & Pay Bills' में जाएं और पीले बल्ब वाले 'Electricity' पर टैप करें।",
                "पेमेंट अॅपमध्ये 'Recharge & Pay Bills' विभागात पिवळा बल्ब असलेल्या 'Electricity' वर दाबा.",
                "BILLPAY_UI", "BILL_MENU",
                "Select Electricity under the bill payment section.",
                "बिल भुगतान में बिजली (इलेक्ट्रिसिटी) का चयन करें।",
                "बिल पेमेंटमध्ये वीज (इलेक्ट्रिसिटी) पर्याय निवडा.");

        DatabaseSeeder.insertStep(conn, l30, 2, "Select Your Electricity Board", "अपना बिजली बोर्ड चुनें", "आपले वीज मंडळ निवडा",
                "Select your power company (e.g. 'MSEDCL - Mahavitaran', 'Tata Power', 'BESCOM', or 'UPPCL').",
                "अपनी बिजली कंपनी चुनें (जैसे 'महावितरण MSEDCL', 'टाटा पावर', या 'अडानी इलेक्ट्रिसिटी')।",
                "आपली वीज कंपनी निवडा (उदा. 'महावितरण MSEDCL', 'टाटा पॉवर' किंवा 'बेस्कॉम').",
                "BILLPAY_UI", "BOARD_SELECT",
                "Pick your state electricity board provider from the list.",
                "सूची में से अपने राज्य के बिजली बोर्ड का चयन करें।",
                "यादीतून आपल्या वीज कंपनीचे नाव निवडा.");

        DatabaseSeeder.insertStep(conn, l30, 3, "Enter Consumer Number from Paper Bill", "बिल पर लिखा 'Consumer Number' डालें", "बिलावरील 'Consumer Number' टाका",
                "Look at your old paper bill. Find the 12-digit 'Consumer Number' (ग्राहक क्र.) and type it. Tap Confirm.",
                "पुराने कागजी बिल पर लिखा 12 अंकों का 'उपभोक्ता नंबर (Consumer Number)' टाइप करें और कन्फर्म दबाएं।",
                "जुन्या कागदी बिलावरील १२ अंकी 'ग्राहक क्रमांक (Consumer Number)' टाईप करा आणि कन्फर्म दाबा.",
                "BILLPAY_UI", "CONSUMER_NUM",
                "Enter your unique consumer number shown on your printed electricity bill.",
                "कागजी बिल पर देखकर अपना उपभोक्ता नंबर दर्ज करें।",
                "कागदी बिलावरून आपला ग्राहक क्रमांक टाका.");

        DatabaseSeeder.insertStep(conn, l30, 4, "Verify Amount and Pay via UPI", "रकम जांचें और यूपीआई पिन से भरें", "रक्कम तपासा आणि यूपीआयने भरा",
                "The app instantly shows your exact due amount and due date. Tap 'Pay Bill', enter your secret UPI PIN, and get a receipt!",
                "ऐप तुरंत आपका सही बिल और नाम दिखाएगा। 'Pay Bill' दबाकर अपना गुप्त यूपीआई पिन डालें। पक्की रसीद स्क्रीन पर मिल जाएगी!",
                "अॅप लगेच तुमचे बिल आणि नाव दाखवेल. 'Pay Bill' दाबून आपला गुप्त यूपीआय पिन टाका. पक्की पावती स्क्रीनवर मिळेल!",
                "BILLPAY_UI", "BILL_PAID",
                "Check the bill amount and enter your UPI PIN to finish payment and get an instant digital receipt.",
                "बिल की रकम जांचें और पिन डालकर डिजिटल रसीद प्राप्त करें।",
                "बिलाची रक्कम तपासून पिन टाका आणि पक्की डिजिटल पावती मिळवा.");

        DatabaseSeeder.insertQuiz(conn, l30, "Where can you find your unique 'Consumer Number' to pay electricity bills on your phone?",
                "मोबाइल पर बिजली बिल भरने के लिए अपना 'Consumer Number' कहां से देखकर लिख सकते हैं?",
                "मोबाईलवर वीज बिल भरण्यासाठी लागणारा 'Consumer Number' कुठे सापडतो?",
                "It is printed prominently at the top of any previous month's paper electricity bill.",
                "यह पिछले किसी भी महीने के कागजी बिजली बिल के ऊपर साफ-साफ लिखा होता है।",
                "हा मागील कोणत्याही महिन्याच्या कागदी बिलावर वरच्या बाजूला ठळक अक्षरात असतो.",
                new String[]{"On your car tyre", "At the top of any previous month's printed electricity bill", "In the newspaper comic strip", "On your school certificate"},
                new String[]{"गाड़ी के टायर पर", "किसी भी पुराने कागजी बिजली बिल के ऊपरी हिस्से में", "अखबार के चुटकुले में", "स्कूल के सर्टिफिकेट पर"},
                new String[]{"गाडीच्या टायरवर", "जुन्या कागदी वीज बिलाच्या वरच्या भागात", "वर्तमानपत्रातील कोडीमध्ये", "शाळेच्या दाखल्यावर"}, 1);

        DatabaseSeeder.insertQuiz(conn, l30, "How do you know that your electricity bill was successfully paid?",
                "आपको कैसे पता चलता है कि आपका बिजली का बिल सफलतापूर्वक भर गया है?",
                "आपले वीज बिल यशस्वी भरले गेले हे कसे समजते?",
                "The app generates an instant green receipt with transaction ID, and your electricity board sends a confirmation SMS.",
                "स्क्रीन पर हरी डिजिटल रसीद और ट्रांजैक्शन आईडी आ जाती है, और बिजली बोर्ड का एसएमएस भी तुरंत मिलता है।",
                "स्क्रीनवर हिरवी पावती आणि ट्रान्झॅक्शन आयडी येतो, तसेच वीज मंडळाचा अधिकृत एसएमएसही येतो.",
                new String[]{"Your phone restarts", "An instant digital receipt is shown and confirmation SMS is received", "The light in the house turns off", "You must visit the power station"},
                new String[]{"फोन रीस्टार्ट हो जाता है", "स्क्रीन पर तुरंत रसीद दिखती है और पुष्टि का एसएमएस आता है", "घर की लाइट बंद हो जाती है", "पावर स्टेशन जाना पड़ता है"},
                new String[]{"फोन बंद होतो", "स्क्रीनवर त्वरित डिजिटल पावती दिसते आणि पुष्टीचा एसएमएस येतो", "घरातील लाईट बंद होते", "वीज केंद्रात जावे लागते"}, 1);

        DatabaseSeeder.insertQuiz(conn, l30, "Do you need to keep paying every month manually, or does the app remind you when the next bill arrives?",
                "क्या हर महीने बिल आने पर ऐप आपको अपने आप याद दिलाता है?",
                "पुढील महिन्याचे बिल आल्यावर अॅप आपोआप आठवण करून देतो का?",
                "Yes! The app saves your consumer number and automatically notifies you whenever a new bill is generated.",
                "हां! ऐप आपके नंबर को सुरक्षित रख लेता है और जैसे ही नया बिल बनता है, आपको तुरंत याद दिला देता है।",
                "होय! अॅप तुमचा ग्राहक क्रमांक सुरक्षित ठेवतो आणि नवीन बिल येताच आठवण करून देतो.",
                new String[]{"No, you must retype everything every month", "Yes, the app saves your details and sends a reminder when next bill arrives", "Only if you pay a penalty", "Only for factory bills"},
                new String[]{"नहीं, हर बार नए सिरे से लिखना पड़ता है", "हां, ऐप विवरण सहेजकर रखता है और नया बिल आने पर याद दिलाता है", "जुर्माना भरने पर ही", "केवल कारखानों के लिए"},
                new String[]{"नाही, दरमहा पुन्हा टाईप करावे लागते", "होय, अॅप माहिती सेव्ह ठेवतो आणि नवीन बिल आल्यावर आठवण करतो", "दंड भरल्यावरच", "फक्त कारखान्यांसाठी"}, 1);

        // L31: Checking Train PNR & Timings on IRCTC
        int l31 = DatabaseSeeder.insertLesson(conn, 31, 9, "Checking Train PNR & Timings on IRCTC", "ट्रेन का टिकट, पीएनआर और समय देखना", "रेल्वे तिकीट, पीएनआर आणि वेळ तपासणे",
                "Check whether your train ticket is Confirmed (CNF) and find platform numbers without asking around at stations.",
                "ट्रेन टिकट कन्फर्म हुआ या नहीं, और किस प्लेटफॉर्म पर गाड़ी आएगी यह घर बैठे देखना सीखें।",
                "तिकीट कन्फर्म (CNF) झाले की नाही आणि गाडी कोणत्या प्लॅटफॉर्मवर येणार हे घरबसल्या तपासणे शिका.",
                "BEGINNER", 5, "NONE", 4,
                "• Find the 10-digit PNR number printed at the top left of your train ticket.\n• Open IRCTC, NTES, or Where is my Train app.\n• Tap 'PNR Status' and enter 10 digits.\n• View coach number (e.g. B2, Berth 24 Lower) peacefully.",
                "• टिकट के ऊपर बाईं ओर लिखा 10 अंकों का पीएनआर नंबर ढूंढें।\n• 'Where is my Train' या IRCTC ऐप खोलें।\n• 'PNR Status' में 10 अंक दर्ज करें।\n• डिब्बा नंबर और लोअर बर्थ (जैसे B2, 24) आराम से देखें।",
                "• तिकिटावर डाव्या बाजूला असलेला १० अंकी पीएनआर नंबर शोधा.\n• 'Where is my Train' किंवा IRCTC अॅप उघडा.\n• 'PNR Status' मध्ये १० अंक टाका.\n• डबा नंबर आणि खालचा बर्थ (उदा. B2, २४) शांतपणे पहा.");

        DatabaseSeeder.insertStep(conn, l31, 1, "Locate the 10-Digit PNR on Ticket", "टिकट पर 10 अंकों का पीएनआर नंबर देखें", "तिकिटावरील १० अंकी पीएनआर नंबर शोधा",
                "Look at the top-left corner of your train ticket or reservation SMS. Find the 10-digit number called 'PNR'.",
                "अपने ट्रेन टिकट या बुकिंग एसएमएस में ऊपर बाईं तरफ देखें। वहां 10 अंकों का 'PNR' नंबर लिखा होता है।",
                "आपल्या रेल्वे तिकिटावर किंवा मेसेजमध्ये डाव्या बाजूला १० अंकी 'PNR' नंबर लिहिलेला असतो तो शोधा.",
                "PHONE_UI", "TRAIN_PNR",
                "Find the 10-digit PNR number on your railway ticket.",
                "अपने रेलवे टिकट पर 10 अंकों का पीएनआर नंबर ढूंढें।",
                "रेल्वे तिकिटावरील १० अंकी पीएनआर नंबर शोधा.");

        DatabaseSeeder.insertStep(conn, l31, 2, "Open 'Where is my Train' or IRCTC", "ट्रेन ऐप खोलें", "रेल्वे अॅप उघडा",
                "Open 'Where is my Train' or official IRCTC app. Tap the button that says 'PNR Status'.",
                "'Where is my Train' या आईआरसीटीसी ऐप खोलें और 'PNR Status' पर टैप करें।",
                "'Where is my Train' किंवा IRCTC अॅप उघडा आणि 'PNR Status' पर्यायावर दाबा.",
                "PHONE_UI", "TRAIN_APP",
                "Open the PNR Status checker in your railway app.",
                "रेलवे ऐप में पीएनआर स्टेटस विकल्प खोलें।",
                "रेल्वे अॅपमध्ये पीएनआर स्टेटस पर्याय उघडा.");

        DatabaseSeeder.insertStep(conn, l31, 3, "Enter 10 Digits and Check Status", "10 अंक लिखें और स्थिति जांचें", "१० अंक लिहा आणि स्थिती तपासा",
                "Type the 10 digits and tap 'Find PNR Status'. The screen shows 'CNF' (Confirmed) or your Waitlist number.",
                "10 अंक लिखकर सर्च दबाएं। स्क्रीन पर दिखेगा 'CNF' (कन्फर्म) या वेटिंग लिस्ट की वर्तमान स्थिति।",
                "१० अंक लिहून शोधा. स्क्रीनवर 'CNF' (कन्फर्म) किंवा वेटिंग लिस्टची खरी स्थिती दिसेल.",
                "PHONE_UI", "PNR_RESULT",
                "Verify your confirmation status and assigned berth number.",
                "अपनी सीट कन्फर्म हुई या नहीं और सीट नंबर जांचें।",
                "आपली सीट कन्फर्म झाली का आणि सीट नंबर तपासा.");

        DatabaseSeeder.insertStep(conn, l31, 4, "Find Coach and Lower Berth", "डिब्बा नंबर और लोअर बर्थ देखें", "डबा नंबर आणि खालची सीट पहा",
                "If confirmed, it shows: Coach 'B3', Berth '35' (Lower Berth / LB). You can walk directly to your coach at the station!",
                "कन्फर्म होने पर डिब्बा नंबर (जैसे B3) और सीट नंबर (जैसे 35 - लोअर बर्थ) दिखेगा। स्टेशन पर सीधे अपने डिब्बे में जा सकते हैं!",
                "कन्फर्म झाल्यावर डबा नंबर (उदा. B3) आणि सीट (उदा. ३५ - लोअर बर्थ) दिसेल. स्टेशनवर थेट आपल्या डब्याकडे जाऊ शकता!",
                "PHONE_UI", "BERTH_DISPLAY",
                "Know your exact coach and seat number before stepping onto the platform.",
                "प्लेटफॉर्म पर जाने से पहले अपना डिब्बा और सीट नंबर पक्का जान लें।",
                "प्लॅटफॉर्मवर जाण्यापूर्वी आपला डबा आणि सीट नंबर नक्की माहिती करून घ्या.");

        DatabaseSeeder.insertQuiz(conn, l31, "What does 'CNF' stand for on a railway PNR inquiry screen?",
                "ट्रेन के पीएनआर स्टेटस में 'CNF' लिखे होने का क्या मतलब होता है?",
                "रेल्वे पीएनआर चौकशीमध्ये 'CNF' दिसल्यास त्याचा अर्थ काय?",
                "It means Confirmed; your seat or sleeping berth is officially guaranteed.",
                "इसका मतलब है 'Confirmed' (कन्फर्म); आपकी सीट या सोने की बर्थ पक्की हो गई है।",
                "याचा अर्थ 'Confirmed' (कन्फर्म); तुमची सीट किंवा झोपण्याची जागा पक्की झाली आहे.",
                new String[]{"Cancelled completely", "Confirmed (your seat and berth are guaranteed)", "Call New Friends", "Car Not Found"},
                new String[]{"पूरी तरह रद्द", "Confirmed (कन्फर्म - सीट पक्की है)", "नए दोस्त बनाएं", "गाड़ी नहीं मिली"},
                new String[]{"तिकीट रद्द झाले", "Confirmed (कन्फर्म - सीट पक्की झाली)", "मित्रांना फोन करा", "गाडी सापडली नाही"}, 1);

        DatabaseSeeder.insertQuiz(conn, l31, "What does 'LB' stand for on your confirmed senior citizen railway ticket?",
                "सीट नंबर के आगे 'LB' लिखे होने का क्या अर्थ होता है?",
                "सीट नंबरपुढे 'LB' लिहिलेले असल्यास त्याचा काय अर्थ होतो?",
                "LB stands for Lower Berth (the ground floor bed which does not require climbing ladders).",
                "LB का मतलब है 'Lower Berth' (नीचे वाली सीट), जिस पर चढ़ने के लिए सीढ़ी की जरूरत नहीं होती।",
                "LB म्हणजे 'Lower Berth' (खालची सीट), ज्यावर चढण्यासाठी शिडीची गरज नसते.",
                new String[]{"Late Bus", "Lower Berth (bottom bed without climbing)", "Lost Baggage", "Light Bulb"},
                new String[]{"देर से आने वाली बस", "Lower Berth (नीचे वाली आरामदेह सीट)", "खोया हुआ सामान", "बिजली का बल्ब"},
                new String[]{"उशिरा येणारी बस", "Lower Berth (खालची आरामदायी सीट)", "हरवलेले सामान", "विजेचा दिवा"}, 1);

        DatabaseSeeder.insertQuiz(conn, l31, "How many digits does an Indian Railways PNR number have?",
                "भारतीय रेलवे के पीएनआर (PNR) नंबर में कितने अंक होते हैं?",
                "भारतीय रेल्वेच्या पीएनआर (PNR) नंबरमध्ये किती अंक असतात?",
                "All railway PNR numbers have exactly 10 digits.",
                "रेलवे पीएनआर में ठीक 10 अंक होते हैं।",
                "रेल्वे पीएनआरमध्ये बरोबर १० अंक असतात.",
                new String[]{"4 digits", "10 digits", "16 digits", "20 digits"},
                new String[]{"4 अंक", "10 अंक", "16 अंक", "20 अंक"},
                new String[]{"४ अंक", "१० अंक", "१६ अंक", "२० अंक"}, 1);
    }

    // ==========================================
    // CAT 10: EMAIL (Lessons 32 - 34)
    // ==========================================
    private static void seedCat10Email(Connection conn) throws Exception {
        // L32: Composing & Sending an Email
        int l32 = DatabaseSeeder.insertLesson(conn, 32, 10, "Composing & Sending an Email", "ईमेल लिखना और भेजना", "ईमेल लिहिणे आणि पाठवणे",
                "Send formal letters, pension documents, and greetings through Gmail safely.",
                "बैंक, पेंशन दफ्तर या परिवार को ईमेल लिखना और फोटो लगाकर भेजना सीखें।",
                "बँक, पेन्शन कार्यालय किंवा कुटुंबाला ईमेल लिहिणे आणि कागदपत्रे जोडून पाठवणे शिका.",
                "BEGINNER", 5, "EMAIL", 1,
                "• Open Gmail app (red 'M' envelope icon).\n• Tap 'Compose' at bottom right.\n• Fill 'To' (recipient email) and 'Subject' (topic summary).\n• Write message and tap the blue paper airplane to Send.",
                "• जीमेल ऐप खोलें (लाल 'M' वाला लिफाफा)।\n• नीचे 'Compose' बटन दबाएं।\n• 'To' में ईमेल पता और 'Subject' में विषय लिखें।\n• संदेश लिखकर ऊपर नीले तीर से सेंड करें।",
                "• जीमेल अॅप उघडा (लाल 'M' असलेले पाकीट).\n• खाली 'Compose' बटणावर दाबा.\n• 'To' मध्ये पत्ता आणि 'Subject' मध्ये विषय लिहा.\n• संदेश लिहून वरच्या निळ्या बाणाने पाठवा.");

        DatabaseSeeder.insertStep(conn, l32, 1, "Open Gmail and Tap 'Compose'", "जीमेल खोलें और 'Compose' दबाएं", "जीमेल उघडा आणि 'Compose' दाबा",
                "Tap the Gmail app with the red 'M' icon. At the bottom right, tap the colorful '+' or pencil button that says 'Compose'.",
                "लाल 'M' वाले जीमेल ऐप को खोलें। नीचे दाईं तरफ बने पेंसिल या रंग-बिरंगे '+' वाले 'Compose' बटन को छुएं।",
                "लाल 'M' असलेले जीमेल अॅप उघडा. खाली उजव्या बाजूला असलेल्या 'Compose' किंवा पेन्सिलच्या चिन्हावर दाबा.",
                "PHONE_UI", "EMAIL_COMPOSE",
                "Tap the Compose button to start a fresh email.",
                "नया ईमेल लिखने के लिए कंपोज बटन दबाएं।",
                "नवीन ईमेल लिहिण्यासाठी कंपोज बटणावर दाबा.");

        DatabaseSeeder.insertStep(conn, l32, 2, "Enter 'To' Address and 'Subject'", "'To' और 'Subject' भरें", "'To' आणि 'Subject' भरा",
                "'To' is the recipient address (e.g. 'anita.sharma@gmail.com'). 'Subject' is a short summary title (e.g. 'Pension Life Certificate').",
                "'To' में पाने वाले का ईमेल पता लिखें। 'Subject' में छोटा विषय लिखें (जैसे: 'पेंशन जीवन प्रमाण पत्र')।",
                "'To' मध्ये ईमेल पत्ता लिहा. 'Subject' मध्ये थोडक्यात विषय लिहा (उदा. 'पेन्शन लाइफ सर्टिफिकेट').",
                "PHONE_UI", "EMAIL_FIELDS",
                "Enter the recipient email address and a concise subject line.",
                "प्राप्तकर्ता का ईमेल और संक्षिप्त विषय दर्ज करें।",
                "मिळणाऱ्याचा ईमेल आणि थोडक्यात विषय टाका.");

        DatabaseSeeder.insertStep(conn, l32, 3, "Type Your Message in the Large Body", "नीचे बड़े हिस्से में अपना संदेश लिखें", "खाली मोठ्या जागेत आपला संदेश लिहा",
                "Tap in the large white area labeled 'Compose email'. Write your message politely and comfortably.",
                "नीचे खाली बड़ी जगह में अपना पूरा संदेश सम्मानपूर्वक लिखें (जैसे: 'सादर प्रणाम, कृपया संलग्न दस्तावेज देखें')।",
                "खालच्या मोकळ्या जागेत आपला संपूर्ण संदेश आदराने लिहा (उदा. 'सप्रेम नमस्कार, कागदपत्रे जोडली आहेत').",
                "PHONE_UI", "EMAIL_BODY",
                "Type your message body clearly in the main text box.",
                "मुख्य बॉक्स में अपना संदेश लिखें।",
                "मुख्य जागेत आपला संदेश लिहा.");

        DatabaseSeeder.insertStep(conn, l32, 4, "Tap the Blue Paper Airplane to Send", "नीला तीर दबाकर ईमेल भेजें", "निळा बाण दाबून ईमेल पाठवा",
                "Look at the top right corner. Tap the blue paper airplane icon. The email flies instantly to the recipient!",
                "ऊपर दाईं तरफ देखें। नीले कागज के हवाई जहाज वाले निशान पर टैप करें। आपका ईमेल तुरंत पहुंच जाएगा!",
                "वरच्या उजव्या बाजूला असलेल्या निळ्या कागदी विमानाच्या चिन्हावर दाबा. ईमेल लगेच पाठवला जाईल!",
                "PHONE_UI", "EMAIL_SEND",
                "Tap the blue send icon at top right to send your email.",
                "ईमेल भेजने के लिए ऊपर नीले सेंड आइकन पर टैप करें।",
                "ईमेल पाठवण्यासाठी वरच्या निळ्या बाणावर दाबा.");

        DatabaseSeeder.insertQuiz(conn, l32, "What should be written in the 'Subject' line of an email?",
                "ईमेल की 'Subject' (विषय) वाली लाइन में क्या लिखना चाहिए?",
                "ईमेलच्या 'Subject' (विषय) ओळीत काय लिहावे?",
                "A brief title summarizing what the email is about (e.g. 'Electricity Bill Query').",
                "ईमेल किस बारे में है, उसका छोटा और साफ शीर्षक (जैसे 'पेंशन संबंधी सवाल')।",
                "ईमेल कशाबद्दल आहे त्याचा लहान आणि स्पष्ट विषय (उदा. 'पेन्शनबाबत विचारणा').",
                new String[]{"Your bank ATM PIN", "A short summary of what the email is about", "Your entire life history", "Nothing, it must always be left empty"},
                new String[]{"अपना बैंक एटीएम पिन", "ईमेल के विषय का छोटा और साफ सारांश", "अपनी पूरी जीवनी", "कुछ नहीं, इसे खाली छोड़ना जरूरी है"},
                new String[]{"आपला एटीएम पिन", "ईमेलचा लहान आणि स्पष्ट विषय", "स्वतःचे संपूर्ण आत्मचरित्र", "काहीच नाही, रिकामे ठेवावे"}, 1);

        DatabaseSeeder.insertQuiz(conn, l32, "What symbol do you press in Gmail to attach a photo or PDF document to your email?",
                "ईमेल में कोई फोटो या पीडीएफ फाइल जोड़ने के लिए किस निशान को दबाया जाता है?",
                "ईमेलसोबत फोटो किंवा फाईल जोडण्यासाठी कोणत्या चिन्हावर दाबावे?",
                "The paperclip icon 📎 opens the file picker to attach documents.",
                "कागज की क्लिप (पेपरक्लिप 📎) का निशान फाइल या फोटो जोड़ने के लिए होता है।",
                "पेपरक्लिप 📎 चे चिन्ह फाईल किंवा फोटो जोडण्यासाठी असते.",
                new String[]{"The paperclip icon 📎", "The trash bin", "The volume button", "The power switch"},
                new String[]{"पेपरक्लिप का निशान 📎", "कचरे का डिब्बा", "आवाज का बटन", "पावर बटन"},
                new String[]{"पेपरक्लिपचे चिन्ह 📎", "कचऱ्याचा डबा", "आवाजाचे बटण", "पॉवर बटण"}, 0);

        DatabaseSeeder.insertQuiz(conn, l32, "Which icon at the top right of the compose screen sends the email?",
                "लिखने के बाद ईमेल को भेजने के लिए ऊपर कौन सा निशान दबाया जाता है?",
                "ईमेल लिहून झाल्यावर पाठवण्यासाठी वर कोणते चिन्ह दाबावे?",
                "The blue paper airplane or send triangle sends the email.",
                "कागज के हवाई जहाज (सेंड) का निशान ईमेल को तुरंत भेज देता है।",
                "कागदी विमानाचे (सेंड) चिन्ह ईमेल लगेच पाठवते.",
                new String[]{"The blue paper airplane / triangle", "The lock symbol", "The camera lens", "The wifi waves"},
                new String[]{"नीले कागज का हवाई जहाज / त्रिभुज", "ताले का निशान", "कैमरा लेंस", "वाई-फाई की तरंगे"},
                new String[]{"निळे कागदी विमान / त्रिकोण", "कुलूपाचे चिन्ह", "कॅमेरा", "वाय-फाय लाटा"}, 0);

        // L33: Reading Emails & Opening Attachments
        int l33 = DatabaseSeeder.insertLesson(conn, 33, 10, "Reading Emails & Opening Attachments", "ईमेल पढ़ना और फाइल खोलना", "ईमेल वाचणे आणि फाईल उघडणे",
                "Read bank statements, utility bills, and medical lab reports sent to your email inbox.",
                "इनबॉक्स में आए बैंक के पत्र, बिजली बिल और लैब की खून जांच रिपोर्ट देखना सीखें।",
                "इनबॉक्समध्ये आलेली बँक विवरणे, वीज बिल आणि रक्ताच्या तपासणीचे रिपोर्ट उघडून पाहणे शिका.",
                "BEGINNER", 4, "EMAIL", 2,
                "• Unread emails appear in bold black text in your Inbox.\n• Tap any email to read it full screen.\n• Tap the attachment box at the bottom to view PDF lab reports.\n• Tap Reply arrow to answer.",
                "• न पढ़े गए ईमेल इनबॉक्स में मोटे काले अक्षरों में दिखते हैं।\n• पढ़ने के लिए किसी भी ईमेल पर टैप करें।\n• नीचे बने चौकोर डिब्बे को छूकर मेडिकल रिपोर्ट या पीडीएफ देखें।\n• जवाब देने के लिए मुड़े हुए तीर (Reply) पर टैप करें।",
                "• न वाचलेले ईमेल इनबॉक्समध्ये ठळक काळ्या अक्षरात दिसतात.\n• वाचण्यासाठी कोणत्याही ईमेलवर दाबा.\n• खालील चौकोनावर दाबून लॅब रिपोर्ट किंवा पीडीएफ फाईल उघडा.\n• उत्तर देण्यासाठी 'Reply' बाणावर दाबा.");

        DatabaseSeeder.insertStep(conn, l33, 1, "Bold Emails are New and Unread", "मोटे अक्षरों वाले ईमेल नए होते हैं", "ठळक अक्षरांचे ईमेल नवीन असतात",
                "Open Gmail. Look at your Inbox. Emails written in bold dark font are fresh messages that you haven't opened yet.",
                "जीमेल खोलें। जो ईमेल मोटे काले अक्षरों में दिख रहे हैं, वे नए पत्र हैं जिन्हें आपने अभी तक नहीं पढ़ा है।",
                "जीमेल उघडा. जे ईमेल ठळक काळ्या अक्षरात दिसत आहेत, ते नवीन आलेले मेसेज आहेत जे अजून वाचलेले नाहीत.",
                "PHONE_UI", "EMAIL_INBOX",
                "Bold subject lines indicate new unread emails in your inbox.",
                "मोटे काले अक्षर नए बिना पढ़े ईमेल को दर्शाते हैं।",
                "ठळक काळी अक्षरे नवीन न वाचलेले ईमेल दर्शवतात.");

        DatabaseSeeder.insertStep(conn, l33, 2, "Tap to Open and Read", "खोलने के लिए टैप करें", "वाचण्यासाठी दाबा",
                "Tap on the email. It opens cleanly. You can read the sender's message, date, and time.",
                "उस ईमेल पर उंगली से टैप करें। पूरा पत्र खुल जाएगा और आप आराम से संदेश पढ़ सकेंगे।",
                "त्या ईमेलवर दाबा. पूर्ण पत्र उघडेल आणि तुम्ही शांतपणे संदेश वाचू शकाल.",
                "PHONE_UI", "EMAIL_READ",
                "Tap any message to open and read its contents comfortably.",
                "ईमेल पढ़ने के लिए उस पर टैप करें।",
                "ईमेल वाचण्यासाठी त्यावर दाबा.");

        DatabaseSeeder.insertStep(conn, l33, 3, "View Attached PDF or Lab Report", "संलग्न रिपोर्ट या पीडीएफ खोलें", "जोडलेला रिपोर्ट किंवा पीडीएफ उघडा",
                "Scroll to the bottom of the email. If the hospital or bank sent a file, you will see a box with a red PDF icon. Tap it to view.",
                "ईमेल में नीचे जाएं। यदि अस्पताल या बैंक ने कोई पर्चा भेजा है, तो लाल पीडीएफ वाला डिब्बा दिखेगा। उसे छूकर रिपोर्ट देखें।",
                "ईमेलच्या खाली जा. दवाखान्याने पाठवलेला रिपोर्ट लाल रंगाच्या पीडीएफ चौकोनात दिसेल. त्यावर दाबून रिपोर्ट पहा.",
                "PHONE_UI", "EMAIL_ATTACH_VIEW",
                "Tap the attachment box at the bottom to view the document.",
                "फाइल या रिपोर्ट देखने के लिए नीचे दिए गए डिब्बे पर टैप करें।",
                "फाईल किंवा रिपोर्ट पाहण्यासाठी खालील चौकोनावर दाबा.");

        DatabaseSeeder.insertStep(conn, l33, 4, "Reply to the Sender", "प्रेषक को जवाब दें", "पाठवणाऱ्याला उत्तर द्या",
                "To write back, tap the backward curved arrow at the bottom ('Reply'). Type your answer and tap Send.",
                "जवाब देने के लिए नीचे मुड़े हुए तीर (Reply) पर टैप करें। अपनी बात लिखकर भेजें।",
                "उत्तर देण्यासाठी खालील वळलेल्या बाणावर (Reply) दाबा. आपला संदेश लिहून पाठवा.",
                "PHONE_UI", "EMAIL_REPLY",
                "Tap Reply to answer the sender directly.",
                "सीधा जवाब देने के लिए रिप्लाई तीर पर टैप करें।",
                "थेट उत्तर देण्यासाठी रिप्लाय बाणावर दाबा.");

        DatabaseSeeder.insertQuiz(conn, l33, "How can you tell which emails in your inbox are fresh and unread?",
                "इनबॉक्स में कौन से ईमेल नए हैं जिन्हें अभी तक नहीं पढ़ा गया, यह कैसे पहचानते हैं?",
                "इनबॉक्समधील कोणते ईमेल नवीन आहेत हे कसे ओळखायचे?",
                "Unread emails appear in bold dark text with a highlighted sender name.",
                "न पढ़े गए ईमेल मोटे और गहरे काले अक्षरों में लिखे होते हैं।",
                "न वाचलेले ईमेल ठळक आणि गडद काळ्या अक्षरात लिहिलेले असतात.",
                new String[]{"They are written in invisible ink", "Unread emails are displayed in bold dark text", "They play a song constantly", "They are upside down"},
                new String[]{"वे अदृश्य स्याही से लिखे होते हैं", "न पढ़े गए ईमेल मोटे गहरे काले अक्षरों में दिखते हैं", "वे लगातार गाना बजाते हैं", "वे उल्टे लिखे होते हैं"},
                new String[]{"ते दिसतच नाहीत", "न वाचलेले ईमेल ठळक काळ्या अक्षरात दिसतात", "ते गाणे वाजवतात", "ते उलटे असतात"}, 1);

        DatabaseSeeder.insertQuiz(conn, l33, "Where do PDF medical reports or bank statements attached to an email appear?",
                "ईमेल के साथ आई खून जांच रिपोर्ट या बैंक स्टेटमेंट कहां दिखाई देती है?",
                "ईमेलसोबत आलेला रिपोर्ट किंवा बँक स्टेटमेंट कुठे दिसते?",
                "Attachments appear as rectangular preview boxes at the very bottom of the email.",
                "संलग्न फाइलें ईमेल के सबसे नीचे चौकोर डिब्बों के रूप में दिखाई देती हैं।",
                "जोडलेल्या फाईल्स ईमेलच्या अगदी शेवटी चौकोनी बॉक्सच्या रूपात दिसतात.",
                new String[]{"Inside the phone battery", "In rectangular attachment preview boxes at the bottom of the email", "On the SIM card", "In the calendar"},
                new String[]{"फोन की बैटरी में", "ईमेल के सबसे नीचे चौकोर प्रिव्यू डिब्बों में", "सिम कार्ड पर", "कैलेंडर में"},
                new String[]{"फोनच्या बॅटरीमध्ये", "ईमेलच्या अगदी खाली चौकोनी बॉक्समध्ये", "सिम कार्डवर", "कॅलेंडरमध्ये"}, 1);

        DatabaseSeeder.insertQuiz(conn, l33, "What does the curved arrow ↩ at the bottom of an email do?",
                "ईमेल के नीचे बना मुड़ा हुआ तीर ↩ क्या काम करता है?",
                "ईमेलच्या खाली असलेला वळलेला बाण ↩ काय करतो?",
                "It starts a 'Reply' so you can write back to the person who sent the email.",
                "यह 'Reply' (जवाब) शुरू करता है ताकि आप भेजने वाले को उत्तर लिख सकें।",
                "हा 'Reply' (उत्तर) सुरू करतो जेणेकरून पाठवणाऱ्याला उत्तर देता येते.",
                new String[]{"Deletes your Gmail account", "Starts a Reply to write back to the sender", "Turns off Wi-Fi", "Locks the phone screen"},
                new String[]{"जीमेल खाता मिटा देता है", "भेजने वाले को उत्तर लिखने के लिए रिप्लाई शुरू करता है", "वाई-फाई बंद करता है", "स्क्रीन लॉक करता है"},
                new String[]{"जीमेल खाते बंद करतो", "पाठवणाऱ्याला उत्तर लिहिण्यासाठी रिप्लाय सुरू करतो", "वाय-फाय बंद करतो", "स्क्रीन लॉक करतो"}, 1);

        // L34: Spotting Spam & Scam Emails
        int l34 = DatabaseSeeder.insertLesson(conn, 34, 10, "Spotting Spam & Scam Emails", "फर्जी ईमेल और स्पैम से सावधान", "बनावट ईमेल आणि स्पॅमपासून सावध",
                "Protect your identity and savings by recognizing fake lottery, job, and foreign inheritance emails.",
                "लॉटरी, नौकरी और इनाम के झूठे ईमेल को पहचानना और स्पैम में डालना सीखें।",
                "बक्षीस, लॉटरी आणि नोकरीच्या खोट्या ईमेलपासून स्वतःचे रक्षण करणे शिका.",
                "BEGINNER", 4, "EMAIL", 3,
                "• Scammers email: 'You inherited $5 Million from London' or 'Click here to claim ₹50,000 gift card'.\n• Never click blue links or open strange attachments from unknown foreigners.\n• Tap three dots and choose 'Report Spam' to block them forever.",
                "• धोखेबाज लिखते हैं: 'आपको विदेश से करोड़ों की वसीयत मिली है' या 'उपहार के लिए लिंक दबाएं'।\n• अनजान लोगों की भेजी नीली लिंक कभी न छुएं।\n• तीन बिंदुओं पर टैप करके 'Report Spam' चुनें और ब्लॉक करें।",
                "• भामटे ईमेल करतात: 'तुम्हाला परदेशातून करोडोंची संपत्ती मिळाली आहे' किंवा 'बक्षिसासाठी लिंक दाबा'.\n• अनोळखी लोकांनी पाठवलेल्या निळ्या लिंकवर कधीही क्लिक करू नका.\n• तीन ठिपक्यांवर दाबून 'Report Spam' निवडा आणि कायमचे ब्लॉक करा.");

        DatabaseSeeder.insertStep(conn, l34, 1, "The 'You Won $5 Million' Trap", "करोड़ों के इनाम का लालच पहचानें", "करोडो रुपयांचे आमिष ओळखा",
                "Scammers send emails pretending to be a lawyer in London or a lottery official in Dubai promising unearned riches. IT IS 100% FRAUD.",
                "धोखेबाज लंदन के वकील या दुबई लॉटरी अधिकारी बनकर ईमेल भेजते हैं कि आपको करोड़ों रुपये मिले हैं। यह 100% फ्रॉड है।",
                "भामटे परदेशातील वकील किंवा लॉटरी अधिकारी असल्याचे भासवून करोडो रुपये मिळाल्याचा ईमेल पाठवतात. हा १००% फ्रॉड आहे.",
                "WARNING_BOX", "EMAIL_SCAM_1",
                "Unsolicited prize and foreign inheritance emails are always scams.",
                "इनाम और विदेशी वसीयत वाले ईमेल हमेशा ठगी का जाल होते हैं।",
                "परदेशी संपत्ती आणि लॉटरीचे ईमेल नेहमी फसवे असतात.");

        DatabaseSeeder.insertStep(conn, l34, 2, "Never Click Mysterious Blue Links", "अनजान नीली लिंक कभी न छुएं", "अनोळखी निळ्या लिंकवर कधीही क्लिक करू नका",
                "These emails contain links like 'Click Here to Claim'. Clicking them takes you to fake phishing pages designed to steal passwords.",
                "ऐसे ईमेल में 'Click Here' लिखी नीली लिंक होती हैं। उन्हें छूने से आपके पासवर्ड चुराने वाली नकली वेबसाइट खुल जाती है।",
                "अशा ईमेलमध्ये 'Click Here' लिहिलेल्या निळ्या लिंक असतात. त्यावर दाबल्यास पासवर्ड चोरणाऱ्या बनावट वेबसाइट उघडतात.",
                "WARNING_BOX", "PHISHING_LINK",
                "Never click links inside emails from senders you do not recognize.",
                "अनजान लोगों के ईमेल में आई लिंक पर कभी क्लिक न करें।",
                "अनोळखी व्यक्तींच्या ईमेलमधील लिंकवर कधीही दाबू नका.");

        DatabaseSeeder.insertStep(conn, l34, 3, "Never Open Attachments from Strangers", "अनजान फाइलें कभी डाउनलोड न करें", "अनोळखी फाईल कधीही डाऊनलोड करू नका",
                "If an unknown email has a zip file or file ending in '.exe' or '.scr', DO NOT open it. It can install viruses onto your phone.",
                "अगर अनजान ईमेल में कोई अज्ञात फाइल जुड़ी हो, तो उसे कभी न खोलें। उसमें फोन खराब करने वाले वायरस हो सकते हैं।",
                "जर अनोळखी ईमेलसोबत संशयास्पद फाईल असेल, तर ती मुळीच उघडू नका. त्यात व्हायरस असू शकतो.",
                "WARNING_BOX", "DANGEROUS_ATTACHMENT",
                "Do not download attachments from unrecognized senders.",
                "अपरिचित ईमेल से आई फाइलें कभी डाउनलोड न करें।",
                "अनोळखी ईमेलवरून आलेल्या फाईल्स कधीही उघडू नका.");

        DatabaseSeeder.insertStep(conn, l34, 4, "Tap Three Dots and 'Report Spam'", "'Report Spam' दबाकर बाहर निकालें", "'Report Spam' करून कायमचे बंद करा",
                "Tap the three dots at the top right of the scam email. Tap 'Report spam'. Gmail will block that sender permanently!",
                "ऊपर तीन बिंदुओं पर टैप करें। 'Report spam' चुनें। जीमेल उस धोखेबाज को हमेशा के लिए ब्लॉक कर देगा!",
                "वरच्या तीन ठिपक्यांवर दाबा. 'Report spam' निवडा. जीमेल त्या भामट्याला कायमचा ब्लॉक करेल!",
                "PHONE_UI", "REPORT_SPAM",
                "Report suspicious messages as spam to keep your inbox clean and protected.",
                "संदिग्ध ईमेल को स्पैम मार्क करके अपना इनबॉक्स सुरक्षित रखें।",
                "संशयास्पद ईमेल स्पॅम म्हणून नोंदवून इनबॉक्स सुरक्षित ठेवा.");

        DatabaseSeeder.insertQuiz(conn, l34, "If you receive an email stating: 'Congratulations! You won ₹50 Lakhs in the UK National Lottery, click here', what is the truth?",
                "अगर ईमेल आए: 'बधाई हो! आपने यूके लॉटरी में ₹50 लाख जीते हैं, यहां क्लिक करें', तो सच क्या है?",
                "जर ईमेल आला की: 'अभिनंदन! तुम्ही ५० लाख रुपयांची लॉटरी जिंकली आहे, येथे क्लिक करा', तर सत्य काय आहे?",
                "It is a classic advance-fee fraud scam. You cannot win a lottery you never entered.",
                "यह पूरी तरह झूठा ठगी का जाल है। जिस लॉटरी का टिकट ही नहीं खरीदा, वह कभी नहीं जीती जा सकती।",
                "हा निव्वळ खोटेपणा आणि फसवणूक आहे. ज्या लॉटरीचे तिकीटच काढले नाही, ती कशी जिंकणार?",
                new String[]{"Pack your bags for London", "It is 100% fake scam; report it as spam and delete it", "Send your passport and bank details", "Forward it to your boss"},
                new String[]{"लंदन जाने की तैयारी करें", "यह 100% फर्जी फ्रॉड है; इसे स्पैम में डालकर मिटा दें", "पासपोर्ट और बैंक विवरण भेजें", "अपने दफ्तर में भेजें"},
                new String[]{"लंडनला जाण्याची तयारी करा", "हा १००% बनावट फ्रॉड आहे; स्पॅम करून डिलीट करा", "पासपोर्ट आणि बँक खात्याची माहिती द्या", "इतरांना पाठवा"}, 1);

        DatabaseSeeder.insertQuiz(conn, l34, "What should you do with suspicious blue links inside an email from an unknown sender?",
                "किसी अनजान व्यक्ति के ईमेल में आई नीली लिंक के साथ क्या करना चाहिए?",
                "अनोळखी व्यक्तीच्या ईमेलमधील निळ्या लिंकचे काय करावे?",
                "Never click or tap on them; they can lead to dangerous phishing websites.",
                "उन्हें कभी न छुएं; वे पासवर्ड और बैंक विवरण चुराने वाली नकली वेबसाइट पर ले जाती हैं।",
                "त्यावर कधीही क्लिक करू नका; त्या धोकादायक बनावट वेबसाइटवर घेऊन जातात.",
                new String[]{"Tap them 5 times quickly", "Never click on them under any circumstances", "Forward them to grandchildren", "Save them as wallpaper"},
                new String[]{"जल्दी से 5 बार टैप करें", "उन्हें किसी भी हाल में कभी न छुएं", "पोते-पोतियों को भेजें", "वॉलपेपर बना लें"},
                new String[]{"५ वेळा दाबा", "त्यावर कधीही क्लिक करू नका", "नातवंडांना पाठवा", "वॉलपेपर ठेवा"}, 1);

        DatabaseSeeder.insertQuiz(conn, l34, "Where does Gmail automatically quarantine most junk advertising and malicious emails?",
                "जीमेल ज्यादातर फालतू विज्ञापनों और संदिग्ध ईमेल्स को अपने आप किस फोल्डर में डाल देता है?",
                "जीमेल बहुतांश फालतू जाहिराती आणि संशयास्पद ईमेल्स आपोआप कोणत्या फोल्डरमध्ये टाकतो?",
                "Gmail isolates them safely in the 'Spam' or 'Junk' folder.",
                "जीमेल उन्हें सुरक्षित रूप से 'Spam' (स्पैम) फोल्डर में अलग बंद करके रखता है।",
                "जीमेल त्यांना सुरक्षितपणे 'Spam' किंवा 'Junk' फोल्डरमध्ये वेगळे ठेवतो.",
                new String[]{"In the Camera app", "In the 'Spam' / 'Junk' folder", "In the music player", "On the SIM card"},
                new String[]{"कैमरा ऐप में", "'Spam' (स्पैम) फोल्डर में", "म्यूजिक प्लेयर में", "सिम कार्ड पर"},
                new String[]{"कॅमेरा अॅपमध्ये", "'Spam' / 'Junk' फोल्डरमध्ये", "गाण्यांच्या प्लेअरमध्ये", "सिम कार्डवर"}, 1);
    }

    // ==========================================
    // CAT 11: DIGITAL SAFETY & SCAMS (Lessons 35 - 38)
    // ==========================================
    private static void seedCat11Safety(Connection conn) throws Exception {
        // L35: The 6 Golden Rules of Digital Safety
        int l35 = DatabaseSeeder.insertLesson(conn, 35, 11, "The 6 Golden Rules of Digital Safety", "डिजिटल सुरक्षा के 6 अमर नियम", "डिजिटल सुरक्षेचे ६ सुवर्ण नियम",
                "Master the essential rules to protect your life savings and pensions from cyber criminals.",
                "अपनी जिंदगी भर की कमाई और पेंशन को साइबर ठगों से सुरक्षित रखने के 6 जरूरी नियम सीखें।",
                "आयुभराची पुंजी आणि पेन्शन सायबर भामट्यांपासून सुरक्षित ठेवण्याचे ६ महत्त्वाचे नियम शिका.",
                "BEGINNER", 6, "NONE", 1,
                "• Rule 1: Never share your OTP with anyone.\n• Rule 2: Never enter your PIN to receive money.\n• Rule 3: Never install AnyDesk or screen sharing apps.\n• Rule 4: Ignore lottery and prize messages.\n• Rule 5: Verify urgent disconnection threats.\n• Rule 6: When in doubt, consult family.",
                "• नियम 1: किसी को कभी अपना ओटीपी न बताएं।\n• नियम 2: पैसे लेने के लिए कभी पिन न डालें।\n• नियम 3: एनीडेस्क जैसी स्क्रीन शेयरिंग ऐप कभी न लगाएं।\n• नियम 4: लॉटरी और इनाम के झांसे में न आएं।\n• नियम 5: बिजली या खाता बंद होने की धमकी से न घबराएं।\n• नियम 6: संदेह होने पर हमेशा परिवार से पूछें।",
                "• नियम १: कोणालाही कधीही ओटीपी सांगू नका.\n• नियम २: पैसे मिळण्यासाठी कधीही पिन टाकू नका.\n• नियम ३: एनीडेस्कसारखे स्क्रीन शेअरिंग अॅप डाऊनलोड करू नका.\n• नियम ४: लॉटरी आणि बक्षिसांच्या आमिषाला बळी पडू नका.\n• नियम ५: वीज किंवा बँक बंद होण्याच्या धमक्यांना घाबरू नका.\n• नियम ६: शंका आल्यास नेहमी कुटुंबीयांशी बोला.");

        DatabaseSeeder.insertStep(conn, l35, 1, "Rule 1 & 2: Secret OTP & UPI PIN", "नियम 1 और 2: गुप्त ओटीपी और पिन", "नियम १ आणि २: गुप्त ओटीपी आणि पिन",
                "Never share your OTP with anyone, even someone claiming to be bank manager. Never enter your UPI PIN to receive money.",
                "ओटीपी किसी को न बताएं, चाहे फोन करने वाला खुद को बैंक मैनेजर ही क्यों न कहे। पैसे लेने के लिए कभी पिन न डालें।",
                "कोणालाही ओटीपी सांगू नका, फोन करणारा स्वतःला बँक मॅनेजर म्हणत असला तरीही. पैसे मिळण्यासाठी कधीही पिन टाकू नका.",
                "WARNING_BOX", "GOLDEN_RULE_1",
                "Rule 1 & 2: OTP and UPI PIN must remain strictly confidential.",
                "नियम 1 व 2: ओटीपी और पिन केवल आपका गुप्त रहस्य है।",
                "नियम १ व २: ओटीपी आणि पिन अत्यंत गुप्त ठेवा.");

        DatabaseSeeder.insertStep(conn, l35, 2, "Rule 3: Never Install Remote Access Apps", "नियम 3: रिमोट ऐप कभी डाउनलोड न करें", "नियम ३: रिमोट अॅप कधीही घेऊ नका",
                "NEVER install AnyDesk, TeamViewer, or QuickSupport on the instruction of a phone caller. They allow thieves to see and control your phone screen!",
                "फोन पर किसी के कहने पर AnyDesk, TeamViewer या QuickSupport ऐप कभी न लगाएं। इससे ठग आपके फोन की स्क्रीन देख और चला सकते हैं!",
                "फोनवरील सांगण्यावरून AnyDesk, TeamViewer किंवा QuickSupport अॅप कधीही डाऊनलोड करू नका. यामुळे भामटे तुमचा फोन स्वतः चालवू शकतात!",
                "WARNING_BOX", "GOLDEN_RULE_3",
                "Rule 3: Never install screen sharing apps requested by phone callers.",
                "नियम 3: फोन करने वाले के कहने पर स्क्रीन शेयरिंग ऐप कभी न लगाएं।",
                "नियम ३: फोनवरील सांगण्यावरून स्क्रीन शेअरिंग अॅप कधीही घेऊ नका.");

        DatabaseSeeder.insertStep(conn, l35, 3, "Rule 4 & 5: Beware of Lotteries & Fake Urgency", "नियम 4 और 5: लॉटरी का लालच और फर्जी डर", "नियम ४ आणि ५: लॉटरीचे आमिष आणि भीती",
                "You cannot win a lottery you never bought a ticket for. Scammers create fake panic: 'Bill unpaid, light cut in 1 hour!' so you don't call family.",
                "जिस लॉटरी का टिकट नहीं खरीदा, वह कभी नहीं जीती जा सकती। '1 घंटे में बिजली कटेगी' कहकर वे सिर्फ आपको डराते हैं ताकि आप बच्चों को फोन न कर सकें।",
                "तिकीट न काढलेली लॉटरी कधीही लागत नाही. '१ तासात वीज कापली जाईल' अशी खोटी भीती घालून ते तुम्हाला मुलांशी बोलण्यापासून रोखतात.",
                "WARNING_BOX", "GOLDEN_RULE_4",
                "Rule 4 & 5: Disregard unearned wealth and resist artificial urgency.",
                "नियम 4 व 5: झूठे लालच से बचें और जल्दबाजी में कोई कदम न उठाएं।",
                "नियम ४ व ५: खोट्या आमिषाला बळी पडू नका आणि घाईगडबड करू नका.");

        DatabaseSeeder.insertStep(conn, l35, 4, "Rule 6: When in Doubt, Consult Family", "नियम 6: संदेह होने पर बच्चों से पूछें", "नियम ६: शंका आल्यास मुलांशी बोला",
                "Whenever an SMS or call makes you feel anxious, confused, or hurried, take a deep breath, hang up, and consult your son, daughter, or trusted neighbor.",
                "जब भी कोई कॉल या मैसेज आपको डराए या उलझन में डाले, एक गहरी सांस लें, फोन काटें और अपने बेटे, बेटी या पड़ोसी से बात करें।",
                "जेव्हा जेव्हा एखादा फोन किंवा मेसेज तुम्हाला घाबरवेल, तेव्हा दीर्घ श्वास घ्या, फोन कट करा आणि आपल्या मुलांशी किंवा शेजाऱ्यांशी बोला.",
                "WARNING_BOX", "GOLDEN_RULE_6",
                "Rule 6: Always pause and consult trusted family before acting on alarming messages.",
                "नियम 6: किसी भी अजीब संदेश पर कदम उठाने से पहले परिवार से जरूर पूछें।",
                "नियम ६: कोणताही संशयास्पद मेसेज आल्यास आधी कुटुंबीयांशी चर्चा करा.");

        DatabaseSeeder.insertQuiz(conn, l35, "If a caller claims: 'I am from State Bank head office, tell me the 6-digit OTP to prevent account closure', what is the right action?",
                "अगर कोई कहे: 'मैं एसबीआई मुख्यालय से हूं, खाता बंद होने से बचाने के लिए 6 अंकों का ओटीपी बताएं', तो क्या करना चाहिए?",
                "जर कोणी फोन करून सांगितले: 'मी स्टेट बँकेतून आहे, खाते बंद होऊ नये म्हणून ६ अंकी ओटीपी सांगा', तर काय करावे?",
                "Hang up immediately! Real banks never ask for OTP over the phone.",
                "तुरंत फोन काट दें! असली बैंक कभी भी फोन पर ओटीपी नहीं मांगता।",
                "लगेच फोन कट करा! खरी बँक कधीही फोनवर ओटीपी मागत नाही.",
                new String[]{"Give the OTP quickly", "Hang up immediately and inform your family", "Give only first 3 digits", "Wait on line for one hour"},
                new String[]{"जल्दी से ओटीपी बता दें", "तुरंत फोन काट दें और अपने परिवार को बताएं", "सिर्फ पहले 3 अंक बताएं", "एक घंटे तक बात करें"},
                new String[]{"लगेच ओटीपी सांगा", "लगेच फोन कट करा आणि कुटुंबाला सांगा", "फक्त पहिले ३ अंक सांगा", "एक तास बोलत राहा"}, 1);

        DatabaseSeeder.insertQuiz(conn, l35, "Why do scammers tell seniors to install 'AnyDesk' or 'QuickSupport' apps?",
                "धोखेबाज बुजुर्गों से 'AnyDesk' या 'QuickSupport' ऐप डाउनलोड करने के लिए क्यों कहते हैं?",
                "भामटे वृद्धांना 'AnyDesk' किंवा 'QuickSupport' अॅप डाऊनलोड करायला का सांगतात?",
                "These apps allow fraudsters to remotely view and control your phone screen to steal bank passwords.",
                "ये ऐप धोखेबाजों को आपके फोन की स्क्रीन देखने और बैंक से पैसे चुराने की छूट दे देते हैं।",
                "या अॅप्समुळे भामट्यांना तुमच्या फोनचा स्क्रीन थेट दिसतो आणि ते बँकेचे पैसे लुटू शकतात.",
                new String[]{"To make the phone battery last longer", "To remotely see your screen and steal banking passwords", "To improve camera picture quality", "To send festival greetings"},
                new String[]{"बैटरी ज्यादा देर चलाने के लिए", "स्क्रीन देखकर बैंक के पासवर्ड और पैसे चुराने के लिए", "कैमरे की क्वालिटी बढ़ाने के लिए", "त्योहार की बधाई देने के लिए"},
                new String[]{"बॅटरी जास्त वेळ टिकवण्यासाठी", "स्क्रीन पाहून बँकेचे पासवर्ड आणि पैसे लुटण्यासाठी", "कॅमेरा चांगला करण्यासाठी", "शुभेच्छा देण्यासाठी"}, 1);

        DatabaseSeeder.insertQuiz(conn, l35, "What is the single most powerful defense a senior citizen has against all digital scams?",
                "डिजिटल धोखाधड़ी से बचने के लिए वरिष्ठ नागरिक के पास सबसे बड़ा हथियार क्या है?",
                "डिजिटल फसवणुकीपासून स्वतःला वाचवण्यासाठी वृद्धांकडे सर्वात मोठे हत्यार कोणते?",
                "Pausing, hanging up the phone, and consulting your family or children before acting.",
                "रुकना, फोन काटना और कोई भी कदम उठाने से पहले अपने बच्चों या परिवार से बात करना।",
                "थांबणे, फोन कट करणे आणि कोणतीही कृती करण्यापूर्वी आपल्या मुलांशी किंवा कुटुंबाशी बोलणे.",
                new String[]{"Buying an expensive phone", "Pausing, hanging up, and consulting your children or family", "Staying awake all night", "Paying the scammer immediately"},
                new String[]{"बहुत महंगा फोन खरीदना", "रुकना, फोन काटना और अपने बच्चों या परिवार से सलाह लेना", "रात भर जागते रहना", "धोखेबाज को तुरंत पैसे दे देना"},
                new String[]{"महागडा फोन विकत घेणे", "थांबणे, फोन कट करणे आणि मुलांशी किंवा कुटुंबाशी चर्चा करणे", "रात्रभर जागे राहणे", "भामट्याला लगेच पैसे देणे"}, 1);

        // L36: Spotting Electricity Cut & KYC Scams
        int l36 = DatabaseSeeder.insertLesson(conn, 36, 11, "Spotting Electricity Cut & KYC Scams", "बिजली कटने और फर्जी केवाईसी के धोखे", "वीज कपात आणि बनावट केवायसीचे घोटाळे",
                "Understand why scammers use threats like 'Electricity disconnected tonight at 9:30 PM' to create panic.",
                "समझें कि धोखेबाज 'आज रात 9:30 बजे बिजली कट जाएगी' जैसी धमकियां देकर कैसे डराते हैं।",
                "'आज रात्री ९:३० वाजता वीज कापली जाईल' अशा धमक्या देऊन भामटे कशी भीती घालतात ते समजून घ्या.",
                "BEGINNER", 5, "NONE", 2,
                "• Electricity boards give weeks of written paper notice, NEVER a same-day threatening SMS.\n• Scammers give an ordinary 10-digit mobile number (+91-98...). Real utilities have official helplines.\n• Never call the number in the SMS. Check your bill in official app or ask family.",
                "• बिजली बोर्ड हफ्तों पहले डाक से नोटिस भेजता है, कभी ऐसा डरावना एसएमएस नहीं भेजता।\n• धोखेबाज 10 अंकों का साधारण मोबाइल नंबर देते हैं।\n• उस नंबर पर कभी फोन न करें। अपने बच्चों से पूछें।",
                "• वीज मंडळ आधी लेखी नोटीस पाठवते, असा अचानक धमकावणारा मेसेज कधीही पाठवत नाही.\n• भामटे साधा १० अंकी मोबाईल नंबर देतात.\n• त्या नंबरवर कधीही फोन करू नका. मुलांकडून खात्री करा.");

        DatabaseSeeder.insertStep(conn, l36, 1, "The 'Power Cut Tonight at 9:30 PM' Script", "'रात को बिजली कट जाएगी' वाला फर्जी मैसेज", "'रात्री वीज कापली जाईल' असा बनावट मेसेज",
                "Scam SMS: 'Dear consumer, your electricity will be disconnected tonight at 9:30 PM because previous month bill was not updated. Call electricity officer at 9876543210 immediately.'",
                "फर्जी मैसेज: 'प्रिय उपभोक्ता, पिछले महीने का बिल न भरने के कारण आज रात 9:30 बजे आपकी बिजली काट दी जाएगी। तुरंत अधिकारी 9876543210 पर संपर्क करें।'",
                "बनावट मेसेज: 'ग्राहकहो, बिल न भरल्याने आज रात्री ९:३० वाजता तुमची वीज कापली जाईल. त्वरित अधिकारी ९८७६५४३२१० वर संपर्क करा.'",
                "WARNING_BOX", "ELEC_SMS",
                "Scammers use the fear of darkness and disconnected power to panic seniors.",
                "धोखेबाज अंधेरे और बिजली कटने का डर दिखाकर वरिष्ठ नागरिकों को हड़बड़ाहट में डालते हैं।",
                "अंधार पडण्याची आणि वीज जाण्याची भीती घालून भामटे वृद्धांना घाबरवतात.");

        DatabaseSeeder.insertStep(conn, l36, 2, "Why Scammers Create Extreme Urgency", "धोखेबाज इतनी जल्दबाजी क्यों मचाते हैं?", "भामटे इतकी घाई का करतात?",
                "They say 'Action required in 1 hour!' so that you panic, don't think clearly, and don't take time to call your son or daughter to verify.",
                "वे कहते हैं '1 घंटे में बिजली कट जाएगी' ताकि आप डर जाएं, हड़बड़ी में सोचने का मौका न मिले और बच्चों को फोन न कर सकें।",
                "ते म्हणतात '१ तासात निर्णय घ्या' जेणेकरून तुम्ही घाबराल, नीट विचार करणार नाही आणि मुलांना फोन करून विचारणार नाही.",
                "WARNING_BOX", "PANIC_TACTIC",
                "Fraudsters use artificial deadlines to stop you from consulting your children.",
                "ठग जानबूझकर कम समय की धमकी देते हैं ताकि आप परिवार से बात न कर सकें।",
                "घाईगडबडीची धमकी देणे ही फसवणूक करणाऱ्यांची ठरलेली युक्ती असते.");

        DatabaseSeeder.insertStep(conn, l36, 3, "Real Utilities Send Official Alphanumeric SMS", "बिजली बोर्ड के असली नियम क्या हैं?", "वीज मंडळाचे खरे नियम काय आहेत?",
                "Genuine power companies (like Mahavitaran MSEB or Tata Power) issue printed paper notices weeks in advance. They never disconnect power without formal notice.",
                "असली बिजली कंपनियां (जैसे महावितरण या टाटा पावर) हफ्तों पहले डाक से लिखित नोटिस भेजती हैं। बिना लिखित सूचना के बिजली कभी नहीं काटी जाती।",
                "महावितरण किंवा टाटा पॉवरसारख्या खऱ्या कंपन्या कित्येक दिवस आधी लेखी नोटीस पाठवतात. अशा प्रकारे मेसेजवर वीज कधीही तोडली जात नाही.",
                "PHONE_UI", "OFFICIAL_NOTICE",
                "Real electricity boards provide official written notices, not panic SMS messages.",
                "असली बिजली विभाग लिखित नोटिस देता है, ऐसे डरावने मैसेज नहीं।",
                "वीज मंडळ अधिकृत लेखी नोटीस देते, असे धमकावणारे मेसेज पाठवत नाही.");

        DatabaseSeeder.insertStep(conn, l36, 4, "What to Do: Show It to Your Children", "सही कदम: अपने बच्चों को मैसेज दिखाएं", "योग्य पाऊल: मुलांना मेसेज दाखवा",
                "Ignore the 10-digit number. Show the SMS to your son or daughter in the evening. You will find your bill was already paid on time!",
                "उस नंबर पर कभी फोन न लगाएं। शाम को अपने बेटे या बेटी को वह मैसेज दिखाएं। आप पाएंगे कि आपका बिल तो पहले ही समय पर भरा हुआ है!",
                "त्या नंबरवर चुकूनही फोन करू नका. संध्याकाळी मुलांना तो मेसेज दाखवा. तुमचे बिल आधीच भरलेले असल्याचे समजेल!",
                "PHONE_UI", "VERIFY_FAMILY",
                "Always verify utility bills in your official payment app or with your family.",
                "बिल की पुष्टि हमेशा अपने बच्चों या आधिकारिक ऐप से करें।",
                "बिलाची खात्री नेहमी मुलांकडून किंवा अधिकृत अॅपवरून करा.");

        DatabaseSeeder.insertQuiz(conn, l36, "Why do scammers write: 'Electricity disconnected in 1 hour, call immediately'?",
                "धोखेबाज मैसेज में '1 घंटे में बिजली कट जाएगी, तुरंत फोन करें' क्यों लिखते हैं?",
                "भामटे मेसेजमध्ये '१ तासात वीज कापली जाईल, त्वरित फोन करा' असे का लिहितात?",
                "To create artificial panic so seniors don't take time to consult their children or check facts.",
                "ताकि बुजुर्ग डर जाएं, घबरा जाएं और अपने बच्चों या पड़ोसियों से सच्चाई न पूछ सकें।",
                "वृद्धांनी घाबरावे आणि मुलांना किंवा शेजाऱ्यांना विचारण्याची संधी मिळू नये म्हणून.",
                new String[]{"Because the electricity server sleeps at night", "To create panic so seniors don't consult their children", "Because they want to help you", "It is required by government rules"},
                new String[]{"क्योंकि बिजली का सर्वर रात को सो जाता है", "ताकि डर और हड़बड़ाहट में बुजुर्ग बच्चों से न पूछ सकें", "क्योंकि वे आपकी मदद करना चाहते हैं", "यह सरकारी नियम है"},
                new String[]{"कारण सर्व्हर रात्री झोपतो", "भीतीपोटी वृद्धांनी मुलांशी चर्चा करू नये म्हणून", "त्यांना मदत करायची असते म्हणून", "हा सरकारी नियम आहे"}, 1);

        DatabaseSeeder.insertQuiz(conn, l36, "If you receive an electricity disconnection SMS giving a random 10-digit mobile number, what should you do?",
                "अगर 10 अंकों का साधारण मोबाइल नंबर देकर बिजली काटने का एसएमएस आए, तो क्या करना चाहिए?",
                "साधा १० अंकी मोबाईल नंबर देऊन वीज कापण्याचा मेसेज आल्यास काय करावे?",
                "Never call that mobile number. Show the SMS to your children or check your bill in official app.",
                "उस नंबर पर कभी फोन न करें। अपने बच्चों को दिखाएं या आधिकारिक ऐप में बिल चेक करें।",
                "त्या नंबरवर कधीही फोन करू नका. मुलांना दाखवा किंवा अधिकृत अॅपमध्ये बिल तपासा.",
                new String[]{"Call the number and pay immediately", "Do NOT call the number; consult your family or check official app", "Buy 50 candles immediately", "Turn off all home lights forever"},
                new String[]{"तुरंत फोन करके पैसे भर दें", "उस नंबर पर कभी फोन न करें; परिवार को दिखाएं या ऐप में जांचें", "तुरंत 50 मोमबत्तियां खरीद लाएं", "घर की सारी बत्तियां हमेशा के लिए बुझा दें"},
                new String[]{"लगेच फोन करून पैसे भरा", "त्या नंबरवर फोन करू नका; कुटुंबाला दाखवा किंवा अॅपमध्ये तपासा", "५० मेणबत्त्या विकत आणा", "घरातील दिवे कायमचे बंद करा"}, 1);

        DatabaseSeeder.insertQuiz(conn, l36, "How do genuine electricity distribution companies (like MSEB) notify customers of pending bills?",
                "असली बिजली कंपनियां (जैसे महावितरण MSEB) बकाया बिल की सूचना कैसे देती हैं?",
                "महावितरणसारख्या खऱ्या वीज कंपन्या थकबाकीची माहिती कशी देतात?",
                "Through official printed paper bills delivered to your home and verified alphanumeric SMS sender IDs.",
                "घर पर आने वाले कागजी बिल पर और सरकारी कोड वाले एसएमएस के जरिए।",
                "घरी येणाऱ्या कागदी बिलावर आणि अधिकृत कोड असलेल्या एसएमएसद्वारे.",
                new String[]{"By sending strangers to knock at 2 AM", "Through printed paper bills and official verified SMS sender headers", "By throwing stones at your roof", "By disconnecting power without notice"},
                new String[]{"रात 2 बजे अनजान लोगों को भेजकर", "कागजी बिल पर और आधिकारिक सेंडर कोड वाले एसएमएस से", "छत पर पत्थर फेंककर", "बिना बताए तुरंत बत्ती काटकर"},
                new String[]{"रात्री २ वाजता माणसे पाठवून", "कागदी बिलावर आणि अधिकृत कोड असलेल्या एसएमएसवरून", "घरावर दगड मारून", "काहीही न सांगता वीज तोडून"}, 1);

        // L37: Digital Arrest & Fake Police Video Calls
        int l37 = DatabaseSeeder.insertLesson(conn, 37, 11, "Digital Arrest & Fake Police Video Calls", "डिजिटल अरेस्ट और फर्जी पुलिस वीडियो कॉल", "डिजिटल अरेस्ट आणि बनावट पोलीस व्हिडिओ कॉल",
                "Recognize the dangerous new cyber scam where criminals pose as police, CBI, or customs officers.",
                "नकली पुलिस, सीबीआई या कस्टम अफसर बनकर वीडियो कॉल पर डराने वाले नए गिरोह से बचें।",
                "पोलीस, सीबीआय किंवा कस्टम अधिकारी असल्याचे भासवून व्हिडिओ कॉलवर धमकावणाऱ्या टोळ्यांपासून सावध राहा.",
                "BEGINNER", 6, "NONE", 3,
                "• THERE IS NO SUCH THING AS 'DIGITAL ARREST' IN INDIAN LAW.\n• Real police, CBI, or judges NEVER conduct arrests or court trials over WhatsApp / Skype video calls.\n• Scammers wear fake police uniforms and sit in fake office sets.\n• If anyone threatens 'Digital Arrest', HANG UP IMMEDIATELY and dial 1930.",
                "• भारतीय कानून में 'डिजिटल अरेस्ट' नाम की कोई चीज नहीं होती।\n• असली पुलिस या जज कभी व्हाट्सएप वीडियो कॉल पर किसी को गिरफ्तार नहीं करते।\n• धोखेबाज नकली वर्दी पहनकर नकली थाने का सेट बनाकर बैठते हैं।\n• 'डिजिटल अरेस्ट' की धमकी मिलते ही तुरंत फोन काटें और 1930 पर शिकायत करें।",
                "• भारतीय कायद्यात 'डिजिटल अरेस्ट' अशी कोणतीही तरतूद नाही.\n• खरे पोलीस किंवा कोर्ट कधीही व्हॉट्सअॅप व्हिडिओ कॉलवरून अटक करत नाही.\n• भामटे बनावट गणवेश घालून आणि खोट्या ठाण्याचा देखावा करून बसतात.\n• 'डिजिटल अरेस्ट'ची धमकी आल्यास लगेच फोन कट करा आणि १९३० वर तक्रार करा.");

        DatabaseSeeder.insertStep(conn, l37, 1, "The 'Digital Arrest' Threat Explained", "'डिजिटल अरेस्ट' का नया धोखा क्या है?", "'डिजिटल अरेस्ट'चा नवीन घोटाळा काय आहे?",
                "Scammers call on WhatsApp video wearing khaki police or customs uniforms with an official-looking police logo in the background. They claim: 'You are under Digital Arrest for money laundering'.",
                "धोखेबाज खाकी वर्दी पहनकर पीछे पुलिस का बोर्ड लगाकर वीडियो कॉल करते हैं और कहते हैं: 'आपके नाम से मनी लॉन्ड्रिंग हुई है, आप डिजिटल अरेस्ट हैं'।",
                "भामटे खाकी वर्दी घालून आणि मागे पोलिसांचा लोगो लावून व्हिडिओ कॉल करतात आणि म्हणतात: 'तुमच्या नावावर गुन्हा दाखल झाला आहे, तुम्ही डिजिटल अरेस्ट आहात'.",
                "WARNING_BOX", "DIGITAL_ARREST",
                "Scammers use fake police uniforms and stage backdrops to intimidate innocent citizens.",
                "धोखेबाज नकली वर्दी और नकली बैकग्राउंड बनाकर डराते हैं।",
                "भामटे बनावट गणवेश आणि खोटे ऑफिस दाखवून लोकांना घाबरवतात.");

        DatabaseSeeder.insertStep(conn, l37, 2, "The Legal Truth: NO Digital Arrest Exists", "कानूनी सच: डिजिटल अरेस्ट जैसी कोई चीज नहीं", "कायदेशीर सत्य: डिजिटल अरेस्ट नावाचा कोणताही प्रकार नाही",
                "The Supreme Court and Government of India have declared: There is NO law of 'Digital Arrest' in India. Police never question, arrest, or threaten citizens via video calls.",
                "भारत सरकार और सुप्रीम कोर्ट ने साफ कहा है: भारत में 'डिजिटल अरेस्ट' का कोई कानून नहीं है। असली पुलिस कभी वीडियो कॉल पर पूछताछ या गिरफ्तारी नहीं करती।",
                "भारत सरकार आणि सर्वोच्च न्यायालयाने स्पष्ट केले आहे: भारतात 'डिजिटल अरेस्ट' असा कोणताही कायदा नाही. पोलीस कधीही व्हिडिओ कॉलवर अटक करत नाहीत.",
                "WARNING_BOX", "LEGAL_TRUTH",
                "Under Indian law, no police force or court has the power to 'digitally arrest' anyone on a video call.",
                "भारतीय कानून में वीडियो कॉल पर किसी को अरेस्ट करने का कोई प्रावधान नहीं है।",
                "भारतीय कायद्यानुसार व्हिडिओ कॉलवरून कोणालाही अटक करण्याची कोणतीही पद्धत नाही.");

        DatabaseSeeder.insertStep(conn, l37, 3, "Their Demand: Transfer Money for 'Verification'", "उनकी असली मांग: 'वेरिफिकेशन' के नाम पर पैसे ऐंठना", "त्यांची खरी मागणी: 'पडताळणी'च्या नावाखाली पैसे उकळणे",
                "They say: 'Transfer all your bank deposits into this secret RBI verification account, and we will return it after investigation'. IT IS AN EXTORTION TRAP!",
                "वे कहते हैं: 'जांच के लिए अपने सारे पैसे इस सरकारी खाते में ट्रांसफर करें, बाद में लौटा देंगे'। याद रखें: यह पूरी तरह ठगी और लूट है!",
                "ते म्हणतात: 'तपासणीसाठी तुमचे सर्व पैसे या सरकारी खात्यात टाका, नंतर परत करू'. लक्षात ठेवा: ही निव्वळ लूट आणि खंडणी आहे!",
                "WARNING_BOX", "EXTORTION_TRAP",
                "Never transfer money to any 'safe account' or 'verification account'. Government agencies never ask for money transfers.",
                "सरकारी जांच के नाम पर किसी भी खाते में कभी पैसे ट्रांसफर न करें।",
                "सरकारी तपासणीच्या नावाखाली कोणत्याही खात्यात पैसे पाठवू नका.");

        DatabaseSeeder.insertStep(conn, l37, 4, "What to Do: Cut Call and Dial 1930", "सही कदम: तुरंत फोन काटें और 1930 मिलाएं", "योग्य कृती: लगेच फोन कट करा आणि १९३० वर फोन करा",
                "Do not get frightened. Press the red button to hang up immediately. Dial national cybercrime helpline 1930 or visit your local police station.",
                "बिल्कुल न डरें। तुरंत लाल बटन दबाकर वीडियो कॉल काट दें। राष्ट्रीय साइबर हेल्पलाइन 1930 पर फोन करें या पास के पुलिस थाने जाएं।",
                "मुळीच घाबरू नका. लाल बटण दाबून व्हिडिओ कॉल लगेच बंद करा. राष्ट्रीय सायबर हेल्पलाइन १९३० वर फोन करा किंवा जवळच्या पोलीस ठाण्यात जा.",
                "PHONE_UI", "DIAL_1930",
                "Hang up on digital arrest calls immediately and report them to the national helpline 1930.",
                "डिजिटल अरेस्ट के फोन तुरंत काटें और 1930 पर शिकायत करें।",
                "डिजिटल अरेस्टचे फोन लगेच कट करा आणि १९३० वर तक्रार नोंदवा.");

        DatabaseSeeder.insertQuiz(conn, l37, "Does the concept of 'Digital Arrest' via WhatsApp or Skype video call exist in Indian law?",
                "क्या भारतीय कानून में व्हाट्सएप या वीडियो कॉल पर 'डिजिटल अरेस्ट' नाम की कोई व्यवस्था है?",
                "भारतीय कायद्यात व्हॉट्सअॅप व्हिडिओ कॉलवर 'डिजिटल अरेस्ट' अशी कोणतीही तरतूद आहे का?",
                "NO! It is a complete criminal fraud. Indian law does not have any provision for digital arrest.",
                "बिल्कुल नहीं! यह पूरी तरह अपराधियों की धोखाधड़ी है। भारत में ऐसा कोई कानून नहीं है।",
                "मुळीच नाही! हा निव्वळ सायबर गुन्हेगारांचा फ्रॉड आहे. भारतात असा कोणताही कायदा नाही.",
                new String[]{"Yes, it was created recently", "NO! There is NO such thing as Digital Arrest in Indian law; it is a 100% scam", "Only for bank managers", "Only on weekends"},
                new String[]{"हां, हाल ही में बना है", "नहीं! भारतीय कानून में डिजिटल अरेस्ट नाम की कोई चीज नहीं है; यह 100% फ्रॉड है", "केवल बैंक मैनेजरों के लिए", "केवल शनिवार-रविवार को"},
                new String[]{"होय, नुकताच झाला आहे", "नाही! भारतीय कायद्यात असा कोणताही प्रकार नाही; हा १००% बनावट फ्रॉड आहे", "फक्त बँक मॅनेजरांसाठी", "फक्त वीकेंडला"}, 1);

        DatabaseSeeder.insertQuiz(conn, l37, "A video caller in police uniform threatens: 'Transfer ₹2 Lakhs to RBI account for verification or face arrest'. What must you do?",
                "पुलिस वर्दी पहने कॉलर कहे: 'वेरिफिकेशन के लिए ₹2 लाख आरबीआई खाते में भेजें वरना गिरफ्तार कर लेंगे'। आपको क्या करना चाहिए?",
                "पोलीस गणवेशातील व्यक्तीने धमकावले: 'तपासणीसाठी २ लाख रुपये पाठवा नाहीतर अटक करू'. तुम्ही काय करावे?",
                "Hang up immediately! Real police never ask for money transfers. Dial 1930.",
                "तुरंत फोन काट दें! असली पुलिस या सरकार कभी पैसे ट्रांसफर करने को नहीं कहती। तुरंत 1930 पर शिकायत करें।",
                "लगेच फोन कट करा! खरे पोलीस किंवा कोर्ट कधीही पैसे ट्रान्सफर करायला सांगत नाही. लगेच १९३० वर फोन करा.",
                new String[]{"Transfer the money quickly to stay safe", "Hang up immediately, never send money, and report to cyber helpline 1930", "Ask for a discount", "Delete WhatsApp"},
                new String[]{"बचने के लिए जल्दी से पैसे भेज दें", "तुरंत फोन काटें, एक रुपया भी न भेजें और 1930 पर शिकायत दर्ज कराएं", "कम पैसों की मिन्नत करें", "व्हाट्सएप हटा दें"},
                new String[]{"घाबरून पैसे पाठवून द्यावेत", "लगेच फोन कट करा, एक रुपयाही पाठवू नका आणि १९३० वर तक्रार करा", "पैसे कमी करायला सांगा", "व्हॉट्सअॅप बंद करा"}, 1);

        DatabaseSeeder.insertQuiz(conn, l37, "What is the national government cybercrime emergency telephone helpline number in India?",
                "भारत में साइबर अपराध और ऑनलाइन धोखाधड़ी की राष्ट्रीय सरकारी आपातकालीन हेल्पलाइन का नंबर क्या है?",
                "भारतातील सायबर गुन्हे आणि ऑनलाइन फसवणुकीसाठी राष्ट्रीय सरकारी हेल्पलाइन नंबर कोणता आहे?",
                "1930 is the dedicated national cybercrime helpline available 24x7.",
                "1930 राष्ट्रीय साइबर क्राइम हेल्पलाइन नंबर है जो 24 घंटे नागरिकों की मदद करता है।",
                "१९३० हा राष्ट्रीय सायबर हेल्पलाइन नंबर आहे जो २४ तास नागरिकांच्या मदतीसाठी सज्ज असतो.",
                new String[]{"100 only", "1930 (National Cyber Crime Helpline)", "911", "0000"},
                new String[]{"केवल 100", "1930 (राष्ट्रीय साइबर क्राइम हेल्पलाइन)", "911", "0000"},
                new String[]{"फक्त १००", "१९३० (राष्ट्रीय सायबर क्राईम हेल्पलाइन)", "९११", "००००"}, 1);

        // L38: Fake Courier & Customs Parcel Scams
        int l38 = DatabaseSeeder.insertLesson(conn, 38, 11, "Fake Courier & Customs Parcel Scams", "फर्जी कूरियर और कस्टम्स पार्सल का जाल", "बनावट कुरिअर आणि कस्टम्स पार्सलचे जाळे",
                "Recognize callers claiming: 'A FedEx parcel containing illegal items in your name has been seized at airport'.",
                "'आपके नाम का एक कूरियर पार्सल मुंबई एयरपोर्ट पर पकड़ा गया है' जैसी धमकियों की सच्चाई जानें।",
                "'तुमच्या नावाचे पार्सल विमानतळावर जप्त झाले आहे' अशा धमक्यांचे खरे रूप ओळखा.",
                "BEGINNER", 5, "NONE", 4,
                "• Scammers call: 'This is FedEx / Customs. A parcel sent by you to Taiwan containing illegal passports has been seized'.\n• If you never sent any parcel, YOU HAVE NOTHING TO FEAR.\n• Scammers use identity fear to extort money.\n• Hang up and do not entertain the call.",
                "• धोखेबाज कहते हैं: 'फेडेक्स या कस्टम से बोल रहा हूं, आपके नाम का एक पार्सल पकड़ा गया है'।\n• जब आपने कोई पार्सल भेजा ही नहीं, तो डरने की कोई बात नहीं है।\n• धोखेबाज केवल डराकर पैसे ऐंठना चाहते हैं।\n• तुरंत फोन काटें और बात आगे न बढ़ाएं।",
                "• भामटे म्हणतात: 'कस्टम्समधून बोलतोय, तुमच्या नावाचे बेकायदेशीर पार्सल पकडले आहे'.\n• तुम्ही कोणतेही पार्सल पाठवले नसेल तर घाबरण्याचे काहीच कारण नाही.\n• भामटे फक्त भीती दाखवून पैसे उकळण्याचा प्रयत्न करतात.\n• तात्काळ फोन कट करा आणि बोलू नका.");

        DatabaseSeeder.insertStep(conn, l38, 1, "The 'Parcel Seized at Customs' Script", "'एयरपोर्ट पर पार्सल पकड़ा गया' वाला नाटक", "'विमानतळावर पार्सल जप्त' करण्याचे नाटक",
                "An automated voice or caller says: 'Your FedEx courier packet with your Aadhaar number has been seized by customs at Mumbai airport. Press 9 to speak to officer'.",
                "कॉल आती है: 'आपके आधार कार्ड से जुड़ा एक पार्सल मुंबई हवाई अड्डे पर कस्टम द्वारा पकड़ लिया गया है। अधिकारी से बात करने के लिए 9 दबाएं।'",
                "कॉल येतो: 'तुमच्या आधार कार्डशी जोडलेले पार्सल विमानतळावर कस्टम्सने जप्त केले आहे. अधिकाऱ्याशी बोलण्यासाठी ९ दाबा.'",
                "WARNING_BOX", "PARCEL_SCAM",
                "Scammers invent imaginary parcels to shock and confuse innocent seniors.",
                "धोखेबाज मनगढ़ंत पार्सल का झूठा डर दिखाकर बुजुर्गों को चौंकाते हैं।",
                "भामटे खोट्या पार्सलची भीती घालून वृद्धांना गोंधळात टाकतात.");

        DatabaseSeeder.insertStep(conn, l38, 2, "Common Sense Check: Did You Send a Parcel?", "सरल सवाल: क्या आपने कोई पार्सल भेजा था?", "साधा विचार: तुम्ही कोणते पार्सल पाठवले होते का?",
                "Ask yourself: 'Did I go to any courier office to send a parcel to Taiwan or Cambodia?'. NO! Then how can any parcel be in your name? It is an obvious lie.",
                "खुद से एक सीधा सवाल पूछें: 'क्या मैंने किसी कूरियर ऑफिस जाकर विदेश कोई पार्सल भेजा था?' नहीं! तो फिर पार्सल कहां से आया? यह सफेद झूठ है।",
                "स्वतःला एक साधा प्रश्न विचारा: 'मी परदेशात कोणते पार्सल पाठवले होते का?' मुळीच नाही! मग पार्सल कुठून आले? हे निव्वळ खोटेपणा आहे.",
                "PHONE_UI", "COMMON_SENSE",
                "If you never dispatched a parcel, you are completely safe. It is an extortion racket.",
                "जब आपने कोई पार्सल भेजा ही नहीं, तो आप पूरी तरह सुरक्षित हैं।",
                "तुम्ही कोणतेही पार्सल पाठवले नसल्याने घाबरण्याचे कसलेही कारण नाही.");

        DatabaseSeeder.insertStep(conn, l38, 3, "The Transfer Threat to 'Clear Your Name'", "नाम हटाने के लिए पैसे मांगने का खेल", "नाव वगळण्यासाठी पैसे उकळण्याचा डाव",
                "A fake 'cyber cell officer' comes on line demanding: 'Pay ₹50,000 security fee to clear your Aadhaar name from police record'. NEVER PAY!",
                "नकली 'साइबर अफसर' बनकर वह कहेगा: 'पुलिस रिकॉर्ड से अपना नाम हटाने के लिए ₹50,000 पेनल्टी भरें'। एक नया पैसा भी न दें!",
                "बनावट 'सायबर अधिकारी' म्हणेल: 'गुन्ह्यातून नाव काढण्यासाठी ५०,००० रुपये भरा'. एक रुपयाही देऊ नका!",
                "WARNING_BOX", "CLEAR_NAME_SCAM",
                "Police and customs never demand money transfers over the phone to clear anyone's name.",
                "पुलिस या कस्टम कभी फोन पर पैसे लेकर किसी का नाम नहीं हटाती।",
                "पोलीस किंवा कस्टम्स कधीही फोनवर पैसे मागून कोणाचे नाव मागे घेत नाहीत.");

        DatabaseSeeder.insertStep(conn, l38, 4, "Simply Hang Up and Smile", "आराम से फोन काटें और भूल जाएं", "शांतपणे फोन कट करा आणि विसरून जा",
                "Simply press the red end-call button. You have not committed any crime. Have your evening tea peacefully and tell your family.",
                "बस लाल बटन दबाकर फोन काट दें। आपने कोई अपराध नहीं किया है। आराम से चाय पिएं और शाम को बच्चों को बताकर हंसें।",
                "शांतपणे लाल बटण दाबून फोन कट करा. तुम्ही कोणताही गुन्हा केलेला नाही. आरामात चहा प्या आणि संध्याकाळी मुलांना सांगा.",
                "PHONE_UI", "RELAX_HANGUP",
                "Hang up fearlessly. Scammers cannot harm you once you disconnect the call.",
                "निडर होकर फोन काटें। फोन कटते ही धोखेबाज बेअसर हो जाते हैं।",
                "निर्धास्तपणे फोन कट करा. फोन बंद करताच भामट्यांचे काहीही चालत नाही.");

        DatabaseSeeder.insertQuiz(conn, l38, "If a caller claims a parcel you never sent was caught with illegal items, what is the reality?",
                "अगर कोई कहे कि आपका भेजा हुआ पार्सल पकड़ा गया है, जबकि आपने कोई पार्सल भेजा ही नहीं, तो सच्चाई क्या है?",
                "तुम्ही कोणतेही पार्सल पाठवले नसताना 'पार्सल जप्त झाले' असा फोन आल्यास सत्य काय आहे?",
                "It is a 100% fake extortion scam. Hang up immediately.",
                "यह 100% झूठा और पैसे ऐंठने वाला फ्रॉड है। तुरंत फोन काट दें।",
                "हा १००% खोटा आणि पैसे उकळण्याचा फ्रॉड आहे. लगेच फोन कट करा.",
                new String[]{"You must immediately hide in the basement", "It is an extortion scam call; hang up immediately", "Fly to the airport to search for it", "Pay them all your pension"},
                new String[]{"तुरंत तहखाने में छिप जाएं", "यह ठगी का फर्जी कॉल है; तुरंत फोन काट दें", "हवाई अड्डे पर ढूंढने जाएं", "अपनी सारी पेंशन उन्हें दे दें"},
                new String[]{"घरात लपून बसावे", "हा निव्वळ फसवणुकीचा कॉल आहे; लगेच फोन कट करा", "विमानतळावर शोधायला जावे", "सर्व पेन्शन त्यांना द्यावी"}, 1);

        DatabaseSeeder.insertQuiz(conn, l38, "Do real customs or police officers ever ask citizens to transfer money to personal bank accounts to settle cases?",
                "क्या असली कस्टम या पुलिस कभी फोन पर व्यक्तिगत बैंक खाते में पैसे ट्रांसफर करके मामला निपटाने को कहती है?",
                "कस्टम्स किंवा पोलीस कधी फोनवर खाजगी खात्यात पैसे भरून प्रकरण मिटवायला सांगतात का?",
                "NEVER! Government agencies never conduct financial settlements over telephone calls.",
                "कभी नहीं! सरकारी एजेंसियां कभी फोन पर पैसे लेकर मामले नहीं निपटातीं।",
                "कधीही नाही! सरकारी यंत्रणा कधीही फोनवर पैसे घेऊन प्रकरण मिटवत नाहीत.",
                new String[]{"Yes, it is common practice", "NEVER! Government agencies never settle cases through telephone money transfers", "Only on holidays", "Only in Mumbai"},
                new String[]{"हां, यह आम बात है", "कभी नहीं! सरकारी विभाग कभी फोन पर पैसे लेकर मामले नहीं निपटाते", "केवल छुट्टियों में", "केवल मुंबई में"},
                new String[]{"होय, नेहमी असेच होते", "कधीही नाही! सरकारी विभाग कधीही फोनवर पैसे घेऊन प्रकरण मिटवत नाहीत", "फक्त सुट्ट्यांच्या दिवशी", "फक्त मुंबईत"}, 1);

        DatabaseSeeder.insertQuiz(conn, l38, "What should you do immediately if someone threatens you with arrest on an unexpected phone call?",
                "अगर अचानक आए फोन पर कोई आपको गिरफ्तारी की धमकी दे, तो तुरंत क्या करना चाहिए?",
                "अचानक आलेल्या फोनवर कोणी अटकेची धमकी दिल्यास सर्वात आधी काय करावे?",
                "Stay calm, disconnect the call immediately, and talk to your children or trusted family members.",
                "शांत रहें, तुरंत फोन काट दें और अपने बच्चों या परिवार के सदस्यों से बात करें।",
                "शांत राहा, लगेच फोन कट करा आणि आपल्या मुलांशी किंवा कुटुंबीयांशी बोला.",
                new String[]{"Cry and plead for mercy", "Stay calm, disconnect the call immediately, and consult trusted family", "Transfer money within 5 minutes", "Turn off your refrigerator"},
                new String[]{"रोने लगें और रहम की भीख मांगें", "शांत रहें, तुरंत फोन काटें और अपने परिवार से बात करें", "5 मिनट में पैसे भेज दें", "घर का फ्रिज बंद कर दें"},
                new String[]{"रडत बसावे आणि गयावया करावी", "शांत राहा, लगेच फोन कट करा आणि कुटुंबाशी बोला", "५ मिनिटांत पैसे पाठवावेत", "घरातील फ्रिज बंद करावा"}, 1);
    }

    // ==========================================
    // CAT 12: GOVERNMENT & EMERGENCY (Lessons 39 - 42)
    // ==========================================
    private static void seedCat12Emergency(Connection conn) throws Exception {
        // L39: Aadhaar & DigiLocker Digital Documents
        int l39 = DatabaseSeeder.insertLesson(conn, 39, 12, "Aadhaar & DigiLocker Digital Documents", "आधार कार्ड और डिजिलॉकर डिजिटल दस्तावेज", "आधार कार्ड आणि डिजिलॉकर डिजिटल कागदपत्रे",
                "Keep government-verified Aadhaar card, driving license, and health ID safely on your phone without carrying physical papers.",
                "कागजी आधार कार्ड खोने के डर के बिना सरकारी डिजिलॉकर में अपने सारे दस्तावेज सुरक्षित रखना सीखें।",
                "कागदी आधार कार्ड हरवण्याच्या भीतीशिवाय सरकारी डिजिलॉकरमध्ये कागदपत्रे सुरक्षित ठेवणे शिका.",
                "BEGINNER", 5, "AADHAAR", 1,
                "• DigiLocker is an official Government of India app.\n• Digital documents stored here are 100% legally valid at airports, trains, and banks.\n• Login securely using your 12-digit Aadhaar and OTP.\n• Never carry laminated paper cards that can be lost.",
                "• डिजिलॉकर भारत सरकार का आधिकारिक सुरक्षित ऐप है।\n• यहां रखे दस्तावेज रेलवे, हवाई अड्डे और बैंक में पूरी तरह मान्य हैं।\n• अपने 12 अंकों के आधार नंबर और ओटीपी से लॉगिन करें।\n• कागजी कार्ड खोने की चिंता हमेशा के लिए खत्म!",
                "• डिजिलॉकर हे भारत सरकारचे अधिकृत आणि सुरक्षित अॅप आहे.\n• येथील कागदपत्रे रेल्वे, विमानतळ आणि बँकेत कायदेशीररीत्या पूर्णपणे ग्राह्य धरली जातात.\n• १२ अंकी आधार नंबर आणि ओटीपीने सुरक्षित लॉगिन करा.\n• कागदी कार्ड हरवण्याची चिंता कायमची दूर!");

        DatabaseSeeder.insertStep(conn, l39, 1, "What is DigiLocker?", "डिजिलॉकर क्या है?", "डिजिलॉकर म्हणजे काय?",
                "DigiLocker is an official initiative of the Ministry of Electronics & IT, Government of India. It issues authentic digital copies of your Aadhaar, PAN, and Vaccine certificates.",
                "डिजिलॉकर भारत सरकार की आधिकारिक डिजिटल तिजोरी है। यह आपके आधार कार्ड, पैन कार्ड और ड्राइविंग लाइसेंस की असली सरकारी डिजिटल कॉपी रखता है।",
                "डिजिलॉकर ही भारत सरकारची अधिकृत डिजिटल तिजोरी आहे. यात तुमचे आधार, पॅन कार्ड आणि इतर महत्त्वाची कागदपत्रे सुरक्षित राहतात.",
                "AADHAAR_UI", "DIGILOCKER_INFO",
                "DigiLocker provides legally valid digital government identity documents.",
                "डिजिलॉकर पूरी तरह कानूनी और मान्य सरकारी दस्तावेज उपलब्ध कराता है।",
                "डिजिलॉकर कायदेशीर आणि अधिकृत सरकारी कागदपत्रे उपलब्ध करून देते.");

        DatabaseSeeder.insertStep(conn, l39, 2, "Open App and Log In with Aadhaar", "ऐप खोलें और आधार से लॉगिन करें", "अॅप उघडा आणि आधारने लॉगिन करा",
                "Open DigiLocker. Enter your 12-digit Aadhaar number. A 6-digit OTP is sent to your registered mobile phone. Enter OTP to sign in.",
                "डिजिलॉकर खोलें। अपना 12 अंकों का आधार नंबर डालें। रजिस्टर्ड फोन पर 6 अंकों का ओटीपी आएगा। उसे डालकर लॉगिन करें।",
                "डिजिलॉकर उघडा. आपला १२ अंकी आधार नंबर टाका. फोनवर ६ अंकी ओटीपी येईल. तो टाकून लॉगिन करा.",
                "AADHAAR_UI", "AADHAAR_LOGIN",
                "Log in securely using your 12-digit Aadhaar number and OTP verification.",
                "आधार नंबर और ओटीपी से सुरक्षित लॉगिन करें।",
                "आधार नंबर आणि ओटीपी टाकून सुरक्षित लॉगिन करा.");

        DatabaseSeeder.insertStep(conn, l39, 3, "View Issued Aadhaar Card", "अपना डिजिटल आधार कार्ड देखें", "आपले डिजिटल आधार कार्ड पहा",
                "Tap 'Issued Documents' -> 'Aadhaar Card'. Your official digital Aadhaar appears on screen with the national Ashoka emblem and QR code.",
                "'Issued Documents' में जाएं और 'Aadhaar Card' पर टैप करें। राष्ट्रीय अशोक चक्र और क्यूआर कोड वाला असली आधार कार्ड स्क्रीन पर दिखेगा।",
                "'Issued Documents' मध्ये जाऊन 'Aadhaar Card' वर दाबा. राष्ट्रीय अशोक चक्र आणि क्यूआर कोड असलेले अधिकृत आधार कार्ड स्क्रीनवर दिसेल.",
                "AADHAAR_UI", "AADHAAR_CARD",
                "Your digitally verified Aadhaar card is displayed with the official national seal.",
                "अशोक चिन्ह और क्यूआर कोड वाला असली आधार कार्ड स्क्रीन पर देखें।",
                "अशोक स्तंभ आणि क्यूआर कोड असलेले अधिकृत आधार कार्ड स्क्रीनवर पहा.");

        DatabaseSeeder.insertStep(conn, l39, 4, "Legally Valid Everywhere in India", "पूरे भारत में हर जगह 100% मान्य", "संपूर्ण भारतात सर्वत्र १००% ग्राह्य",
                "Under Rule 9A of the IT Act, DigiLocker digital documents have the exact same legal validity as original physical certificates at airports, railway stations, and government counters.",
                "भारतीय सूचना प्रौद्योगिकी कानून के तहत डिजिलॉकर का डिजिटल आधार हवाई अड्डे, रेलवे स्टेशन और बैंक में असली कागजी कार्ड के बराबर मान्य है।",
                "माहिती तंत्रज्ञान कायद्यानुसार डिजिलॉकरमधील आधार कार्ड विमानतळ, रेल्वे आणि बँकांमध्ये मूळ कागदपत्रासारखेच १००% वैध मानले जाते.",
                "AADHAAR_UI", "LEGAL_VALIDITY",
                "Digital Aadhaar on DigiLocker is legally recognized across all government authorities.",
                "डिजिलॉकर का आधार सभी सरकारी और निजी संस्थानों में पूरी तरह मान्य है।",
                "डिजिलॉकरमधील आधार सर्व सरकारी आणि खाजगी कार्यालयांमध्ये अधिकृतपणे चालते.");

        DatabaseSeeder.insertQuiz(conn, l39, "Is the digital Aadhaar card shown inside the official DigiLocker app legally valid for travel at Indian airports and railway stations?",
                "क्या सरकारी डिजिलॉकर ऐप में दिखाया गया डिजिटल आधार कार्ड रेलवे और हवाई अड्डे पर यात्रा के लिए कानूनी रूप से मान्य है?",
                "सरकारी डिजिलॉकर अॅपमधील डिजिटल आधार कार्ड रेल्वे आणि विमानतळावर प्रवासासाठी कायदेशीररीत्या चालते का?",
                "YES! Under Indian IT Rules, digital documents in DigiLocker are treated at par with original physical certificates.",
                "हां! भारत सरकार के कानून के तहत डिजिलॉकर का दस्तावेज असली कागजी सर्टिफिकेट के बराबर 100% मान्य है।",
                "होय! भारतीय कायद्यानुसार डिजिलॉकरमधील कागदपत्रे मूळ कागदपत्रांइतकीच १००% कायदेशीर मानली जातात.",
                new String[]{"No, only laminated paper is accepted", "YES! It is 100% legally valid under Indian Information Technology Rules", "Only on train sleeper coaches", "Only with doctor's signature"},
                new String[]{"नहीं, केवल कागजी कार्ड चलता है", "हां! भारतीय आईटी कानून के तहत यह 100% कानूनी रूप से मान्य है", "केवल स्लीपर डिब्बों में", "डॉक्टर के हस्ताक्षर के साथ ही"},
                new String[]{"नाही, फक्त कागद चालतो", "होय! भारतीय कायद्यानुसार हे १००% कायदेशीररीत्या वैध आहे", "फक्त स्लीपर डब्यात", "डॉक्टरांच्या सहीनेच"}, 1);

        DatabaseSeeder.insertQuiz(conn, l39, "What is the biggest safety benefit of keeping your documents in DigiLocker on your smartphone?",
                "अपने दस्तावेज मोबाइल में डिजिलॉकर में रखने का सबसे बड़ा सुरक्षा फायदा क्या है?",
                "कागदपत्रे मोबाईलमधील डिजिलॉकरमध्ये ठेवण्याचा सर्वात मोठा फायदा कोणता?",
                "You don't risk losing your original laminated Aadhaar or PAN card while traveling.",
                "सफर के दौरान असली कागजी आधार या पैन कार्ड के खोने या चोरी होने का कोई डर नहीं रहता।",
                "प्रवासात मूळ कागदी आधार किंवा पॅन कार्ड गहाळ होण्याची किंवा चोरीला जाण्याची कसलीही भीती उरत नाही.",
                new String[]{"Your phone battery never runs out", "You avoid the risk of losing original paper cards while traveling outside", "It buys you free groceries", "It doubles your bank balance"},
                new String[]{"फोन की बैटरी कभी खत्म नहीं होती", "सफर के दौरान असली कार्ड खोने का कोई डर नहीं रहता", "राशन मुफ्त मिलता है", "बैंक बैलेंस दुगना हो जाता है"},
                new String[]{"बॅटरी कधीच संपत नाही", "प्रवासात मूळ कागदपत्रे हरवण्याची कसलीही भीती राहत नाही", "मोफत रेशन मिळते", "बँक शिल्लक दुप्पट होते"}, 1);

        DatabaseSeeder.insertQuiz(conn, l39, "Which government entity runs the official DigiLocker platform?",
                "आधिकारिक डिजिलॉकर प्लेटफॉर्म का संचालन कौन करता है?",
                "अधिकृत डिजिलॉकर प्रणालीचे संचालन कोण करते?",
                "Ministry of Electronics and Information Technology (MeitY), Government of India.",
                "इलेक्ट्रॉनिक्स और सूचना प्रौद्योगिकी मंत्रालय, भारत सरकार।",
                "इलेक्ट्रॉनिक्स आणि माहिती तंत्रज्ञान मंत्रालय, भारत सरकार.",
                new String[]{"A private foreign company", "Ministry of Electronics & IT, Government of India", "A local shopping mall", "A local tea vendor"},
                new String[]{"एक विदेशी निजी कंपनी", "इलेक्ट्रॉनिक्स और सूचना प्रौद्योगिकी मंत्रालय, भारत सरकार", "एक शॉपिंग मॉल", "चाय की दुकान"},
                new String[]{"परदेशी खाजगी कंपनी", "इलेक्ट्रॉनिक्स आणि माहिती तंत्रज्ञान मंत्रालय, भारत सरकार", "शॉपिंग मॉल", "चहाची टपरी"}, 1);

        // L40: Telemedicine & Online Doctor Appointments
        int l40 = DatabaseSeeder.insertLesson(conn, 40, 12, "Telemedicine & Online Doctor Appointments", "घर बैठे डॉक्टर से वीडियो पर परामर्श", "घरी बसून डॉक्टरांशी व्हिडिओ सल्लामसलत",
                "Consult specialized doctors via video call from home and receive digital prescriptions for health checkups.",
                "भीड़ और अस्पताल के चक्कर लगाए बिना घर बैठे वीडियो कॉल पर डॉक्टर से सलाह और दवा का पर्चा लेना सीखें।",
                "दवाखान्याच्या फेऱ्या न मारता घरबसल्या व्हिडिओ कॉलवर डॉक्टरांचा सल्ला आणि औषधांची चिठ्ठी मिळवणे शिका.",
                "BEGINNER", 5, "NONE", 2,
                "• Use government eSanjeevani or apps like Practo / Apollo 24/7.\n• Select doctor by specialty (e.g. Heart, Joints, Diabetes).\n• Video call doctor at chosen appointment time.\n• Download digital prescription directly on phone.",
                "• सरकारी eSanjeevani या Practo / Apollo ऐप का उपयोग करें।\n• विशेषज्ञ डॉक्टर (हड्डी, बीपी, शुगर) चुनें।\n• तय समय पर वीडियो कॉल से बात करें।\n• डॉक्टर का लिखा पर्चा सीधे फोन में डाउनलोड करें।",
                "• सरकारी eSanjeevani किंवा Practo / Apollo अॅप वापरा.\n• तज्ज्ञ डॉक्टर (हाडे, बीपी, मधुमेह) निवडा.\n• ठरलेल्या वेळी व्हिडिओ कॉलवरून चर्चा करा.\n• डॉक्टरांचे प्रिस्क्रिप्शन थेट फोनमध्ये डाऊनलोड करा.");

        DatabaseSeeder.insertStep(conn, l40, 1, "What is Telemedicine?", "टेलीमेडिसिन क्या है?", "टेलिमेडिसिन म्हणजे काय?",
                "Telemedicine lets you consult certified doctors over a private video call from your living room without traveling to crowded clinics.",
                "टेलीमेडिसिन के जरिए आप घर के सोफे पर बैठकर ही वीडियो कॉल पर योग्य डॉक्टर को अपनी बीमारी बता सकते हैं और सलाह ले सकते हैं।",
                "टेलिमेडिसिनच्या मदतीने तुम्ही घराबाहेर न पडता आरामखुर्चीवर बसूनच व्हिडिओ कॉलवर डॉक्टरांना आपले दुखणे दाखवू शकता.",
                "PHONE_UI", "TELEMED_INTRO",
                "Consult certified physicians from the comfort and safety of home.",
                "घर बैठे प्रमाणित डॉक्टरों से आराम से वीडियो सलाह लें।",
                "घरी बसून तज्ज्ञ डॉक्टरांचा सल्ला सुरक्षितपणे मिळवा.");

        DatabaseSeeder.insertStep(conn, l40, 2, "Government eSanjeevani Platform", "भारत सरकार का 'eSanjeevani' ऐप", "भारत सरकारचे 'eSanjeevani' अॅप",
                "Download the official government 'eSanjeevani' app. It provides free tele-consultation with government civil hospital doctors across India.",
                "भारत सरकार का आधिकारिक 'eSanjeevani' ऐप डाउनलोड करें। यह पूरे भारत में सरकारी डॉक्टरों से मुफ्त वीडियो सलाह उपलब्ध कराता है।",
                "भारत सरकारचे अधिकृत 'eSanjeevani' अॅप वापरा. यावर सरकारी रुग्णालयातील डॉक्टरांचा मोफत व्हिडिओ सल्ला मिळतो.",
                "PHONE_UI", "SANJEEVANI_APP",
                "Use the Government of India eSanjeevani app for free expert medical consultations.",
                "मुफ्त डॉक्टर सलाह के लिए सरकारी ई-संजीवनी ऐप का उपयोग करें।",
                "मोफत डॉक्टर सल्ल्यासाठी सरकारी ई-संजीवनी अॅप वापरा.");

        DatabaseSeeder.insertStep(conn, l40, 3, "Speak with the Doctor on Video", "वीडियो कॉल पर डॉक्टर से खुलकर बात करें", "व्हिडिओ कॉलवर डॉक्टरांशी मोकळेपणाने बोला",
                "At your appointment time, your phone rings. Talk to the doctor face to face. Explain your symptoms and show past lab reports.",
                "तय समय पर डॉक्टर की कॉल आएगी। आमने-सामने देखकर अपनी तकलीफ बताएं और पुरानी खून जांच रिपोर्ट कैमरे के सामने दिखाएं।",
                "ठरलेल्या वेळी डॉक्टरांचा कॉल येईल. समोरासमोर आपले दुखणे सांगा आणि जुने रिपोर्ट कॅमेऱ्यासमोर दाखवा.",
                "PHONE_UI", "DOCTOR_CALL",
                "Talk clearly about your symptoms and show past reports during the video call.",
                "डॉक्टर को अपनी तकलीफ बताएं और पुरानी रिपोर्ट दिखाएं।",
                "आपली लक्षणे स्पष्ट सांगा आणि जुने रिपोर्ट दाखवा.");

        DatabaseSeeder.insertStep(conn, l40, 4, "Receive Signed Digital Prescription", "हस्ताक्षरित डिजिटल पर्चा प्राप्त करें", "स्वाक्षरी केलेले डिजिटल प्रिस्क्रिप्शन मिळवा",
                "When the consultation ends, the doctor sends a digitally signed prescription PDF to your phone. You can use it to buy medicines anywhere.",
                "परामर्श पूरा होते ही डॉक्टर का कानूनी डिजिटल पर्चा आपके फोन में आ जाता है। इसे दिखाकर किसी भी मेडिकल स्टोर से दवाइयां ले सकते हैं।",
                "सल्ला पूर्ण होताच डॉक्टरांची स्वाक्षरी असलेली चिठ्ठी थेट फोनमध्ये येते. ती दाखवून कोणत्याही मेडिकल दुकानातून औषधे घेता येतात.",
                "PHONE_UI", "DIGITAL_RX",
                "Download the official digital prescription signed by the physician.",
                "डॉक्टर द्वारा हस्ताक्षरित आधिकारिक डिजिटल पर्चा फोन में सुरक्षित रखें।",
                "डॉक्टरांनी सही केलेले अधिकृत प्रिस्क्रिप्शन फोनमध्ये सुरक्षित ठेवा.");

        DatabaseSeeder.insertQuiz(conn, l40, "What is the official Government of India free tele-consultation platform for doctors?",
                "भारत सरकार द्वारा नागरिकों के लिए मुफ्त डॉक्टर वीडियो सलाह का आधिकारिक प्लेटफॉर्म कौन सा है?",
                "भारत सरकारची नागरिकांसाठी मोफत डॉक्टर व्हिडिओ सल्ल्याची अधिकृत प्रणाली कोणती आहे?",
                "eSanjeevani is the National Telemedicine Service of India run by the Ministry of Health.",
                "eSanjeevani (ई-संजीवनी) स्वास्थ्य मंत्रालय द्वारा चलाई जाने वाली राष्ट्रीय मुफ्त डॉक्टर सेवा है।",
                "eSanjeevani (ई-संजीवनी) ही आरोग्य मंत्रालयाची राष्ट्रीय मोफत डॉक्टर सेवा आहे.",
                new String[]{"eSanjeevani (National Telemedicine Service)", "Google Maps", "YouTube Kids", "Calculator"},
                new String[]{"eSanjeevani (राष्ट्रीय टेलीमेडिसिन सेवा)", "गूगल मैप्स", "यूट्यूब किड्स", "कैलकुलेटर"},
                new String[]{"eSanjeevani (राष्ट्रीय टेलिमेडिसिन सेवा)", "गुगल मॅप्स", "युट्यूब लहान मुलांसाठी", "कॅल्क्युलेटर"}, 0);

        DatabaseSeeder.insertQuiz(conn, l40, "How do you receive the doctor's prescribed medicine slip after an online video consultation?",
                "ऑनलाइन वीडियो सलाह के बाद डॉक्टर द्वारा लिखी गई दवाइयों का पर्चा कैसे मिलता है?",
                "ऑनलाइन सल्ल्यानंतर डॉक्टरांनी लिहून दिलेली औषधांची चिठ्ठी कशी मिळते?",
                "A digitally signed PDF prescription is delivered directly inside your app and SMS within minutes.",
                "डॉक्टर के डिजिटल हस्ताक्षर वाला पीडीएफ पर्चा कुछ ही मिनटों में सीधे ऐप और एसएमएस पर आ जाता है।",
                "डॉक्टरांची स्वाक्षरी असलेली पीडीएफ चिठ्ठी काही मिनिटांत थेट अॅप आणि मेसेजवर येते.",
                new String[]{"By postal telegram after 1 month", "A digitally signed PDF prescription arrives instantly on your phone", "You must walk to Delhi to collect it", "Through the TV screen"},
                new String[]{"एक महीने बाद डाक से", "डिजिटल हस्ताक्षरित पीडीएफ पर्चा तुरंत आपके फोन पर आ जाता है", "दिल्ली जाकर लेना पड़ता है", "टीवी की स्क्रीन से"},
                new String[]{"१ महिन्यांनी पोस्टाने", "डिजिटल सही असलेली पीडीएफ चिठ्ठी लगेच फोनवर येते", "दिल्लीला जाऊन आणावी लागते", "टीव्हीवरून"}, 1);

        DatabaseSeeder.insertQuiz(conn, l40, "Can you show your physical medical reports or swollen joint directly through your phone camera to the doctor?",
                "क्या वीडियो कॉल के दौरान आप फोन के कैमरे से अपनी पुरानी रिपोर्ट या घुटने की सूजन डॉक्टर को दिखा सकते हैं?",
                "व्हिडिओ कॉल सुरू असताना तुम्ही फोनच्या कॅमेऱ्याने जुने रिपोर्ट किंवा गुडघ्याची सूज डॉक्टरांना दाखवू शकता का?",
                "Yes! The camera lets the doctor examine swellings, skin patches, and read lab reports live.",
                "हां! वीडियो कैमरे से डॉक्टर सूजन, त्वचा और पुरानी खून जांच रिपोर्ट सीधे देख सकते हैं।",
                "होय! व्हिडिओ कॅमेऱ्यातून डॉक्टर सूज, त्वचेचे आजार आणि तपासणीचे रिपोर्ट थेट पाहू शकतात.",
                new String[]{"No, the camera is disabled", "Yes, video lets the doctor visually inspect swellings, rashes, and test papers live", "Only on Sundays", "Only in foreign languages"},
                new String[]{"नहीं, कैमरा बंद रहता है", "हां, वीडियो कॉल से डॉक्टर सूजन और रिपोर्ट सीधे देख सकते हैं", "केवल रविवार को", "केवल विदेशी भाषा में"},
                new String[]{"नाही, कॅमेरा बंद असतो", "होय, व्हिडिओ कॉलने डॉक्टर सूज आणि रिपोर्ट थेट पाहू शकतात", "फक्त रविवारी", "फक्त परदेशी भाषेत"}, 1);

        // L41: One-Touch Emergency Assistance
        int l41 = DatabaseSeeder.insertLesson(conn, 41, 12, "One-Touch Emergency Assistance", "एक टच में आपातकालीन मदद", "एका स्पर्शात तातडीची मदत",
                "How to quickly call family, ambulance (108), or national emergency (112) with giant easy-to-tap buttons.",
                "मुसीबत के समय बड़े बटनों से परिवार, एम्बुलेंस (108) या राष्ट्रीय आपातकाल (112) को तुरंत बुलाना सीखें।",
                "संकटकाळी मोठ्या बटनांनी कुटुंब, रुग्णवाहिका (१०८) किंवा राष्ट्रीय मदत (११२) पटकन बोलावणे शिका.",
                "BEGINNER", 4, "NONE", 3,
                "• Dial 112 for all-in-one Police, Fire, and Ambulance help across India.\n• Dial 108 for free medical ambulance.\n• Use the high-contrast Emergency tab in this Senior Tutor app for giant one-touch calling.",
                "• पूरे भारत में पुलिस, एम्बुलेंस और आग के लिए 112 राष्ट्रीय नंबर है।\n• मुफ्त मेडिकल एम्बुलेंस के लिए 108 मिलाएं।\n• इस ऐप के 'Emergency' टैब में एक छुअन से बच्चों या डॉक्टर को फोन लगाएं।",
                "• संपूर्ण भारतात पोलीस, रुग्णवाहिका आणि अग्निशामक दलासाठी ११२ हा मुख्य नंबर आहे.\n• मोफत रुग्णवाहिकेसाठी १०८ डायल करा.\n• या अॅपमधील 'Emergency' टॅबवरून एका स्पर्शात मुले किंवा डॉक्टरांना कॉल करा.");

        DatabaseSeeder.insertStep(conn, l41, 1, "National Emergency Number: 112", "राष्ट्रीय आपातकालीन नंबर: 112", "राष्ट्रीय आणीबाणी नंबर: ११२",
                "In India, dialing 112 connects you immediately to the Central Emergency Response Center for Police, Fire, and Ambulance.",
                "भारत में 112 एक ऐसा नंबर है जो पुलिस, फायर ब्रिगेड और एम्बुलेंस तीनों की मदद तुरंत पहुंचाता है।",
                "भारतात ११२ हा असा एक नंबर आहे जो पोलीस, अग्निशामक दल आणि रुग्णवाहिका तिन्ही मदत तत्काळ पोहोचवतो.",
                "PHONE_UI", "EMERGENCY_112",
                "112 is the single all-in-one national emergency helpline number.",
                "112 राष्ट्रीय स्तर पर सभी आपातकालीन सेवाओं का मुख्य नंबर है।",
                "११२ हा सर्व प्रकारच्या आणीबाणीसाठी राष्ट्रीय मुख्य नंबर आहे.");

        DatabaseSeeder.insertStep(conn, l41, 2, "Medical Ambulance Helpline: 108", "सरकारी एम्बुलेंस: 108", "शासकीय रुग्णवाहिका: १०८",
                "If anyone at home suffers chest pain, breathing difficulty, or falls, dial 108 immediately for a free government ambulance.",
                "अगर सीने में दर्द, सांस लेने में तकलीफ या चक्कर आने की समस्या हो, तो तुरंत 108 मिलाएं। मुफ्त एम्बुलेंस घर पहुंचेगी।",
                "छातीत दुखणे, श्वास घेण्यास त्रास किंवा चक्कर आल्यास तात्काळ १०८ डायल करा. मोफत शासकीय रुग्णवाहिका येईल.",
                "PHONE_UI", "AMBULANCE_108",
                "Dial 108 for immediate medical ambulance dispatch to your home.",
                "तुरंत सरकारी एम्बुलेंस बुलाने के लिए 108 डायल करें।",
                "तातडीने रुग्णवाहिका बोलावण्यासाठी १०८ वर कॉल करा.");

        DatabaseSeeder.insertStep(conn, l41, 3, "Use Senior Tutor Emergency Tab", "सीनियर ट्यूटर ऐप की इमरजेंसी स्क्रीन", "सीनियर ट्यूटर अॅपची इमर्जन्सी स्क्रीन",
                "In this app, tap the red 'Emergency' tab on the left. Giant buttons let you call your daughter, son, or family doctor with a single tap.",
                "इस ऐप में बाईं तरफ लाल 'Emergency' टैब देखें। बड़े-बड़े बटनों को छूकर आप बेटी, बेटे या पारिवारिक डॉक्टर को बिना चश्मे के कॉल कर सकते हैं।",
                "या अॅपमध्ये डाव्या बाजूला लाल 'Emergency' टॅब आहे. मोठ्या बटनांना स्पर्श करून तुम्ही मुलगी, मुलगा किंवा फॅमिली डॉक्टरांना चष्मा न लावताही कॉल करू शकता.",
                "PHONE_UI", "APP_EMERGENCY",
                "Use the high-contrast large buttons in this application for quick access to family and medical help.",
                "परिवार और डॉक्टर को तुरंत कॉल लगाने के लिए ऐप के इमरजेंसी टैब का उपयोग करें।",
                "कुटुंब आणि डॉक्टरांना तात्काळ कॉल करण्यासाठी अॅपमधील इमर्जन्सी टॅब वापरा.");

        DatabaseSeeder.insertStep(conn, l41, 4, "Medical Info Card for Doctors", "डॉक्टर के लिए मेडिकल जानकारी कार्ड", "डॉक्टरांसाठी वैद्यकीय माहिती कार्ड",
                "The emergency screen displays your Blood Group, current BP/Diabetes medicines, and doctor's contact for first responders.",
                "आपातकालीन स्क्रीन पर आपका ब्लड ग्रुप और रोज चलने वाली जरूरी दवाइयां लिखी होती हैं ताकि डॉक्टर तुरंत सही इलाज कर सकें।",
                "इमर्जन्सी स्क्रीनवर तुमचा रक्तगट आणि रोजची चालू औषधे लिहिलेली असतात जेणेकरून आपत्कालीन डॉक्टरांना लगेच योग्य उपचार करता येतील.",
                "PHONE_UI", "MEDICAL_CARD",
                "Keep your medical info card updated with your blood group and daily medications.",
                "अपना ब्लड ग्रुप और रोज चलने वाली दवाइयां हमेशा सही दर्ज रखें।",
                "आपला रक्तगट आणि रोजची औषधे नेहमी अचूक नोंदवून ठेवा.");

        DatabaseSeeder.insertQuiz(conn, l41, "What is the single all-in-one national emergency helpline number across India?",
                "पूरे भारत में सभी आपातकालीन सेवाओं (पुलिस, एम्बुलेंस, फायर) का एकमात्र राष्ट्रीय नंबर कौन सा है?",
                "संपूर्ण भारतात सर्व आणीबाणीच्या सेवांसाठी (पोलीस, रुग्णवाहिका, अग्निशामक) एकमेव मुख्य नंबर कोणता आहे?",
                "112 is the pan-India national emergency response number.",
                "112 पूरे भारत का एकल राष्ट्रीय आपातकालीन हेल्पलाइन नंबर है।",
                "११२ हा संपूर्ण भारताचा मुख्य राष्ट्रीय आणीबाणी हेल्पलाइन नंबर आहे.",
                new String[]{"911", "112 (National Emergency Helpline)", "100 only", "000"},
                new String[]{"911", "112 (राष्ट्रीय आपातकालीन हेल्पलाइन)", "केवल 100", "000"},
                new String[]{"९११", "११२ (राष्ट्रीय आणीबाणी हेल्पलाइन)", "फक्त १००", "०००"}, 1);

        DatabaseSeeder.insertQuiz(conn, l41, "Which dedicated number dispatches a free government medical ambulance to your doorstep in medical emergencies?",
                "चिकित्सा आपातकाल में आपके घर मुफ्त सरकारी एम्बुलेंस भेजने के लिए कौन सा नंबर मिलाया जाता है?",
                "वैद्यकीय आणीबाणीच्या वेळी दारात मोफत शासकीय रुग्णवाहिका बोलावण्यासाठी कोणता नंबर डायल करावा?",
                "108 is the dedicated government emergency ambulance service across most states.",
                "108 आपातकालीन सरकारी एम्बुलेंस सेवा का प्रमुख नंबर है।",
                "१०८ हा आपत्कालीन शासकीय रुग्णवाहिका सेवेचा प्रमुख नंबर आहे.",
                new String[]{"108 (Medical Ambulance Service)", "101", "139", "121"},
                new String[]{"108 (मेडिकल एम्बुलेंस सेवा)", "101", "139", "121"},
                new String[]{"१०८ (वैद्यकीय रुग्णवाहिका सेवा)", "१०१", "१३९", "१२१"}, 0);

        DatabaseSeeder.insertQuiz(conn, l41, "Why does the Senior Tutor Emergency screen have giant buttons with confirmation?",
                "सीनियर ट्यूटर ऐप की इमरजेंसी स्क्रीन पर बड़े-बड़े बटन और पुष्टि का विकल्प क्यों दिया गया है?",
                "सीनियर ट्यूटर अॅपच्या इमर्जन्सी स्क्रीनवर मोठी बटणे आणि खात्रीचा पर्याय का दिला आहे?",
                "Giant buttons make calling easy without glasses, and confirmation prevents accidental dialing.",
                "बड़े बटन बिना चश्मे के आसानी से दिखते हैं और गलती से दबने से रोकते हैं।",
                "मोठी बटणे चष्मा न लावताही स्पष्ट दिसतात आणि चुकून कॉल लागणे टाळतात.",
                new String[]{"To make the app slower", "Large buttons make emergency calls easy without reading glasses and prevent misdials", "To consume more battery", "Because of color restrictions"},
                new String[]{"ऐप को धीमा करने के लिए", "बिना चश्मे के आसानी से दिखें और गलती से कॉल लगने से बचें", "बैटरी ज्यादा खर्च करने के लिए", "रंगों के नियम के कारण"},
                new String[]{"अॅप हळू करण्यासाठी", "चष्म्याशिवाय स्पष्ट दिसावे आणि चुकून कॉल लागू नये म्हणून", "बॅटरी संपवण्यासाठी", "रंगांच्या नियमामुळे"}, 1);

        // L42: What to Do if You Get Scammed - 1930 Helpline
        int l42 = DatabaseSeeder.insertLesson(conn, 42, 12, "What to Do if You Get Scammed - 1930 Helpline", "अगर धोखा हो जाए तो क्या करें - 1930 हेल्पलाइन", "फसवणूक झाल्यास काय करावे - १९३० हेल्पलाइन",
                "Act quickly in the 'Golden Hour' to freeze fraudulent bank transfers and recover your hard-earned money.",
                "धोखाधड़ी होने पर 'गोल्डन ऑवर' में तेजी से कदम उठाकर अपने पैसे वापस पाना और खाता बचाना सीखें।",
                "फसवणूक झाल्यास 'गोल्डन अवर'मध्ये त्वरित पावले उचलून गेलेले पैसे परत मिळवणे आणि खाते वाचवणे शिका.",
                "BEGINNER", 5, "NONE", 4,
                "• The first 1 to 2 hours after a scam is the GOLDEN HOUR.\n• Call National Cyber Helpline 1930 immediately.\n• They can coordinate with banks to FREEZE the money before the thief withdraws it.\n• Report full details on cybercrime.gov.in and call your bank branch.",
                "• धोखाधड़ी के पहले 1-2 घंटे 'गोल्डन ऑवर' कहलाते हैं।\n• तुरंत राष्ट्रीय साइबर हेल्पलाइन 1930 पर फोन लगाएं।\n• वे बैंकों से बात करके चोर द्वारा पैसे निकालने से पहले खाते को फ्रीज कर देते हैं।\n• cybercrime.gov.in पर रिपोर्ट दर्ज कराएं और अपनी बैंक शाखा को सूचित करें।",
                "• फसवणूक झाल्यानंतरचे पहिले १-२ तास 'गोल्डन अवर' असतात.\n• तात्काळ राष्ट्रीय सायबर हेल्पलाइन १९३० वर फोन करा.\n• भामट्यांनी पैसे काढण्यापूर्वी बँक खाती गोठवून (फ्रीज) पैसे वाचवता येतात.\n• cybercrime.gov.in वर तक्रार नोंदवा आणि स्वतःच्या बँकेला सांगा.");

        DatabaseSeeder.insertStep(conn, l42, 1, "The 'Golden Hour' Concept", "गोल्डन ऑवर का महत्व समझें", "'गोल्डन अवर'चे महत्त्व समजून घ्या",
                "If money is accidentally debited due to fraud, act within the first 1 to 2 hours. This period is called the GOLDEN HOUR when money can still be frozen before scammers withdraw it from ATMs.",
                "अगर गलती से धोखाधड़ी में पैसे कट जाएं, तो पहले 1-2 घंटे सबसे कीमती होते हैं। इसे 'गोल्डन ऑवर' कहते हैं। इस दौरान पैसे को चोर के हाथ लगने से पहले फ्रीज किया जा सकता है।",
                "फसवणुकीने पैसे कापले गेल्यास पहिले १-२ तास अत्यंत महत्त्वाचे असतात. याला 'गोल्डन अवर' म्हणतात. या वेळेत भामट्यांनी एटीएममधून पैसे काढण्यापूर्वी ते गोठवता येतात.",
                "WARNING_BOX", "GOLDEN_HOUR",
                "Acting immediately within the Golden Hour dramatically increases the chance of recovering your funds.",
                "शुरुआती 1-2 घंटों में तुरंत कदम उठाने से पैसे वापस मिलने की संभावना सबसे ज्यादा होती है।",
                "पहिल्या १-२ तासांत तत्काळ पावले उचलल्यास पैसे परत मिळण्याची शक्यता सर्वाधिक असते.");

        DatabaseSeeder.insertStep(conn, l42, 2, "Dial National Cyber Helpline 1930", "तुरंत 1930 पर कॉल करें", "तात्काळ १९३० वर कॉल करा",
                "Pick up your phone and dial 1930. The Government of India cybercrime team will ask for: Your bank name, account number, time of deduction, and transaction ID from the SMS.",
                "तुरंत 1930 नंबर मिलाएं। सरकारी साइबर टीम आपसे पूछेगी: आपका बैंक नाम, खाता नंबर, पैसे कटने का समय और एसएमएस में आया ट्रांजैक्शन आईडी।",
                "लगेच १९३० नंबर डायल करा. सरकारी सायबर टीम विचारेल: बँकेचे नाव, खाते नंबर, पैसे कापल्याची वेळ आणि मेसेजमधील ट्रान्झॅक्शन आयडी.",
                "PHONE_UI", "CALL_1930",
                "Dial 1930 immediately to report the financial fraud to the national coordination desk.",
                "1930 पर तुरंत फोन करके पैसे कटने की पूरी जानकारी दें।",
                "१९३० वर तत्काळ फोन करून संपूर्ण माहिती द्या.");

        DatabaseSeeder.insertStep(conn, l42, 3, "How 1930 Freezes the Stolen Money", "1930 पैसे कैसे रोकती है?", "१९३० पैसे कसे अडवते?",
                "The 1930 team directly alerts the receiving bank and payment gateway to immediately FREEZE the destination account before the criminal can transfer it elsewhere.",
                "1930 की टीम सीधे उस बैंक को अलर्ट भेजती है जहां पैसा गया है, और उस खाते को तुरंत सील (फ्रीज) कर देती है ताकि चोर पैसे निकाल न सके।",
                "१९३० ची टीम थेट ज्या बँकेत पैसे गेले आहेत त्या खात्याला तात्काळ गोठवते (फ्रीज करते) जेणेकरून चोर पैसे काढू शकत नाही.",
                "PHONE_UI", "FREEZE_MONEY",
                "1930 coordinates with banking networks to intercept and freeze illicit fund transfers.",
                "1930 सीधे बैंकों से संपर्क करके चोरी के पैसे को बीच में ही रोक देती है।",
                "१९३० थेट बँकांशी संपर्क साधून चोरीचे पैसे मधेच अडवून ठेवते.");

        DatabaseSeeder.insertStep(conn, l42, 4, "File Official Complaint on cybercrime.gov.in", "cybercrime.gov.in पर रसीद दर्ज कराएं", "cybercrime.gov.in वर तक्रार नोंदवा",
                "After calling 1930, ask your child to help submit the formal written report on the official portal 'cybercrime.gov.in' and visit your bank branch to get a new ATM card.",
                "1930 पर बात करने के बाद बच्चों की मदद से 'cybercrime.gov.in' पर पूरी लिखित रिपोर्ट दर्ज कराएं और बैंक जाकर नया एटीएम कार्ड जारी कराएं।",
                "१९३० वर बोलून झाल्यावर मुलांच्या मदतीने 'cybercrime.gov.in' वर लेखी तक्रार नोंदवा आणि बँकेत जाऊन नवीन सुरक्षित एटीएम कार्ड घ्या.",
                "PHONE_UI", "CYBER_PORTAL",
                "Complete the formal report on cybercrime.gov.in to support legal fund recovery.",
                "cybercrime.gov.in पोर्टल पर लिखित शिकायत दर्ज कराकर पावती संभाल कर रखें।",
                "cybercrime.gov.in वर अधिकृत तक्रार नोंदवून पावती जपून ठेवा.");

        DatabaseSeeder.insertQuiz(conn, l42, "What is the 'Golden Hour' in cyber fraud?",
                "साइबर धोखाधड़ी के संदर्भ में 'गोल्डन ऑवर' (Golden Hour) का क्या अर्थ है?",
                "सायबर फसवणुकीच्या बाबतीत 'गोल्डन अवर' (Golden Hour) म्हणजे काय?",
                "The first 1 to 2 hours after a fraudulent transaction when authorities can still freeze the money in transit.",
                "धोखाधड़ी होने के बाद के शुरुआती 1-2 घंटे जब सरकारी तंत्र पैसे को चोर के पास पहुंचने से पहले बैंक में ही फ्रीज कर सकता है।",
                "फसवणूक झाल्यानंतरचे पहिले १-२ तास जेव्हा बँक खाती गोठवून पैसे वाचवता येतात.",
                new String[]{"The hour when gold is cheapest", "The first 1 to 2 hours after fraud when money can be frozen and recovered", "An hour in the evening when sun sets", "A bank holiday"},
                new String[]{"सोना सस्ता होने का समय", "धोखाधड़ी के पहले 1-2 घंटे जब पैसे को फ्रीज करके बचाया जा सकता है", "शाम के सूरज ढलने का समय", "बैंक की छुट्टी"},
                new String[]{"सोने स्वस्त होण्याची वेळ", "फसवणुकीनंतरचे पहिले १-२ तास जेव्हा पैसे अडवून परत मिळवता येतात", "संध्याकाळची वेळ", "बँकेची सुट्टी"}, 1);

        DatabaseSeeder.insertQuiz(conn, l42, "Which official national telephone number should you dial immediately if money is stolen by digital fraud?",
                "डिजिटल फ्रॉड में पैसे कटने पर तुरंत किस राष्ट्रीय सरकारी फोन नंबर पर कॉल करना चाहिए?",
                "डिजिटल फसवणुकीत पैसे गेल्यास तत्काळ कोणत्या राष्ट्रीय नंबरवर फोन करावा?",
                "Dial 1930 immediately to alert national cybercrime and banking authorities.",
                "राष्ट्रीय साइबर हेल्पलाइन 1930 पर तुरंत कॉल करना चाहिए।",
                "राष्ट्रीय सायबर हेल्पलाइन १९३० वर लगेच फोन केला पाहिजे.",
                new String[]{"1930 (National Cybercrime Reporting Helpline)", "100 only", "1800-00-00", "000"},
                new String[]{"1930 (राष्ट्रीय साइबर क्राइम हेल्पलाइन)", "केवल 100", "1800-00-00", "000"},
                new String[]{"१९३० (राष्ट्रीय सायबर क्राईम हेल्पलाइन)", "फक्त १००", "१८००-००-००", "०००"}, 0);

        DatabaseSeeder.insertQuiz(conn, l42, "What is the official Government of India website to report cyber financial scams?",
                "साइबर अपराध की आधिकारिक सरकारी रिपोर्ट दर्ज कराने के लिए भारत सरकार की वेबसाइट कौन सी है?",
                "सायबर गुन्ह्यांची अधिकृत तक्रार नोंदवण्यासाठी भारत सरकारची वेबसाइट कोणती आहे?",
                "cybercrime.gov.in is the designated national portal under Ministry of Home Affairs.",
                "cybercrime.gov.in गृह मंत्रालय द्वारा संचालित आधिकारिक राष्ट्रीय पोर्टल है।",
                "cybercrime.gov.in हे गृह मंत्रालयाचे अधिकृत राष्ट्रीय पोर्टल आहे.",
                new String[]{"facebook.com", "cybercrime.gov.in", "google.com", "whatsapp.com"},
                new String[]{"facebook.com", "cybercrime.gov.in", "google.com", "whatsapp.com"},
                new String[]{"facebook.com", "cybercrime.gov.in", "google.com", "whatsapp.com"}, 1);
    }
}
