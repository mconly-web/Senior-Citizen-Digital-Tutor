package com.seniortutor.database;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Handles SQLite database connections, schema migrations, and table lifecycle.
 */
public class DatabaseManager {
    private static final String DB_DIR = "database";
    private static final String DB_FILE = "database/seniortutor.db";
    private static final String JDBC_URL = "jdbc:sqlite:" + DB_FILE;

    private static DatabaseManager instance;

    private DatabaseManager() {
        instance = this;
        initDatabase();
    }

    public static synchronized DatabaseManager getInstance() {
        if (instance == null) {
            instance = new DatabaseManager();
        }
        return instance;
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL);
    }

    private void initDatabase() {
        try {
            File dir = new File(DB_DIR);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
                stmt.execute("PRAGMA foreign_keys = ON;");

                // Schema version tracking
                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS schema_version (
                        version INTEGER PRIMARY KEY,
                        description TEXT,
                        applied_at TEXT DEFAULT CURRENT_TIMESTAMP
                    );
                """);

                // Users table
                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        role TEXT NOT NULL DEFAULT 'SENIOR',
                        avatar TEXT,
                        current_streak INTEGER DEFAULT 1,
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP
                    );
                """);

                // Categories table
                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS categories (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        name_hi TEXT,
                        name_mr TEXT,
                        icon TEXT NOT NULL,
                        description TEXT,
                        description_hi TEXT,
                        description_mr TEXT,
                        display_order INTEGER DEFAULT 0
                    );
                """);

                // Lessons table
                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS lessons (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        category_id INTEGER NOT NULL,
                        title TEXT NOT NULL,
                        title_hi TEXT,
                        title_mr TEXT,
                        description TEXT,
                        description_hi TEXT,
                        description_mr TEXT,
                        difficulty TEXT DEFAULT 'BEGINNER',
                        estimated_minutes INTEGER DEFAULT 5,
                        practice_type TEXT DEFAULT 'NONE',
                        order_index INTEGER DEFAULT 0,
                        recap TEXT,
                        recap_hi TEXT,
                        recap_mr TEXT,
                        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
                    );
                """);

                // Lesson steps table
                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS lesson_steps (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        lesson_id INTEGER NOT NULL,
                        step_number INTEGER NOT NULL,
                        title TEXT NOT NULL,
                        title_hi TEXT,
                        title_mr TEXT,
                        explanation TEXT NOT NULL,
                        explanation_hi TEXT,
                        explanation_mr TEXT,
                        visual_type TEXT DEFAULT 'PHONE_UI',
                        visual_data TEXT,
                        voice_text TEXT,
                        voice_text_hi TEXT,
                        voice_text_mr TEXT,
                        FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE
                    );
                """);

                // Quiz questions table
                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS quiz_questions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        lesson_id INTEGER NOT NULL,
                        question_text TEXT NOT NULL,
                        question_text_hi TEXT,
                        question_text_mr TEXT,
                        explanation TEXT,
                        explanation_hi TEXT,
                        explanation_mr TEXT,
                        FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE
                    );
                """);

                // Quiz options table
                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS quiz_options (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        question_id INTEGER NOT NULL,
                        option_text TEXT NOT NULL,
                        option_text_hi TEXT,
                        option_text_mr TEXT,
                        is_correct INTEGER DEFAULT 0,
                        FOREIGN KEY (question_id) REFERENCES quiz_questions(id) ON DELETE CASCADE
                    );
                """);

                // User progress table
                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS user_progress (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        lesson_id INTEGER NOT NULL,
                        is_completed INTEGER DEFAULT 0,
                        last_step INTEGER DEFAULT 1,
                        quiz_score INTEGER DEFAULT 0,
                        quiz_passed INTEGER DEFAULT 0,
                        completed_at TEXT,
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                        FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE,
                        UNIQUE(user_id, lesson_id)
                    );
                """);

                // Achievements table
                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS achievements (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        code TEXT UNIQUE NOT NULL,
                        title TEXT NOT NULL,
                        description TEXT,
                        icon TEXT,
                        req_type TEXT NOT NULL,
                        req_value INTEGER DEFAULT 1
                    );
                """);

                // User achievements table
                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS user_achievements (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        achievement_id INTEGER NOT NULL,
                        unlocked_at TEXT DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                        FOREIGN KEY (achievement_id) REFERENCES achievements(id) ON DELETE CASCADE,
                        UNIQUE(user_id, achievement_id)
                    );
                """);

                // Recommendations table
                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS recommendations (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        senior_user_id INTEGER NOT NULL,
                        helper_user_id INTEGER NOT NULL,
                        lesson_id INTEGER NOT NULL,
                        note TEXT,
                        is_completed INTEGER DEFAULT 0,
                        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (senior_user_id) REFERENCES users(id) ON DELETE CASCADE,
                        FOREIGN KEY (helper_user_id) REFERENCES users(id) ON DELETE CASCADE,
                        FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE
                    );
                """);

                // Safety logs table
                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS safety_logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        input_text TEXT NOT NULL,
                        risk_level TEXT NOT NULL,
                        score INTEGER DEFAULT 0,
                        detected_flags TEXT,
                        checked_at TEXT DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                    );
                """);

                // Settings table
                stmt.execute("""
                    CREATE TABLE IF NOT EXISTS settings (
                        user_id INTEGER PRIMARY KEY,
                        font_scale REAL DEFAULT 1.0,
                        high_contrast INTEGER DEFAULT 0,
                        voice_enabled INTEGER DEFAULT 1,
                        sound_effects INTEGER DEFAULT 1,
                        reduced_animations INTEGER DEFAULT 0,
                        language TEXT DEFAULT 'en',
                        speech_rate REAL DEFAULT -1.0,
                        helper_pin TEXT DEFAULT '',
                        emergency_blood_group TEXT DEFAULT 'O+',
                        emergency_medications TEXT DEFAULT 'Aspirin, BP medication',
                        contact1_name TEXT DEFAULT 'Anita (Daughter)',
                        contact1_phone TEXT DEFAULT '+91 98765 43210',
                        contact2_name TEXT DEFAULT 'Rohan (Son)',
                        contact2_phone TEXT DEFAULT '+91 98123 45678',
                        doctor_name TEXT DEFAULT 'Dr. K. S. Verma',
                        doctor_phone TEXT DEFAULT '+91 94220 11223',
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                    );
                """);

                // Run safe schema migrations for existing database files
                runSafeMigrations(stmt);

                // Seed initial data or update content if lesson count is low
                DatabaseSeeder.seedIfEmpty(conn);
            }

        } catch (Exception e) {
            System.err.println("Database initialization error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void runSafeMigrations(Statement stmt) {
        // Safe column additions for categories
        safeAddColumn(stmt, "categories", "name_hi", "TEXT");
        safeAddColumn(stmt, "categories", "name_mr", "TEXT");
        safeAddColumn(stmt, "categories", "description_hi", "TEXT");
        safeAddColumn(stmt, "categories", "description_mr", "TEXT");

        // Safe column additions for lessons
        safeAddColumn(stmt, "lessons", "title_hi", "TEXT");
        safeAddColumn(stmt, "lessons", "title_mr", "TEXT");
        safeAddColumn(stmt, "lessons", "description_hi", "TEXT");
        safeAddColumn(stmt, "lessons", "description_mr", "TEXT");
        safeAddColumn(stmt, "lessons", "recap", "TEXT");
        safeAddColumn(stmt, "lessons", "recap_hi", "TEXT");
        safeAddColumn(stmt, "lessons", "recap_mr", "TEXT");

        // Safe column additions for lesson_steps
        safeAddColumn(stmt, "lesson_steps", "title_hi", "TEXT");
        safeAddColumn(stmt, "lesson_steps", "title_mr", "TEXT");
        safeAddColumn(stmt, "lesson_steps", "explanation_hi", "TEXT");
        safeAddColumn(stmt, "lesson_steps", "explanation_mr", "TEXT");
        safeAddColumn(stmt, "lesson_steps", "voice_text_hi", "TEXT");
        safeAddColumn(stmt, "lesson_steps", "voice_text_mr", "TEXT");

        // Safe column additions for quiz_questions
        safeAddColumn(stmt, "quiz_questions", "question_text_hi", "TEXT");
        safeAddColumn(stmt, "quiz_questions", "question_text_mr", "TEXT");
        safeAddColumn(stmt, "quiz_questions", "explanation_hi", "TEXT");
        safeAddColumn(stmt, "quiz_questions", "explanation_mr", "TEXT");

        // Safe column additions for quiz_options
        safeAddColumn(stmt, "quiz_options", "option_text_hi", "TEXT");
        safeAddColumn(stmt, "quiz_options", "option_text_mr", "TEXT");

        // Safe column additions for settings
        safeAddColumn(stmt, "settings", "speech_rate", "REAL DEFAULT -1.0");
        safeAddColumn(stmt, "settings", "helper_pin", "TEXT DEFAULT ''");
        safeAddColumn(stmt, "settings", "emergency_blood_group", "TEXT DEFAULT 'O+'");
        safeAddColumn(stmt, "settings", "emergency_medications", "TEXT DEFAULT 'Aspirin, BP medication'");

        // Record schema version 2
        try {
            stmt.execute("INSERT OR IGNORE INTO schema_version (version, description) VALUES (2, 'Multilingual, recaps, and accessibility columns')");
        } catch (Exception ignored) {}
    }

    private void safeAddColumn(Statement stmt, String table, String column, String type) {
        try {
            stmt.execute("ALTER TABLE " + table + " ADD COLUMN " + column + " " + type + ";");
        } catch (SQLException ignored) {
            // Column already exists or table altered
        }
    }
}
