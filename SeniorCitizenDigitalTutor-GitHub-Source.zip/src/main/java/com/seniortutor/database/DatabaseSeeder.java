package com.seniortutor.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Seeds and updates initial curriculum, users, categories, 42 lessons,
 * steps, quizzes, and achievements in English, Hindi, and Marathi.
 */
public class DatabaseSeeder {

    public static void seedIfEmpty() {
        try (Connection conn = DatabaseManager.getInstance().getConnection()) {
            seedIfEmpty(conn);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void seedIfEmpty(Connection conn) {
        try {
            // Check if users already seeded
            boolean hasUsers = false;
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM users")) {
                if (rs.next() && rs.getInt(1) > 0) {
                    hasUsers = true;
                }
            }

            // Check if full curriculum (>= 40 lessons) already seeded
            boolean hasCurriculum = false;
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM lessons")) {
                if (rs.next() && rs.getInt(1) >= 40) {
                    hasCurriculum = true;
                }
            }

            if (hasUsers && hasCurriculum) {
                return; // Everything already seeded
            }

            conn.setAutoCommit(false);

            if (!hasUsers) {
                // 1. Seed Users
                insertUser(conn, 1, "Shanti Sharma", "SENIOR", "👵", 3);
                insertUser(conn, 2, "Anita Sharma", "HELPER", "👩", 0);

                // 2. Seed Default Settings
                try (PreparedStatement ps = conn.prepareStatement(
                        "INSERT OR IGNORE INTO settings (user_id, font_scale, high_contrast, voice_enabled, sound_effects, language, contact1_name, contact1_phone, contact2_name, contact2_phone, doctor_name, doctor_phone, speech_rate, emergency_blood_group, emergency_medications) " +
                        "VALUES (1, 1.0, 0, 1, 1, 'en', 'Anita (Daughter)', '+91 98765 43210', 'Rohan (Son)', '+91 98123 45678', 'Dr. K. S. Verma', '+91 94220 11223', -1.0, 'B+', 'Telmisartan 40mg (BP), Metformin 500mg')")) {
                    ps.executeUpdate();
                }
            }

            if (!hasCurriculum) {
                // Clear existing lessons/quizzes to rebuild full 42-lesson curriculum cleanly
                try (Statement stmt = conn.createStatement()) {
                    stmt.execute("DELETE FROM user_achievements;");
                    stmt.execute("DELETE FROM recommendations;");
                    stmt.execute("DELETE FROM user_progress;");
                    stmt.execute("DELETE FROM quiz_options;");
                    stmt.execute("DELETE FROM quiz_questions;");
                    stmt.execute("DELETE FROM lesson_steps;");
                    stmt.execute("DELETE FROM lessons;");
                    stmt.execute("DELETE FROM categories;");
                    stmt.execute("DELETE FROM achievements;");
                }

                // 3. Seed 12 Categories
                seedCategories(conn);

                // 4. Seed 42 Lessons & Steps & Quizzes
                seedCat1Smartphone(conn);
                seedCat2Calling(conn);
                seedCat3WhatsApp(conn);
                CurriculumPart2.seed(conn);
                CurriculumPart3.seed(conn);

                // 5. Seed Achievements
                seedAchievements(conn);

                // 6. Seed Demo Progress & Recommendations if empty
                seedDemoProgress(conn);
            }

            conn.commit();
            System.out.println("Curriculum successfully seeded with 42 lessons and full multilingual content!");

        } catch (Exception e) {
            System.err.println("Database seeding failed: " + e.getMessage());
            e.printStackTrace();
            try {
                conn.rollback();
            } catch (Exception ignored) {}
        }
    }

    private static void insertUser(Connection conn, int id, String name, String role, String avatar, int streak) throws Exception {
        try (PreparedStatement ps = conn.prepareStatement("INSERT OR REPLACE INTO users (id, name, role, avatar, current_streak) VALUES (?, ?, ?, ?, ?)")) {
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.setString(3, role);
            ps.setString(4, avatar);
            ps.setInt(5, streak);
            ps.executeUpdate();
        }
    }

    private static void insertCategory(Connection conn, int id, String name, String nameHi, String nameMr,
                                       String icon, String desc, String descHi, String descMr, int order) throws Exception {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO categories (id, name, name_hi, name_mr, icon, description, description_hi, description_mr, display_order) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.setString(3, nameHi);
            ps.setString(4, nameMr);
            ps.setString(5, icon);
            ps.setString(6, desc);
            ps.setString(7, descHi);
            ps.setString(8, descMr);
            ps.setInt(9, order);
            ps.executeUpdate();
        }
    }

    private static void insertAchievement(Connection conn, int id, String code, String title, String desc, String icon, String reqType, int reqVal) throws Exception {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT OR REPLACE INTO achievements (id, code, title, description, icon, req_type, req_value) VALUES (?, ?, ?, ?, ?, ?, ?)")) {
            ps.setInt(1, id);
            ps.setString(2, code);
            ps.setString(3, title);
            ps.setString(4, desc);
            ps.setString(5, icon);
            ps.setString(6, reqType);
            ps.setInt(7, reqVal);
            ps.executeUpdate();
        }
    }

    public static int insertLesson(Connection conn, int id, int catId, String title, String titleHi, String titleMr,
                                    String desc, String descHi, String descMr, String diff, int mins, String practice, int order,
                                    String recap, String recapHi, String recapMr) throws Exception {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO lessons (id, category_id, title, title_hi, title_mr, description, description_hi, description_mr, " +
                "difficulty, estimated_minutes, practice_type, order_index, recap, recap_hi, recap_mr) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
            ps.setInt(1, id);
            ps.setInt(2, catId);
            ps.setString(3, title);
            ps.setString(4, titleHi);
            ps.setString(5, titleMr);
            ps.setString(6, desc);
            ps.setString(7, descHi);
            ps.setString(8, descMr);
            ps.setString(9, diff);
            ps.setInt(10, mins);
            ps.setString(11, practice);
            ps.setInt(12, order);
            ps.setString(13, recap);
            ps.setString(14, recapHi);
            ps.setString(15, recapMr);
            ps.executeUpdate();
            return id;
        }
    }

    public static void insertStep(Connection conn, int lessonId, int num, String title, String titleHi, String titleMr,
                                   String exp, String expHi, String expMr, String vType, String vData,
                                   String voice, String voiceHi, String voiceMr) throws Exception {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO lesson_steps (lesson_id, step_number, title, title_hi, title_mr, explanation, explanation_hi, explanation_mr, visual_type, visual_data, voice_text, voice_text_hi, voice_text_mr) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
            ps.setInt(1, lessonId);
            ps.setInt(2, num);
            ps.setString(3, title);
            ps.setString(4, titleHi);
            ps.setString(5, titleMr);
            ps.setString(6, exp);
            ps.setString(7, expHi);
            ps.setString(8, expMr);
            ps.setString(9, vType);
            ps.setString(10, vData);
            ps.setString(11, voice);
            ps.setString(12, voiceHi);
            ps.setString(13, voiceMr);
            ps.executeUpdate();
        }
    }

    public static void insertQuiz(Connection conn, int lessonId, String qText, String qTextHi, String qTextMr,
                                   String exp, String expHi, String expMr,
                                   String[] opts, String[] optsHi, String[] optsMr, int correctIdx) throws Exception {
        int qId = 0;
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO quiz_questions (lesson_id, question_text, question_text_hi, question_text_mr, explanation, explanation_hi, explanation_mr) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, lessonId);
            ps.setString(2, qText);
            ps.setString(3, qTextHi);
            ps.setString(4, qTextMr);
            ps.setString(5, exp);
            ps.setString(6, expHi);
            ps.setString(7, expMr);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) qId = rs.getInt(1);
            }
        }

        if (qId > 0) {
            for (int i = 0; i < opts.length; i++) {
                try (PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO quiz_options (question_id, option_text, option_text_hi, option_text_mr, is_correct) VALUES (?, ?, ?, ?, ?)")) {
                    ps.setInt(1, qId);
                    ps.setString(2, opts[i]);
                    ps.setString(3, (optsHi != null && i < optsHi.length) ? optsHi[i] : opts[i]);
                    ps.setString(4, (optsMr != null && i < optsMr.length) ? optsMr[i] : opts[i]);
                    ps.setInt(5, (i == correctIdx) ? 1 : 0);
                    ps.executeUpdate();
                }
            }
        }
    }

    // ==========================================
    // 3. SEED 12 CATEGORIES
    // ==========================================
    private static void seedCategories(Connection conn) throws Exception {
        insertCategory(conn, 1, "Smartphone Basics", "स्मार्टफोन मूल बातें", "स्मार्टफोन मूलभूत माहिती", "📱",
                "Power, volume, screen lock, buttons, and battery saving",
                "पावर, वॉल्यूम, स्क्रीन लॉक, बटन और बैटरी प्रबंधन",
                "पॉवर, आवाज, स्क्रीन लॉक, बटणे आणि बॅटरी व्यवस्थापन", 1);

        insertCategory(conn, 2, "Calling & Contacts", "कॉल और संपर्क", "कॉल आणि संपर्क", "📞",
                "Making calls, saving family numbers, speaker mode, and blocking spam",
                "कॉल करना, परिवार के नंबर सेव करना, स्पीकर मोड और स्पैम ब्लॉक करना",
                "कॉल करणे, कुटुंबीयांचे नंबर सेव्ह करणे, स्पीकर मोड आणि स्पॅम ब्लॉक करणे", 2);

        insertCategory(conn, 3, "WhatsApp", "व्हाट्सएप", "व्हॉट्सअॅप", "💬",
                "Messages, voice notes, photos, video calls, and group chats",
                "संदेश, वॉयस नोट्स, फोटो, वीडियो कॉल और पारिवारिक ग्रुप",
                "मेसेज, व्हॉइस नोट्स, फोटो, व्हिडिओ कॉल आणि कौटुंबिक ग्रुप", 3);

        insertCategory(conn, 4, "Camera & Photos", "कैमरा और तस्वीरें", "कॅमेरा आणि फोटो", "📸",
                "Taking clear photos, selfies, viewing gallery, and sharing pictures",
                "साफ तस्वीरें खींचना, सेल्फी, गैलरी देखना और सुरक्षित शेयर करना",
                "स्पष्ट फोटो काढणे, सेल्फी, गॅलरी पाहणे आणि सुरक्षित पाठवणे", 4);

        insertCategory(conn, 5, "Internet & Entertainment", "इंटरनेट और मनोरंजन", "इंटरनेट आणि मनोरंजन", "🌐",
                "Voice search on Google, YouTube bhajans and songs, and safe browsing",
                "गूगल पर बोलकर खोजना, यूट्यूब भजन-गीत और सुरक्षित ब्राउज़िंग",
                "गुगलवर बोलून शोधणे, युट्यूब भजन-गाणी आणि सुरक्षित ब्राउझिंग", 5);

        insertCategory(conn, 6, "Google Maps", "गूगल मैप्स", "गुगल मॅप्स", "🗺️",
                "Finding nearby hospitals, pharmacies, walking and voice directions",
                "आस-पास के अस्पताल, मेडिकल दुकान खोजना और आवाज वाले रास्ते",
                "जवळचे रुग्णालय, मेडिकल दुकान शोधणे आणि बोलणारे नकाशे", 6);

        insertCategory(conn, 7, "Digital Payments", "डिजिटल भुगतान (UPI)", "डिजिटल पेमेंट (UPI)", "💳",
                "Safe UPI, scanning QR codes, checking balance, and NEVER sharing PIN",
                "सुरक्षित UPI, QR कोड स्कैन करना, बैलेंस देखना और पिन कभी न बताना",
                "सुरक्षित UPI, QR कोड स्कॅन करणे, शिल्लक पाहणे आणि पिन कधीही न सांगणे", 7);

        insertCategory(conn, 8, "Banking & Safety", "बैंकिंग सुरक्षा", "बँकिंग सुरक्षा", "🏦",
                "Official SMS alerts, ATM card safety, balance checks, spotting fake callers",
                "बैंक के असली एसएमएस, एटीएम सुरक्षा, बैलेंस जांच और फर्जी कॉल पहचानना",
                "बँकेचे खरे एसएमएस, एटीएम सुरक्षा, शिल्लक तपासणे आणि बनावट कॉल ओळखणे", 8);

        insertCategory(conn, 9, "Online Services", "ऑनलाइन सेवाएं", "ऑनलाइन सेवा", "🛒",
                "Booking cabs, ordering medicines online, train PNR, and paying bills",
                "कैब बुक करना, ऑनलाइन दवाइयां मंगवाना, ट्रेन पीएनआर और बिल भरना",
                "कॅब बुक करणे, औषधे मागवणे, रेल्वे पीएनआर आणि वीज बिल भरणे", 9);

        insertCategory(conn, 10, "Email", "ईमेल", "ईमेल", "📧",
                "Composing emails, reading letters, opening attachments, and spotting spam",
                "ईमेल लिखना, जरूरी पत्र पढ़ना, फाइल खोलना और स्पैम से बचाव",
                "ईमेल लिहिणे, पत्र वाचणे, फाईल उघडणे आणि स्पॅम ओळखणे", 10);

        insertCategory(conn, 11, "Digital Safety & Scams", "साइबर सुरक्षा एवं फ्रॉड", "सायबर सुरक्षा आणि फसवणूक", "🔐",
                "Golden safety rules, fake electricity cuts, digital arrest, and courier scams",
                "सुरक्षा के 6 नियम, बिजली कटने के फर्जी मैसेज, डिजिटल अरेस्ट और पार्सल फ्रॉड",
                "सुरक्षेचे ६ नियम, वीज कपातीचे बनावट मेसेज, डिजिटल अरेस्ट आणि पार्सल घोटाळे", 11);

        insertCategory(conn, 12, "Government & Emergency", "सरकारी सेवाएं व आपातकालीन", "शासकीय सेवा व आणीबाणी", "🆘",
                "DigiLocker, Aadhaar download, online doctor consultation, and 112 / 1930 help",
                "डिजिलॉकर, आधार डाउनलोड, ऑनलाइन डॉक्टर सलाह और 112 / 1930 हेल्पलाइन",
                "डिजिलॉकर, आधार डाउनलोड, ऑनलाइन डॉक्टर सल्ला आणि 112 / 1930 मदत", 12);
    }

    // ==========================================
    // CAT 1: SMARTPHONE BASICS (Lessons 1 - 4)
    // ==========================================
    private static void seedCat1Smartphone(Connection conn) throws Exception {
        // L1: How to Turn Phone ON and OFF
        int l1 = insertLesson(conn, 1, 1, "How to Turn Phone ON and OFF", "फोन चालू और बंद करना सीखें", "फोन सुरू आणि बंद करणे शिका",
                "Learn how to power on, restart when slow, and safely switch off.",
                "स्मार्टफोन को ऑन करना, रीस्टार्ट करना और सुरक्षित रूप से बंद करना सीखें।",
                "स्मार्टफोन चालू करणे, रीस्टार्ट करणे आणि सुरक्षितपणे बंद करणे शिका.",
                "BEGINNER", 4, "PHONE", 1,
                "• Press & hold Power button for 3 seconds.\n• Choose 'Restart' if phone is slow or stuck.\n• Choose 'Power Off' before flights or sleeping.",
                "• पावर बटन को 3 सेकंड दबाकर रखें।\n• फोन धीमा होने पर 'Restart' चुनें।\n• सोने से पहले या लंबी यात्रा में 'Power Off' चुनें।",
                "• पॉवर बटण ३ सेकंद दाबून ठेवा.\n• फोन अडकल्यास 'Restart' निवडा.\n• फोन बंद करण्यासाठी 'Power Off' निवडा.");

        insertStep(conn, l1, 1, "Locate the Power Button", "पावर बटन ढूंढें", "पॉवर बटण शोधा",
                "Look at the right or top edge of your smartphone. Find the small physical button.",
                "अपने फोन के दाएं या ऊपर की तरफ देखें। वहां एक छोटा उभरा हुआ पावर बटन होता है।",
                "तुमच्या फोनच्या उजव्या बाजूला किंवा वरच्या कडेला असलेले लहान पॉवर बटण शोधा.",
                "PHONE_UI", "POWER_BUTTON",
                "Locate the power button on the right side of your phone.",
                "अपने फोन के दाएं तरफ पावर बटन को देखें।",
                "तुमच्या फोनच्या उजव्या बाजूला असलेले पॉवर बटण पहा.");

        insertStep(conn, l1, 2, "Press and Hold for 3 Seconds", "3 सेकंड तक दबाकर रखें", "३ सेकंद दाबून ठेवा",
                "Firmly press and hold the button for 3 seconds until options appear on the screen.",
                "पावर बटन को 3 सेकंड तक लगातार दबाकर रखें जब तक स्क्रीन पर विकल्प न आ जाएं।",
                "पॉवर बटण ३ सेकंद दाबून ठेवा जोपर्यंत स्क्रीनवर पर्याय दिसत नाहीत.",
                "PHONE_UI", "POWER_HOLD",
                "Press and hold the power button for three seconds.",
                "पावर बटन को तीन सेकंड तक दबाकर रखें।",
                "पॉवर बटण तीन सेकंद दाबून ठेवा.");

        insertStep(conn, l1, 3, "Select Power Off or Restart", "पावर ऑफ या रीस्टार्ट चुनें", "पॉवर ऑफ किंवा रीस्टार्ट निवडा",
                "Tap the red 'Power Off' button to shut down, or green 'Restart' if your phone is hanging.",
                "फोन बंद करने के लिए लाल 'Power Off' छुएं, या फोन अटकने पर हरा 'Restart' छुएं।",
                "फोन बंद करण्यासाठी लाल 'Power Off' किंवा फोन हळू चालल्यास 'Restart' दाबा.",
                "PHONE_UI", "POWER_MENU",
                "Tap Power Off to shut down, or Restart if the phone is slow.",
                "फोन बंद करने के लिए पावर ऑफ दबाएं या रीस्टार्ट चुनें।",
                "फोन बंद करण्यासाठी पॉवर ऑफ किंवा रीस्टार्ट निवडा.");

        insertStep(conn, l1, 4, "Turning It Back On", "फोन दोबारा चालू करना", "फोन पुन्हा सुरू करणे",
                "To turn the phone back on, press and hold the same Power button until the company logo appears.",
                "फोन दोबारा चालू करने के लिए वही पावर बटन 4 सेकंड तक दबाएं जब तक कंपनी का लोगो न दिखे।",
                "फोन पुन्हा चालू करण्यासाठी तेच पॉवर बटण कंपनीचे नाव दिसेपर्यंत दाबून ठेवा.",
                "PHONE_UI", "POWER_BUTTON",
                "Hold the power button until the screen lights up to turn your phone back on.",
                "स्क्रीन पर लोगो दिखने तक पावर बटन दबाए रखें।",
                "स्क्रीन उजळेपर्यंत पॉवर बटण दाबून ठेवा.");

        insertQuiz(conn, l1, "How do you bring up the Power menu on your smartphone?",
                "स्मार्टफोन पर पावर मेनू कैसे खोला जाता है?",
                "स्मार्टफोनवर पॉवर मेनू कसा उघडला जातो?",
                "Pressing and holding the power button for 3 seconds opens the power options.",
                "पावर बटन को 3 सेकंड दबाए रखने से शटडाउन और रीस्टार्ट विकल्प खुलते हैं।",
                "पॉवर बटण ३ सेकंद दाबून ठेवल्याने पॉवर पर्याय उघडतात.",
                new String[]{"Tap the screen three times", "Press and hold the Power button for 3 seconds", "Plug in the charger", "Shake the phone vigorously"},
                new String[]{"स्क्रीन पर तीन बार टैप करें", "पावर बटन को 3 सेकंड दबाकर रखें", "चार्जर लगाएं", "फोन को जोर से हिलाएं"},
                new String[]{"स्क्रीनवर ३ वेळा दाबा", "पॉवर बटण ३ सेकंद दाबून ठेवा", "चार्जर लावा", "फोन जोरात हलवा"}, 1);

        insertQuiz(conn, l1, "What should you do if your smartphone is frozen or running very slowly?",
                "अगर आपका फोन अटक जाए या बहुत धीमा चले तो क्या करना चाहिए?",
                "जर तुमचा फोन अडकला किंवा हळू चालत असेल तर काय करावे?",
                "Restarting clears temporary memory and makes your phone fresh and fast.",
                "फोन रीस्टार्ट करने से पुरानी मेमोरी खाली होती है और फोन तेज चलने लगता है।",
                "फोन रीस्टार्ट केल्याने तात्पुरती मेमरी साफ होते आणि फोन सुरळीत चालतो.",
                new String[]{"Throw the phone away", "Select 'Restart' from the power menu", "Put it in water", "Press volume down for 10 minutes"},
                new String[]{"फोन फेंक दें", "पावर मेनू से 'Restart' चुनें", "पानी में रख दें", "वॉल्यूम बटन 10 मिनट दबाएं"},
                new String[]{"फोन फेकून द्या", "पॉवर मेनूमधून 'Restart' निवडा", "पाण्यात ठेवा", "आवाजाचे बटण दाबत बसा"}, 1);

        insertQuiz(conn, l1, "How do you know the phone is starting up when you turn it on?",
                "फोन चालू होते समय कैसे पता चलता है कि वह शुरू हो रहा है?",
                "फोन सुरू होत असताना काय दिसते?",
                "The screen lights up with the manufacturer's brand logo (like Samsung, Vivo, etc.).",
                "स्क्रीन रोशनी के साथ कंपनी का लोगो दिखाती है।",
                "स्क्रीनवर कंपनीचा लोगो किंवा नाव झळकते.",
                new String[]{"It rings loudly immediately", "The screen lights up with the brand logo", "The flashlight stays on forever", "It takes a photo automatically"},
                new String[]{"तुरंत जोर से घंटी बजती है", "स्क्रीन पर कंपनी का लोगो चमकता है", "टॉर्च जलती रहती है", "अपने आप फोटो खींचता है"},
                new String[]{"लगेच रिंग वाजते", "स्क्रीनवर कंपनीचा लोगो दिसतो", "टॉर्च सुरू राहते", "आपोआप फोटो निघतो"}, 1);

        // L2: How to Lock and Unlock the Screen
        int l2 = insertLesson(conn, 2, 1, "How to Lock and Unlock the Screen", "स्क्रीन लॉक और अनलॉक करना", "स्क्रीन लॉक आणि अनलॉक करणे",
                "Keep your phone safe and prevent accidental calls in your pocket.",
                "स्क्रीन लॉक करके अनचाहे कॉल और बैटरी की बर्बादी से बचें।",
                "स्क्रीन लॉक करून अनावधानाने होणारे कॉल आणि बॅटरी वाया जाणे टाळा.",
                "BEGINNER", 3, "NONE", 2,
                "• Press Power button once quickly to lock.\n• Press Power button again to wake the screen.\n• Swipe up gently to unlock.",
                "• स्क्रीन बंद करने के लिए पावर बटन एक बार हल्का दबाएं।\n• जगाने के लिए फिर से पावर बटन दबाएं।\n• अनलॉक करने के लिए नीचे से ऊपर उंगली सरकाएं।",
                "• लॉक करण्यासाठी पॉवर बटण एकदा दाबा.\n• स्क्रीन सुरू करण्यासाठी पुन्हा दाबा.\n• अनलॉक करण्यासाठी खालून वर सरकवा.");

        insertStep(conn, l2, 1, "Press Power Button Once to Lock", "लॉक करने के लिए पावर बटन एक बार दबाएं", "लॉक करण्यासाठी पॉवर बटण एकदा दाबा",
                "Whenever you finish using your phone, tap the power button once quickly. The screen turns black.",
                "जब भी फोन का काम पूरा हो, पावर बटन एक बार दबाएं। स्क्रीन बंद हो जाएगी।",
                "काम संपल्यावर पॉवर बटण एकदा हलकेच दाबा. स्क्रीन काळी होईल.",
                "PHONE_UI", "SCREEN_LOCK",
                "Press the power button once quickly to lock your screen.",
                "स्क्रीन लॉक करने के लिए पावर बटन को एक बार दबाएं।",
                "स्क्रीन लॉक करण्यासाठी पॉवर बटण एकदा दाबा.");

        insertStep(conn, l2, 2, "Wake the Screen", "स्क्रीन को जगाएं", "स्क्रीन सुरू करा",
                "To see the time or notifications, press the power button once. The lock screen will light up.",
                "समय या संदेश देखने के लिए पावर बटन फिर एक बार दबाएं। लॉक स्क्रीन जल उठेगी।",
                "वेळ किंवा मेसेज पाहण्यासाठी पॉवर बटण पुन्हा एकदा दाबा.",
                "PHONE_UI", "LOCK_SCREEN",
                "Press the power button once again to wake up the screen.",
                "स्क्रीन जगाने के लिए पावर बटन को फिर से दबाएं।",
                "स्क्रीन सुरू करण्यासाठी पॉवर बटण पुन्हा दाबा.");

        insertStep(conn, l2, 3, "Swipe Up Gently to Open", "हल्के से ऊपर स्वाइप करें", "हळूवार वर सरकवा",
                "Place your thumb at the bottom center of the glass and slide it upwards smoothly.",
                "स्क्रीन के निचले हिस्से पर अंगूठा रखकर धीरे से ऊपर की ओर सरकाएं।",
                "स्क्रीनच्या खालच्या भागावर बोट ठेवून हळूच वरच्या दिशेने सरकवा.",
                "PHONE_UI", "SWIPE_UP",
                "Swipe your finger upwards from the bottom of the screen.",
                "स्क्रीन के नीचे से ऊपर की ओर उंगली सरकाएं।",
                "स्क्रीनच्या खालून वर बोट सरकवा.");

        insertStep(conn, l2, 4, "Enter PIN or Fingerprint If Set", "पिन या फिंगरप्रिंट लगाएं", "पिन किंवा फिंगरप्रिंट वापरा",
                "If your phone asks for security, tap your 4-digit screen lock PIN or touch the fingerprint sensor.",
                "यदि फोन सुरक्षा मांगता है, तो अपना 4 अंकों का स्क्रीन पासवर्ड डालें या फिंगरप्रिंट सेंसर छुएं।",
                "सुरक्षेसाठी ४ अंकी स्क्रीन लॉक पिन टाका किंवा फिंगरप्रिंट सेन्सरला स्पर्श करा.",
                "PHONE_UI", "LOCK_SCREEN",
                "Enter your four digit screen lock PIN to access your home screen.",
                "होम स्क्रीन पर जाने के लिए अपना 4 अंकों का पिन डालें।",
                "फोन उघडण्यासाठी ४ अंकी पिन टाका.");

        insertQuiz(conn, l2, "Why should you always lock your phone screen before putting it in your pocket or purse?",
                "फोन को जेब या बैग में रखने से पहले स्क्रीन लॉक क्यों करना चाहिए?",
                "फोन खिशात किंवा पर्समध्ये ठेवण्यापूर्वी स्क्रीन लॉक का करावी?",
                "Locking prevents accidental phone calls and battery drain.",
                "लॉक करने से अनजाने में किसी को कॉल नहीं लगती और बैटरी बचती है।",
                "लॉक केल्याने चुकून कॉल लागत नाही आणि बॅटरी वाचते.",
                new String[]{"To make the phone heavier", "To prevent accidental dialing and battery drain", "To disconnect internet permanently", "To delete old photos"},
                new String[]{"फोन भारी करने के लिए", "अनचाहे कॉल और बैटरी बर्बादी रोकने के लिए", "इंटरनेट हमेशा के लिए बंद करने को", "पुरानी फोटो मिटाने के लिए"},
                new String[]{"फोन जड करण्यासाठी", "चुकून कॉल लागणे आणि बॅटरी संपणे टाळण्यासाठी", "इंटरनेट कायमचे बंद करण्यासाठी", "फोटो डिलीट करण्यासाठी"}, 1);

        insertQuiz(conn, l2, "How do you wake up a sleeping phone screen?",
                "सोए हुए फोन की स्क्रीन को कैसे जगाया जाता है?",
                "बंद पडलेली फोनची स्क्रीन कशी सुरू करावी?",
                "Pressing the power button once immediately wakes up the screen.",
                "पावर बटन को एक बार हल्का दबाने से स्क्रीन जल उठती है।",
                "पॉवर बटण एकदा दाबल्यास स्क्रीन उजळते.",
                new String[]{"Press the power button once", "Shout at the microphone", "Drop it on the floor", "Unscrew the back cover"},
                new String[]{"पावर बटन एक बार दबाएं", "माइक में चिल्लाएं", "जमीन पर गिराएं", "पीछे का ढक्कन खोलें"},
                new String[]{"पॉवर बटण एकदा दाबा", "माइकवर ओरडा", "खाली पाडा", "मागचे कव्हर उघडा"}, 0);

        insertQuiz(conn, l2, "What gesture unlocks most Android phones from the lock screen?",
                "अधिकतर फोन में लॉक स्क्रीन से अंदर जाने के लिए कौन सा इशारा किया जाता है?",
                "लॉक स्क्रीनवरून आत जाण्यासाठी काय करावे लागते?",
                "Swiping up gently from the bottom of the screen unlocks it.",
                "स्क्रीन के निचले हिस्से से ऊपर की ओर उंगली सरकाना।",
                "स्क्रीनच्या खालून वर हळूवार बोट सरकवणे.",
                new String[]{"Pinching with four fingers", "Swiping up gently from the bottom", "Blowing air into the speaker", "Covering the camera with tape"},
                new String[]{"चार उंगलियों से चुटकी काटना", "नीचे से ऊपर की ओर धीरे से स्वाइप करना", "स्पीकर में फूंक मारना", "कैमरे पर टेप चिपकाना"},
                new String[]{"चार बोटांनी चिमटा काढणे", "खालून वर हळूच स्वाइप करणे", "स्पीकरवर फुंकर मारणे", "कॅमेऱ्यावर पट्टी लावणे"}, 1);

        // L3: Adjusting Volume & Screen Brightness
        int l3 = insertLesson(conn, 3, 1, "Adjusting Volume & Screen Brightness", "आवाज़ और स्क्रीन की रोशनी बदलना", "आवाज आणि स्क्रीनचा प्रकाश नियंत्रित करणे",
                "Hear calls clearly and read text comfortably in direct sunlight.",
                "रिंगटोन तेज करना और धूप में स्क्रीन को साफ-साफ पढ़ना सीखें।",
                "रिंगटोन मोठी करणे आणि उन्हात स्क्रीन स्पष्ट वाचणे शिका.",
                "BEGINNER", 4, "NONE", 3,
                "• Press Top volume button to increase sound.\n• Press Bottom volume button to decrease sound.\n• Swipe down from top edge to adjust screen brightness slider.",
                "• आवाज़ बढ़ाने के लिए ऊपर का बटन दबाएं।\n• आवाज़ घटाने के लिए नीचे का बटन दबाएं।\n• रोशनी बढ़ाने के लिए स्क्रीन पर ऊपर से नीचे स्वाइप कर सूरज वाला स्लाइडर खींचे।",
                "• आवाज वाढवण्यासाठी वरचे बटण दाबा.\n• आवाज कमी करण्यासाठी खालचे बटण दाबा.\n• प्रकाश वाढवण्यासाठी वरून खाली सरकवून सूर्याचा स्लाइडर हलवा.");

        insertStep(conn, l3, 1, "Use the Side Volume Rocker", "साइड का वॉल्यूम बटन पहचानें", "बाजूचे आवाजाचे बटण ओळखा",
                "On the side of your phone, find the long two-sided volume button. The top half increases volume.",
                "फोन की साइड में लंबा दोतरफा बटन देखें। ऊपर वाला सिरा दबाने से आवाज़ बढ़ती है।",
                "फोनच्या बाजूला असलेले लांब बटण पहा. वरचा भाग दाबल्यास आवाज वाढतो.",
                "PHONE_UI", "VOLUME_BUTTONS",
                "Press the top side button to increase volume and bottom button to decrease it.",
                "आवाज़ बढ़ाने के लिए ऊपर का बटन और कम करने के लिए नीचे का बटन दबाएं।",
                "आवाज वाढवण्यासाठी वरचे बटण दाबा आणि कमी करण्यासाठी खालचे बटण दाबा.");

        insertStep(conn, l3, 2, "Swipe Down Quick Settings", "क्विक सेटिंग्स खोलें", "क्विक सेटिंग्स उघडा",
                "With your finger at the very top edge of the screen, drag downwards towards the middle.",
                "स्क्रीन के सबसे ऊपरी किनारे से उंगली को नीचे की ओर खींचें। नियंत्रण पैनल खुल जाएगा।",
                "स्क्रीनच्या अगदी वरच्या टोकावरून बोट खाली ओढा. कंट्रोल पॅनेल उघडेल.",
                "PHONE_UI", "SWIPE_DOWN",
                "Swipe down from the top edge of your screen to see brightness controls.",
                "स्क्रीन के ऊपर से नीचे स्वाइप करके ब्राइटनेस बार देखें।",
                "स्क्रीनच्या वरून खाली स्वाइप करून ब्राइटनेस पट्टी पहा.");

        insertStep(conn, l3, 3, "Drag the Sun Slider for Brightness", "सूरज वाले निशान को आगे बढ़ाएं", "सूर्याचे चिन्ह पुढे सरकवा",
                "Look for the bar with a small Sun icon. Drag the dot to the right to make the screen bright and clear.",
                "सूरज के निशान वाली पट्टी देखें। बिंदु को दाईं तरफ खिसकाएं जिससे स्क्रीन तेज और साफ दिखे।",
                "लहान सूर्याचे चिन्ह असलेली पट्टी पहा. उजवीकडे सरकवून स्क्रीन अधिक उजळ करा.",
                "PHONE_UI", "BRIGHTNESS_SLIDER",
                "Drag the sun slider to the right to make the display easy to read.",
                "सूरज के स्लाइडर को दाईं ओर खींचकर स्क्रीन साफ और चमकदार बनाएं।",
                "सूर्याचा स्लाइडर उजवीकडे ओढून स्क्रीन स्पष्ट करा.");

        insertQuiz(conn, l3, "Which side button makes phone calls and ringtones louder?",
                "फोन कॉल और घंटी की आवाज़ तेज करने के लिए कौन सा बटन दबाते हैं?",
                "फोन कॉल आणि रिंगटोनचा आवाज वाढवण्यासाठी कोणते बटण दाबावे?",
                "The upper portion of the volume rocker increases volume.",
                "वॉल्यूम बटन का ऊपरी हिस्सा आवाज़ बढ़ाता है।",
                "व्हॉल्यूम बटणाचा वरचा भाग आवाज वाढवतो.",
                new String[]{"The lower volume button", "The upper volume button", "The camera lens", "The charging socket"},
                new String[]{"नीचे वाला वॉल्यूम बटन", "ऊपर वाला वॉल्यूम बटन", "कैमरा लेंस", "चार्जिंग सॉकेट"},
                new String[]{"खालचे व्हॉल्यूम बटण", "वरचे व्हॉल्यूम बटण", "कॅमेरा", "चार्जरची जागा"}, 1);

        insertQuiz(conn, l3, "What icon represents screen brightness in the top quick panel?",
                "स्क्रीन की रोशनी (ब्राइटनेस) बदलने के लिए कौन सा चिन्ह बना होता है?",
                "स्क्रीनचा प्रकाश बदलण्यासाठी कोणते चिन्ह असते?",
                "A little Sun icon represents screen brightness.",
                "छोटा सूरज का चिन्ह स्क्रीन की चमक को दर्शाता है।",
                "लहान सूर्याचे चिन्ह स्क्रीनच्या प्रकाशासाठी असते.",
                new String[]{"A cup of tea", "A small Sun icon ☀️", "An airplane", "A bicycle"},
                new String[]{"चाय का कप", "छोटा सूरज का चिन्ह ☀️", "हवाई जहाज", "साइकिल"},
                new String[]{"चहाचा कप", "लहान सूर्याचे चिन्ह ☀️", "विमान", "सायकल"}, 1);

        insertQuiz(conn, l3, "If you are outside in bright sunlight and cannot see the screen, what should you do?",
                "यदि आप बाहर धूप में हैं और स्क्रीन पर कुछ दिखाई नहीं दे रहा, तो क्या करें?",
                "उन्हात असताना स्क्रीनवरील अक्षरे नीट दिसत नसतील तर काय करावे?",
                "Increasing screen brightness makes text clearly visible even in sunlight.",
                "स्क्रीन की ब्राइटनेस बढ़ाने से धूप में भी सब कुछ साफ दिखाई देता है।",
                "स्क्रीनचा प्रकाश (ब्राइटनेस) वाढवल्यास उन्हातही अक्षरे स्पष्ट दिसतात.",
                new String[]{"Pour water on the glass", "Increase screen brightness using the sun slider", "Switch off the phone forever", "Delete your contacts"},
                new String[]{"स्क्रीन पर पानी डालें", "सूरज वाले स्लाइडर से ब्राइटनेस बढ़ाएं", "फोन हमेशा के लिए बंद कर दें", "संपर्क डिलीट करें"},
                new String[]{"स्क्रीनवर पाणी ओता", "सूर्याच्या स्लाइडरने प्रकाश वाढवा", "फोन कायमचा बंद करा", "नंबर डिलीट करा"}, 1);

        // L4: Safe Battery Charging & Battery Saving
        int l4 = insertLesson(conn, 4, 1, "Safe Battery Charging & Battery Saving", "बैटरी चार्ज करना और बिजली बचाना", "बॅटरी चार्ज करणे आणि बचत करणे",
                "Keep your phone charged and avoid sudden shutdowns when outside.",
                "फोन को सही तरीके से चार्ज करें और बाहर रहते समय बैटरी बचाना सीखें।",
                "फोन योग्य प्रकारे चार्ज करा आणि प्रवासात बॅटरी वाचवणे शिका.",
                "BEGINNER", 4, "NONE", 4,
                "• Plug in charger when battery drops below 20%.\n• Avoid using phone while fast charging.\n• Turn on 'Battery Saver' mode when traveling.",
                "• बैटरी 20% से कम होने पर चार्जर लगाएं।\n• चार्ज होते समय बात करने से बचें।\n• बाहर जाने पर 'Battery Saver' मोड ऑन करें।",
                "• बॅटरी २०% च्या खाली गेल्यास चार्जर लावा.\n• चार्जिंग होत असताना फोन वापरणे टाळा.\n• प्रवासात 'Battery Saver' मोड चालू करा.");

        insertStep(conn, l4, 1, "Check Battery Percentage in Status Bar", "स्टेटस बार में बैटरी प्रतिशत देखें", "स्क्रीनवर बॅटरी किती टक्के आहे ते तपासा",
                "Look at the top right corner of the screen. You will see a small battery icon with a number like 65%.",
                "स्क्रीन के सबसे ऊपर दाईं ओर देखें। वहां बैटरी का छोटा निशान और नंबर (जैसे 65%) दिखेगा।",
                "स्क्रीनच्या वरच्या उजव्या कोपऱ्यात बॅटरीचे चिन्ह आणि टक्केवारी (उदा. ६५%) दिसेल.",
                "PHONE_UI", "BATTERY_LEVEL",
                "Look at the top right corner of the screen to check your battery level.",
                "स्क्रीन के ऊपर दाईं ओर अपनी बैटरी का स्तर देखें।",
                "स्क्रीनच्या वरच्या उजव्या बाजूला बॅटरी किती आहे ते पहा.");

        insertStep(conn, l4, 2, "Insert the Charging Cable Gently", "चार्जर केबल आराम से लगाएं", "चार्जरची पिन हळूच लावा",
                "Modern phones use Type-C oval cables. Gently insert it into the bottom socket until it clicks.",
                "चार्जर की केबल को फोन के नीचे वाले गोल सॉकेट में धीरे से लगाएं। स्क्रीन पर बिजली का निशान दिखेगा।",
                "चार्जरची पिन फोनच्या खालच्या भागात हळूच लावा. स्क्रीनवर चार्जिंगचे चिन्ह दिसेल.",
                "PHONE_UI", "CHARGING_ICON",
                "Connect the charger gently to the bottom charging port of your phone.",
                "चार्जर की पिन को फोन के निचले हिस्से में आराम से लगाएं।",
                "चार्जरची पिन फोनच्या खालच्या भागात जोरात न दाबता लावा.");

        insertStep(conn, l4, 3, "Enable Battery Saver When Traveling", "सफर में बैटरी सेवर चालू करें", "प्रवासात बॅटरी सेव्हर सुरू करा",
                "When you are outside and battery is low, swipe down quick settings and tap 'Battery Saver'.",
                "जब आप घर से बाहर हों और बैटरी 20% रह जाए, तो ऊपर से नीचे स्वाइप कर 'Battery Saver' दबाएं।",
                "बाहेर असताना बॅटरी कमी झाल्यास वरून खाली स्वाइप करून 'Battery Saver' चालू करा.",
                "PHONE_UI", "BATTERY_SAVER",
                "Tap Battery Saver to extend battery life when you are away from home.",
                "बैटरी बचाने के लिए बैटरी सेवर चालू करें।",
                "बॅटरी अधिक काळ टिकवण्यासाठी बॅटरी सेव्हर चालू करा.");

        insertQuiz(conn, l4, "When is the ideal time to put your phone on charge?",
                "फोन को चार्जिंग पर लगाने का सबसे सही समय कब होता है?",
                "फोन चार्जिंगला लावण्याची योग्य वेळ कोणती?",
                "Plugging in before it drops below 20% protects the health of the battery.",
                "बैटरी 20% से नीचे जाने से पहले चार्ज करने से बैटरी की उम्र लंबी रहती है।",
                "बॅटरी २०% च्या खाली जाण्यापूर्वी चार्ज केल्यास बॅटरीचे आयुष्य वाढते.",
                new String[]{"When battery drops to around 20%", "Only once a year", "When the phone explodes", "Never charge it at all"},
                new String[]{"जब बैटरी 20% के आसपास आ जाए", "साल में केवल एक बार", "जब फोन गर्म हो जाए", "कभी चार्ज न करें"},
                new String[]{"जेव्हा बॅटरी २०% च्या जवळ येते", "वर्षातून एकदाच", "फोन गरम झाल्यावर", "कधीच चार्ज करू नका"}, 0);

        insertQuiz(conn, l4, "What does the 'Battery Saver' mode do on a smartphone?",
                "फोन में 'Battery Saver' मोड क्या करता है?",
                "फोनमधील 'Battery Saver' मोड काय करतो?",
                "It reduces unnecessary background tasks to make battery last several hours longer.",
                "यह गैर-ज़रूरी ऐप्स रोककर बैटरी को कई घंटे ज्यादा चलाता है।",
                "हा नको असलेले बॅकग्राउंड काम बंद करून बॅटरीचे तास वाढवतो.",
                new String[]{"Deletes all photos", "Reduces background power usage to prolong battery", "Makes the phone ring automatically", "Locks the SIM card"},
                new String[]{"सभी फोटो मिटाता है", "गैर-जरूरी बिजली खपत घटाकर बैटरी चलाता है", "अपने आप घंटी बजाता है", "सिम कार्ड लॉक करता है"},
                new String[]{"फोटो डिलीट करतो", "अनावश्यक वापर थांबवून बॅटरी जास्त वेळ टिकवतो", "आपोआप रिंग वाजवतो", "सिम कार्ड बंद करतो"}, 1);

        insertQuiz(conn, l4, "Is it safe to use your phone for heavy gaming or calls while fast charging under a pillow?",
                "क्या तकिए के नीचे दबाकर फोन को चार्ज करते हुए बात करना सुरक्षित है?",
                "उशीखाली फोन दाबून चार्जिंग करत बोलणे सुरक्षित आहे का?",
                "No, phones need airflow while charging to prevent overheating.",
                "नहीं, चार्जिंग के दौरान फोन को खुली जगह पर रखना चाहिए ताकि वह गर्म न हो।",
                "नाही, चार्जिंगच्या वेळी फोन मोकळ्या जागेत ठेवणे गरजेचे असते.",
                new String[]{"Yes, it is very good", "No, keep the phone on a hard, open surface to prevent heat", "Yes, pillows cool the phone", "It does not matter"},
                new String[]{"हां, बहुत अच्छा है", "नहीं, फोन को हमेशा खुली और ठंडी सतह पर रखें", "हां, तकिया फोन को ठंडा करता है", "कोई फर्क नहीं पड़ता"},
                new String[]{"होय, खूप चांगले आहे", "नाही, फोन गरम होऊ नये म्हणून मोकळ्या जागेवर ठेवा", "होय, उशी फोन थंड ठेवते", "काही फरक पडत नाही"}, 1);
    }

    // ==========================================
    // CAT 2: CALLING & CONTACTS (Lessons 5 - 7)
    // ==========================================
    private static void seedCat2Calling(Connection conn) throws Exception {
        // L5: Making a Phone Call
        int l5 = insertLesson(conn, 5, 2, "Making a Phone Call", "फोन कॉल लगाना सीखें", "फोन कॉल करणे शिका",
                "Learn how to dial a number or call a family member from your contacts.",
                "फोन डायलर से नंबर मिलाना या संपर्कों से बेटे-बेटी को कॉल करना सीखें।",
                "नंबर डायल करून किंवा सेव्ह केलेल्या नंबरवरून फोन लावणे शिका.",
                "BEGINNER", 4, "PHONE", 1,
                "• Tap the green telephone icon.\n• Dial 10 digits or search in Contacts.\n• Tap green button to call, red button to hang up.",
                "• हरे फोन वाले निशान को छुएं।\n• 10 अंकों का नंबर डायल करें या नाम खोजें।\n• कॉल शुरू करने के लिए हरा और काटने के लिए लाल बटन दबाएं।",
                "• हिरव्या फोनच्या चिन्हावर दाबा.\n• १० अंकी नंबर डायल करा किंवा नाव शोधा.\n• कॉल सुरू करण्यासाठी हिरवे आणि संपवण्यासाठी लाल बटण दाबा.");

        insertStep(conn, l5, 1, "Open the Phone App", "फोन ऐप खोलें", "फोन अॅप उघडा",
                "Look for the green telephone receiver icon on your home screen and tap it.",
                "अपनी स्क्रीन पर हरे रंग का टेलीफोन रिसीवर वाला ऐप ढूंढें और उसे छुएं।",
                "तुमच्या स्क्रीनवरील हिरव्या रंगाचे फोनचे चिन्ह शोधा आणि त्यावर दाबा.",
                "PHONE_UI", "DIALER_ICON",
                "Tap the green phone icon on your home screen.",
                "होम स्क्रीन पर हरे फोन के निशान को छुएं।",
                "स्क्रीनवरील हिरव्या फोन चिन्हावर दाबा.");

        insertStep(conn, l5, 2, "Dial the 10-Digit Number or Pick Contact", "10 अंकों का नंबर डालें या संपर्क चुनें", "१० अंकी नंबर टाका किंवा संपर्क निवडा",
                "Tap 'Keypad' to type 10 digits, or tap 'Contacts' to find your son, daughter, or doctor.",
                "'Keypad' पर 10 अंकों का मोबाइल नंबर टाइप करें, या 'Contacts' में जाकर नाम चुनें।",
                "'Keypad' वर १० अंकी नंबर दाबा किंवा 'Contacts' मध्ये जाऊन नाव निवडा.",
                "PHONE_UI", "DIALPAD",
                "Type the phone number on the keypad or select from contacts.",
                "कीपैड पर नंबर लिखें या संपर्कों में से चुनें।",
                "कीपॅडवर नंबर टाईप करा किंवा संपर्कांमधून नाव निवडा.");

        insertStep(conn, l5, 3, "Tap the Green Call Button", "हरा कॉल बटन दबाएं", "हिरवे कॉल बटण दाबा",
                "Press the big round green telephone button at the bottom. Hold the phone to your ear.",
                "नीचे दिए गए बड़े हरे फोन बटन को दबाएं। फोन को अपने कान के पास ले जाएं।",
                "खालील मोठे हिरवे फोन बटण दाबा आणि फोन कानाला लावा.",
                "PHONE_UI", "CALL_BUTTON",
                "Tap the green button to start your call.",
                "कॉल शुरू करने के लिए हरे बटन को दबाएं।",
                "कॉल सुरू करण्यासाठी हिरवे बटण दाबा.");

        insertStep(conn, l5, 4, "End Call Using the Red Button", "बात पूरी होने पर लाल बटन दबाएं", "कॉल संपल्यावर लाल बटण दाबा",
                "When your conversation is over, tap the round red button on screen to disconnect.",
                "बातचीत समाप्त होने के बाद स्क्रीन पर बने लाल गोल बटन को छूकर फोन काटें।",
                "बोलणे संपल्यावर फोन कट करण्यासाठी स्क्रीनवरील लाल गोल बटण दाबा.",
                "PHONE_UI", "END_CALL",
                "Tap the red button to end the call when you finish speaking.",
                "बात पूरी होने पर लाल बटन दबाकर फोन काटें।",
                "बोलणे पूर्ण झाल्यावर लाल बटण दाबून कॉल बंद करा.");

        insertQuiz(conn, l5, "What color button do you press to disconnect or end a phone call?",
                "फोन कॉल समाप्त करने या काटने के लिए किस रंग का बटन दबाया जाता है?",
                "फोन कॉल कट करण्यासाठी कोणत्या रंगाचे बटण दाबावे?",
                "The red round button ends any active telephone call.",
                "लाल गोल बटन चालू कॉल को काट देता है।",
                "लाल गोल बटणामुळे चालू असलेला फोन कट होतो.",
                new String[]{"The green button", "The red button", "The yellow star", "The purple circle"},
                new String[]{"हरा बटन", "लाल बटन", "पीला तारा", "बैंगनी गोल"},
                new String[]{"हिरवे बटण", "लाल बटण", "पिवळा तारा", "जांभळा गोल"}, 1);

        insertQuiz(conn, l5, "How many digits does a standard mobile telephone number in India have?",
                "भारत में सामान्य मोबाइल फोन नंबर में कितने अंक होते हैं?",
                "भारतातील सामान्य मोबाईल नंबरमध्ये किती अंक असतात?",
                "Indian mobile phone numbers consist of 10 digits.",
                "भारतीय मोबाइल नंबर 10 अंकों के होते हैं।",
                "भारतीय मोबाईल नंबर १० अंकांचा असतो.",
                new String[]{"6 digits", "10 digits", "15 digits", "4 digits"},
                new String[]{"6 अंक", "10 अंक", "15 अंक", "4 अंक"},
                new String[]{"६ अंक", "१० अंक", "१५ अंक", "४ अंक"}, 1);

        insertQuiz(conn, l5, "Where in the Phone app can you find previously saved family numbers?",
                "फोन ऐप में पहले से सेव किए गए पारिवारिक नंबर कहां मिलते हैं?",
                "फोन अॅपमध्ये आधीच सेव्ह केलेले नंबर कुठे सापडतात?",
                "The 'Contacts' tab lists all saved names and numbers in alphabetical order.",
                "'Contacts' टैब में सभी सेव किए गए नाम वर्णमाला के अनुसार मिलते हैं।",
                "'Contacts' टॅबमध्ये सर्व सेव्ह केलेली नावे सापडतात.",
                new String[]{"In the trash bin", "In the Contacts tab", "In the calculator", "In the camera"},
                new String[]{"कचरे के डिब्बे में", "Contacts (संपर्क) टैब में", "कैलकुलेटर में", "कैमरे में"},
                new String[]{"कचऱ्याच्या डब्यात", "Contacts टॅबमध्ये", "कॅल्क्युलेटरमध्ये", "कॅमेऱ्यात"}, 1);

        // L6: Saving a New Family Contact
        int l6 = insertLesson(conn, 6, 2, "Saving a New Family Contact", "नया फोन नंबर सेव करना", "नवीन नंबर सेव्ह करणे",
                "Save children, grandchildren, and doctors so you never have to remember 10 digits.",
                "बच्चों और डॉक्टर का नंबर नाम के साथ फोन में सहेजना सीखें।",
                "मुले, नातवंडे आणि डॉक्टरांचे नंबर सेव्ह करा जेणेकरून नंबर लक्षात ठेवावा लागणार नाही.",
                "BEGINNER", 4, "PHONE", 2,
                "• Open Phone app and tap 'Contacts'.\n• Tap the '+' icon to create a new contact.\n• Type Name and 10-digit number, then tap 'Save'.",
                "• फोन ऐप खोलकर 'Contacts' पर जाएं।\n• नया नंबर जोड़ने के लिए '+' दबाएं।\n• नाम और मोबाइल नंबर लिखकर 'Save' दबाएं।",
                "• फोन अॅप उघडून 'Contacts' वर जा.\n• नवीन नंबरसाठी '+' चिन्हावर दाबा.\n• नाव आणि मोबाईल नंबर लिहून 'Save' दाबा.");

        insertStep(conn, l6, 1, "Tap 'Contacts' and the '+' Sign", "संपर्क खोलें और '+' छुएं", "संपर्क उघडा आणि '+' दाबा",
                "Inside the Phone app, tap 'Contacts' at the bottom, then tap the '+' (Create new contact) button.",
                "फोन ऐप के अंदर 'Contacts' पर जाएं, फिर नया संपर्क बनाने के लिए '+' निशान दबाएं।",
                "फोन अॅपमध्ये 'Contacts' वर जा आणि नवीन नंबर जोडण्यासाठी '+' दाबा.",
                "PHONE_UI", "CONTACT_ADD",
                "Tap the plus sign to add a new contact.",
                "नया संपर्क जोड़ने के लिए प्लस का निशान दबाएं।",
                "नवीन संपर्क जोडण्यासाठी प्लस चिन्हावर दाबा.");

        insertStep(conn, l6, 2, "Type the Person's Name", "व्यक्ति का नाम लिखें", "व्यक्तीचे नाव लिहा",
                "Tap the 'Name' box. The keyboard opens. Type their familiar name (e.g., 'Anita Beti' or 'Dr. Verma').",
                "'Name' वाली जगह पर छुएं और कीबोर्ड से उनका नाम लिखें (जैसे: 'अनिता बेटी' या 'डॉक्टर वर्मा')।",
                "'Name' वर दाबा आणि कीबोर्डवरून नाव लिहा (उदा. 'अनिता मुलगी' किंवा 'डॉक्टर जोशी').",
                "PHONE_UI", "CONTACT_NAME",
                "Type the full name or relationship of the person.",
                "व्यक्ति का नाम या रिश्ता लिखें।",
                "व्यक्तीचे नाव किंवा नाते लिहा.");

        insertStep(conn, l6, 3, "Type Their 10-Digit Phone Number", "उनका 10 अंकों का नंबर लिखें", "त्यांचा १० अंकी नंबर लिहा",
                "Tap the 'Phone' box. Type their 10-digit mobile number carefully. Double check each digit.",
                "'Phone' वाली लाइन को छुएं और 10 अंकों का नंबर ध्यान से टाइप करें।",
                "'Phone' च्या जागी त्यांचा १० अंकी मोबाईल नंबर काळजीपूर्वक टाईप करा.",
                "PHONE_UI", "CONTACT_PHONE",
                "Enter the ten digit mobile phone number.",
                "उनका 10 अंकों का मोबाइल नंबर दर्ज करें।",
                "त्यांचा १० अंकी मोबाईल नंबर टाका.");

        insertStep(conn, l6, 4, "Tap 'Save'", "'Save' पर टैप करें", "'Save' वर दाबा",
                "Look at the top right corner. Tap the 'Save' button. Their name is now permanently stored!",
                "ऊपर दाईं ओर देखें और 'Save' बटन दबाएं। अब उनका नाम हमेशा के लिए फोन में सेव हो गया है!",
                "वरच्या उजव्या कोपऱ्यात 'Save' बटण दाबा. नंबर सुरक्षित सेव्ह होईल!",
                "PHONE_UI", "CONTACT_SAVE",
                "Tap the Save button at the top to complete saving the contact.",
                "संपर्क सुरक्षित करने के लिए ऊपर सेव बटन दबाएं।",
                "नंबर सुरक्षित ठेवण्यासाठी सेव्ह बटण दाबा.");

        insertQuiz(conn, l6, "What symbol do you look for to add a brand new contact?",
                "फोन में बिल्कुल नया संपर्क जोड़ने के लिए किस चिन्ह को ढूंढा जाता है?",
                "नवीन संपर्क जोडण्यासाठी कोणते चिन्ह शोधायचे असते?",
                "The plus symbol '+' or 'Add Contact' creates a new entry.",
                "प्लस का निशान '+' नया संपर्क जोड़ने के लिए इस्तेमाल होता है।",
                "अधिकचे चिन्ह '+' नवीन संपर्क तयार करण्यासाठी असते.",
                new String[]{"The minus sign '-'", "The plus sign '+'", "The scissor sign", "The lock sign"},
                new String[]{"माइनस का निशान '-'", "प्लस का निशान '+'", "कैंची का निशान", "ताले का निशान"},
                new String[]{"वजाबाकीचे चिन्ह '-'", "अधिकचे चिन्ह '+'", "कात्रीचे चिन्ह", "कुल्पाचे चिन्ह"}, 1);

        insertQuiz(conn, l6, "What button must you press after typing the name and phone number to avoid losing it?",
                "नाम और नंबर लिखने के बाद उसे पक्का रखने के लिए कौन सा बटन दबाना जरूरी है?",
                "नाव आणि नंबर लिहिल्यावर तो सुरक्षित राहण्यासाठी कोणते बटण दाबावे?",
                "Pressing 'Save' stores the new contact into your phone memory.",
                "'Save' (सहेजें) दबाने से नंबर फोन में हमेशा के लिए सुरक्षित हो जाता है।",
                "'Save' बटण दाबल्याने तो नंबर फोनमध्ये कायमचा सेव्ह होतो.",
                new String[]{"Cancel", "Save", "Delete", "Power Off"},
                new String[]{"Cancel (रद्द करें)", "Save (सहेजें)", "Delete (मिटाएं)", "Power Off"},
                new String[]{"Cancel", "Save (सेव्ह करा)", "Delete", "Power Off"}, 1);

        insertQuiz(conn, l6, "Can you add a helpful note like 'Doctor' or 'Plumber' to someone's name?",
                "क्या आप किसी के नाम के साथ 'डॉक्टर' या 'प्लंबर' जैसा उपयोगी शब्द जोड़ सकते हैं?",
                "तुम्ही नावाच्या पुढे 'डॉक्टर' किंवा 'इलेक्ट्रिशियन' असे लिहू शकता का?",
                "Yes! Adding their profession or relationship helps you identify them quickly.",
                "हां! नाम के साथ रिश्ता या काम लिखने से उन्हें पहचानना बहुत आसान हो जाता है।",
                "होय! नावापुढे नाते किंवा काम लिहिल्याने पटकन ओळखता येते.",
                new String[]{"No, only single words allowed", "Yes, writing relationship or work helps you find them easily", "Only in English", "Only if police permits"},
                new String[]{"नहीं, केवल एक शब्द मान्य है", "हां, रिश्ता या काम लिखने से पहचानना बहुत आसान रहता है", "सिर्फ अंग्रेजी में", "पुलिस की अनुमति जरूरी है"},
                new String[]{"नाही, फक्त एकच शब्द चालतो", "होय, नाते किंवा काम लिहिल्याने ओळखणे सोपे जाते", "फक्त इंग्रजीत", "पोलिसांची परवानगी लागते"}, 1);

        // L7: Speakerphone & Blocking Spam Calls
        int l7 = insertLesson(conn, 7, 2, "Speakerphone & Blocking Spam Calls", "स्पीकरफोन और फर्जी कॉल ब्लॉक करना", "स्पीकरफोन आणि स्पॅम कॉल ब्लॉक करणे",
                "Hear louder without holding the phone to your ear, and stop harassing telemarketers.",
                "फोन कान से लगाए बिना तेज आवाज़ में बात करें और फालतू कॉल को ब्लॉक करना सीखें।",
                "फोन कानाला न लावता मोठ्या आवाजात बोला आणि नको असलेले फोन ब्लॉक करा.",
                "BEGINNER", 4, "PHONE", 3,
                "• Tap 'Speaker' icon during call for loud hands-free talk.\n• Tap 'Mute' if you need to sneeze or talk to someone in room.\n• Tap unknown number in Call Log and select 'Block / Report Spam'.",
                "• कॉल के दौरान तेज आवाज के लिए 'Speaker' छुएं।\n• कमरे में किसी और से बात करते समय 'Mute' दबाएं।\n• अज्ञात नंबर को कॉल हिस्ट्री में जाकर 'Block' करें।",
                "• कॉल सुरू असताना मोठा आवाज करण्यासाठी 'Speaker' दाबा.\n• घरातल्यांशी बोलताना 'Mute' दाबा.\n• अनोळखी नंबर कॉल हिस्ट्रीमध्ये जाऊन 'Block' करा.");

        insertStep(conn, l7, 1, "Turn On Speaker Mode", "स्पीकर मोड चालू करें", "स्पीकर मोड सुरू करा",
                "During a phone call, look at your screen. Tap the icon that looks like a loudspeaker labeled 'Speaker'.",
                "कॉल के दौरान स्क्रीन पर लाउडस्पीकर जैसा निशान देखें और उसे छुएं। आवाज़ तेज होकर बाहर आएगी।",
                "कॉल सुरू असताना स्क्रीनवरील लाउडस्पीकरच्या चिन्हावर दाबा. आवाज मोठा येईल.",
                "PHONE_UI", "SPEAKER_BUTTON",
                "Tap the Speaker icon to hear loud and clear without holding the phone to your ear.",
                "कान से लगाए बिना सुनने के लिए स्पीकर बटन दबाएं।",
                "मोठ्या आवाजात ऐकण्यासाठी स्पीकर बटण दाबा.");

        insertStep(conn, l7, 2, "Using the Mute Microphone Feature", "माइक म्यूट करना सीखें", "माइक म्यूट करणे शिका",
                "Tap the microphone with a slash through it ('Mute') if you need to talk to someone at home privately.",
                "यदि घर में किसी से बात करनी हो तो 'Mute' दबाएं। सामने वाले को आपकी आवाज़ नहीं सुनाई देगी।",
                "घरातील व्यक्तीशी खाजगी बोलायचे असल्यास 'Mute' दाबा. समोरच्याला तुमचा आवाज जाणार नाही.",
                "PHONE_UI", "MUTE_BUTTON",
                "Tap Mute to temporarily silence your microphone.",
                "अपनी आवाज़ को कुछ देर के लिए रोकने के लिए म्यूट दबाएं।",
                "तुमचा आवाज तात्पुरता बंद करण्यासाठी म्यूट दाबा.");

        insertStep(conn, l7, 3, "Find Unknown Numbers in Call Log", "कॉल हिस्ट्री में अनजान नंबर देखें", "कॉल हिस्ट्रीमध्ये अनोळखी नंबर शोधा",
                "After the call ends, tap 'Recents' in the Phone app. You will see numbers that called you in red or black.",
                "फोन ऐप में 'Recents' पर जाएं। वहां आए हुए सभी अनजान नंबरों की सूची दिखाई देगी।",
                "फोन अॅपमध्ये 'Recents' वर जा. आलेले सर्व अनोळखी नंबर दिसतील.",
                "PHONE_UI", "CALL_LOG",
                "Open your recent calls list to find suspicious incoming numbers.",
                "हाल ही में आए अनजान नंबर देखने के लिए रीसेंट्स सूची खोलें।",
                "नुकतेच आलेले अनोळखी नंबर पाहण्यासाठी रिसेंट लिस्ट उघडा.");

        insertStep(conn, l7, 4, "Block and Report as Spam", "ब्लॉक करें और हमेशा के लिए रोकें", "ब्लॉक करून कायमचे थांबवा",
                "Tap the unknown number, tap 'Info' or three dots, and choose 'Block / Report Spam'. They can never ring you again!",
                "उस नंबर पर टैप करके 'Block number' चुनें। इसके बाद वह धोखेबाज कभी आपके फोन पर घंटी नहीं बजा पाएगा!",
                "त्या नंबरवर दाबून 'Block' निवडा. त्यानंतर तो नंबर पुन्हा कधीही तुमच्या फोनवर वाजू शकणार नाही!",
                "PHONE_UI", "BLOCK_SPAM",
                "Select Block number to prevent annoying telemarketers and scammers from calling you.",
                "धोखेबाजों और विज्ञापनों को रोकने के लिए ब्लॉक नंबर चुनें।",
                "फसव्या लोकांना थांबवण्यासाठी ब्लॉक नंबर निवडा.");

        insertQuiz(conn, l7, "What icon on your screen makes phone call sound loud through the speaker?",
                "कॉल के दौरान आवाज़ को लाउडस्पीकर पर तेज करने के लिए कौन सा चिन्ह दबाते हैं?",
                "कॉल सुरू असताना स्पीकरवर मोठा आवाज करण्यासाठी कोणते चिन्ह दाबावे?",
                "The loudspeaker icon activates hands-free speakerphone.",
                "लाउडस्पीकर का निशान हैंड्स-फ्री स्पीकर चालू करता है।",
                "लाउडस्पीकरचे चिन्ह स्पीकरफोन चालू करते.",
                new String[]{"A padlock", "A loudspeaker icon 📢", "A shopping trolley", "A camera"},
                new String[]{"ताला", "लाउडस्पीकर का निशान 📢", "सामान की ट्रॉली", "कैमरा"},
                new String[]{"कुलूप", "लाउडस्पीकरचे चिन्ह 📢", "खरेदीची ट्रॉली", "कॅमेरा"}, 1);

        insertQuiz(conn, l7, "What happens when you select 'Block Number' for an unknown scam caller?",
                "जब आप किसी अनजान फ्रॉड नंबर को 'Block' कर देते हैं, तो क्या होता है?",
                "एखादा फसवणूक करणारा नंबर 'Block' केल्यावर काय होते?",
                "The phone automatically rejects any future calls from that number silently.",
                "फोन उस नंबर से आने वाली सभी कॉल को अपने आप बिना घंटी बजाए रोक देता है।",
                "तो नंबर पुन्हा कधीही फोन करू शकत नाही आणि रिंग वाजत नाही.",
                new String[]{"Your phone gets deleted", "That number can never ring your phone again", "Your electricity bill goes up", "The phone turns off"},
                new String[]{"फोन डिलीट हो जाता है", "वह नंबर दोबारा कभी आपके फोन पर कॉल नहीं कर पाता", "बिजली का बिल बढ़ जाता है", "फोन बंद हो जाता है"},
                new String[]{"फोन खराब होतो", "तो नंबर पुन्हा कधीही फोन करू शकत नाही", "वीज बिल वाढते", "फोन बंद पडतो"}, 1);

        insertQuiz(conn, l7, "If you need to cough or speak to your family member in the room without the caller hearing, what should you tap?",
                "यदि आपको खांसना हो या कमरे में किसी से बात करनी हो और आप नहीं चाहते कि कॉलर सुने, तो क्या दबाएं?",
                "समोरच्याला आपला आवाज जाऊ नये म्हणून तात्पुरते काय दाबावे?",
                "The 'Mute' button silences your microphone until you tap it again.",
                "'Mute' बटन आपके माइक को बंद कर देता है ताकि आपकी बात बाहर न जाए।",
                "'Mute' बटणामुळे तुमचा आवाज समोरच्याला ऐकू जात नाही.",
                new String[]{"The Mute button", "The Power button", "The Delete button", "The Camera button"},
                new String[]{"Mute (म्यूट) बटन", "पावर बटन", "डिलीट बटन", "कैमरा बटन"},
                new String[]{"Mute बटण", "पॉवर बटण", "डिलीट बटण", "कॅमेरा बटण"}, 0);
    }

    // ==========================================
    // CAT 3: WHATSAPP (Lessons 8 - 11)
    // ==========================================
    private static void seedCat3WhatsApp(Connection conn) throws Exception {
        // L8: Sending WhatsApp Text & Voice Notes
        int l8 = insertLesson(conn, 8, 3, "Sending WhatsApp Text & Voice Notes", "व्हाट्सएप पर संदेश और बोलकर वॉइस मैसेज भेजना", "व्हॉट्सअॅपवर मेसेज आणि बोलून व्हॉइस नोट पाठवणे",
                "Keep in touch with children and friends without struggling to type long sentences.",
                "बिना टाइप किए सिर्फ बोलकर बच्चों को अपना संदेश भेजना सीखें।",
                "मोठे मेसेज टाईप न करता फक्त बोलून मुलांना व्हॉइस मेसेज पाठवणे शिका.",
                "BEGINNER", 4, "WHATSAPP", 1,
                "• Open WhatsApp and tap on a family member's chat.\n• To type, tap the text bar and use the keyboard.\n• To send voice, press & hold green microphone while speaking, then release.",
                "• व्हाट्सएप खोलकर परिवार के सदस्य की चैट पर जाएं।\n• लिखने के लिए मैसेज बार छुएं।\n• बोलकर भेजने के लिए हरे माइक को दबाकर बोलें और छोड़ दें।",
                "• व्हॉट्सअॅप उघडून नातेवाईकाच्या चॅटवर जा.\n• टाईप करण्यासाठी मेसेज पट्टीवर दाबा.\n• बोलून पाठवण्यासाठी हिरवा माइक दाबून बोला आणि सोडून द्या.");

        insertStep(conn, l8, 1, "Open WhatsApp and Pick a Chat", "व्हाट्सएप खोलें और चैट चुनें", "व्हॉट्सअॅप उघडा आणि चॅट निवडा",
                "Tap the green WhatsApp icon. Tap the name of your son, daughter, or grandchild from the chat list.",
                "हरे व्हाट्सएप आइकन को छुएं। अपने बेटे, बेटी या रिश्तेदार के नाम पर टैप करें।",
                "हिरव्या व्हॉट्सअॅप चिन्हावर दाबा. मुलांच्या किंवा नातवंडांच्या नावावर दाबा.",
                "WHATSAPP_UI", "WA_ICON",
                "Open WhatsApp and tap on the person you want to message.",
                "व्हाट्सएप खोलें और जिसे संदेश भेजना है उसके नाम पर टैप करें।",
                "व्हॉट्सअॅप उघडा आणि मेसेज करायच्या व्यक्तीच्या नावावर दाबा.");

        insertStep(conn, l8, 2, "Type a Short Greeting", "छोटा संदेश लिखें", "लहान मेसेज टाईप करा",
                "Tap 'Message' at the bottom. The keyboard appears. Type 'Shubh Prabhat' or 'Namaste' and tap the green send arrow.",
                "नीचे 'Message' वाली जगह पर टैप करें। 'नमस्ते' लिखकर हरे तीर वाले सेंड बटन को दबाएं।",
                "खालच्या पट्टीवर दाबा. 'शुभ प्रभात' किंवा 'नमस्कार' लिहून हिरव्या बाणावर दाबा.",
                "WHATSAPP_UI", "TEXT_BAR",
                "Type your message and tap the green arrow to send it.",
                "अपना संदेश लिखें और भेजने के लिए हरे तीर को दबाएं।",
                "मेसेज लिहून पाठवण्यासाठी हिरव्या बाणावर दाबा.");

        insertStep(conn, l8, 3, "Press & Hold Microphone to Speak", "माइक दबाकर अपनी आवाज़ में बोलें", "माइक दाबून आपल्या आवाजात बोला",
                "Look at the bottom right. Press and keep holding the green microphone circle. Speak clearly in Hindi, Marathi, or English.",
                "नीचे दाईं तरफ बने हरे माइक के गोले को अंगूठे से दबाए रखें और साफ आवाज़ में अपना संदेश बोलें।",
                "उजव्या बाजूला असलेल्या हिरव्या माइकच्या गोलावर अंगठा दाबून ठेवा आणि स्पष्ट आवाजात बोला.",
                "WHATSAPP_UI", "MIC_HOLD",
                "Press and hold the green microphone icon while speaking your message.",
                "हरे माइक बटन को दबाए रखते हुए अपना संदेश बोलें।",
                "हिरवे माइक बटण दाबून धरून आपला संदेश बोला.");

        insertStep(conn, l8, 4, "Release Finger to Send Voice Note", "अंगूठा हटाते ही संदेश पहुंच जाएगा", "अंगठा उचलताच मेसेज रवाना होईल",
                "When you finish speaking, simply lift your thumb. The voice note is sent instantly!",
                "बोलना समाप्त होते ही अंगूठा हटा लें। आपकी आवाज़ तुरंत रिकॉर्ड होकर सामने वाले तक पहुंच जाएगी!",
                "बोलून झाल्यावर अंगठा वर उचला. तुमचा व्हॉइस मेसेज लगेच समोरच्याला जाईल!",
                "WHATSAPP_UI", "VOICE_SENT",
                "Lift your finger to send the voice message instantly.",
                "बोलना पूरा होने पर अंगूठा उठाएं, संदेश अपने आप चला जाएगा।",
                "बोलून झाल्यावर बोट उचला, मेसेज आपोआप जाईल.");

        insertQuiz(conn, l8, "How can you send a message on WhatsApp without typing any words?",
                "बिना कोई अक्षर टाइप किए व्हाट्सएप पर संदेश कैसे भेजा जा सकता है?",
                "काहीही टाईप न करता व्हॉट्सअॅपवर मेसेज कसा पाठवता येतो?",
                "Pressing and holding the green microphone icon records and sends your spoken voice.",
                "हरे माइक आइकन को दबाए रखकर बोलने से आपकी आवाज़ का संदेश चला जाता है।",
                "हिरवा माइक दाबून धरल्याने तुमचा बोललेला आवाज रेकॉर्ड होऊन पाठवला जातो.",
                new String[]{"By shaking the phone", "By pressing and holding the microphone icon while speaking", "By switching off Wi-Fi", "By taking a screenshot"},
                new String[]{"फोन को हिलाकर", "माइक वाले निशान को दबाकर रखते हुए बोलकर", "वाई-फाई बंद करके", "स्क्रीनशॉट लेकर"},
                new String[]{"फोन हलवून", "माइकचे चिन्ह दाबून ठेवून बोलल्याने", "वाय-फाय बंद करून", "स्क्रीनशॉट काढून"}, 1);

        insertQuiz(conn, l8, "What does the blue double-tick next to a WhatsApp message mean?",
                "व्हाट्सएप संदेश के आगे दो नीले सही के निशान (✓✓) का क्या अर्थ होता है?",
                "व्हॉट्सअॅप मेसेजच्या पुढे दोन निळ्या रंगाच्या टिक (✓✓) दिसल्या तर त्याचा अर्थ काय?",
                "Two blue ticks mean the recipient has received and opened your message.",
                "दो नीले निशान बताते हैं कि सामने वाले ने आपका संदेश देख और पढ़ लिया है।",
                "दोन निळ्या टिकचा अर्थ समोरच्याने तुमचा मेसेज उघडून वाचला आहे असा होतो.",
                new String[]{"Your phone is out of charge", "The person has read your message", "The message failed to deliver", "The message was deleted"},
                new String[]{"फोन की बैटरी खत्म है", "सामने वाले ने आपका संदेश पढ़ लिया है", "संदेश नहीं पहुंचा", "संदेश मिटा दिया गया"},
                new String[]{"बॅटरी संपली आहे", "समोरच्याने मेसेज वाचला आहे", "मेसेज गेला नाही", "मेसेज डिलीट झाला"}, 1);

        insertQuiz(conn, l8, "If you make a mistake while recording a voice message, how do you cancel it?",
                "यदि वॉइस मैसेज बोलते समय गलती हो जाए, तो उसे भेजे बिना कैसे रद्द करें?",
                "व्हॉइस मेसेज रेकॉर्ड करताना चूक झाली तर तो रद्द कसा करायचा?",
                "Slide your thumb to the left towards the trash bin icon to discard the recording.",
                "अंगूठे को बाईं ओर कचरे के डिब्बे की तरफ खिसका देने से रिकॉर्डिंग रद्द हो जाती है।",
                "अंगठा डाव्या बाजूला कचऱ्याच्या चिन्हाकडे सरकवल्यास तो मेसेज डिलीट होतो.",
                new String[]{"Slide your thumb to the left towards the trash can icon", "Throw the phone on the bed", "Restart the mobile immediately", "Press volume down"},
                new String[]{"अंगूठे को बाईं तरफ कचरे के डिब्बे की ओर सरकाएं", "फोन को बिस्तर पर फेंक दें", "फोन को तुरंत बंद करें", "आवाज का बटन दबाएं"},
                new String[]{"अंगठा डाव्या बाजूला कचऱ्याच्या डब्याकडे सरकवा", "फोन पलंगावर फेका", "फोन बंद करा", "आवाज कमी करा"}, 0);

        // L9: Making a WhatsApp Video Call
        int l9 = insertLesson(conn, 9, 3, "Making a WhatsApp Video Call", "व्हाट्सएप वीडियो कॉल करना", "व्हॉट्सअॅप व्हिडिओ कॉल करणे",
                "See your children and grandchildren face-to-face from anywhere in the world.",
                "देश-विदेश में बैठे बच्चों और पोते-पोतियों को आमने-सामने देखकर बात करें।",
                "परगावी किंवा परदेशात असणाऱ्या मुलांना आणि नातवंडांना समोरासमोर पाहून बोला.",
                "BEGINNER", 5, "WHATSAPP", 2,
                "• Open the contact's chat.\n• Tap the Video Camera icon at top right.\n• Look at the front camera and speak.\n• Tap the red phone circle to end call.",
                "• जिसे कॉल करना है उसकी चैट खोलें।\n• ऊपर दाईं तरफ वीडियो कैमरा का निशान छुएं।\n• चेहरे के सामने फोन रखकर बात करें।\n• बातचीत पूरी होने पर लाल बटन दबाएं।",
                "• ज्यांना कॉल करायचा आहे त्यांची चॅट उघडा.\n• वरच्या उजव्या बाजूला व्हिडिओ कॅमेऱ्याच्या चिन्हावर दाबा.\n• फोन समोर धरून बोला.\n• शेवटी लाल बटण दाबून कॉल बंद करा.");

        insertStep(conn, l9, 1, "Open the Chat of Your Family Member", "परिवार के सदस्य की चैट खोलें", "कुटुंबीयांची चॅट उघडा",
                "In WhatsApp, tap on your child, grandchild, or friend to open their conversation window.",
                "व्हाट्सएप में अपने बेटे, बहू, पोते या दोस्त के नाम पर टैप करें।",
                "व्हॉट्सअॅपमध्ये तुमच्या मुलांच्या किंवा मित्रांच्या नावावर दाबा.",
                "WHATSAPP_UI", "CONTACT_LIST",
                "Open the conversation with the person you wish to video call.",
                "जिससे बात करनी है उसकी चैट खोलें।",
                "ज्यांच्याशी बोलायचे आहे त्यांची चॅट उघडा.");

        insertStep(conn, l9, 2, "Tap the Video Camera Icon at Top Right", "ऊपर दाईं तरफ वीडियो कैमरे का निशान छुएं", "वर उजवीकडे व्हिडिओ कॅमेरा चिन्हावर दाबा",
                "Look at the very top right corner. Tap the icon that looks like a small video camera.",
                "स्क्रीन के ऊपर दाईं ओर देखें। वहां बने छोटे वीडियो कैमरे के निशान पर टैप करें।",
                "स्क्रीनच्या वरच्या उजव्या कोपऱ्यात असलेल्या लहान व्हिडिओ कॅमेऱ्याच्या चिन्हावर दाबा.",
                "WHATSAPP_UI", "VIDEO_ICON",
                "Tap the video camera icon at the top right to start a video call.",
                "वीडियो कॉल शुरू करने के लिए वीडियो कैमरा आइकन पर टैप करें।",
                "व्हिडिओ कॉल सुरू करण्यासाठी व्हिडिओ कॅमेऱ्याच्या चिन्हावर दाबा.");

        insertStep(conn, l9, 3, "Hold Phone in Front of Your Face", "फोन को चेहरे के सामने सीधा रखें", "फोन चेहऱ्यासमोर सरळ धरा",
                "Hold your phone comfortably at arm's length so your family can see your smile clearly.",
                "फोन को चेहरे से थोड़ी दूरी पर रखें ताकि परिवार वाले आपका चेहरा साफ-साफ देख सकें।",
                "फोन चेहऱ्यापासून थोडा लांब धरा जेणेकरून तुमचा चेहरा स्पष्ट दिसेल.",
                "WHATSAPP_UI", "ACTIVE_CALL",
                "Look towards the front camera lens and enjoy your conversation.",
                "कैमरे की तरफ देखकर प्यार से बात करें।",
                "कॅमेऱ्याकडे पाहून मनमोकळे बोला.");

        insertStep(conn, l9, 4, "End the Video Call with the Red Button", "बात पूरी होने पर लाल बटन दबाएं", "बोलणे संपल्यावर लाल बटण दाबा",
                "When your talk is finished, tap the screen once and press the round red button to disconnect.",
                "जब बातचीत पूरी हो जाए, स्क्रीन पर एक बार टैप करें और लाल गोल बटन दबाकर कॉल बंद करें।",
                "बोलणे संपल्यावर स्क्रीनवर एकदा दाबा आणि लाल गोल बटण दाबून कॉल बंद करा.",
                "WHATSAPP_UI", "END_CALL",
                "Tap the red button to finish your video call.",
                "वीडियो कॉल समाप्त करने के लिए लाल बटन दबाएं।",
                "व्हिडिओ कॉल संपवण्यासाठी लाल बटण दाबा.");

        insertQuiz(conn, l9, "Which icon at the top of a WhatsApp chat starts a video call?",
                "व्हाट्सएप चैट में सबसे ऊपर कौन सा चिन्ह वीडियो कॉल शुरू करता है?",
                "व्हॉट्सअॅप चॅटमध्ये वरच्या बाजूला कोणते चिन्ह व्हिडिओ कॉल सुरू करते?",
                "The video camera icon connects you with live video.",
                "वीडियो कैमरा का निशान लाइव वीडियो कॉल शुरू करता है।",
                "व्हिडिओ कॅमेऱ्याचे चिन्ह थेट व्हिडिओ कॉल सुरू करते.",
                new String[]{"The magnifying glass", "The video camera icon 📹", "The paperclip icon", "The three dots"},
                new String[]{"कांच का चश्मा", "वीडियो कैमरा का निशान 📹", "पेपरक्लिप", "तीन बिंदु"},
                new String[]{"भिंगाचे चिन्ह", "व्हिडिओ कॅमेऱ्याचे चिन्ह 📹", "पेपरक्लिप", "तीन ठिपके"}, 1);

        insertQuiz(conn, l9, "Does making a WhatsApp video call over home Wi-Fi cost any mobile balance?",
                "क्या घर के वाई-फाई पर व्हाट्सएप वीडियो कॉल करने से मोबाइल का बैलेंस कटता है?",
                "घरातील वाय-फायवर व्हॉट्सअॅप व्हिडिओ कॉल केल्यास मोबाईलचे पैसे कटतात का?",
                "No! WhatsApp uses internet data (Wi-Fi), not mobile talktime balance.",
                "नहीं! व्हाट्सएप इंटरनेट से चलता है, इसमें फोन का टॉकटाइम बैलेंस नहीं कटता।",
                "नाही! व्हॉट्सअॅप इंटरनेटवर चालते, यात मोबाईलचे पैसे कटत नाहीत.",
                new String[]{"Yes, it charges ₹10 per minute", "No, it uses internet/Wi-Fi and does not cost mobile talktime balance", "Only on Sundays", "Only after midnight"},
                new String[]{"हां, ₹10 प्रति मिनट कटता है", "नहीं, यह वाई-फाई इंटरनेट से चलता है और बैलेंस नहीं कटता", "केवल रविवार को", "केवल रात में"},
                new String[]{"होय, १० रुपये प्रति मिनिट", "नाही, हे वाय-फाय इंटरनेटवर चालते आणि बॅलन्स कटत नाही", "फक्त रविवारी", "फक्त मध्यरात्री"}, 1);

        insertQuiz(conn, l9, "What should you do if the other person cannot hear you during a video call?",
                "यदि वीडियो कॉल के दौरान सामने वाले को आपकी आवाज़ न आए, तो क्या देखना चाहिए?",
                "व्हिडिओ कॉल सुरू असताना समोरच्याला तुमचा आवाज येत नसेल तर काय तपासावे?",
                "Check if the microphone has a line across it (muted) and tap it to unmute.",
                "देखें कि कहीं गलती से माइक म्यूट (कटा हुआ) तो नहीं है, उसे दबाकर अनम्यूट करें।",
                "माइक म्यूट (बंद) झाला आहे का ते तपासा आणि त्यावर दाबून सुरू करा.",
                new String[]{"Buy a new smartphone", "Check if your microphone is accidentally muted on screen", "Turn off the lights", "Delete the chat"},
                new String[]{"नया फोन खरीदें", "देखें कि कहीं स्क्रीन पर माइक म्यूट तो नहीं हो गया", "कमरे की बत्ती बुझाएं", "चैट मिटा दें"},
                new String[]{"नवीन फोन विकत घ्या", "स्क्रीनवर माइक म्यूट झाला आहे का ते पहा", "घरातील दिवे बंद करा", "चॅट डिलीट करा"}, 1);

        // L10: Sharing Photos & Family Memories
        int l10 = insertLesson(conn, 10, 3, "Sharing Photos & Family Memories", "फोटो और पुरानी यादें साझा करना", "फोटो आणि आठवणी शेअर करणे",
                "Send festival photos, pooja pictures, and grandchild memories to family easily.",
                "त्योहार, पूजा और बच्चों की तस्वीरें परिवार के साथ शेयर करना सीखें।",
                "सण, पूजा आणि घरगुती आनंदाचे फोटो कुटुंबासोबत शेअर करणे शिका.",
                "BEGINNER", 4, "WHATSAPP", 3,
                "• Tap the Paperclip icon in chat.\n• Tap 'Gallery' to see your photos.\n• Select the photo and tap green Send arrow.\n• Add a caption if you like.",
                "• चैट में पेपरक्लिप निशान छुएं।\n• 'Gallery' चुनकर अपनी फोटो पर टैप करें।\n• हरा तीर दबाकर फोटो भेजें।\n• चाहें तो नीचे कुछ लिख भी सकते हैं।",
                "• चॅटमध्ये पेपरक्लिपवर दाबा.\n• 'Gallery' मध्ये जाऊन फोटो निवडा.\n• हिरवा बाण दाबून फोटो पाठवा.\n• खाली हवे असल्यास संदेशही लिहा.");

        insertStep(conn, l10, 1, "Tap the Paperclip Icon", "पेपरक्लिप आइकन छुएं", "पेपरक्लिप चिन्हावर दाबा",
                "Inside any chat, look at the message box at the bottom. Tap the paperclip icon (attachment).",
                "चैट के अंदर नीचे जहां मैसेज लिखते हैं, उसके पास पेपरक्लिप का निशान छुएं।",
                "चॅटमध्ये खाली मेसेज लिहिण्याच्या जागेजवळ पेपरक्लिपचे चिन्ह दिसेल, त्यावर दाबा.",
                "WHATSAPP_UI", "ATTACH_ICON",
                "Tap the paperclip icon next to the message bar.",
                "मैसेज बार के पास पेपरक्लिप आइकन पर टैप करें।",
                "मेसेज पट्टीजवळ पेपरक्लिप चिन्हावर दाबा.");

        insertStep(conn, l10, 2, "Select 'Gallery'", "'Gallery' (गैलरी) चुनें", "'Gallery' निवडा",
                "Tap the purple 'Gallery' circle. You will see all photos saved on your phone.",
                "बैंगनी रंग के 'Gallery' गोले को छुएं। आपके फोन की सभी तस्वीरें सामने आ जाएंगी।",
                "जांभळ्या रंगाच्या 'Gallery' पर्यायावर दाबा. फोनमधील सर्व फोटो दिसतील.",
                "WHATSAPP_UI", "GALLERY_PICKER",
                "Tap Gallery to browse pictures on your phone.",
                "अपने फोन की तस्वीरें देखने के लिए गैलरी पर टैप करें।",
                "फोनमधील फोटो पाहण्यासाठी गॅलरीवर दाबा.");

        insertStep(conn, l10, 3, "Select Your Photo", "अपनी पसंद की फोटो चुनें", "हवा असलेला फोटो निवडा",
                "Tap the photo you want to send. A large preview will appear on your screen.",
                "जो फोटो भेजनी है उस पर उंगली से टैप करें। वह फोटो पूरी स्क्रीन पर दिखेगी।",
                "पाठवायचा असलेला फोटो निवडा. तो फोटो मोठ्या आकारात दिसेल.",
                "WHATSAPP_UI", "PHOTO_PREVIEW",
                "Tap the photo you wish to send to family.",
                "भेजने वाली फोटो का चयन करें।",
                "पाठवायचा असलेला फोटो निवडा.");

        insertStep(conn, l10, 4, "Tap the Green Send Arrow", "हरा तीर दबाकर भेजें", "हिरवा बाण दाबून पाठवा",
                "Tap the green circle with the white paper airplane arrow at the bottom right. Sent!",
                "नीचे दाईं तरफ बने सफेद तीर वाले हरे गोले को दबाएं। फोटो तुरंत पहुंच जाएगी!",
                "खालच्या उजव्या बाजूला असलेल्या हिरव्या बाणाच्या चिन्हावर दाबा. फोटो लगेच जाईल!",
                "WHATSAPP_UI", "SEND_BUTTON",
                "Tap the green send button to deliver your photo.",
                "फोटो भेजने के लिए हरा बटन दबाएं।",
                "फोटो पाठवण्यासाठी हिरवे बटण दाबा.");

        insertQuiz(conn, l10, "Which icon inside a WhatsApp chat allows you to attach photos from your phone?",
                "व्हाट्सएप में फोन से फोटो भेजने के लिए किस निशान को दबाते हैं?",
                "व्हॉट्सअॅपवरून फोटो पाठवण्यासाठी कोणत्या चिन्हावर दाबावे लागते?",
                "The paperclip icon opens options to attach photos, documents, and contacts.",
                "पेपरक्लिप का निशान फोटो, दस्तावेज और संपर्क भेजने का विकल्प खोलता है।",
                "पेपरक्लिपचे चिन्ह फोटो, कागदपत्रे आणि संपर्क जोडण्याचे पर्याय उघडते.",
                new String[]{"The paperclip icon 📎", "The power button", "The volume button", "The battery icon"},
                new String[]{"पेपरक्लिप का निशान 📎", "पावर बटन", "वॉल्यूम बटन", "बैटरी का निशान"},
                new String[]{"पेपरक्लिपचे चिन्ह 📎", "पॉवर बटण", "आवाजाचे बटण", "बॅटरीचे चिन्ह"}, 0);

        insertQuiz(conn, l10, "Where are incoming photos sent by your family stored on your smartphone?",
                "परिवार द्वारा भेजी गई फोटो आपके फोन में कहां सुरक्षित रहती हैं?",
                "नातेवाईकांनी पाठवलेले फोटो फोनमध्ये कुठे सुरक्षित राहतात?",
                "Incoming WhatsApp photos are automatically saved to your phone's 'Gallery' or 'Photos' app.",
                "आई हुई तस्वीरें अपने आप फोन की 'Gallery' या 'Photos' ऐप में सहेज ली जाती हैं।",
                "आलेले फोटो फोनमधील 'Gallery' किंवा 'Photos' अॅपमध्ये सेव्ह होतात.",
                new String[]{"In the trash bin", "In the Gallery or Photos app", "In the SIM card", "In the calculator"},
                new String[]{"कचरे के डिब्बे में", "Gallery (गैलरी) या Photos ऐप में", "सिम कार्ड में", "कैलकुलेटर में"},
                new String[]{"कचऱ्यात", "Gallery किंवा Photos अॅपमध्ये", "सिम कार्डमध्ये", "कॅल्क्युलेटरमध्ये"}, 1);

        insertQuiz(conn, l10, "Can you add a short text message like 'Happy Diwali' below a photo before sending it?",
                "क्या फोटो भेजने से पहले उसके नीचे 'शुभ दिवाली' जैसा संदेश लिख सकते हैं?",
                "फोटो पाठवण्यापूर्वी खाली 'शुभ दीपावली' असा संदेश लिहिता येतो का?",
                "Yes, typing in 'Add a caption' sends text along with the photo.",
                "हां, 'Add a caption' वाली जगह लिखकर फोटो के साथ संदेश भेजा जा सकता है।",
                "होय, 'Add a caption' मध्ये लिहून फोटोसोबत शुभेच्छा पाठवता येतात.",
                new String[]{"No, it is impossible", "Yes, you can write in 'Add a caption' box below the preview", "Only if you pay money", "Only in English"},
                new String[]{"नहीं, यह संभव नहीं है", "हां, फोटो के नीचे 'Add a caption' में लिख सकते हैं", "केवल पैसे देकर", "केवल अंग्रेजी में"},
                new String[]{"नाही, शक्य नाही", "होय, फोटोखाली 'Add a caption' मध्ये लिहू शकता", "फक्त पैसे भरून", "फक्त इंग्रजीत"}, 1);

        // L11: WhatsApp Groups & Spam Protection
        int l11 = insertLesson(conn, 11, 3, "WhatsApp Groups & Spam Protection", "पारिवारिक ग्रुप और अफवाहों से बचाव", "कौटुंबिक ग्रुप आणि अफवांपासून बचाव",
                "Enjoy family chatter without noisy notifications or spreading fake rumors.",
                "परिवार के ग्रुप में जुड़े रहें, शोर से बचने के लिए म्यूट करें और अफवाहें न फैलाएं।",
                "कुटुंबाच्या ग्रुपमध्ये आनंद घ्या, नको असलेला आवाज म्यूट करा आणि अफवा पसरवणे टाळा.",
                "BEGINNER", 4, "WHATSAPP", 4,
                "• Mute group notifications if too noisy.\n• Check facts before forwarding 'Forwarded many times' messages.\n• Leave any group anytime using 'Exit Group'.",
                "• बार-बार आवाज आने पर ग्रुप को 'Mute' करें।\n• कई बार फॉरवर्ड किए गए चमत्कारी संदेशों को आगे न भेजें।\n• किसी भी ग्रुप से बाहर निकलने के लिए 'Exit Group' चुनें।",
                "• सतत आवाज येत असल्यास ग्रुप 'Mute' करा.\n• 'Forwarded' आलेले संशयास्पद मेसेज पुढे पाठवू नका.\n• नको असलेल्या ग्रुपमधून बाहेर पडण्यासाठी 'Exit Group' करा.");

        insertStep(conn, l11, 1, "What is a WhatsApp Group?", "व्हाट्सएप ग्रुप क्या होता है?", "व्हॉट्सअॅप ग्रुप म्हणजे काय?",
                "A group connects all family members (like 'Sharma Parivar'). A message sent here is seen by everyone.",
                "ग्रुप में परिवार के सभी लोग एक साथ जुड़े होते हैं। यहां भेजा गया एक संदेश सभी सदस्य पढ़ सकते हैं।",
                "ग्रुपमध्ये कुटुंबातील सर्व मंडळी एकत्र असतात. येथे पाठवलेला मेसेज सर्वजण वाचू शकतात.",
                "WHATSAPP_UI", "GROUP_INFO",
                "A group lets multiple family members share greetings and news in one place.",
                "ग्रुप में परिवार के सभी लोग एक साथ जुड़े रहते हैं।",
                "ग्रुपमध्ये सर्व नातेवाईक एकत्र संवाद साधू शकतात.");

        insertStep(conn, l11, 2, "Muting a Noisy Group", "शोर मचाने वाले ग्रुप को म्यूट करें", "सतत आवाज येणारा ग्रुप म्यूट करा",
                "If morning greetings disturb you, open the group, tap three dots at top right, tap 'Mute notifications' -> 'Always'.",
                "अगर बार-बार मैसेज की घंटी से परेशानी हो, तो ग्रुप खोलकर तीन बिंदुओं पर जाएं और 'Mute notifications' चुनें।",
                "मेसेजचा सतत आवाज नको असल्यास ग्रुप उघडून तीन ठिपक्यांवर जा आणि 'Mute notifications' निवडा.",
                "WHATSAPP_UI", "MUTE_GROUP",
                "Mute notifications to stop your phone from ringing on every group message.",
                "बार-बार घंटी बजने से बचने के लिए ग्रुप को म्यूट करें।",
                "सतत वाजणारा आवाज थांबवण्यासाठी ग्रुप म्यूट करा.");

        insertStep(conn, l11, 3, "Beware of 'Forwarded Many Times' Rumors", "फॉरवर्ड की गई अफवाहों से सावधान", "फारवर्ड केलेल्या अफवांपासून सावध राहा",
                "If a message says: 'Send to 10 people or bad luck happens / get free recharge', IT IS FAKE. Do NOT forward it.",
                "यदि कोई कहे कि '10 लोगों को भेजो तो मुफ्त रिचार्ज मिलेगा या चमत्कार होगा', तो यह झूठा है। इसे आगे न भेजें।",
                "जर मेसेजमध्ये '१० जणांना पाठवा आणि फ्री रिचार्ज मिळवा' असे असेल, तर ती अफवा आहे. पुढे पाठवू नका.",
                "WARNING_BOX", "FAKE_FORWARD",
                "Do not forward chain messages claiming free recharges or good luck.",
                "मुफ्त रिचार्ज या अंधविश्वास वाले झूठे संदेशों को आगे न भेजें।",
                "मोफत रिचार्ज किंवा अंधश्रद्धा पसरवणारे मेसेज पुढे पाठवू नका.");

        insertStep(conn, l11, 4, "Exiting an Unwanted Group", "अनचाहे ग्रुप से बाहर निकलना", "नको असलेल्या ग्रुपमधून बाहेर पडणे",
                "To leave any group, tap the group name at top, scroll down, and tap the red 'Exit Group'.",
                "किसी भी ग्रुप से बाहर निकलने के लिए ऊपर ग्रुप के नाम पर टैप करें, नीचे जाकर लाल 'Exit Group' दबाएं।",
                "ग्रुपमधून बाहेर पडण्यासाठी वर ग्रुपच्या नावावर दाबा, खाली जाऊन लाल रंगात असलेले 'Exit Group' दाबा.",
                "WHATSAPP_UI", "EXIT_GROUP",
                "Tap Exit Group to leave any group you no longer wish to be in.",
                "ग्रुप छोड़ने के लिए एग्जिट ग्रुप पर टैप करें।",
                "ग्रुप सोडण्यासाठी एक्झिट ग्रुपवर दाबा.");

        insertQuiz(conn, l11, "If a message claims: 'Government is giving ₹5000 to all seniors, forward to 20 friends to claim', what should you do?",
                "अगर संदेश आए कि 'सरकार सभी वरिष्ठ नागरिकों को ₹5000 दे रही है, 20 लोगों को भेजें', तो क्या करना चाहिए?",
                "जर मेसेज आला की 'सरकार वृद्धांना ५००० रुपये देत आहे, २० जणांना पाठवा', तर काय करावे?",
                "This is a classic fake forward scam. Never forward unverified rumors.",
                "यह पूरी तरह फर्जी और झूठी अफवाह है। इसे किसी को न भेजें और मिटा दें।",
                "ही खोटी अफवा आहे. हा मेसेज कोणालाही पाठवू नये आणि डिलीट करावा.",
                new String[]{"Forward it to 50 people quickly", "Ignore and delete it; it is a fake rumor", "Send your bank details", "Go to the police station immediately"},
                new String[]{"जल्दी से 50 लोगों को भेजें", "इसे नजरअंदाज करें और मिटा दें; यह झूठी अफवाह है", "अपने बैंक की जानकारी भेजें", "तुरंत थाने दौड़ें"},
                new String[]{"५० जणांना लगेच पाठवा", "दुर्लक्ष करून डिलीट करा; ही खोटी अफवा आहे", "बँकेची माहिती पाठवा", "पोलीस ठाण्यात जा"}, 1);

        insertQuiz(conn, l11, "How can you silence a noisy family group without leaving it?",
                "ग्रुप छोड़े बिना उसकी बार-बार बजने वाली घंटी कैसे बंद की जाती है?",
                "ग्रुपमधून बाहेर न पडता सतत येणारा आवाज कसा बंद करावा?",
                "Selecting 'Mute notifications' silences incoming message sounds quietly.",
                "'Mute notifications' चुनने से ग्रुप के मैसेज बिना आवाज़ किए शांति से आते हैं।",
                "'Mute notifications' निवडल्याने मेसेजचा आवाज येत नाही.",
                new String[]{"Throw the phone in water", "Select 'Mute notifications' in the group menu", "Uninstall WhatsApp", "Block your children"},
                new String[]{"फोन को पानी में डालें", "ग्रुप मेनू से 'Mute notifications' चुनें", "व्हाट्सएप हटा दें", "बच्चों को ब्लॉक करें"},
                new String[]{"फोन पाण्यात टाका", "ग्रुप मेनूमधून 'Mute notifications' निवडा", "व्हॉट्सअॅप काढून टाका", "मुलांना ब्लॉक करा"}, 1);

        insertQuiz(conn, l11, "Can you leave a group if strangers or unwanted people add you?",
                "अगर कोई अनजान व्यक्ति आपको किसी ग्रुप में जोड़ दे, तो क्या आप बाहर निकल सकते हैं?",
                "अनोळखी व्यक्तीने ग्रुपमध्ये जोडल्यास बाहेर पडता येते का?",
                "Yes, you have full control to tap 'Exit Group' anytime.",
                "हां, आप कभी भी 'Exit Group' दबाकर अपनी मर्जी से बाहर निकल सकते हैं।",
                "होय, तुम्ही कधीही 'Exit Group' दाबून ग्रुप सोडू शकता.",
                new String[]{"No, you are trapped forever", "Yes, scroll down in group info and tap 'Exit Group'", "Only if the group admin agrees", "Only after paying a fee"},
                new String[]{"नहीं, आप हमेशा के लिए फंस गए हैं", "हां, ग्रुप जानकारी में नीचे जाकर 'Exit Group' दबाएं", "एडमिन की मर्जी पर", "पैसे देने के बाद"},
                new String[]{"नाही, कायमचे अडकलात", "होय, खाली जाऊन 'Exit Group' दाबा", "फक्त अॅडमिनने हो म्हटल्यावर", "पैसे भरल्यावर"}, 1);
    }

    private static void seedAchievements(Connection conn) throws Exception {
        insertAchievement(conn, 1, "FIRST_LESSON", "First Steps", "Completed your very first digital lesson!", "🌟", "LESSON_COUNT", 1);
        insertAchievement(conn, 2, "WHATSAPP_STAR", "WhatsApp Explorer", "Learned how to connect with family on WhatsApp", "💬", "CATEGORY_COMPLETE", 3);
        insertAchievement(conn, 3, "SAFETY_HERO", "Safety Champion", "Mastered the Golden Rules of digital safety", "🛡️", "SAFETY_CHECK", 1);
        insertAchievement(conn, 4, "UPI_SMART", "Digital Money Smart", "Practiced UPI payments safely without real money", "💳", "PRACTICE", 1);
        insertAchievement(conn, 5, "QUIZ_MASTER", "Quiz Champion", "Scored 100% on a digital literacy quiz", "🎯", "PERFECT_QUIZ", 1);
        insertAchievement(conn, 6, "TEN_LESSONS", "Tech Champion", "Completed 10 digital tutor lessons!", "🏆", "LESSON_COUNT", 10);
        insertAchievement(conn, 7, "MAPS_NAVIGATOR", "City Navigator", "Learned to find nearby hospitals and directions", "🗺️", "PRACTICE", 2);
        insertAchievement(conn, 8, "STREAK_3", "Daily Learner", "Practiced learning 3 days in a row!", "🔥", "STREAK", 3);
    }

    private static void seedDemoProgress(Connection conn) throws Exception {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT OR IGNORE INTO user_progress (user_id, lesson_id, is_completed, last_step, quiz_score, quiz_passed, completed_at) VALUES (1, 1, 1, 4, 100, 1, CURRENT_TIMESTAMP)")) {
            ps.executeUpdate();
        }
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT OR IGNORE INTO user_achievements (user_id, achievement_id) VALUES (1, 1)")) {
            ps.executeUpdate();
        }
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT OR IGNORE INTO user_progress (user_id, lesson_id, is_completed, last_step, quiz_score, quiz_passed) VALUES (1, 8, 0, 2, 0, 0)")) {
            ps.executeUpdate();
        }
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT OR IGNORE INTO recommendations (senior_user_id, helper_user_id, lesson_id, note, is_completed) VALUES (1, 2, 21, 'Maa, please review this lesson before shopping this evening!', 0)")) {
            ps.executeUpdate();
        }
    }
}
