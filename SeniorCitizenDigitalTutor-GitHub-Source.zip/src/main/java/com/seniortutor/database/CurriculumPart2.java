package com.seniortutor.database;

import java.sql.Connection;

/**
 * Seeds Categories 4 to 8 (Lessons 12 to 27) with 3-5 quiz questions, explanations,
 * recaps, and English/Hindi/Marathi translations.
 */
public class CurriculumPart2 {

    public static void seed(Connection conn) throws Exception {
        seedCat4Camera(conn);
        seedCat5Internet(conn);
        seedCat6Maps(conn);
        seedCat7Payments(conn);
        seedCat8Banking(conn);
    }

    // ==========================================
    // CAT 4: CAMERA & PHOTOS (Lessons 12 - 14)
    // ==========================================
    private static void seedCat4Camera(Connection conn) throws Exception {
        // L12: Taking Clear Photos & Selfies
        int l12 = DatabaseSeeder.insertLesson(conn, 12, 4, "Taking Clear Photos & Selfies", "साफ तस्वीरें और सेल्फी खींचना", "स्पष्ट फोटो आणि सेल्फी काढणे",
                "Capture memories of family, flowers, and festivals without blurry shakes.",
                "बिना हिले परिवार और त्योहारों की खूबसूरत और साफ तस्वीरें खींचना सीखें।",
                "हात न हलवता कुटुंब आणि सणांचे सुंदर आणि स्पष्ट फोटो काढणे शिका.",
                "BEGINNER", 4, "NONE", 1,
                "• Hold phone firmly with both hands.\n• Tap on the person's face to focus.\n• Gently press the big white shutter circle.\n• Tap flip icon for selfie.",
                "• दोनों हाथों से फोन को सीधा और स्थिर पकड़ें।\n• चेहरे पर टैप करके फोकस सेट करें।\n• सफेद शटर बटन को धीरे से दबाएं।\n• सेल्फी के लिए कैमरा घुमाने वाला निशान छुएं।",
                "• दोन्ही हातांनी फोन स्थिर धरा.\n• चेहऱ्यावर बोट ठेवून फोकस करा.\n• पांढरे शटर बटण हळूच दाबा.\n• सेल्फीसाठी कॅमेरा फिरवण्याचे चिन्ह दाबा.");

        DatabaseSeeder.insertStep(conn, l12, 1, "Open the Camera App", "कैमरा ऐप खोलें", "कॅमेरा अॅप उघडा",
                "Find the app icon with a camera lens on your home screen and tap it.",
                "होम स्क्रीन पर कैमरा लेंस वाले ऐप को छूकर खोलें।",
                "स्क्रीनवरील कॅमेऱ्याच्या चिन्हावर दाबून कॅमेरा उघडा.",
                "PHONE_UI", "CAMERA_ICON",
                "Open the camera app on your phone.",
                "अपने फोन का कैमरा ऐप खोलें।",
                "फोनमधील कॅमेरा अॅप उघडा.");

        DatabaseSeeder.insertStep(conn, l12, 2, "Hold Steady with Both Hands", "दोनों हाथों से फोन स्थिर पकड़ें", "दोन्ही हातांनी फोन स्थिर धरा",
                "Grip the phone with both hands. Tap on the person's face on the screen to focus and make it sharp.",
                "फोन को दोनों हाथों से पकड़ें ताकि वह हिले नहीं। स्क्रीन पर सामने वाले के चेहरे पर टैप करके फोकस करें।",
                "फोन हलणार नाही याची काळजी घ्या. स्क्रीनवर व्यक्तीच्या चेहऱ्यावर दाबून फोकस करा.",
                "PHONE_UI", "CAMERA_PREVIEW",
                "Hold the phone steady with both hands and tap to focus.",
                "दोनों हाथों से फोन को थामें और फोकस के लिए टैप करें।",
                "दोन्ही हातांनी फोन स्थिर धरा आणि फोकस करा.");

        DatabaseSeeder.insertStep(conn, l12, 3, "Gently Tap the White Shutter Circle", "सफेद गोल शटर बटन दबाएं", "पांढऱ्या गोल शटरवर दाबा",
                "Tap the large white circle at the bottom. You will hear a pleasant camera click sound. Photo taken!",
                "नीचे बने बड़े सफेद गोल बटन को हल्का सा छुएं। कैमरे की क्लिक आवाज आएगी और फोटो खिंच जाएगी!",
                "खालच्या मोठ्या पांढऱ्या गोलावर हलकेच दाबा. क्लिक आवाज येईल आणि फोटो निघेल!",
                "PHONE_UI", "SHUTTER_BUTTON",
                "Tap the white circle at the bottom to snap the picture.",
                "तस्वीर खींचने के लिए सफेद गोले पर टैप करें।",
                "फोटो काढण्यासाठी पांढऱ्या गोलावर दाबा.");

        DatabaseSeeder.insertStep(conn, l12, 4, "Switch to Front Camera for a Selfie", "सेल्फी के लिए कैमरा घुमाएं", "सेल्फीसाठी कॅमेरा फिरवा",
                "Tap the two-arrow circle icon near the shutter to turn the camera towards your face for a selfie with grandchildren.",
                "शटर बटन के पास दो तीरों वाले गोल निशान को छुएं। कैमरा आपकी तरफ घूम जाएगा और आप पोते-पोतियों संग सेल्फी ले सकेंगे।",
                "शटरजवळ दोन बाण असलेल्या गोलावर दाबा. कॅमेरा तुमच्याकडे फिरेल आणि सेल्फी काढता येईल.",
                "PHONE_UI", "CAMERA_FLIP",
                "Tap the camera flip icon to take a selfie.",
                "सेल्फी लेने के लिए कैमरा घुमाने वाले आइकन पर टैप करें।",
                "सेल्फी काढण्यासाठी कॅमेरा फिरवण्याच्या चिन्हावर दाबा.");

        DatabaseSeeder.insertQuiz(conn, l12, "What is the best way to prevent blurry, hazy photos?",
                "तस्वीरों को धुंधला होने से बचाने का सबसे सही तरीका क्या है?",
                "फोटो अंधुक न येण्यासाठी काय करावे?",
                "Holding the phone firmly with both hands prevents handshake vibrations.",
                "फोन को दोनों हाथों से मजबूती से थामने से कंपन नहीं होता और तस्वीर साफ आती है।",
                "दोन्ही हातांनी फोन स्थिर धरल्याने हात हालत नाही आणि फोटो स्पष्ट येतो.",
                new String[]{"Running while pressing the shutter", "Holding phone steady with both hands and tapping face to focus", "Closing your eyes", "Blowing air on lens"},
                new String[]{"दौड़ते हुए शटर दबाना", "दोनों हाथों से फोन स्थिर पकड़ना और चेहरे पर फोकस करना", "आंखें बंद कर लेना", "लेंस पर फूंक मारना"},
                new String[]{"धावत असताना फोटो काढणे", "दोन्ही हातांनी फोन स्थिर धरून फोकस करणे", "डोळे झाकून घेणे", "लेन्सवर फुंकर मारणे"}, 1);

        DatabaseSeeder.insertQuiz(conn, l12, "What icon switches between the back camera and the selfie front camera?",
                "पीछे के कैमरे और सामने के सेल्फी कैमरे को बदलने के लिए कौन सा निशान दबाते हैं?",
                "पुढचा आणि मागचा कॅमेरा बदलण्यासाठी कोणते चिन्ह असते?",
                "The circular double arrows icon flips the camera.",
                "दो तीरों वाला गोल निशान कैमरा घुमाने का काम करता है।",
                "दोन बाणांचे गोलाकार चिन्ह कॅमेरा फिरवण्याचे काम करते.",
                new String[]{"A trash can", "Circular rotating arrows 🔄", "A musical note", "A battery icon"},
                new String[]{"कचरे का डिब्बा", "घूमते हुए दो तीरों का निशान 🔄", "संगीत का सुर", "बैटरी का निशान"},
                new String[]{"कचऱ्याचा डबा", "गोल फिरणारे बाण 🔄", "गाण्याचे चिन्ह", "बॅटरीचे चिन्ह"}, 1);

        DatabaseSeeder.insertQuiz(conn, l12, "Where can you immediately preview the photo you just captured?",
                "अभी-अभी खींची गई तस्वीर को तुरंत देखने के लिए कहां टैप किया जाता है?",
                "नुकताच काढलेला फोटो लगेच पाहण्यासाठी कुठे दाबावे?",
                "A small square thumbnail of the photo appears right next to the shutter button.",
                "शटर बटन के ठीक कोने में एक छोटा सा फोटो चौकोर दिखता है, उसे छूकर देखें।",
                "शटर बटणाच्या कोपऱ्यात लहान चौकोनी फोटो दिसतो, त्यावर दाबून पहावे.",
                new String[]{"In the settings menu", "In the small circular thumbnail next to the shutter button", "In the phone dialer", "On the back cover"},
                new String[]{"सेटिंग्स मेनू में", "शटर बटन के पास बने छोटे गोल थंबनेल पर", "फोन डायलर में", "पीछे के ढक्कन पर"},
                new String[]{"सेटिंग्जमध्ये", "शटर बटणाजवळ असलेल्या लहान फोटोवर", "फोन डायलरमध्ये", "मागच्या कव्हरवर"}, 1);

        // L13: Viewing Photos in Gallery & Zooming
        int l13 = DatabaseSeeder.insertLesson(conn, 13, 4, "Viewing Photos in Gallery & Zooming", "गैलरी में फोटो देखना और बड़ा करना", "गॅलरीमध्ये फोटो पाहणे आणि मोठे करणे",
                "Browse through happy moments and pinch the screen to zoom into grandchild faces.",
                "पुरानी यादें देखना और उंगलियों से स्क्रीन फैलाकर चेहरे को बड़ा करके देखना सीखें।",
                "जुन्या आठवणी पाहणे आणि बोटे पसरवून स्क्रीनवरील फोटो मोठा करून पाहणे शिका.",
                "BEGINNER", 4, "NONE", 2,
                "• Open 'Gallery' or 'Photos' app.\n• Swipe left or right to flip between photos.\n• Pinch outward with two fingers to zoom in.\n• Double-tap screen to return to normal size.",
                "• 'Gallery' या 'Photos' ऐप खोलें।\n• फोटो बदलने के लिए दाएं-बाएं स्वाइप करें।\n• बड़ा करने के लिए दो उंगलियों को स्क्रीन पर फैलाएं।\n• सामान्य आकार के लिए स्क्रीन पर दो बार टैप करें।",
                "• 'Gallery' किंवा 'Photos' अॅप उघडा.\n• फोटो बदलण्यासाठी डावीकडे-उजवीकडे सरकवा.\n• झूम करण्यासाठी दोन बोटे स्क्रीनवर पसरा.\n• मूळ आकारात येण्यासाठी दोनदा दाबा.");

        DatabaseSeeder.insertStep(conn, l13, 1, "Open the Gallery or Photos App", "गैलरी ऐप खोलें", "गॅलरी अॅप उघडा",
                "Tap the colorful pinwheel 'Photos' or flower 'Gallery' icon on your screen.",
                "अपनी स्क्रीन पर रंग-बिरंगी फिरकी या फूल वाले 'Gallery' ऐप को छुएं।",
                "स्क्रीनवरील फुलासारख्या किंवा फिरकीसारख्या 'Gallery' चिन्हावर दाबा.",
                "PHONE_UI", "GALLERY_ICON",
                "Tap the Gallery app to see all your saved photos.",
                "अपनी सभी तस्वीरें देखने के लिए गैलरी ऐप खोलें।",
                "सर्व फोटो पाहण्यासाठी गॅलरी अॅप उघडा.");

        DatabaseSeeder.insertStep(conn, l13, 2, "Swipe Left and Right to Flip", "दाएं-बाएं सरकाकर फोटो बदलें", "डावी-उजवीकडे सरकवून फोटो पहा",
                "Tap on any photo to open it. Slide your finger left or right across the screen to see the next and previous photos.",
                "किसी भी फोटो को खोलें। अगली तस्वीर देखने के लिए उंगली को बाईं या दाईं तरफ सरकाएं।",
                "फोटो उघडा. पुढील किंवा मागील फोटो पाहण्यासाठी बोट डावीकडे किंवा उजवीकडे सरकवा.",
                "PHONE_UI", "SWIPE_PHOTO",
                "Swipe horizontally to browse through your pictures.",
                "तस्वीरें देखने के लिए उंगली को दाएं-बाएं सरकाएं।",
                "फोटो पाहण्यासाठी डावीकडे किंवा उजवीकडे बोट फिरवा.");

        DatabaseSeeder.insertStep(conn, l13, 3, "Pinch Outward with Two Fingers to Zoom", "दो उंगलियों से ज़ूम करें", "दोन बोटांनी झूम करा",
                "Place your thumb and index finger close together on the screen, then spread them apart to zoom into details.",
                "स्क्रीन पर अंगूठा और उंगली रखकर उन्हें बाहर की तरफ फैलाएं। तस्वीर बड़ी होकर बारीक चेहरे साफ दिखेंगे।",
                "दोन बोटे स्क्रीनवर ठेवून ती एकमेकांपासून लांब करा. फोटो मोठा होऊन बारीक गोष्टी स्पष्ट दिसतील.",
                "PHONE_UI", "PINCH_ZOOM",
                "Spread two fingers apart on the screen to zoom into any detail.",
                "फोटो को बड़ा करने के लिए दो उंगलियों को फैलाएं।",
                "फोटो मोठा करण्यासाठी दोन बोटे बाहेरच्या दिशेने पसरवा.");

        DatabaseSeeder.insertStep(conn, l13, 4, "Double Tap to Reset", "दो बार टैप करके सामान्य करें", "दोनदा दाबून पूर्ववत करा",
                "Quickly tap the photo twice with one finger to reset it smoothly back to normal full-screen view.",
                "एक उंगली से फोटो पर दो बार हल्का सा टैप करें। फोटो वापस सामान्य आकार में आ जाएगी।",
                "एका बोटाने फोटोवर दोनदा हलकेच दाबा. फोटो पुन्हा मूळ आकाराचा होईल.",
                "PHONE_UI", "DOUBLE_TAP",
                "Double-tap the screen to reset zoom back to normal.",
                "सामान्य आकार में लौटने के लिए दो बार टैप करें।",
                "मूळ आकारात येण्यासाठी दोनदा दाबा.");

        DatabaseSeeder.insertQuiz(conn, l13, "How do you zoom in on a small detail or face in a photo?",
                "फोटो में किसी चेहरे या छोटे अक्षर को बड़ा करके देखने के लिए क्या किया जाता है?",
                "फोटोमधील लहान अक्षर किंवा चेहरा मोठा करून पाहण्यासाठी काय करावे?",
                "Pinching two fingers outward spreads and enlarges the image smoothly.",
                "स्क्रीन पर दो उंगलियों को रखकर बाहर की ओर फैलाने (पिंच ज़ूम) से फोटो बड़ी होती है।",
                "स्क्रीनवर दोन बोटे ठेवून ती बाहेर पसरवल्याने फोटो मोठा होतो.",
                new String[]{"Blow on the phone", "Spread two fingers apart on the screen (pinch-to-zoom)", "Shake the phone hard", "Turn off the screen"},
                new String[]{"फोन पर फूंक मारना", "दो उंगलियों को स्क्रीन पर बाहर फैलाना (पिंच ज़ूम)", "फोन को जोर से हिलाना", "स्क्रीन बंद करना"},
                new String[]{"फुंकर मारणे", "स्क्रीनवर दोन बोटे बाहेर पसरवणे (झूम करणे)", "फोन जोरात हलवणे", "स्क्रीन बंद करणे"}, 1);

        DatabaseSeeder.insertQuiz(conn, l13, "How do you browse to the next picture in the gallery?",
                "गैलरी में अगली तस्वीर देखने के लिए क्या करते हैं?",
                "गॅलरीमध्ये पुढचा फोटो पाहण्यासाठी काय करावे?",
                "Swiping horizontally left across the screen flips to the next photograph.",
                "स्क्रीन पर उंगली को बाईं तरफ सरकाने से अगली फोटो सामने आती है।",
                "स्क्रीनवर बोट डावीकडे सरकवल्यास पुढचा फोटो येतो.",
                new String[]{"Press the power button 10 times", "Swipe horizontally across the screen", "Take a new selfie", "Restart the phone"},
                new String[]{"पावर बटन 10 बार दबाना", "स्क्रीन पर उंगली को बाएं या दाएं सरकाना", "नई सेल्फी खींचना", "फोन रीस्टार्ट करना"},
                new String[]{"पॉवर बटण १० वेळा दाबणे", "स्क्रीनवर आडवे बोट सरकवणे", "नवीन सेल्फी काढणे", "फोन रीस्टार्ट करणे"}, 1);

        DatabaseSeeder.insertQuiz(conn, l13, "What happens if you accidentally delete a photo in Google Photos?",
                "यदि आपसे गलती से कोई फोटो डिलीट हो जाए, तो क्या वह हमेशा के लिए खो जाती है?",
                "गुगल फोटोजमधून चुकून फोटो डिलीट झाल्यास तो कायमचा जातो का?",
                "Deleted photos stay safely in the 'Trash' folder for 30 to 60 days and can be restored.",
                "डिलीट की गई फोटो 30-60 दिनों तक 'Trash' में सुरक्षित रहती है और वापस लाई जा सकती है।",
                "डिलीट झालेले फोटो ३०-६० दिवस 'Trash' मध्ये सुरक्षित राहतात आणि परत मिळवता येतात.",
                new String[]{"It is destroyed forever immediately", "It stays in the 'Trash / Bin' folder and can easily be restored", "The phone stops working", "You must buy a new camera"},
                new String[]{"वह तुरंत नष्ट हो जाती है", "वह 'Trash (कचरा)' में सुरक्षित रहती है और वापस लाई जा सकती है", "फोन चलना बंद हो जाता है", "नया कैमरा लेना पड़ेगा"},
                new String[]{"लगेच कायमचा नष्ट होतो", "तो 'Trash' मध्ये सुरक्षित राहतो आणि परत मिळवता येतो", "फोन बंद पडतो", "नवीन कॅमेरा घ्यावा लागतो"}, 1);

        // L14: Sharing Photos to Family Safely
        int l14 = DatabaseSeeder.insertLesson(conn, 14, 4, "Sharing Photos to Family Safely", "परिवार को सुरक्षित फोटो भेजना", "कुटुंबाला सुरक्षित फोटो पाठवणे",
                "Send pictures directly from Gallery to WhatsApp without losing photo quality.",
                "गैलरी से सीधे व्हाट्सएप पर बच्चों को तस्वीरें भेजना और गैर-जरूरी फोटो मिटाना सीखें।",
                "गॅलरीमधून थेट व्हॉट्सअॅपवर फोटो पाठवणे आणि नको असलेले फोटो काढून जागा मोकळी करणे शिका.",
                "BEGINNER", 4, "NONE", 3,
                "• Open photo in Gallery and tap 'Share' icon (< with dots).\n• Choose WhatsApp and pick the contact.\n• Tap Send.\n• Delete blurry photos periodically to keep phone storage clean.",
                "• गैलरी में फोटो खोलकर 'Share' (तीन जुड़े बिंदु) का निशान छुएं।\n• व्हाट्सएप चुनकर संपर्क पर टैप करें।\n• सेंड तीर दबाएं।\n• फोन की जगह खाली रखने के लिए धुंधली फोटो समय-समय पर डिलीट करें।",
                "• गॅलरीमध्ये फोटो उघडून 'Share' (तीन जोडलेले ठिपके) दाबा.\n• व्हॉट्सअॅप निवडून व्यक्तीच्या नावावर दाबा.\n• पाठवा.\n• फोनची मेमरी मोकळी ठेवण्यासाठी अंधुक फोटो वेळोवेळी डिलीट करा.");

        DatabaseSeeder.insertStep(conn, l14, 1, "Open the Photo and Tap 'Share'", "फोटो खोलकर 'Share' आइकन छुएं", "फोटो उघडून 'Share' चिन्हावर दाबा",
                "Look at the bottom of the photo. Tap the icon that looks like three connected dots or a box with an arrow (<).",
                "फोटो के नीचे देखें। तीन जुड़े हुए बिंदुओं या तीर वाले निशान (Share) पर टैप करें।",
                "फोटोच्या खाली असलेल्या तीन जोडलेल्या ठिपक्यांच्या किंवा बाणाच्या चिन्हावर (Share) दाबा.",
                "PHONE_UI", "SHARE_ICON",
                "Tap the Share icon at the bottom of the photo.",
                "फोटो के नीचे शेयर के निशान पर टैप करें।",
                "फोटोच्या खाली असलेल्या शेअर चिन्हावर दाबा.");

        DatabaseSeeder.insertStep(conn, l14, 2, "Choose 'WhatsApp' from App List", "ऐप्स में से 'WhatsApp' चुनें", "अॅप्समधून 'WhatsApp' निवडा",
                "A panel of apps appears. Tap the green WhatsApp icon to send via WhatsApp.",
                "कई ऐप्स की सूची आएगी। फोटो भेजने के लिए हरे व्हाट्सएप आइकन पर टैप करें।",
                "अॅप्सची यादी येईल. फोटो पाठवण्यासाठी हिरव्या व्हॉट्सअॅप चिन्हावर दाबा.",
                "PHONE_UI", "SHARE_SHEET",
                "Select WhatsApp from the list of sharing apps.",
                "शेयर करने के लिए व्हाट्सएप का चयन करें।",
                "शेअर करण्यासाठी व्हॉट्सअॅप निवडा.");

        DatabaseSeeder.insertStep(conn, l14, 3, "Select Your Child or Friend", "बेटे, बेटी या मित्र का नाम चुनें", "मुलगा, मुलगी किंवा मित्राचे नाव निवडा",
                "WhatsApp opens. Tap the circle next to your child's name, then tap the green arrow at bottom right.",
                "व्हाट्सएप खुलेगा। जिसे भेजना है उनके नाम पर टैप करें, फिर नीचे बने हरे तीर को दबाएं।",
                "व्हॉट्सअॅप उघडेल. ज्यांना पाठवायचा आहे त्यांच्या नावावर दाबा आणि खालील हिरव्या बाणावर दाबा.",
                "WHATSAPP_UI", "SELECT_CONTACT",
                "Tap on your contact and press the green send button.",
                "संपर्क चुनकर हरा सेंड बटन दबाएं।",
                "नाव निवडून हिरवे बटण दाबा.");

        DatabaseSeeder.insertStep(conn, l14, 4, "Deleting Blurry Unneeded Photos", "धुंधली और फालतू फोटो मिटाएं", "अंधुक फोटो डिलीट करून जागा वाचवा",
                "To free up memory, tap the Trash Can icon on any bad photo, then tap 'Delete'. Keeps your phone running fast!",
                "फोन में जगह बनाए रखने के लिए खराब फोटो पर कचरे के डिब्बे (Trash) का निशान दबाकर 'Delete' करें।",
                "फोन रिकामा ठेवण्यासाठी खराब फोटोवर कचऱ्याच्या डब्याचे (Trash) चिन्ह दाबून 'Delete' करा.",
                "PHONE_UI", "DELETE_PHOTO",
                "Delete duplicate or blurry photos to keep your phone storage free.",
                "फोन में जगह खाली रखने के लिए खराब तस्वीरें डिलीट करें।",
                "फोन सुरळीत चालण्यासाठी अनावश्यक फोटो काढून टाका.");

        DatabaseSeeder.insertQuiz(conn, l14, "What universal symbol represents 'Share' across Android smartphones?",
                "एंड्रॉयड फोन में फोटो या फाइल भेजने (Share) के लिए कौन सा चिन्ह बना होता है?",
                "अँड्रॉइड फोनमध्ये फोटो पाठवण्यासाठी (Share) कोणते चिन्ह असते?",
                "Three connected dots with lines (<) or a box with an arrow represents the Share command.",
                "तीन आपस में जुड़े हुए बिंदु (<) शेयर करने का वैश्विक चिन्ह हैं।",
                "तीन जोडलेले ठिपके (<) हे शेअर करण्याचे मुख्य चिन्ह आहे.",
                new String[]{"A keyhole", "Three connected dots (<) or arrow", "A snowflake", "A dollar symbol"},
                new String[]{"चाबी का छेद", "तीन जुड़े हुए बिंदु (<) या तीर", "बर्फ का टुकड़ा", "डॉलर का निशान"},
                new String[]{"किल्लीचे छिद्र", "तीन जोडलेले ठिपके (<) किंवा बाण", "बर्फाचा तुकडा", "डॉलरचे चिन्ह"}, 1);

        DatabaseSeeder.insertQuiz(conn, l14, "Why is it healthy to delete blurry or duplicate festival photos occasionally?",
                "धुंधली या एक जैसी कई तस्वीरों को समय-समय पर हटाना क्यों फायदेमंद होता है?",
                "अंधुक किंवा एकाच प्रकारच्या अनेक फोटो डिलीट करणे का चांगले असते?",
                "Deleting junk photos frees up storage and prevents the phone from lagging.",
                "फालतू फोटो हटाने से फोन की मेमोरी खाली रहती है और फोन कभी अटकता नहीं है।",
                "अनावश्यक फोटो काढल्याने फोनची जागा मोकळी राहते आणि फोन हळू चालत नाही.",
                new String[]{"It increases the monthly electricity bill", "It frees up storage space and keeps your phone running smoothly", "It locks the screen permanently", "It makes the camera black and white"},
                new String[]{"बिजली का बिल बढ़ता है", "मेमोरी खाली होती है और फोन तेजी से काम करता है", "स्क्रीन हमेशा के लिए बंद हो जाती है", "कैमरा काला-सफेद हो जाता है"},
                new String[]{"वीज बिल वाढते", "जागा मोकळी होते आणि फोन सुरळीत चालतो", "स्क्रीन कायमची बंद होते", "कॅमेरा काळा-पांढरा होतो"}, 1);

        DatabaseSeeder.insertQuiz(conn, l14, "Can you share multiple photos together at the same time to a WhatsApp contact?",
                "क्या आप व्हाट्सएप पर एक साथ 4-5 तस्वीरें चुनकर भेज सकते हैं?",
                "व्हॉट्सअॅपवर एकाच वेळी अनेक फोटो एकत्र पाठवता येतात का?",
                "Yes, long-pressing the first photo lets you select several more with checkmarks.",
                "हां, पहली फोटो को दबाकर रखने से कई फोटो एक साथ चुनी जा सकती हैं।",
                "होय, पहिल्या फोटोवर दाबून धरल्यास इतरही फोटो एकत्र निवडता येतात.",
                new String[]{"No, only one photo per year", "Yes, you can select multiple photos and send them together", "Only with government permission", "Only in the morning"},
                new String[]{"नहीं, साल में सिर्फ एक फोटो", "हां, एक साथ कई फोटो चुनकर भेजी जा सकती हैं", "केवल सरकारी अनुमति से", "केवल सुबह के समय"},
                new String[]{"नाही, वर्षातून एकच फोटो", "होय, अनेक फोटो एकत्र निवडून पाठवता येतात", "फक्त सरकारी परवानगीने", "फक्त सकाळी"}, 1);
    }

    // ==========================================
    // CAT 5: INTERNET & ENTERTAINMENT (Lessons 15 - 17)
    // ==========================================
    private static void seedCat5Internet(Connection conn) throws Exception {
        // L15: Voice Search on Google
        int l15 = DatabaseSeeder.insertLesson(conn, 15, 5, "Voice Search on Google", "गूगल पर बोलकर खोजना", "गुगलवर बोलून शोधणे",
                "Find bhajan lyrics, health tips, train timings, and weather without typing a single word.",
                "बिना टाइप किए सिर्फ बोलकर भजन, मौसम, ट्रेन समय और घरेलू नुस्खे खोजें।",
                "काहीही टाईप न करता फक्त बोलून भजन, हवामान, रेल्वे वेळ आणि आरोग्यविषयक माहिती शोधा.",
                "BEGINNER", 4, "NONE", 1,
                "• Open Google or Chrome app.\n• Tap the colorful microphone icon in search bar.\n• Speak clearly in Hindi, Marathi, or English.\n• Read top reliable results.",
                "• गूगल या क्रोम ऐप खोलें।\n• सर्च बार में रंग-बिरंगे माइक पर टैप करें।\n• हिंदी, मराठी या अंग्रेजी में साफ-साफ बोलें।\n• ऊपर आए भरोसेमंद जवाब पढ़ें।",
                "• गुगल किंवा क्रोम अॅप उघडा.\n• सर्च पट्टीतील रंगीत माइकवर दाबा.\n• मराठी, हिंदी किंवा इंग्रजीत स्पष्ट बोला.\n• आलेली खात्रीशीर उत्तरे वाचा.");

        DatabaseSeeder.insertStep(conn, l15, 1, "Open Google or Chrome", "गूगल या क्रोम खोलें", "गुगल किंवा क्रोम उघडा",
                "Tap the colorful 'G' or Chrome circle icon on your home screen.",
                "अपनी स्क्रीन पर रंगीन 'G' या क्रोम के गोल निशान को दबाकर खोलें।",
                "स्क्रीनवरील रंगीत 'G' किंवा क्रोमच्या चिन्हावर दाबा.",
                "PHONE_UI", "GOOGLE_ICON",
                "Open Google or Chrome on your phone.",
                "अपने फोन पर गूगल खोलें।",
                "फोनवर गुगल उघडा.");

        DatabaseSeeder.insertStep(conn, l15, 2, "Tap the Microphone in the Search Bar", "सर्च बार में बने माइक को छुएं", "सर्च पट्टीतील माइक चिन्हावर दाबा",
                "Look at the search box. On the right end, tap the colorful microphone icon.",
                "सर्च बार के दाईं तरफ देखें। वहां बने रंग-बिरंगे माइक के निशान पर टैप करें।",
                "सर्च पट्टीच्या उजव्या बाजूला असलेल्या रंगीत माइकवर दाबा.",
                "PHONE_UI", "VOICE_MIC",
                "Tap the microphone icon to begin speaking.",
                "बोलने के लिए माइक वाले निशान को छुएं।",
                "बोलण्यासाठी माइकच्या चिन्हावर दाबा.");

        DatabaseSeeder.insertStep(conn, l15, 3, "Speak Your Question Clearly", "साफ आवाज़ में अपना सवाल बोलें", "स्पष्ट आवाजात तुमचा प्रश्न विचारा",
                "Wait until you see 'Listening...'. Speak naturally, for example: 'Today weather in Pune' or 'Hanuman Chalisa lyrics'.",
                "स्क्रीन पर 'Listening...' आते ही बोलें, जैसे: 'आज पुणे का मौसम कैसा है' या 'शिव भजन सुनाओ'।",
                "'Listening...' दिसताच बोला, उदा. 'आजचे पुण्यातील हवामान' किंवा 'मनाचे श्लोक'.",
                "PHONE_UI", "SPEAK_PROMPT",
                "Speak your question naturally in your mother tongue.",
                "अपनी भाषा में स्वाभाविक रूप से सवाल पूछें।",
                "आपल्या भाषेत सहजपणे प्रश्न विचारा.");

        DatabaseSeeder.insertStep(conn, l15, 4, "Read or Listen to the Answer", "जवाब पढ़ें या सुनें", "उत्तर वाचा किंवा ऐका",
                "Google will show answers on screen and often speak the answer aloud to you!",
                "गूगल स्क्रीन पर उत्तर दिखाएगा और कई बार बोलकर भी आपको जवाब सुनाएगा!",
                "गुगल स्क्रीनवर माहिती दाखवेल आणि अनेकदा बोलून उत्तरही ऐकवेल!",
                "PHONE_UI", "SEARCH_RESULTS",
                "Google provides instant answers and reads aloud the summary.",
                "गूगल तुरंत उत्तर दिखाता है और पढ़कर सुनाता है।",
                "गुगल त्वरित उत्तर दाखवतो आणि वाचूनही दाखवतो.");

        DatabaseSeeder.insertQuiz(conn, l15, "Can you speak to Google in Hindi or Marathi instead of typing in English?",
                "क्या आप अंग्रेजी टाइप करने के बजाय हिंदी या मराठी में बोलकर गूगल से पूछ सकते हैं?",
                "इंग्रजीत टाईप न करता गुगलला मराठी किंवा हिंदीत बोलून विचारू शकता का?",
                "Yes! Google voice search supports Hindi, Marathi, and most Indian languages fluently.",
                "हां! गूगल वॉइस सर्च हिंदी, मराठी और भारतीय भाषाओं को बहुत अच्छी तरह समझता है।",
                "होय! गुगल व्हॉइस सर्च मराठी, हिंदी भाषा सहजपणे समजून घेते.",
                new String[]{"No, Google only knows English", "Yes, tap the microphone and speak in your comfortable language", "Only if you have a doctor's certificate", "Only on Saturday"},
                new String[]{"नहीं, गूगल केवल अंग्रेजी जानता है", "हां, माइक दबाकर अपनी पसंद की भाषा में बोल सकते हैं", "केवल डॉक्टर के पर्चे के साथ", "केवल शनिवार को"},
                new String[]{"नाही, गुगलला फक्त इंग्रजी येते", "होय, माइक दाबून आपल्या भाषेत बोलू शकता", "फक्त डॉक्टरांच्या दाखल्यावर", "फक्त शनिवारी"}, 1);

        DatabaseSeeder.insertQuiz(conn, l15, "What should you see on screen before you start speaking your search query?",
                "बोलना शुरू करने से पहले स्क्रीन पर क्या लिखा हुआ देखना चाहिए?",
                "बोलण्यास सुरुवात करण्यापूर्वी स्क्रीनवर काय दिसले पाहिजे?",
                "Wait until the prompt shows 'Listening...' or the sound wave moves.",
                "स्क्रीन पर 'Listening...' या आवाज़ की तरंगे बनने का इंतज़ार करें।",
                "स्क्रीनवर 'Listening...' किंवा आवाजाची लाट दिसण्याची वाट पहावी.",
                new String[]{"'Game Over'", "'Listening...' with moving sound waves", "'Battery Empty'", "'Call Ended'"},
                new String[]{"'Game Over'", "'Listening...' और आवाज़ की तरंगे", "'Battery Empty'", "'Call Ended'"},
                new String[]{"'Game Over'", "'Listening...' आणि आवाजाची लाट", "'Battery Empty'", "'Call Ended'"}, 1);

        DatabaseSeeder.insertQuiz(conn, l15, "What is a good practical example of using Google voice search for daily life?",
                "दैनिक जीवन में गूगल वॉइस सर्च का सबसे अच्छा उदाहरण क्या है?",
                "दैनंदिन जीवनात गुगल व्हॉइस सर्चचा उत्तम उपयोग कोणता?",
                "Asking for daily weather, train delays, or bhajan lyrics saves effort.",
                "मौसम की जानकारी, दवाइयों के घरेलू उपाय या भजन के बोल पूछना।",
                "हवामान, गाणी किंवा भजनाचे शब्द बोलून शोधणे.",
                new String[]{"Checking tomorrow's weather or bhajan lyrics", "Sending money without entering PIN", "Making coffee automatically", "Repairing a broken tap"},
                new String[]{"कल का मौसम या भजन के बोल खोजना", "बिना पिन डाले पैसे भेजना", "अपने आप चाय बनाना", "टूटा नल ठीक करना"},
                new String[]{"उद्याचे हवामान किंवा भजनाचे शब्द शोधणे", "पिन न टाकता पैसे पाठवणे", "आपोआप चहा बनवणे", "नळ दुरुस्त करणे"}, 0);

        // L16: Watching Bhajans & News on YouTube
        int l16 = DatabaseSeeder.insertLesson(conn, 16, 5, "Watching Bhajans & News on YouTube", "यूट्यूब पर भजन, आरती और समाचार देखना", "युट्यूबवर भजन, कीर्तन आणि बातम्या पाहणे",
                "Listen to morning prayers, old Kishore Kumar songs, and live news on a big clear screen.",
                "सुबह के भजन, पुराने गीत और लाइव समाचार घर बैठे आराम से देखना सीखें।",
                "सकाळची भजने, जुनी गाणी आणि ताज्या बातम्या घरबसल्या आरामात पाहणे शिका.",
                "BEGINNER", 5, "NONE", 2,
                "• Open the red YouTube app.\n• Tap search magnifying glass and type or speak your bhajan name.\n• Tap the video to play.\n• Tap square icon at bottom right of video for full-screen mode.",
                "• लाल यूट्यूब ऐप खोलें।\n• सर्च का निशान दबाकर बोलें: 'प्रभात फेरी भजन'।\n• वीडियो पर टैप करके चलाएं।\n• पूरी स्क्रीन पर बड़ा देखने के लिए वीडियो के कोने में चौकोर निशान छुएं।",
                "• लाल युट्यूब अॅप उघडा.\n• सर्चवर दाबून बोला: 'विठ्ठलाची भजने'.\n• व्हिडिओवर दाबा.\n• पूर्ण स्क्रीनवर मोठा पाहण्यासाठी व्हिडिओच्या कोपऱ्यातील चौकोनी चिन्हावर दाबा.");

        DatabaseSeeder.insertStep(conn, l16, 1, "Open the YouTube App", "यूट्यूब ऐप खोलें", "युट्यूब अॅप उघडा",
                "Look for the red rectangle with a white play triangle inside. Tap it.",
                "लाल रंग के चौकोर पर बने सफेद प्ले त्रिभुज वाले यूट्यूब ऐप को छुएं।",
                "पांढरा त्रिकोण असलेले लाल रंगाचे युट्यूब अॅप शोधा आणि उघडा.",
                "PHONE_UI", "YOUTUBE_ICON",
                "Open the YouTube application on your phone.",
                "अपने फोन पर यूट्यूब खोलें।",
                "फोनवर युट्यूब उघडा.");

        DatabaseSeeder.insertStep(conn, l16, 2, "Search for Bhajans or Old Songs", "भजन या पुराने गीत खोजें", "भजन किंवा जुनी गाणी शोधा",
                "Tap the magnifying glass at top right, tap the microphone, and say: 'Anup Jalota bhajan' or 'Lata Mangeshkar songs'.",
                "ऊपर सर्च आइकन दबाएं, माइक छुएं और बोलें: 'अनूप जलोटा के भजन' या 'लता मंगेशकर के पुराने गीत'।",
                "वरच्या सर्च चिन्हावर दाबा, माइक दाबून बोला: 'संत ज्ञानेश्वर कीर्तन' किंवा 'लतादीदींची गाणी'.",
                "PHONE_UI", "YOUTUBE_SEARCH",
                "Search your favorite prayers or musicians using the voice microphone.",
                "माइक से अपनी पसंद के भजन या गायक का नाम बोलें।",
                "माइकवरून आपल्या आवडीचे भजन किंवा गायकाचे नाव बोला.");

        DatabaseSeeder.insertStep(conn, l16, 3, "Tap Video to Play", "वीडियो चलाएं", "व्हिडिओ सुरू करा",
                "Tap on the video title or picture. The music begins immediately. Adjust side volume for pleasant sound.",
                "वीडियो की तस्वीर पर टैप करें। संगीत शुरू हो जाएगा। साइड के बटन से मनपसंद आवाज़ सेट करें।",
                "व्हिडिओच्या चित्रावर दाबा. गाणे लगेच सुरू होईल. बाजूच्या बटणाने आवाज योग्य ठेवा.",
                "PHONE_UI", "YOUTUBE_PLAYER",
                "Tap the video to start playback and adjust volume comfortably.",
                "वीडियो चलाने के लिए उस पर टैप करें और आवाज़ व्यवस्थित करें।",
                "व्हिडिओ सुरू करण्यासाठी दाबा आणि आवाज नीट ठेवा.");

        DatabaseSeeder.insertStep(conn, l16, 4, "Go Fullscreen for Big View", "पूरी स्क्रीन पर बड़ा करें", "मोठ्या पडद्यावर पहा",
                "Tap the video once. In the bottom right corner of the video, tap the small square icon to expand full-screen.",
                "वीडियो पर हल्का सा टैप करें। कोने में बने छोटे चौकोर निशान को दबाएं। वीडियो पूरी स्क्रीन पर बड़ा हो जाएगा।",
                "व्हिडिओवर हलकेच दाबा. कोपऱ्यात असलेल्या लहान चौकोनावर दाबा. व्हिडिओ पूर्ण स्क्रीनवर मोठा दिसेल.",
                "PHONE_UI", "YOUTUBE_FULLSCREEN",
                "Tap the square box icon to enjoy full-screen horizontal video.",
                "बड़ा और स्पष्ट देखने के लिए फुल-स्क्रीन चौकोर पर टैप करें।",
                "मोठ्या आकारात पाहण्यासाठी फुल-स्क्रीन चौकोनावर दाबा.");

        DatabaseSeeder.insertQuiz(conn, l16, "What icon on a playing YouTube video makes it expand to the entire screen?",
                "यूट्यूब पर वीडियो को पूरी स्क्रीन पर बड़ा करने के लिए कौन सा निशान दबाते हैं?",
                "युट्यूबवर व्हिडिओ पूर्ण स्क्रीनवर मोठा करण्यासाठी कोणते चिन्ह असते?",
                "The small square or rectangle icon in the lower right of the video opens full-screen mode.",
                "वीडियो के निचले कोने में बना छोटा चौकोर निशान फुल-स्क्रीन करता है।",
                "व्हिडिओच्या उजव्या कोपऱ्यातील लहान चौकोनी चिन्ह फुल-स्क्रीन करते.",
                new String[]{"A small square icon ⛶", "The airplane icon", "The power button", "The trash bin"},
                new String[]{"छोटा चौकोर निशान ⛶", "हवाई जहाज का निशान", "पावर बटन", "कचरे का डिब्बा"},
                new String[]{"लहान चौकोनी चिन्ह ⛶", "विमानाचे चिन्ह", "पॉवर बटण", "कचऱ्याचा डबा"}, 0);

        DatabaseSeeder.insertQuiz(conn, l16, "How do you pause a video if the doorbell rings or someone calls you?",
                "यदि दरवाजे की घंटी बजे तो चलते हुए वीडियो को कुछ देर कैसे रोका जाता है?",
                "दारावर बेल वाजल्यास चालणारा व्हिडिओ तात्पुरता कसा थांबवायचा?",
                "Tapping the screen brings up the two vertical pause bars (⏸); tap it to pause.",
                "स्क्रीन पर टैप करके बीच में बने दो खड़े डंडों वाले पॉज़ (⏸) निशान को दबाएं।",
                "स्क्रीनवर दाबून दोन उभ्या रेषा असलेल्या पॉझ (⏸) चिन्हावर दाबावे.",
                new String[]{"Throw the phone", "Tap the screen and press the two vertical pause bars (⏸)", "Disconnect home electricity", "Delete the app"},
                new String[]{"फोन फेंक दें", "स्क्रीन पर टैप करके दो डंडों वाले पॉज़ (⏸) निशान को दबाएं", "घर की बिजली बंद करें", "ऐप मिटाएं"},
                new String[]{"फोन फेकून द्या", "स्क्रीनवर दाबून दोन उभ्या रेषा (⏸) दाबा", "घरातील वीज बंद करा", "अॅप काढून टाका"}, 1);

        DatabaseSeeder.insertQuiz(conn, l16, "Can you subscribe to a devotional channel (like T-Series Bhakti) so new songs appear easily?",
                "क्या आप किसी भक्ति चैनल को 'Subscribe' कर सकते हैं ताकि नए भजन आसानी से मिलते रहें?",
                "नवीन भजने सहज मिळावीत म्हणून चॅनेल 'Subscribe' करता येते का?",
                "Yes, tapping the red 'Subscribe' button adds the channel to your subscriptions for free.",
                "हां, लाल 'Subscribe' बटन दबाने से उनके नए भजन आपको हमेशा आसानी से दिखते रहेंगे।",
                "होय, लाल 'Subscribe' बटण दाबल्याने त्यांची नवीन भजने सहज सापडतात.",
                new String[]{"No, it costs ₹500 every day", "Yes, tapping 'Subscribe' is free and keeps favorite channels handy", "Only if you have a laptop", "Only for children"},
                new String[]{"नहीं, रोज ₹500 कटते हैं", "हां, 'Subscribe' दबाना बिल्कुल मुफ्त है और चैनल आसानी से मिलता है", "केवल लैपटॉप पर", "केवल बच्चों के लिए"},
                new String[]{"नाही, रोज ५०० रुपये लागतात", "होय, 'Subscribe' करणे पूर्ण मोफत असते आणि गाणी पटकन सापडतात", "फक्त लॅपटॉपवर", "फक्त मुलांसाठी"}, 1);

        // L17: Safe Web Browsing & Avoiding Pop-ups
        int l17 = DatabaseSeeder.insertLesson(conn, 17, 5, "Safe Web Browsing & Avoiding Pop-ups", "सुरक्षित इंटरनेट ब्राउज़िंग और पॉप-अप से बचाव", "सुरक्षित इंटरनेट वापर आणि पॉप-अपपासून बचाव",
                "Recognize official websites, close scary fake virus pop-ups, and browse peacefully.",
                "असली वेबसाइट पहचानना, 'वायरस आ गया' वाले झूठे विज्ञापनों को बंद करना सीखें।",
                "खऱ्या वेबसाइट ओळखणे आणि 'व्हायरस आला' अशा खोट्या जाहिराती बंद करणे शिका.",
                "BEGINNER", 4, "NONE", 3,
                "• Look for the small padlock icon in address bar for secure sites.\n• If a pop-up screams 'Your phone has 13 viruses!', IT IS FAKE. Close the tab with 'X'.\n• Never download unknown '.apk' files.",
                "• सुरक्षित वेबसाइट के लिए ऊपर ताले का निशान देखें।\n• अगर पॉप-अप कहे 'आपके फोन में वायरस है', तो वह झूठा है। 'X' दबाकर टैब बंद करें।\n• अज्ञात '.apk' फाइलें कभी डाउनलोड न करें।",
                "• सुरक्षित वेबसाइटसाठी वर कुलूपाचे चिन्ह पहा.\n• 'तुमच्या फोनमध्ये व्हायरस आहे' असा मेसेज आल्यास घाबरू नका, तो खोटा असतो. 'X' दाबून टॅब बंद करा.\n• अनोळखी '.apk' फाइल कधीही डाऊनलोड करू नका.");

        DatabaseSeeder.insertStep(conn, l17, 1, "The Padlock in the Address Bar", "वेबसाइट पर ताले का निशान पहचानें", "वेबसाइटवरील कुलूपाचे चिन्ह ओळखा",
                "At the top of Chrome, official secure websites show a small lock symbol 🔒. This means your connection is private.",
                "क्रोम में सबसे ऊपर वेबसाइट के नाम के आगे छोटा ताला 🔒 बना होता है। इसका मतलब कनेक्शन सुरक्षित है।",
                "क्रोममध्ये वर वेबसाइटच्या नावापुढे लहान कुलूप 🔒 असते. याचा अर्थ वेबसाइट सुरक्षित आहे.",
                "PHONE_UI", "PADLOCK_URL",
                "Look for the secure lock symbol in the browser address bar.",
                "ब्राउज़र में ताले का निशान देखें जो सुरक्षित कनेक्शन दिखाता है।",
                "ब्राउझरमध्ये कुलूपाचे चिन्ह सुरक्षितता दर्शवते.");

        DatabaseSeeder.insertStep(conn, l17, 2, "Spotting Fake 'Virus Detected' Pop-ups", "झूठे 'वायरस अलर्ट' विज्ञापनों को पहचानें", "खोट्या 'व्हायरस अलर्ट' जाहिराती ओळखा",
                "Scam websites show flashing red screens: 'Warning! 5 viruses found, clean now!'. Scammers do this to scare you.",
                "धोखेबाज वेबसाइट लाल रंग में डराती हैं: 'सावधान! आपके फोन में वायरस है'। यह केवल डराकर ऐप डाउनलोड कराने का झांसा है।",
                "फसवे लोक लाल रंगात घाबरवतात: 'सावधान! फोनमध्ये व्हायरस आहे'. हे घाबरवून भलतेच अॅप डाऊनलोड करवण्याचे नाटक असते.",
                "WARNING_BOX", "VIRUS_POPUP",
                "Ignore flashing virus pop-ups designed by fraudsters to panic you.",
                "डराने वाले फर्जी वायरस विज्ञापनों को पूरी तरह नजरअंदाज करें।",
                "घाबरवणाऱ्या बनावट व्हायरसच्या जाहिरातींकडे दुर्लक्ष करा.");

        DatabaseSeeder.insertStep(conn, l17, 3, "Close the Scam Tab with the 'X'", "'X' दबाकर उस पेज को तुरंत बंद करें", "'X' दाबून ते पान लगेच बंद करा",
                "Tap the little square showing open tabs at top right, find the scary page, and tap the 'X' to close it safely.",
                "ऊपर चौकोर टैब बटन पर टैप करें। उस डरावने पेज के कोने में बने 'X' (कांटा) को दबाकर उसे हमेशा के लिए बंद कर दें।",
                "वरच्या बाजूला असलेल्या टॅबच्या चौकोनावर दाबा. त्या पानावरील 'X' दाबून ते पान बंद करून टाका.",
                "PHONE_UI", "CLOSE_TAB",
                "Tap the X button on the tab to close suspicious websites immediately.",
                "संदिग्ध पेज को बंद करने के लिए टैब पर बने क्रॉस 'X' को दबाएं।",
                "संशयास्पद पान बंद करण्यासाठी 'X' चिन्हावर दाबा.");

        DatabaseSeeder.insertStep(conn, l17, 4, "Never Download '.apk' Files from Strangers", "अनजान '.apk' फाइल कभी न खोलें", "अनोळखी '.apk' फाईल कधीही उघडू नका",
                "If a website asks to download a file ending in '.apk', tap CANCEL immediately. Only install apps from Google Play Store.",
                "यदि कोई वेबसाइट '.apk' फाइल डाउनलोड करने को कहे, तो तुरंत 'Cancel' दबाएं। ऐप हमेशा Google Play Store से ही लें।",
                "जर कोणतीही वेबसाइट '.apk' फाईल डाऊनलोड करण्यास सांगत असेल, तर लगेच 'Cancel' दाबा. अॅप फक्त Play Store वरूनच घ्या.",
                "WARNING_BOX", "BLOCK_APK",
                "Only install apps from the official Google Play Store, never from web links.",
                "ऐप केवल गूगल प्ले स्टोर से ही लें, इंटरनेट लिंक से कभी नहीं।",
                "अॅप फक्त गुगल प्ले स्टोअरवरूनच घ्या, अनोळखी लिंकवरून कधीही नाही.");

        DatabaseSeeder.insertQuiz(conn, l17, "If a website screen suddenly flashes red and says: 'Your battery is infected with 7 viruses, click here to clean', what is the truth?",
                "अगर अचानक स्क्रीन लाल होकर कहे: 'आपके फोन में 7 वायरस आ गए हैं, साफ करने के लिए यहां क्लिक करें', तो सच क्या है?",
                "जर अचानक स्क्रीनवर दिसले: 'तुमच्या फोनमध्ये ७ व्हायरस आले आहेत, स्वच्छ करण्यासाठी येथे दाबा', तर सत्य काय आहे?",
                "It is a 100% fake advertising trick. Browsers cannot detect viruses this way.",
                "यह पूरी तरह झूठा विज्ञापन है। कोई वेबसाइट ऐसे वायरस नहीं बता सकती। इसे बिना छुए बंद कर दें।",
                "ही १००% खोटी जाहिरात आहे. कोणतीही वेबसाइट अशा प्रकारे व्हायरस शोधू शकत नाही. ते पान बंद करावे.",
                new String[]{"Your phone is definitely broken", "It is a fake scam pop-up; close the tab safely", "You must immediately buy a new phone", "Transfer your pension to clean it"},
                new String[]{"फोन सच में खराब हो गया है", "यह पूरी तरह फर्जी पॉप-अप है; टैब को तुरंत बंद कर दें", "तुरंत नया फोन खरीदना पड़ेगा", "सफाई के लिए पेंशन ट्रांसफर करें"},
                new String[]{"फोन खरोखर खराब झाला", "हा बनावट पॉप-अप आहे; ते पान लगेच बंद करा", "नवीन फोन विकत घ्यावा लागेल", "पैसे पाठवावे लागतील"}, 1);

        DatabaseSeeder.insertQuiz(conn, l17, "Where is the only safe, trusted place to download applications on an Android phone?",
                "एंड्रॉयड फोन में नई ऐप डाउनलोड करने की एकमात्र सुरक्षित और प्रमाणित जगह कौन सी है?",
                "अँड्रॉइड फोनमध्ये नवीन अॅप डाऊनलोड करण्यासाठी एकमेव सुरक्षित जागा कोणती?",
                "The official Google Play Store verifies all apps for senior safety and security.",
                "आधिकारिक 'Google Play Store' ही ऐप डाउनलोड करने की सबसे सुरक्षित जगह है।",
                "अधिकृत 'Google Play Store' हीच अॅप डाऊनलोड करण्यासाठी सुरक्षित जागा आहे.",
                new String[]{"Unknown links sent on SMS", "The official Google Play Store", "Flashy website pop-ups", "A stranger's WhatsApp status"},
                new String[]{"एसएमएस पर आई अनजान लिंक", "आधिकारिक Google Play Store", "चमकीले वेब विज्ञापन", "किसी अनजान का व्हाट्सएप स्टेटस"},
                new String[]{"अनोळखी एसएमएस लिंक", "अधिकृत Google Play Store", "जाहिरातींचे पॉप-अप", "कोणाचाही व्हॉट्सअॅप स्टेटस"}, 1);

        DatabaseSeeder.insertQuiz(conn, l17, "What does a small lock symbol 🔒 in the browser address bar indicate?",
                "ब्राउज़र में वेबसाइट के पते के आगे छोटा ताला 🔒 क्या बताता है?",
                "वेबसाइटच्या पत्त्यापुढे लहान कुलूप 🔒 काय दर्शवते?",
                "The lock indicates an encrypted, secure connection between you and the verified website.",
                "ताला बताता है कि वेबसाइट सुरक्षित है और आपकी जानकारी सुरक्षित रूप से भेजी जा रही है।",
                "कुलूप दर्शवते की वेबसाइट सुरक्षित आहे आणि माहिती सुरक्षित राहते.",
                new String[]{"The phone screen is locked", "The website has an encrypted, secure connection", "The website is closed on Sundays", "You cannot read any text"},
                new String[]{"फोन की स्क्रीन बंद है", "वेबसाइट का कनेक्शन सुरक्षित और एन्क्रिप्टेड है", "वेबसाइट रविवार को बंद रहती है", "आप कुछ नहीं पढ़ सकते"},
                new String[]{"स्क्रीन लॉक झाली आहे", "वेबसाइट सुरक्षित आणि गोपनीय आहे", "वेबसाइट रविवारी बंद असते", "तुम्ही काहीही वाचू शकत नाही"}, 1);
    }

    // ==========================================
    // CAT 6: GOOGLE MAPS (Lessons 18 - 20)
    // ==========================================
    private static void seedCat6Maps(Connection conn) throws Exception {
        // L18: Finding Nearby Hospitals and Chemists
        int l18 = DatabaseSeeder.insertLesson(conn, 18, 6, "Finding Nearby Hospitals and Chemists", "आस-पास के अस्पताल और दवाई की दुकान ढूंढना", "जवळचे रुग्णालय आणि मेडिकल दुकान शोधणे",
                "Use Google Maps to locate medical clinics, chemist shops, and see walking distances.",
                "गूगल मैप्स से नजदीकी अस्पताल, केमिस्ट दुकान और उनकी दूरी देखना सीखें।",
                "गुगल मॅप्सवरून जवळचे दवाखाने, औषधांची दुकाने आणि अंतर पाहणे शिका.",
                "BEGINNER", 5, "MAPS", 1,
                "• Open Google Maps.\n• Tap 'Hospitals' or 'Pharmacies' shortcut button.\n• View list with distance (e.g. 800m) and open hours.\n• Tap phone icon to call clinic directly.",
                "• गूगल मैप्स खोलें।\n• 'Hospitals' या 'Pharmacies' के बटन पर टैप करें।\n• दूरी (जैसे 800 मीटर) और दुकान खुलने का समय देखें।\n• सीधे बात करने के लिए फोन के निशान को छुएं।",
                "• गुगल मॅप्स उघडा.\n• 'Hospitals' किंवा 'Pharmacies' बटणावर दाबा.\n• अंतर (उदा. ८०० मीटर) आणि उघडण्याची वेळ पहा.\n• थेट बोलण्यासाठी फोन चिन्हावर दाबा.");

        DatabaseSeeder.insertStep(conn, l18, 1, "Open Google Maps", "गूगल मैप्स खोलें", "गुगल मॅप्स उघडा",
                "Tap the app icon that looks like a colorful map location pin labeled 'Maps'.",
                "रंग-बिरंगे पिन वाले 'Maps' ऐप को अपनी स्क्रीन पर छूकर खोलें।",
                "रंगीत पिनचे चिन्ह असलेले 'Maps' अॅप स्क्रीनवर शोधा आणि उघडा.",
                "MAPS_UI", "MAPS_ICON",
                "Open Google Maps to see your current location on the map.",
                "नक्शे पर अपनी स्थिति देखने के लिए गूगल मैप्स खोलें।",
                "नकाशावर आपली जागा पाहण्यासाठी गुगल मॅप्स उघडा.");

        DatabaseSeeder.insertStep(conn, l18, 2, "Search for 'Hospital' or 'Chemist'", "अस्पताल या मेडिकल स्टोर खोजें", "दवाखाना किंवा मेडिकल दुकान शोधा",
                "Tap the search box at top and speak or type 'Hospital near me' or 'Chemist shop'.",
                "ऊपर सर्च बॉक्स पर टैप करें और बोलें: 'नजदीकी अस्पताल' या 'दवाई की दुकान'।",
                "वरच्या सर्च बॉक्सवर दाबा आणि बोला: 'जवळचे रुग्णालय' किंवा 'औषध दुकान'.",
                "MAPS_UI", "SEARCH_MAP",
                "Search for hospitals or pharmacies nearby.",
                "आस-पास के अस्पताल या मेडिकल स्टोर खोजें।",
                "जवळचे दवाखाने किंवा मेडिकल स्टोअर्स शोधा.");

        DatabaseSeeder.insertStep(conn, l18, 3, "Check Distance and Opening Hours", "दूरी और खुलने का समय देखें", "अंतर आणि उघडण्याची वेळ तपासा",
                "The map shows red pins. Tap on the nearest one. Check if it says 'Open 24 hours' and how far it is (e.g., 600m).",
                "नक्शे पर लाल निशान दिखेंगे। सबसे पास वाले पर टैप करें। देखें कि क्या लिखा है 'Open 24 hours' और दूरी कितनी है।",
                "नकाशावर लाल खुणा दिसतील. सर्वात जवळच्यावर दाबा. 'Open 24 hours' आणि अंतर (उदा. ६०० मी) तपासा.",
                "MAPS_UI", "PLACE_CARD",
                "Review the clinic distance, ratings, and whether it is open right now.",
                "अस्पताल की दूरी और खुलने का समय जांचें।",
                "दवाखान्याचे अंतर आणि वेळ तपासा.");

        DatabaseSeeder.insertStep(conn, l18, 4, "Tap 'Call' to Inquire", "फोन करके जानकारी लें", "फोन करून चौकशी करा",
                "Tap the 'Call' button with the phone icon to speak directly to the hospital reception desk before leaving home.",
                "घर से निकलने से पहले अस्पताल के स्वागत कक्ष पर बात करने के लिए 'Call' बटन दबाएं।",
                "घरातून निघण्यापूर्वी रिसेप्शनवर बोलण्यासाठी 'Call' बटणावर दाबा.",
                "MAPS_UI", "CALL_PLACE",
                "Tap Call to speak with the clinic reception before visiting.",
                "जाने से पहले अस्पताल में फोन करके पुष्टि करें।",
                "जाण्यापूर्वी दवाखान्यात फोन करून विचारून घ्या.");

        DatabaseSeeder.insertQuiz(conn, l18, "How can you tell if a pharmacy found on Google Maps is currently open?",
                "गूगल मैप्स पर कोई मेडिकल स्टोर इस समय खुला है या नहीं, यह कैसे पता चलता है?",
                "गुगल मॅप्सवर औषधाचे दुकान सध्या उघडे आहे की नाही हे कसे समजते?",
                "The place card clearly shows 'Open' in green text or 'Closed' with opening hours.",
                "अस्पताल या दुकान के कार्ड पर हरे अक्षरों में 'Open' या लाल में 'Closed' लिखा होता है।",
                "कार्डवर हिरव्या अक्षरात 'Open' किंवा लाल अक्षरात 'Closed' लिहिलेले असते.",
                new String[]{"You have to walk there to find out", "The listing shows green 'Open now' or opening hours", "You must write a letter", "By checking yesterday's newspaper"},
                new String[]{"वहां जाकर ही पता चलता है", "कार्ड पर हरे रंग में 'Open now' और समय लिखा दिखता है", "चिट्ठी लिखकर पूछना पड़ता है", "कल का अखबार देखकर"},
                new String[]{"तिथे चालत गेल्यावरच समजते", "कार्डवर हिरव्या अक्षरात 'Open now' आणि वेळ दिसते", "पत्र लिहून विचारावे लागते", "कालचे वर्तमानपत्र पाहून"}, 1);

        DatabaseSeeder.insertQuiz(conn, l18, "What does '800 m' mean next to a clinic on Google Maps?",
                "गूगल मैप्स पर किसी क्लिनिक के आगे '800 m' लिखे होने का क्या मतलब है?",
                "गुगल मॅप्सवर दवाखान्यापुढे '८०० मी' लिहिलेले असल्यास त्याचा अर्थ काय?",
                "It means the clinic is 800 meters away (less than 1 kilometer walk).",
                "इसका मतलब है कि वह अस्पताल आपसे सिर्फ 800 मीटर की दूरी पर है (1 किलोमीटर से भी कम)।",
                "याचा अर्थ तो दवाखाना तुमच्यापासून फक्त ८०० मीटर (१ किमीपेक्षा कमी) अंतरावर आहे.",
                new String[]{"800 doctors are inside", "The clinic is 800 meters away from your location", "The bill will be ₹800", "The clinic was built in year 800"},
                new String[]{"अस्पताल में 800 डॉक्टर हैं", "अस्पताल आपसे 800 मीटर की दूरी पर स्थित है", "इलाज का बिल ₹800 होगा", "अस्पताल 800 साल पुराना है"},
                new String[]{"तिथे ८०० डॉक्टर आहेत", "दवाखाना तुमच्यापासून ८०० मीटर अंतरावर आहे", "बिल ८०० रुपये होईल", "दवाखाना ८०० वर्षे जुना आहे"}, 1);

        DatabaseSeeder.insertQuiz(conn, l18, "Which button connects you to the hospital's reception directly from the map screen?",
                "नक्शे की स्क्रीन से अस्पताल के रिसेप्शन पर सीधे बात करने के लिए कौन सा बटन दबाते हैं?",
                "नकाशावरून थेट दवाखान्याच्या फोनवर बोलण्यासाठी कोणते बटण दाबावे?",
                "The 'Call' button directly opens the phone dialer with the clinic's number.",
                "'Call' बटन दबाने से अस्पताल का फोन नंबर सीधे आपके डायलर पर आ जाता है।",
                "'Call' बटण दाबल्याने दवाखान्याचा नंबर थेट फोन डायलरवर येतो.",
                new String[]{"The 'Delete' button", "The 'Call' button with phone icon", "The 'Wallpaper' button", "The 'Camera' button"},
                new String[]{"'Delete' बटन", "फोन निशान वाला 'Call' बटन", "वॉलपेपर बटन", "कैमरा बटन"},
                new String[]{"'Delete' बटण", "फोन चिन्ह असलेले 'Call' बटण", "वॉलपेपर बटण", "कॅमेरा बटण"}, 1);

        // L19: Spoken Turn-by-Turn Directions
        int l19 = DatabaseSeeder.insertLesson(conn, 19, 6, "Spoken Turn-by-Turn Directions", "बोलकर रास्ता बताने वाले नक्शे", "बोलून रस्ता दाखवणारे नकाशे",
                "Never get lost. Let your phone speak directions: 'In 100 meters, turn left.'",
                "रास्ता भटकने से बचें। फोन बोलकर बताएगा: '100 मीटर आगे बाएं मुड़ें'।",
                "रस्ता चुकण्याची भीती नाही. फोन बोलून सांगेल: '१०० मीटर पुढे डावीकडे वळा'.",
                "BEGINNER", 6, "MAPS", 2,
                "• Search destination and tap blue 'Directions' button.\n• Choose Walking icon (person walking) or Car/Auto icon.\n• Tap green or blue 'Start' button.\n• Listen to voice instructions and follow the blue arrow.",
                "• मंजिल खोजकर नीले 'Directions' बटन को छुएं।\n• पैदल चलने के लिए आदमी वाला या ऑटो/गाड़ी का निशान चुनें।\n• 'Start' बटन दबाएं।\n• फोन की आवाज़ सुनें और नीले तीर के साथ आगे बढ़ें।",
                "• ठिकाण शोधून निळ्या 'Directions' बटणावर दाबा.\n• पायी चालण्यासाठी माणसाचे किंवा गाडीचे चिन्ह निवडा.\n• 'Start' बटण दाबा.\n• फोनचा आवाज ऐका आणि निळ्या बाणासोबत पुढे चला.");

        DatabaseSeeder.insertStep(conn, l19, 1, "Search Your Destination and Tap 'Directions'", "मंजिल खोजें और 'Directions' दबाएं", "ठिकाण शोधा आणि 'Directions' दाबा",
                "Type or speak where you want to go (e.g. 'Shivaji Park' or 'Pune Railway Station'). Tap the blue 'Directions' button.",
                "जहां जाना है उस जगह का नाम बोलें और नीचे नीले रंग के 'Directions' बटन को छुएं।",
                "जिथे जायचे आहे ते नाव बोला आणि खालील निळ्या रंगाच्या 'Directions' बटणावर दाबा.",
                "MAPS_UI", "DIRECTIONS_BTN",
                "Tap the blue Directions button to see the route.",
                "रास्ता देखने के लिए नीला डायरेक्शन्स बटन दबाएं।",
                "रस्ता पाहण्यासाठी निळ्या डायरेक्शन्स बटणावर दाबा.");

        DatabaseSeeder.insertStep(conn, l19, 2, "Choose Walking or Vehicle Mode", "पैदल या वाहन का तरीका चुनें", "पायी किंवा वाहनाचा पर्याय निवडा",
                "At the top, tap the walking person icon for footpaths, or the car/two-wheeler icon for auto/cab ride.",
                "ऊपर पैदल चलने वाले व्यक्ति का निशान (पैदल रास्ता) या कार/ऑटो का निशान चुनें।",
                "वरच्या बाजूला पायी चालणाऱ्या माणसाचे चिन्ह किंवा रिक्षा/कारचे चिन्ह निवडा.",
                "MAPS_UI", "TRAVEL_MODE",
                "Select walking or driving mode based on how you are traveling.",
                "पैदल या गाड़ी में से अपने सफर का तरीका चुनें।",
                "पायी किंवा वाहनाने जाण्याचा पर्याय निवडा.");

        DatabaseSeeder.insertStep(conn, l19, 3, "Tap the Big 'Start' Button", "बड़ा 'Start' बटन दबाएं", "मोठे 'Start' बटण दाबा",
                "Look at the bottom left. Tap the green or blue button that says 'Start'. Navigation begins!",
                "नीचे बाईं तरफ 'Start' लिखा बटन दबाएं। अब फोन रास्ता बताना शुरू कर देगा!",
                "खाली डाव्या बाजूला 'Start' बटण दाबा. आता फोन दिशा सांगणे सुरू करेल!",
                "MAPS_UI", "NAVIGATE_START",
                "Tap Start to begin spoken turn-by-turn navigation.",
                "बोलकर रास्ता सुनने के लिए स्टार्ट बटन दबाएं।",
                "बोलून रस्ता ऐकण्यासाठी स्टार्ट बटण दाबा.");

        DatabaseSeeder.insertStep(conn, l19, 4, "Listen to Spoken Instructions", "फोन की आवाज सुनकर आगे बढ़ें", "फोनचा आवाज ऐकून पुढे चला",
                "Keep phone in hand or pocket. The phone speaks aloud: 'In 50 meters, turn right on MG Road'. Follow the blue line.",
                "फोन को हाथ में रखें। फोन खुद बोलकर रास्ता बताएगा: '50 मीटर बाद दाएं मुड़ें'। नीली लकीर का पीछा करें।",
                "फोन हातात ठेवा. फोन स्वतः बोलेल: '५० मीटर नंतर उजवीकडे वळा'. नकाशावरील निळ्या रेषेप्रमाणे चला.",
                "MAPS_UI", "VOICE_NAV",
                "Listen to the spoken directions guiding you smoothly to your destination.",
                "फोन की मीठी आवाज के निर्देशों का पालन करते हुए मंजिल तक पहुंचें।",
                "फोनच्या सूचना ऐकत आपल्या ठिकाणी सुरक्षित पोहोचा.");

        DatabaseSeeder.insertQuiz(conn, l19, "Which button in Google Maps starts live turn-by-turn spoken voice guidance?",
                "गूगल मैप्स में लाइव बोलकर रास्ता बताने वाली नेविगेशन शुरू करने के लिए कौन सा बटन दबाया जाता है?",
                "गुगल मॅप्समध्ये बोलून रस्ता सांगणारी नेव्हिगेशन सुरू करण्यासाठी कोणते बटण दाबावे?",
                "The 'Start' button activates real-time voice guided navigation.",
                "'Start' (शुरू करें) बटन दबाने से फोन बोलकर रास्ता दिखाना शुरू कर देता है।",
                "'Start' बटण दाबल्याने फोन बोलून रस्ता सांगण्यास सुरुवात करतो.",
                new String[]{"The 'Delete' button", "The 'Start' navigation button", "The 'Airplane' button", "The 'Sleep' button"},
                new String[]{"'Delete' बटन", "'Start' (शुरू करें) बटन", "'Airplane' बटन", "'Sleep' बटन"},
                new String[]{"'Delete' बटण", "'Start' नेव्हिगेशन बटण", "'Airplane' बटण", "'Sleep' बटण"}, 1);

        DatabaseSeeder.insertQuiz(conn, l19, "What happens if you accidentally take a wrong turn while following Google Maps?",
                "अगर रास्ता चलते समय आप गलती से किसी गलत गली में मुड़ जाएं, तो क्या होगा?",
                "नकाशा वापरताना चुकून चुकीच्या गल्लीत वळल्यास काय होते?",
                "Google Maps automatically recalculates a new route from where you are standing within 3 seconds.",
                "गूगल मैप्स घबराता नहीं है, वह 3 सेकंड में आपकी नई जगह से नया सही रास्ता खुद बना देता है।",
                "गुगल मॅप्स घाबरत नाही, तो ३ सेकंदात तुम्ही जिथे आहात तिथून नवीन रस्ता लगेच दाखवतो.",
                new String[]{"The phone locks forever", "Google Maps automatically recalculates a new correct route for you", "You must call the police", "You are lost forever"},
                new String[]{"फोन हमेशा के लिए बंद हो जाता है", "गूगल मैप्स अपने आप नई जगह से सही रास्ता दोबारा बना देता है", "पुलिस को बुलाना पड़ता है", "आप हमेशा के लिए खो गए"},
                new String[]{"फोन कायमचा बंद होतो", "गुगल मॅप्स आपोआप नवीन ठिकाणाहून योग्य रस्ता तयार करतो", "पोलिसांना बोलवावे लागते", "तुम्ही कायमचे हरवलात"}, 1);

        DatabaseSeeder.insertQuiz(conn, l19, "How can you tell how many minutes it will take to reach your destination?",
                "अपनी मंजिल तक पहुंचने में कितने मिनट लगेंगे, यह स्क्रीन पर कहां दिखता है?",
                "आपल्या ठिकाणी पोहोचायला किती मिनिटे लागतील हे कुठे दिसते?",
                "The estimated travel time is prominently displayed in large bold green text at the bottom.",
                "स्क्रीन के निचले हिस्से में बड़े अक्षरों में समय (जैसे '15 min') और दूरी साफ दिखाई देती है।",
                "स्क्रीनच्या खालच्या भागात ठळक अक्षरात वेळ (उदा. '१५ मिनिटे') आणि अंतर दिसते.",
                new String[]{"In the battery icon", "At the bottom in bold green text showing estimated minutes", "In your contact list", "In the calendar"},
                new String[]{"बैटरी के निशान में", "स्क्रीन के नीचे बड़े अक्षरों में समय (जैसे 15 min)", "संपर्क सूची में", "कैलेंडर में"},
                new String[]{"बॅटरीच्या चिन्हात", "स्क्रीनच्या खाली ठळक अक्षरात वेळ (उदा. १५ मिनिटे)", "संपर्क यादीत", "कॅलेंडरमध्ये"}, 1);

        // L20: Sharing Live Location with Family
        int l20 = DatabaseSeeder.insertLesson(conn, 20, 6, "Sharing Live Location with Family", "बच्चों के साथ अपनी लोकेशन साझा करना", "मुलांसोबत लाईव्ह लोकेशन शेअर करणे",
                "Give your family peace of mind by letting them see where you are when traveling alone.",
                "अकेले सफर करते समय बच्चों को अपनी लाइव लोकेशन भेजें ताकि उन्हें चिंता न हो।",
                "एकटे प्रवास करताना मुलांना आपली थेट जागा (लाईव्ह लोकेशन) पाठवा जेणेकरून त्यांना काळजी वाटणार नाही.",
                "BEGINNER", 4, "MAPS", 3,
                "• In Google Maps, tap your profile circle at top right.\n• Tap 'Location sharing'.\n• Choose duration (e.g. 1 hour or Until you turn this off).\n• Select your son or daughter's WhatsApp or contact.",
                "• गूगल मैप्स में ऊपर अपनी प्रोफाइल फोटो छुएं।\n• 'Location sharing' पर टैप करें।\n• समय चुनें (जैसे 1 घंटा)।\n• अपने बेटे या बेटी को व्हाट्सएप पर भेजें।",
                "• गुगल मॅप्समध्ये वर प्रोफाइल फोटोवर दाबा.\n• 'Location sharing' निवडा.\n• वेळ निवडा (उदा. १ तास).\n• मुलांना व्हॉट्सअॅपवर पाठवा.");

        DatabaseSeeder.insertStep(conn, l20, 1, "Tap Your Profile Photo Circle", "अपनी प्रोफाइल फोटो पर टैप करें", "आपल्या प्रोफाइल फोटोवर दाबा",
                "Open Google Maps. At the top right corner inside the search bar, tap your profile circle (letter or photo).",
                "गूगल मैप्स में ऊपर दाईं तरफ अपनी फोटो या नाम के पहले अक्षर वाले गोले पर टैप करें।",
                "गुगल मॅप्समध्ये वर उजव्या कोपऱ्यात असलेल्या आपल्या फोटोवर किंवा आद्याक्षरावर दाबा.",
                "MAPS_UI", "PROFILE_MENU",
                "Tap your profile icon at the top right of Google Maps.",
                "गूगल मैप्स में ऊपर दाईं ओर अपनी प्रोफाइल पर टैप करें।",
                "गुगल मॅप्समध्ये वर उजवीकडे प्रोफाइलवर दाबा.");

        DatabaseSeeder.insertStep(conn, l20, 2, "Select 'Location Sharing'", "'Location sharing' चुनें", "'Location sharing' निवडा",
                "A menu pops up. Tap the option with two people silhouettes that says 'Location sharing'.",
                "एक मेनू खुलेगा। वहां 'Location sharing' (स्थान साझा करना) वाले विकल्प को छुएं।",
                "मेनू उघडेल. त्यातील 'Location sharing' या पर्यायावर दाबा.",
                "MAPS_UI", "LOCATION_SHARE",
                "Select Location sharing to share your real-time whereabouts.",
                "अपने परिवार को स्थिति दिखाने के लिए लोकेशन शेयरिंग चुनें।",
                "कुटुंबीयांना आपली जागा दाखवण्यासाठी लोकेशन शेअरिंग निवडा.");

        DatabaseSeeder.insertStep(conn, l20, 3, "Choose How Long (e.g. 1 Hour)", "समय चुनें (जैसे 1 घंटा)", "वेळ निवडा (उदा. १ तास)",
                "Select 'For 1 hour' or use '+' to increase time to 2 or 3 hours until you safely return home.",
                "सफर के हिसाब से समय चुनें, जैसे '1 घंटा' या सुरक्षित घर लौटने तक '2 घंटे'।",
                "प्रवासाच्या अंदाजानुसार वेळ निवडा, जसे '१ तास' किंवा घरी पोहोचेपर्यंत '२ तास'.",
                "MAPS_UI", "SHARE_TIME",
                "Set the duration you want your location to remain visible.",
                "जितनी देर के लिए लोकेशन दिखानी है वह समय तय करें।",
                "किती वेळ लोकेशन दिसावी ती वेळ निश्चित करा.");

        DatabaseSeeder.insertStep(conn, l20, 4, "Send to Your Child on WhatsApp", "व्हाट्सएप पर बच्चों को भेजें", "व्हॉट्सअॅपवर मुलांना पाठवा",
                "Tap the green WhatsApp icon and select your son or daughter. They can now see your moving car/bus on their phone screen!",
                "व्हाट्सएप चुनकर अपने बेटे या बेटी को भेजें। वे अपने फोन पर देख सकेंगे कि आपकी बस या ऑटो कहां तक पहुंची है!",
                "व्हॉट्सअॅप निवडून मुलांच्या नावावर पाठवा. तुमची रिक्षा किंवा बस कुठे पोहोचली आहे ते त्यांना थेट दिसेल!",
                "WHATSAPP_UI", "LOCATION_SENT",
                "Send the link so your family knows exactly where you are and when you will arrive safely.",
                "अपने बच्चों को लिंक भेजें ताकि वे आपकी सुरक्षित यात्रा देख सकें।",
                "मुलांना लिंक पाठवा जेणेकरून त्यांचा जीव टांगणीला लागणार नाही.");

        DatabaseSeeder.insertQuiz(conn, l20, "Why is 'Share Live Location' so helpful for seniors traveling in an auto or bus?",
                "अकेले ऑटो या बस में सफर करते समय वरिष्ठ नागरिकों के लिए 'लाइव लोकेशन' भेजना क्यों उपयोगी है?",
                "एकटे रिक्षा किंवा बसने प्रवास करताना 'लाईव्ह लोकेशन' पाठवणे का गरजेचे आहे?",
                "Children can see the exact moving vehicle position on their phone screen without having to call and worry.",
                "परिवार वाले बिना बार-बार फोन किए अपने मोबाइल पर देख सकते हैं कि आप कहां सुरक्षित पहुंचे हैं।",
                "घरच्यांना सतत फोन न करता तुम्ही कुठे पोहोचला आहात ते थेट त्यांच्या फोनवर दिसते.",
                new String[]{"It pays the auto fare automatically", "Family can see your safe moving route on their screen in real-time", "It cleans the auto window", "It makes the bus go faster"},
                new String[]{"ऑटो का किराया खुद भर देता है", "परिवार वाले आपकी सुरक्षित यात्रा को अपने स्क्रीन पर लाइव देख सकते हैं", "ऑटो की खिड़की साफ करता है", "बस की रफ्तार तेज कर देता है"},
                new String[]{"रिक्षाचे भाडे आपोआप भरते", "कुटुंबीयांना तुमचा सुरक्षित प्रवास त्यांच्या स्क्रीनवर थेट दिसतो", "रिक्षाची खिडकी स्वच्छ करतो", "बसचा वेग वाढवतो"}, 1);

        DatabaseSeeder.insertQuiz(conn, l20, "Does Live Location stop sharing automatically when the time you set expires?",
                "क्या आपके द्वारा तय किया गया समय (जैसे 1 घंटा) पूरा होने पर लोकेशन शेयरिंग अपने आप बंद हो जाती है?",
                "ठरवून दिलेली वेळ (उदा. १ तास) संपल्यावर लोकेशन शेअरिंग आपोआप बंद होते का?",
                "Yes, the sharing automatically expires safely without any action needed.",
                "हां, तय समय पूरा होते ही लोकेशन दिखना अपने आप पूरी तरह बंद हो जाता है।",
                "होय, वेळ संपताच लोकेशन दिसणे आपोआप पूर्णपणे बंद होते.",
                new String[]{"No, it shares forever for 100 years", "Yes, it stops automatically after the chosen time duration", "Only if you turn off the phone", "Only on bank holidays"},
                new String[]{"नहीं, यह 100 साल तक चलती रहती है", "हां, तय समय पूरा होने पर यह अपने आप बंद हो जाती है", "केवल फोन बंद करने पर", "केवल बैंक की छुट्टी पर"},
                new String[]{"नाही, १०० वर्षे चालू राहते", "होय, निवडलेली वेळ संपताच ती आपोआप बंद होते", "फक्त फोन बंद केल्यावर", "फक्त बँकेच्या सुट्टीला"}, 1);

        DatabaseSeeder.insertQuiz(conn, l20, "Can you stop sharing your location early if you reach home before the timer ends?",
                "अगर आप समय से पहले घर पहुंच जाएं, तो क्या आप लोकेशन शेयरिंग तुरंत बंद कर सकते हैं?",
                "वेळेपूर्वीच घरी पोहोचल्यास लोकेशन शेअरिंग लगेच थांबवता येते का?",
                "Yes, tapping the 'Stop' button in Google Maps ends sharing immediately.",
                "हां, गूगल मैप्स में 'Stop' बटन दबाकर इसे किसी भी समय तुरंत रोका जा सकता है।",
                "होय, गुगल मॅप्समधील 'Stop' बटण दाबून हे कधीही लगेच थांबवता येते.",
                new String[]{"No, you must wait outside the house", "Yes, you can tap 'Stop' in Google Maps anytime", "Only after paying a penalty", "Only with written police permission"},
                new String[]{"नहीं, बाहर खड़े रहना पड़ेगा", "हां, गूगल मैप्स में 'Stop' बटन दबाकर कभी भी बंद कर सकते हैं", "जुर्माना भरने के बाद ही", "पुलिस की लिखित अनुमति से"},
                new String[]{"नाही, घराबाहेर उभे राहावे लागेल", "होय, गुगल मॅप्समध्ये 'Stop' दाबून कधीही बंद करू शकता", "दंड भरल्यावरच", "पोलिसांच्या परवानगीने"}, 1);
    }

    // ==========================================
    // CAT 7: DIGITAL PAYMENTS (Lessons 21 - 24)
    // ==========================================
    private static void seedCat7Payments(Connection conn) throws Exception {
        // L21: What is UPI and Scanning QR Codes
        int l21 = DatabaseSeeder.insertLesson(conn, 21, 7, "What is UPI and Scanning QR Codes", "यूपीआई क्या है और क्यूआर कोड स्कैन करना", "यूपीआय म्हणजे काय आणि क्यूआर कोड स्कॅन करणे",
                "Learn how digital money works and pay safely at grocery stores without handling cash.",
                "डिजिटल पेमेंट समझना और किराने की दुकान पर सुरक्षित क्यूआर कोड स्कैन करके भुगतान करना सीखें।",
                "डिजिटल पैसे समजून घेणे आणि दुकानात रोख पैशांशिवाय क्यूआर कोड स्कॅन करून सुरक्षित पैसे देणे शिका.",
                "BEGINNER", 6, "UPI", 1,
                "• A QR code is a black-and-white square containing merchant details.\n• Open PhonePe/GPay and tap 'Scan QR' button.\n• Point camera at the shop's printed QR stand.\n• Always verify merchant name on screen before typing amount and PIN.",
                "• क्यूआर कोड काले-सफेद बिंदुओं वाला चौकोर निशान होता है जिसमें दुकानदार का नाम होता है।\n• PhonePe या GPay खोलकर 'Scan QR' दबाएं।\n• काउंटर पर रखे क्यूआर कोड के सामने कैमरा रखें।\n• पैसे और पिन डालने से पहले स्क्रीन पर दुकानदार का नाम जरूर जांचें।",
                "• क्यूआर कोड म्हणजे काळ्या-पांढऱ्या ठिपक्यांचा चौकोन ज्यात दुकानदाराचे नाव असते.\n• PhonePe किंवा GPay उघडून 'Scan QR' दाबा.\n• दुकानातील क्यूआर कोडसमोर कॅमेरा धरा.\n• पैसे आणि पिन टाकण्यापूर्वी स्क्रीनवर दुकानदाराचे नाव नक्की तपासा.");

        DatabaseSeeder.insertStep(conn, l21, 1, "What is a QR Code?", "क्यूआर कोड क्या होता है?", "क्यूआर कोड म्हणजे काय?",
                "A QR code is the square black-and-white patterned code printed on shop counters. It contains the merchant's official UPI bank address.",
                "क्यूआर कोड दुकानों पर काउंटर पर रखा चौकोर निशान होता है। इसमें दुकानदार के बैंक खाते का पता छिपा होता है।",
                "क्यूआर कोड म्हणजे दुकानाच्या काउंटरवर असलेला काळा-पांढरा चौकोन. यात दुकानदाराच्या खात्याचा पत्ता असतो.",
                "UPI_UI", "QR_EXPLAIN",
                "A QR code uniquely identifies the shopkeeper's payment address.",
                "क्यूआर कोड दुकानदार की पहचान सुरक्षित रूप से कराता है।",
                "क्यूआर कोड दुकानदाराची ओळख अचूक पटवतो.");

        DatabaseSeeder.insertStep(conn, l21, 2, "Open App & Tap 'Scan QR'", "ऐप खोलें और 'Scan QR' दबाएं", "अॅप उघडा आणि 'Scan QR' दाबा",
                "Open your UPI app (PhonePe, Google Pay, or Paytm). Tap the square camera scan icon at the top.",
                "फोनपे, गूगल पे या पेटीएम खोलें। ऊपर बने चौकोर कैमरा स्कैनर आइकन पर टैप करें।",
                "PhonePe, Google Pay किंवा Paytm उघडा. वर असलेल्या स्कॅनर चिन्हावर दाबा.",
                "UPI_UI", "SCAN_BUTTON",
                "Tap the Scan QR button in your payment application.",
                "पेमेंट ऐप में स्कैन क्यूआर बटन पर टैप करें।",
                "पेमेंट अॅपमधील स्कॅन क्यूआर बटणावर दाबा.");

        DatabaseSeeder.insertStep(conn, l21, 3, "Point Camera at Counter QR Code", "कैमरा क्यूआर कोड के सामने रखें", "कॅमेरा क्यूआर कोडसमोर धरा",
                "Hold your phone steady so the printed square fits inside the scanning box. The phone will beep cheerfully!",
                "फोन को थोड़ा आगे करके काउंटर वाले क्यूआर कोड के सामने रखें। फोन से एक मीठी बीप आवाज़ आएगी!",
                "फोन दुकानातील क्यूआर कोडसमोर धरा. चौकोन जुळताच फोनमधून बीप असा मंजुळ आवाज येईल!",
                "UPI_UI", "CAMERA_QR",
                "Align the shop QR code inside the camera box.",
                "दुकान के क्यूआर कोड को कैमरे के चौकोर बॉक्स के अंदर लाएं।",
                "दुकानातील क्यूआर कोड कॅमेऱ्याच्या चौकटीत आणा.");

        DatabaseSeeder.insertStep(conn, l21, 4, "Verify Name, Enter Amount & Enter PIN", "नाम जांचें, रकम लिखें और गुप्त पिन डालें", "नाव तपासा, रक्कम लिहा आणि गुप्त पिन टाका",
                "Check the shopkeeper's name on screen (e.g. 'Mohan Kirana Store'). Type the exact amount (₹45), tap Pay, and enter your secret 4 or 6 digit UPI PIN.",
                "स्क्रीन पर दुकानदार का नाम जांचें (जैसे 'मोहन किराना स्टोर')। सही रकम (₹45) लिखें, फिर अपना गुप्त 4 या 6 अंकों का यूपीआई पिन डालें।",
                "स्क्रीनवर दुकानदाराचे नाव (उदा. 'मोहन किराणा स्टोअर') तपासा. अचूक रक्कम (₹४५) लिहा आणि तुमचा गुप्त ४ किंवा ६ अंकी यूपीआय पिन टाका.",
                "UPI_UI", "AMOUNT_CONFIRM",
                "Always verify the merchant name on screen before entering your secret UPI PIN.",
                "पिन डालने से पहले दुकानदार का नाम स्क्रीन पर हमेशा देखें।",
                "पिन टाकण्यापूर्वी दुकानदाराचे नाव स्क्रीनवर नक्की तपासा.");

        DatabaseSeeder.insertQuiz(conn, l21, "What should you ALWAYS verify on your phone screen immediately after scanning a shop's QR code?",
                "दुकान का क्यूआर कोड स्कैन करने के बाद फोन की स्क्रीन पर सबसे पहले क्या जांचना जरूरी है?",
                "दुकानातील क्यूआर कोड स्कॅन केल्यावर स्क्रीनवर सर्वात आधी काय तपासणे आवश्यक आहे?",
                "Always verify the merchant's business name and payee identity before entering amount or PIN.",
                "पैसे डालने से पहले स्क्रीन पर दुकानदार का नाम और दुकान की पहचान जरूर जांचनी चाहिए।",
                "पैसे आणि पिन टाकण्यापूर्वी दुकानदाराचे नाव स्क्रीनवर नक्की तपासले पाहिजे.",
                new String[]{"The shopkeeper's shoes", "The merchant's name and store identity", "The weather forecast", "The battery percentage"},
                new String[]{"दुकानदार के जूते", "दुकानदार का नाम और दुकान की पहचान", "मौसम की जानकारी", "बैटरी का प्रतिशत"},
                new String[]{"दुकानदाराचे कपडे", "दुकानदाराचे नाव आणि दुकानाची ओळख", "हवामानाचा अंदाज", "बॅटरीची टक्केवारी"}, 1);

        DatabaseSeeder.insertQuiz(conn, l21, "How do you know that a UPI payment succeeded at the store?",
                "आपको कैसे पता चलता है कि दुकान पर यूपीआई से पैसे सफलतापूर्वक पहुंच गए हैं?",
                "दुकानदाराला यूपीआयने पैसे गेले हे कसे समजते?",
                "The screen shows a large green checkmark ✅ with a payment successful sound chime.",
                "स्क्रीन पर बड़ा हरा सही का निशान ✅ दिखता है और फोन में सफल भुगतान की धुन बजती है।",
                "स्क्रीनवर मोठी हिरवी टिक ✅ दिसते आणि पैसे यशस्वी झाल्याचा आवाज येतो.",
                new String[]{"The phone turns off", "A large green checkmark ✅ appears with a success chime", "The phone gets hot", "The camera takes a selfie"},
                new String[]{"फोन बंद हो जाता है", "स्क्रीन पर बड़ा हरा सही का निशान ✅ और घंटी की आवाज आती है", "फोन गर्म हो जाता है", "कैमरा सेल्फी खींचता है"},
                new String[]{"फोन बंद पडतो", "स्क्रीनवर मोठी हिरवी टिक ✅ आणि यशस्वी झाल्याचा आवाज येतो", "फोन गरम होतो", "कॅमेरा सेल्फी काढतो"}, 1);

        DatabaseSeeder.insertQuiz(conn, l21, "Does paying through UPI require you to carry exact coins or cash change?",
                "क्या यूपीआई से भुगतान करते समय खुले पैसे या चिल्लर सिक्कों की चिंता करनी पड़ती है?",
                "यूपीआयने पैसे देताना सुट्या पैशांची चिंता करावी लागते का?",
                "No, UPI transfers the exact rupee amount directly from your bank account to the seller.",
                "नहीं! यूपीआई से बिल्कुल सटीक रकम (जैसे ₹47.50) सीधे बैंक से चली जाती है, खुले पैसों की जरूरत नहीं होती।",
                "नाही! यूपीआयने अगदी अचूक रक्कम (उदा. ₹४७) थेट बँकेतून जाते, सुट्या पैशांची गरज नसते.",
                new String[]{"Yes, you must always give coins", "No, UPI pays the exact amount digitally down to the rupee", "Only if you pay in foreign currency", "Only on Sundays"},
                new String[]{"हां, हमेशा सिक्के देने पड़ते हैं", "नहीं, यूपीआई बिल्कुल सही रुपये बिना चिल्लर के सीधे ट्रांसफर करता है", "केवल विदेशी मुद्रा में", "केवल रविवार को"},
                new String[]{"होय, नेहमी नाणी द्यावी लागतात", "नाही, यूपीआय अगदी अचूक रक्कम सुट्या पैशांशिवाय ट्रान्सफर करतो", "फक्त परदेशी पैशांसाठी", "फक्त रविवारी"}, 1);

        // L22: Paying via Mobile Number / Contact
        int l22 = DatabaseSeeder.insertLesson(conn, 22, 7, "Paying via Mobile Number / Contact", "मोबाइल नंबर पर सीधे पैसे भेजना", "मोबाईल नंबरवर थेट पैसे पाठवणे",
                "Send money to children in college, family, or milkman directly using their phone number.",
                "बच्चों को या दूधवाले को उनके 10 अंकों के मोबाइल नंबर पर सीधे पैसे भेजना सीखें।",
                "मुलांना किंवा दूधवाल्याला त्यांच्या १० अंकी मोबाईल नंबरवर थेट पैसे पाठवणे शिका.",
                "BEGINNER", 5, "UPI", 2,
                "• Tap 'Pay to Contact' or 'Pay Mobile Number'.\n• Select your child from contacts or type 10 digits.\n• Confirm their registered bank name on screen.\n• Enter amount, tap Pay, and enter UPI PIN.",
                "• 'Pay to Contact' या 'Mobile Number' पर टैप करें।\n• संपर्कों में से नाम चुनें या 10 अंकों का नंबर लिखें।\n• स्क्रीन पर उनका बैंक से जुड़ा नाम जरूर देखें।\n• रकम लिखें और यूपीआई पिन डालकर पैसे भेजें।",
                "• 'Pay to Contact' किंवा 'Mobile Number' वर दाबा.\n• संपर्क यादीतून नाव निवडा किंवा १० अंकी नंबर लिहा.\n• स्क्रीनवर त्यांचे बँकेशी जोडलेले नाव नक्की तपासा.\n• रक्कम लिहून यूपीआय पिन टाका.");

        DatabaseSeeder.insertStep(conn, l22, 1, "Tap 'Pay Contacts' or 'To Mobile Number'", "'Pay to Mobile' पर टैप करें", "'Pay to Mobile' वर दाबा",
                "Inside PhonePe or Google Pay, tap the button labeled 'Pay Contacts' or 'To Mobile Number'.",
                "फोनपे या गूगल पे में 'Pay Contacts' या 'To Mobile Number' वाले विकल्प को छुएं।",
                "PhonePe किंवा Google Pay मध्ये 'Pay Contacts' किंवा 'To Mobile Number' पर्यायावर दाबा.",
                "UPI_UI", "PAY_CONTACT",
                "Select Pay to Mobile Number in your UPI app.",
                "यूपीआई ऐप में मोबाइल नंबर पर भेजने का विकल्प चुनें।",
                "यूपीआय अॅपमध्ये मोबाईल नंबरवर पाठवण्याचा पर्याय निवडा.");

        DatabaseSeeder.insertStep(conn, l22, 2, "Select Family Member or Type Number", "परिवार का संपर्क चुनें या नंबर लिखें", "कुटुंबीयांचे नाव निवडा किंवा नंबर लिहा",
                "Select your son, daughter, or neighbor from your contact list, or type their 10-digit number carefully.",
                "अपने फोन की संपर्क सूची से बेटे-बेटी का नाम चुनें, या उनका 10 अंकों का नंबर ध्यान से टाइप करें।",
                "संपर्क यादीतून मुलांचे नाव निवडा किंवा त्यांचा १० अंकी नंबर काळजीपूर्वक लिहा.",
                "UPI_UI", "CONTACT_PICKER",
                "Pick the family contact or type their phone number.",
                "परिवार का संपर्क चुनें या मोबाइल नंबर लिखें।",
                "नातेवाईकांचे नाव निवडा किंवा नंबर टाईप करा.");

        DatabaseSeeder.insertStep(conn, l22, 3, "Verify Registered Bank Account Name", "बैंक में दर्ज नाम की जांच करें", "बँकेत नोंदवलेले नाव तपासा",
                "UPI will show their official bank account holder name on screen (e.g., 'Anita Sharma'). Check this carefully!",
                "ऐप उनके बैंक खाते में दर्ज असली नाम स्क्रीन पर दिखाएगा (जैसे 'अनिता शर्मा')। इसे ध्यान से पढ़ें!",
                "अॅप त्यांच्या बँकेत नोंदवलेले खरे नाव दाखवेल (उदा. 'अनिता शर्मा'). ते नाव नीट वाचा!",
                "UPI_UI", "NAME_VERIFIED",
                "Confirm that the recipient name matches who you intend to send money to.",
                "पुष्टि करें कि नाम वही है जिसे आप पैसे भेजना चाहते हैं।",
                "ज्यांना पैसे पाठवायचे आहेत त्यांचेच नाव आले आहे ना याची खात्री करा.");

        DatabaseSeeder.insertStep(conn, l22, 4, "Enter Amount and Secret UPI PIN", "रकम लिखें और गुप्त पिन डालें", "रक्कम लिहा आणि गुप्त पिन टाका",
                "Type the amount (e.g. ₹500). Tap 'Pay'. The secure black PIN screen appears. Enter your secret UPI PIN to complete.",
                "रकम लिखें (जैसे ₹500)। 'Pay' दबाएं। काली सुरक्षित स्क्रीन पर अपना गुप्त यूपीआई पिन डालें। पैसे तुरंत पहुंच जाएंगे!",
                "रक्कम लिहा (उदा. ₹५००). 'Pay' दाबा. सुरक्षित काळ्या पडद्यावर तुमचा गुप्त यूपीआय पिन टाका. पैसे लगेच पोहोचतील!",
                "UPI_UI", "ENTER_PIN",
                "Type the exact amount and enter your secret UPI PIN.",
                "रकम लिखकर अपना गुप्त यूपीआई पिन दर्ज करें।",
                "रक्कम लिहून आपला गुप्त यूपीआय पिन टाका.");

        DatabaseSeeder.insertQuiz(conn, l22, "What important confirmation does UPI show before you transfer money to a mobile number?",
                "मोबाइल नंबर पर पैसे भेजने से पहले यूपीआई स्क्रीन पर क्या जरूरी पुष्टि दिखाता है?",
                "मोबाईल नंबरवर पैसे पाठवण्यापूर्वी यूपीआय स्क्रीनवर कोणती महत्त्वाची खात्री दाखवतो?",
                "It fetches and shows the recipient's real bank account holder name to prevent sending to wrong numbers.",
                "यह सामने वाले व्यक्ति के बैंक खाते में दर्ज असली नाम दिखाता है ताकि गलत नंबर पर पैसे न जाएं।",
                "हे समोरच्या व्यक्तीच्या बँक खात्यातील खरे नाव दाखवते जेणेकरून चुकीच्या नंबरवर पैसे जाऊ नयेत.",
                new String[]{"The color of their house", "The verified bank account holder's real name", "Their height and weight", "Their favorite sweet"},
                new String[]{"उनके घर का रंग", "बैंक खातेदार का प्रमाणित असली नाम", "उनकी लंबाई और वजन", "उनकी पसंदीदा मिठाई"},
                new String[]{"त्यांच्या घराचा रंग", "बँकेत नोंदवलेले खरे नाव", "त्यांची उंची", "त्यांची आवडती मिठाई"}, 1);

        DatabaseSeeder.insertQuiz(conn, l22, "If you send ₹500 to your daughter via UPI, how long does it take to reach her bank account?",
                "यदि आप यूपीआई से अपनी बेटी को ₹500 भेजते हैं, तो उसके खाते में पैसे पहुंचने में कितना समय लगता है?",
                "जर तुम्ही मुलीला यूपीआयने ५०० रुपये पाठवले, तर तिच्या खात्यात पोहोचायला किती वेळ लागतो?",
                "UPI transfers happen instantly in real-time within 2 to 3 seconds, 24 hours a day.",
                "यूपीआई से पैसे तुरंत 2 से 3 सेकंड के अंदर 24 घंटे किसी भी दिन पहुंच जाते हैं।",
                "यूपीआयने पैसे २४ तास कोणत्याही दिवशी अवघ्या २ ते ३ सेकंदात लगेच जमा होतात.",
                new String[]{"3 to 5 working days", "Instantly in 2 to 3 seconds", "Only next Monday", "It takes 1 month"},
                new String[]{"3 से 5 कार्य दिवस", "तुरंत 2 से 3 सेकंड में", "अगले सोमवार को", "1 महीना लगता है"},
                new String[]{"३ ते ५ दिवस", "अवघ्या २ ते ३ सेकंदात लगेच", "पुढच्या सोमवारी", "१ महिना लागतो"}, 1);

        DatabaseSeeder.insertQuiz(conn, l22, "Should you ever enter your UPI PIN to RECEIVE money sent by your family?",
                "क्या परिवार द्वारा भेजे गए पैसे अपने खाते में पाने के लिए आपको अपना यूपीआई पिन डालना पड़ता है?",
                "कुटुंबीयांनी पाठवलेले पैसे आपल्या खात्यात येण्यासाठी यूपीआय पिन टाकावा लागतो का?",
                "NO! Never! Receiving money never requires typing a PIN. PIN is only for sending money out.",
                "बिल्कुल नहीं! पैसे आने पर कभी पिन नहीं डालना होता। पिन केवल पैसे भेजने के लिए होता है।",
                "मुळीच नाही! पैसे येण्यासाठी कधीही पिन टाकावा लागत नाही. पिन फक्त पैसे पाठवण्यासाठी असतो.",
                new String[]{"Yes, always enter PIN to receive", "NO! Receiving money NEVER requires entering your PIN", "Only for amounts above ₹100", "Only on holidays"},
                new String[]{"हां, पैसे पाने के लिए हमेशा पिन डालें", "नहीं! पैसे पाने के लिए कभी भी पिन नहीं डालना होता", "केवल ₹100 से ऊपर", "केवल छुट्टियों पर"},
                new String[]{"होय, पैसे मिळवण्यासाठी नेहमी पिन टाका", "नाही! पैसे मिळवण्यासाठी कधीही पिन टाकावा लागत नाही", "फक्त १०० रुपयांवर", "फक्त सुट्टीच्या दिवशी"}, 1);

        // L23: NEVER Share Your UPI PIN - Crucial Rules
        int l23 = DatabaseSeeder.insertLesson(conn, 23, 7, "NEVER Share Your UPI PIN - Crucial Rules", "यूपीआई पिन कभी किसी को न बताएं - जरूरी नियम", "यूपीआय पिन कोणालाही सांगू नका - महत्त्वाचे नियम",
                "The #1 Golden Rule of digital banking: Entering your PIN DEDUCTS money from your account!",
                "डिजिटल सुरक्षा का सबसे बड़ा नियम: यूपीआई पिन डालते ही आपके बैंक खाते से पैसे कटते हैं!",
                "डिजिटल सुरक्षिततेचा सर्वात मोठा नियम: यूपीआय पिन टाकताच तुमच्या खात्यातून पैसे वजा होतात!",
                "BEGINNER", 5, "UPI", 3,
                "• CRITICAL RULE: You only enter your UPI PIN when money LEAVES your bank account.\n• Receiving money NEVER requires entering your PIN or scanning a QR code.\n• Bank staff, police, or lottery callers will NEVER ask for your secret PIN.\n• Keep hand covered when typing PIN.",
                "• सबसे जरूरी नियम: यूपीआई पिन केवल तब डलता है जब पैसे आपके खाते से बाहर जा रहे हों।\n• पैसे प्राप्त करने के लिए कभी पिन नहीं डालना होता और न ही क्यूआर कोड स्कैन करना होता है।\n• बैंक अधिकारी या पुलिस कभी फोन पर पिन नहीं पूछते।\n• पिन डालते समय स्क्रीन को हाथ से छिपाकर रखें।",
                "• सर्वात महत्त्वाचा नियम: यूपीआय पिन फक्त तेव्हाच टाकला जातो जेव्हा खात्यातून पैसे बाहेर जायचे असतात.\n• पैसे येण्यासाठी कधीही पिन टाकावा लागत नाही किंवा क्यूआर कोड स्कॅन करावा लागत नाही.\n• बँक मॅनेजर किंवा पोलीस कधीही फोनवर पिन मागत नाहीत.\n• पिन टाकताना स्क्रीन हाताने झाकून ठेवा.");

        DatabaseSeeder.insertStep(conn, l23, 1, "The Golden Rule: PIN is ONLY for Sending", "स्वर्ण नियम: पिन केवल पैसे भेजने के लिए है", "सुवर्ण नियम: पिन फक्त पैसे पाठवण्यासाठी आहे",
                "Remember this by heart: You only enter your UPI PIN when you want money to LEAVE your bank account.",
                "यह बात गांठ बांध लें: यूपीआई पिन केवल तभी डाला जाता है जब आप किसी को पैसे भेज रहे हों और आपके बैंक से पैसे कटने हों।",
                "ही गोष्ट मनावर ठसवा: यूपीआय पिन फक्त तेव्हाच टाकायचा असतो जेव्हा तुम्हाला स्वतःच्या खात्यातून पैसे बाहेर पाठवायचे असतात.",
                "WARNING_BOX", "PIN_RULE_1",
                "Entering your secret UPI PIN always deducts money from your bank account.",
                "यूपीआई पिन डालते ही हमेशा आपके बैंक खाते से पैसे कटते हैं।",
                "यूपीआय पिन टाकताच नेहमी तुमच्या बँक खात्यातून पैसे वजा होतात.");

        DatabaseSeeder.insertStep(conn, l23, 2, "The 'Receive Money' Scam Trap", "पैसे भेजने का झांसा देने वाले फ्रॉड से बचें", "पैसे मिळण्याचे आमिष दाखवणाऱ्या फसवणुकीपासून सावध",
                "Scammers call: 'Sir, enter your PIN to claim ₹25,000 lottery / pension / refund'. IT IS A TRAP! The moment you enter your PIN, your money is stolen.",
                "धोखेबाज कहते हैं: 'पेंशन या लॉटरी का पैसा लेने के लिए पिन डालें'। यह धोखा है! जैसे ही आप पिन डालेंगे, आपके खाते के पैसे उड़ जाएंगे।",
                "फसवे लोक म्हणतात: 'पेन्शन किंवा बक्षीस खात्यात येण्यासाठी पिन टाका'. ही मोठी फसवणूक आहे! पिन टाकताच तुमचेच पैसे चोरीला जातात.",
                "WARNING_BOX", "PIN_RULE_2",
                "Receiving money NEVER requires your UPI PIN. If anyone asks you to enter PIN to receive money, hang up!",
                "पैसे आने के लिए कभी पिन की जरूरत नहीं होती। जो भी पैसे लेने के लिए पिन मांगे, तुरंत फोन काटें!",
                "पैसे मिळण्यासाठी कधीही पिनची गरज नसते. कोणीही पैसे मिळण्यासाठी पिन मागितल्यास लगेच फोन कट करा!");

        DatabaseSeeder.insertStep(conn, l23, 3, "Never Scan a QR Code to Receive Money", "पैसे लेने के लिए कभी क्यूआर कोड स्कैन न करें", "पैसे मिळण्यासाठी कधीही क्यूआर कोड स्कॅन करू नका",
                "If a buyer on OLX or WhatsApp sends a QR code and says: 'Scan this to receive payment', DO NOT SCAN IT. Scanning a QR code only pays money.",
                "अगर कोई कहे कि 'पैसे लेने के लिए यह क्यूआर कोड स्कैन करें', तो कभी स्कैन न करें। क्यूआर कोड से केवल पैसे जाते हैं, आते नहीं।",
                "जर कोणी व्हॉट्सअॅपवर क्यूआर कोड पाठवून म्हणाला 'पैसे घेण्यासाठी हा कोड स्कॅन करा', तर मुळीच करू नका. क्यूआर कोडने फक्त पैसे जातात.",
                "WARNING_BOX", "QR_SCAM",
                "Never scan a QR code to receive money. Scanning a QR always initiates an outgoing payment.",
                "पैसे लेने के लिए कभी क्यूआर कोड स्कैन न करें।",
                "पैसे घेण्यासाठी कधीही क्यूआर कोड स्कॅन करू नका.");

        DatabaseSeeder.insertStep(conn, l23, 4, "Bank Officials NEVER Ask for PIN or OTP", "बैंक कभी फोन पर पिन या ओटीपी नहीं मांगता", "बँक कधीही फोनवर पिन किंवा ओटीपी मागत नाही",
                "SBI, HDFC, Post Office, or RBI staff will NEVER call to ask for your secret PIN or OTP. If someone asks, they are a thief.",
                "एसबीआई या डाकघर का कोई भी कर्मचारी कभी फोन पर आपका पिन या ओटीपी नहीं मांगता। जो भी मांगे, वह पक्का चोर है।",
                "स्टेट बँक किंवा पोस्टाचे अधिकारी कधीही फोनवर तुमचा पिन किंवा ओटीपी मागत नाहीत. जो कोणी मागेल, तो लबाड आहे.",
                "WARNING_BOX", "NEVER_SHARE",
                "Never reveal your PIN or OTP to anyone, even someone claiming to be a bank manager.",
                "बैंक मैनेजर बनकर फोन करने वाले को भी कभी अपना पिन या ओटीपी न बताएं।",
                "बँक मॅनेजर सांगणाऱ्यालाही आपला पिन किंवा ओटीपी कधीही सांगू नका.");

        DatabaseSeeder.insertQuiz(conn, l23, "When do you ever need to enter your secret UPI PIN to RECEIVE money in your bank account?",
                "अपने बैंक खाते में पैसे प्राप्त करने या लेने के लिए आपको अपना यूपीआई पिन कब डालना पड़ता है?",
                "आपल्या बँक खात्यात पैसे जमा होण्यासाठी यूपीआय पिन कधी टाकावा लागतो?",
                "NEVER! Money is received into your account automatically without typing any PIN.",
                "कभी नहीं! पैसे हमेशा अपने आप सीधे खाते में आ जाते हैं, इसके लिए कोई पिन नहीं डालना होता।",
                "कधीही नाही! पैसे आपोआप खात्यात जमा होतात, त्यासाठी कोणताही पिन टाकावा लागत नाही.",
                new String[]{"Whenever someone transfers money to you", "Only for amounts above ₹500", "NEVER! You never enter a PIN to receive money", "Only on bank holidays"},
                new String[]{"जब भी कोई पैसे भेजे", "केवल ₹500 से ऊपर की रकम पर", "कभी नहीं! पैसे लेने के लिए कभी पिन नहीं डालना होता", "केवल रविवार को"},
                new String[]{"जेव्हा कोणी पैसे पाठवतो", "फक्त ५०० रुपयांपेक्षा जास्त रकमेवर", "कधीही नाही! पैसे येण्यासाठी कधीही पिन टाकावा लागत नाही", "फक्त सुट्टीच्या दिवशी"}, 2);

        DatabaseSeeder.insertQuiz(conn, l23, "A caller says: 'Sir, your pension refund of ₹12,000 is ready, just scan this QR code and enter your PIN'. What should you do?",
                "कोई फोन करके कहे: 'आपकी ₹12,000 की पेंशन का रिफंड आया है, यह क्यूआर कोड स्कैन करके पिन डालें'। आपको क्या करना चाहिए?",
                "फोन आला की: 'तुमचा पेन्शन परतावा १२,००० रुपये आला आहे, हा क्यूआर कोड स्कॅन करून पिन टाका'. तुम्ही काय करावे?",
                "Hang up immediately! It is a dangerous scam. Entering PIN will deduct your own hard-earned money.",
                "तुरंत फोन काट दें! यह भयानक फ्रॉड है। पिन डालते ही आपके खाते से पैसे कट जाएंगे।",
                "लगेच फोन कट करा! ही मोठी फसवणूक आहे. पिन टाकताच तुमचेच पैसे कापले जातील.",
                new String[]{"Quickly scan and enter PIN to get ₹12,000", "Hang up immediately! It is a scam trick to steal your money", "Tell them your ATM card number", "Forward the call to neighbors"},
                new String[]{"पैसे पाने के लिए जल्दी से स्कैन करके पिन डालें", "तुरंत फोन काटें! यह पैसे चुराने का खतरनाक फ्रॉड है", "उन्हें एटीएम कार्ड का नंबर बताएं", "पड़ोसियों को फोन दें"},
                new String[]{"पैसे मिळवण्यासाठी लगेच स्कॅन करून पिन टाका", "लगेच फोन कट करा! ही पैसे लुटण्याची फसवणूक आहे", "त्यांना एटीएम कार्डचा नंबर सांगा", "शेजाऱ्यांना फोन द्या"}, 1);

        DatabaseSeeder.insertQuiz(conn, l23, "What should you do while entering your UPI PIN or ATM PIN in a public shop?",
                "दुकान या एटीएम में अपना यूपीआई पिन या एटीएम पिन डालते समय क्या सावधानी रखनी चाहिए?",
                "दुकानात किंवा एटीएममध्ये पिन टाकताना कोणती काळजी घ्यावी?",
                "Always cover the screen or keypad with your other hand so nobody can peek at your numbers.",
                "हमेशा दूसरे हाथ से स्क्रीन या कीपैड को छिपा लें ताकि कोई आपके गुप्त नंबर न देख सके।",
                "दुसऱ्या हाताने स्क्रीन किंवा कीपॅड झाकून ठेवावा जेणेकरून कोणालाही नंबर दिसणार नाही.",
                new String[]{"Shout the PIN loudly to the shopkeeper", "Cover the keypad or screen with your free hand to keep it private", "Write the PIN on the shop counter", "Show it to strangers in queue"},
                new String[]{"दुकानदार को जोर से बोलकर बताएं", "स्क्रीन या कीपैड को दूसरे हाथ से छिपाकर रखें", "दुकान के काउंटर पर लिख दें", "लाइन में खड़े लोगों को दिखाएं"},
                new String[]{"दुकानदाराला मोठ्याने ओरडून सांगा", "स्क्रीन किंवा कीपॅड दुसऱ्या हाताने झाकून गुप्त ठेवा", "काउंटरवर लिहून ठेवा", "रांगेतील लोकांना दाखवा"}, 1);

        // L24: Checking Bank Balance on UPI Safely
        int l24 = DatabaseSeeder.insertLesson(conn, 24, 7, "Checking Bank Balance on UPI Safely", "यूपीआई पर बैंक बैलेंस जांचना", "यूपीआयवर बँक शिल्लक सुरक्षित तपासणे",
                "Check your bank account balance anytime from home without standing in bank queues.",
                "बैंक की लंबी लाइन में लगे बिना घर बैठे कभी भी अपने खाते की जमा रकम देखना सीखें।",
                "बँकेच्या रांगेत उभे न राहता घरबसल्या कधीही खात्यातील जमा शिल्लक तपासणे शिका.",
                "BEGINNER", 4, "UPI", 4,
                "• Open PhonePe or Google Pay.\n• Tap 'Check Bank Balance'.\n• Select your bank account.\n• Enter your secret UPI PIN.\n• View balance on screen peacefully.",
                "• फोनपे या गूगल पे खोलें।\n• 'Check Bank Balance' पर टैप करें।\n• अपना बैंक खाता चुनें।\n• अपना गुप्त यूपीआई पिन दर्ज करें।\n• खाते का बैलेंस स्क्रीन पर आराम से देखें।",
                "• PhonePe किंवा Google Pay उघडा.\n• 'Check Bank Balance' वर दाबा.\n• आपले बँक खाते निवडा.\n• आपला गुप्त यूपीआय पिन टाका.\n• खात्यातील शिल्लक शांतपणे पहा.");

        DatabaseSeeder.insertStep(conn, l24, 1, "Tap 'Check Bank Balance'", "'Check Balance' पर टैप करें", "'Check Balance' वर दाबा",
                "On the home screen of PhonePe or Google Pay, tap the button with a small bank icon labeled 'Check Bank Balance'.",
                "फोनपे या गूगल पे की मुख्य स्क्रीन पर छोटे बैंक वाले निशान 'Check Bank Balance' पर टैप करें।",
                "PhonePe किंवा Google Pay च्या मुख्य स्क्रीनवर 'Check Bank Balance' या चिन्हावर दाबा.",
                "UPI_UI", "BALANCE_BTN",
                "Tap Check Bank Balance on your payment app home screen.",
                "पेमेंट ऐप में चेक बैंक बैलेंस बटन दबाएं।",
                "पेमेंट अॅपमध्ये चेक बँक बॅलन्स बटणावर दाबा.");

        DatabaseSeeder.insertStep(conn, l24, 2, "Select Your Bank Account", "अपना बैंक खाता चुनें", "आपले बँक खाते निवडा",
                "Tap your registered bank name (e.g. 'State Bank of India - 4210').",
                "अपने बैंक खाते के नाम पर टैप करें (जैसे 'भारतीय स्टेट बैंक - 4210')।",
                "आपल्या बँकेच्या नावावर दाबा (उदा. 'स्टेट बँक ऑफ इंडिया - ४२१०').",
                "UPI_UI", "BANK_LIST",
                "Select the bank account whose balance you wish to verify.",
                "जिस खाते का बैलेंस देखना है उस बैंक पर टैप करें।",
                "ज्या खात्याची शिल्लक पाहायची आहे त्यावर दाबा.");

        DatabaseSeeder.insertStep(conn, l24, 3, "Enter Your Secret UPI PIN", "अपना गुप्त यूपीआई पिन डालें", "आपला गुप्त यूपीआय पिन टाका",
                "A secure black keypad appears. Enter your secret 4 or 6 digit UPI PIN carefully. (No money is deducted!).",
                "काली सुरक्षित स्क्रीन आएगी। अपना 4 या 6 अंकों का यूपीआई पिन डालें। (बैलेंस देखने में कोई पैसा नहीं कटता!)।",
                "सुरक्षित काळा पडदा येईल. आपला ४ किंवा ६ अंकी यूपीआय पिन काळजीपूर्वक टाका. (पैसे कटत नाहीत!).",
                "UPI_UI", "SECURE_PIN",
                "Enter your secret UPI PIN on the secure black screen.",
                "सुरक्षित ब्लैक स्क्रीन पर अपना गुप्त यूपीआई पिन डालें।",
                "सुरक्षित काळ्या स्क्रीनवर आपला गुप्त यूपीआय पिन टाका.");

        DatabaseSeeder.insertStep(conn, l24, 4, "View Your Balance Comfortably", "स्क्रीन पर अपना बैलेंस देखें", "स्क्रीनवर आपली शिल्लक पहा",
                "Your available balance is displayed clearly (e.g. 'Available Balance: ₹18,450.00'). Tap Done to exit.",
                "आपके खाते में जमा कुल रकम साफ-साफ दिखेगी (जैसे 'उपलब्ध बैलेंस: ₹18,450')। काम होने पर Done दबाएं।",
                "तुमच्या खात्यातील शिल्लक रक्कम स्पष्ट दिसेल (उदा. 'शिल्लक: ₹१८,४५०'). काम झाल्यावर Done दाबा.",
                "UPI_UI", "BALANCE_DISPLAY",
                "Your verified bank balance is displayed safely on screen.",
                "आपके बैंक का बैलेंस स्क्रीन पर सुरक्षित रूप से दिखाई देता है।",
                "आपल्या बँकेची शिल्लक स्क्रीनवर सुरक्षितपणे दिसते.");

        DatabaseSeeder.insertQuiz(conn, l24, "Does checking your bank account balance through UPI cost any bank fees or service charges?",
                "क्या यूपीआई पर बैंक बैलेंस देखने से कोई चार्ज या फीस कटती है?",
                "यूपीआयवर बँक शिल्लक तपासल्याने काही पैसे किंवा फी कापली जाते का?",
                "No! Checking your bank balance on UPI is completely free at all times.",
                "बिल्कुल नहीं! यूपीआई पर अपना बैंक बैलेंस देखना पूरी तरह मुफ्त और असीमित है।",
                "मुळीच नाही! यूपीआयवर बँकेची शिल्लक पाहणे पूर्णपणे मोफत असते.",
                new String[]{"Yes, ₹5 per check", "No, it is completely free at all times", "Only if checked on Sundays", "Only after 5:00 PM"},
                new String[]{"हां, हर बार ₹5 कटते हैं", "नहीं, यह हमेशा पूरी तरह मुफ्त है", "केवल रविवार को चार्ज लगता है", "केवल शाम 5 बजे के बाद"},
                new String[]{"होय, प्रत्येक वेळी ५ रुपये", "नाही, हे नेहमी पूर्णपणे मोफत असते", "फक्त रविवारी पैसे लागतात", "फक्त संध्याकाळी ५ नंतर"}, 1);

        DatabaseSeeder.insertQuiz(conn, l24, "Why is checking balance on your smartphone so helpful after receiving your monthly pension?",
                "हर महीने पेंशन आने के बाद मोबाइल पर बैलेंस देखना वरिष्ठ नागरिकों के लिए क्यों सुविधाजनक है?",
                "दरमहा पेन्शन आल्यावर मोबाईलवर शिल्लक तपासणे वृद्धांसाठी का सोयीचे आहे?",
                "You can verify that pension arrived safely from the comfort of home without waiting in long bank queues.",
                "बैंक की लंबी लाइनों में खड़े हुए बिना घर बैठे ही पता चल जाता है कि पेंशन का पैसा आ गया है।",
                "बँकेच्या लांबलचक रांगेत तासनतास उभे न राहता घरी बसूनच समजते की पेन्शन जमा झाली आहे.",
                new String[]{"It prints cash automatically", "You can verify pension arrived from home without standing in bank queues", "It increases your pension by 50%", "It buys groceries automatically"},
                new String[]{"यह अपने आप नोट छापता है", "बैंक की लाइन में खड़े बिना घर बैठे पेंशन आने की पुष्टि हो जाती है", "पेंशन 50% बढ़ा देता है", "अपने आप राशन खरीदता है"},
                new String[]{"हे आपोआप नोटा छापते", "बँकेच्या रांगेत उभे न राहता घरी बसून खात्री करता येते", "पेन्शन ५०% वाढवते", "आपोआप किराणा खरेदी करतो"}, 1);

        DatabaseSeeder.insertQuiz(conn, l24, "Is money deducted from your bank account when you enter your UPI PIN to check balance?",
                "क्या बैंक बैलेंस चेक करते समय यूपीआई पिन डालने पर खाते से कोई पैसा कटता है?",
                "बँक शिल्लक तपासताना यूपीआय पिन टाकल्यास खात्यातून पैसे कटतात का?",
                "No! When checking balance, your PIN is only used to verify your identity to show your balance.",
                "नहीं! बैलेंस देखते समय पिन केवल आपकी पहचान प्रमाणित करने के लिए होता है, कोई पैसा नहीं कटता।",
                "नाही! शिल्लक तपासताना पिन फक्त आपली ओळख पटवण्यासाठी असतो, पैसे मुळीच कटत नाहीत.",
                new String[]{"Yes, ₹100 is deducted", "No, checking balance never deducts any money from your bank account", "Half of your balance is lost", "Money goes to the post office"},
                new String[]{"हां, ₹100 कट जाते हैं", "नहीं, बैलेंस देखने से आपके खाते से एक भी रुपया नहीं कटता", "आधा पैसा कट जाता है", "पैसा डाकघर चला जाता है"},
                new String[]{"होय, १०० रुपये कटतात", "नाही, शिल्लक तपासताना एकही रुपया कटत नाही", "अर्धे पैसे जातात", "पैसे पोस्टात जातात"}, 1);
    }

    // ==========================================
    // CAT 8: BANKING & SAFETY (Lessons 25 - 27)
    // ==========================================
    private static void seedCat8Banking(Connection conn) throws Exception {
        // L25: Understanding Bank SMS Alerts & Statements
        int l25 = DatabaseSeeder.insertLesson(conn, 25, 8, "Understanding Bank SMS Alerts & Statements", "बैंक के असली एसएमएस और खाते का हिसाब", "बँकेचे खरे एसएमएस आणि खात्याचा हिशोब",
                "Distinguish official bank transaction alerts from fake phishing threats.",
                "बैंक के असली मैसेज की पहचान करें और धोखाधड़ी वाले धमकी भरे एसएमएस से सावधान रहें।",
                "बँकेचे खरे मेसेज ओळखणे आणि धमकावणाऱ्या खोट्या एसएमएसपासून सावध राहणे शिका.",
                "BEGINNER", 5, "NONE", 1,
                "• Official bank SMS comes from sender codes like 'VK-SBINB' or 'AD-HDFCBK' (never 10-digit mobile numbers).\n• 'Credited' means money arrived (+); 'Debited' means money spent (-).\n• If you see an unknown debit, call your bank branch immediately.",
                "• बैंक के असली एसएमएस 10 अंकों के मोबाइल नंबर से नहीं, बल्कि 'VK-SBINB' जैसे सरकारी कोड से आते हैं।\n• 'Credited' का मतलब पैसा आया (+); 'Debited' का मतलब पैसा कटा (-)।\n• अनजान कटौती दिखने पर तुरंत बैंक को सूचित करें।",
                "• बँकेचे खरे एसएमएस १० अंकी मोबाईल नंबरवरून येत नाहीत, तर 'VK-SBINB' सारख्या अधिकृत कोडवरून येतात.\n• 'Credited' म्हणजे पैसे जमा झाले (+); 'Debited' म्हणजे पैसे खर्च झाले (-).\n• संशयास्पद पैशांची कपात दिसल्यास लगेच बँकेशी संपर्क साधा.");

        DatabaseSeeder.insertStep(conn, l25, 1, "Official Bank Sender Codes", "बैंक के आधिकारिक सेंडर कोड पहचानें", "बँकेचे अधिकृत सेंडर कोड ओळखा",
                "Official SMS from State Bank, PNB, or HDFC always arrives from 6-letter official codes like 'AX-SBINB'. Scammers use random 10-digit mobile numbers (+91-98...).",
                "बैंक के असली संदेश कभी भी 10 अंकों के आम मोबाइल नंबर से नहीं आते। उनके ऊपर 'VK-SBINB' या 'AD-BOBINB' लिखा होता है।",
                "बँकेचे खरे मेसेज कधीही साध्या १० अंकी मोबाईल नंबरवरून येत नाहीत. त्यावर 'VK-SBINB' किंवा 'AD-HDFCBK' असा अधिकृत कोड असतो.",
                "PHONE_UI", "BANK_SMS",
                "Official bank SMS alerts come from registered alphanumeric sender IDs.",
                "बैंक के असली मैसेज रजिस्टर्ड कोड से आते हैं, आम नंबरों से नहीं।",
                "बँकेचे खरे मेसेज अधिकृत कोडवरून येतात, साध्या मोबाईल नंबरवरून नाही.");

        DatabaseSeeder.insertStep(conn, l25, 2, "Credited vs Debited: The Meaning", "Credited और Debited का सही मतलब", "Credited आणि Debited चा खरा अर्थ",
                "'Credited' means money has been deposited into your account (e.g. Pension arrived +). 'Debited' means money was spent or withdrawn (-).",
                "'Credited' का मतलब है कि आपके खाते में पैसा आया है (जैसे पेंशन जमा +)। 'Debited' का मतलब है कि आपके खाते से पैसा निकला है (-)।",
                "'Credited' चा अर्थ खात्यात पैसे जमा झाले असा होतो (उदा. पेन्शन आली +). 'Debited' चा अर्थ खात्यातून पैसे खर्च झाले असा होतो (-).",
                "PHONE_UI", "CREDIT_DEBIT",
                "Credited means money arrived into your account. Debited means money was withdrawn.",
                "क्रेडिटेड मतलब पैसा आया, डेबिटेड मतलब पैसा कटा।",
                "क्रेडिटेड म्हणजे पैसे आले, डेबिटेड म्हणजे पैसे गेले.");

        DatabaseSeeder.insertStep(conn, l25, 3, "Spotting Fake SMS Threats", "धमकी भरे फर्जी एसएमएस पहचानें", "धमकावणारे बनावट मेसेज ओळखा",
                "Scam SMS: 'Dear customer, your bank account is blocked today. Call 9876543210 immediately to update KYC'. REAL BANKS NEVER SEND THESE!",
                "फर्जी मैसेज: 'आपका खाता आज रात बंद हो जाएगा, तुरंत इस नंबर पर फोन करके केवाईसी करें'। याद रखें: असली बैंक कभी ऐसे धमकी भरे मैसेज नहीं भेजता!",
                "बनावट मेसेज: 'तुमचे खाते आज बंद होईल, केवायसी करण्यासाठी या नंबरवर फोन करा'. लक्षात ठेवा: बँक कधीही असे धमकीचे मेसेज पाठवत नाही!",
                "WARNING_BOX", "FAKE_SMS",
                "Real banks never threaten immediate account suspension via random 10-digit phone numbers.",
                "असली बैंक कभी मोबाइल नंबर देकर खाता बंद करने की धमकी नहीं देता।",
                "खऱ्या बँका कधीही मोबाईल नंबर देऊन खाते बंद करण्याची धमकी देत नाहीत.");

        DatabaseSeeder.insertStep(conn, l25, 4, "What to Do If an Unknown Debit Happens", "अनजान कटौती दिखने पर क्या करें", "अनोळखी कपात दिसल्यास काय करावे",
                "If you receive an SMS showing money debited that you did not spend, immediately call the official toll-free number on the back of your passbook or bank card.",
                "अगर ऐसा मैसेज आए जिसमें पैसे कटने का जिक्र हो जो आपने खर्च नहीं किए, तो तुरंत अपनी पासबुक के पीछे लिखे बैंक के असली नंबर पर फोन करके खाता लॉक कराएं।",
                "जर न केलेल्या खर्चाचा मेसेज आला, तर पासबुकच्या मागे असलेल्या बँकेच्या अधिकृत टोल-फ्री नंबरवर फोन करून तात्काळ कार्ड ब्लॉक करा.",
                "PHONE_UI", "BANK_HELP",
                "Call the official toll-free helpline on your passbook immediately to report unauthorized transactions.",
                "पासबुक पर लिखे बैंक के असली नंबर पर तुरंत फोन करें।",
                "पासबुकवरील बँकेच्या अधिकृत नंबरवर लगेच संपर्क साधा.");

        DatabaseSeeder.insertQuiz(conn, l25, "In a bank transaction SMS, what does the word 'Credited' indicate?",
                "बैंक के एसएमएस में 'Credited' शब्द का क्या अर्थ होता है?",
                "बँकेच्या एसएमएसमध्ये 'Credited' शब्दाचा काय अर्थ होतो?",
                "'Credited' means money has been deposited into your bank account.",
                "'Credited' का मतलब है कि आपके बैंक खाते में पैसा जमा हुआ है।",
                "'Credited' म्हणजे तुमच्या बँक खात्यात पैसे जमा झाले आहेत.",
                new String[]{"Money was deducted from your account", "Money was deposited into your account (+)", "Your account has been deleted", "You owe money to the bank"},
                new String[]{"खाते से पैसे कट गए हैं", "खाते में पैसा जमा हुआ है (+)", "खाता मिटा दिया गया है", "आपको बैंक का कर्ज चुकाना है"},
                new String[]{"खात्यातून पैसे कापले गेले", "खात्यात पैसे जमा झाले (+)", "खाते बंद झाले", "बँकेचे देणे आहे"}, 1);

        DatabaseSeeder.insertQuiz(conn, l25, "If an SMS claims your bank account is suspended and asks you to call a 10-digit mobile number, what should you do?",
                "अगर कोई एसएमएस कहे कि आपका बैंक खाता ब्लॉक हो गया है और 10 अंकों के मोबाइल नंबर पर फोन करने को कहे, तो क्या करना चाहिए?",
                "जर मेसेज आला की बँक खाते बंद झाले आहे आणि १० अंकी मोबाईल नंबरवर कॉल करा, तर काय करावे?",
                "Never call numbers from suspicious SMS. Visit your local bank branch directly with your passbook.",
                "उस नंबर पर कभी फोन न करें। अपनी पासबुक लेकर सीधे अपनी बैंक शाखा जाएं या बच्चों को बताएं।",
                "त्या नंबरवर कधीही फोन करू नका. पासबुक घेऊन थेट आपल्या बँकेच्या शाखेत जा किंवा मुलांना सांगा.",
                new String[]{"Call the number immediately and share your OTP", "Ignore the SMS and consult your family or visit branch with passbook", "Send them money immediately", "Forward the message to 20 people"},
                new String[]{"तुरंत उस नंबर पर फोन करके ओटीपी बताएं", "मैसेज को नजरअंदाज करें और पासबुक लेकर बैंक शाखा जाएं", "उन्हें पैसे भेज दें", "20 लोगों को फॉरवर्ड करें"},
                new String[]{"लगेच फोन करून ओटीपी सांगा", "मेसेजकडे दुर्लक्ष करा आणि पासबुक घेऊन बँकेत जा", "पैसे पाठवून द्या", "२० जणांना फॉरवर्ड करा"}, 1);

        DatabaseSeeder.insertQuiz(conn, l25, "How can you tell an official bank SMS apart from a fraudster's message?",
                "बैंक के असली एसएमएस और धोखेबाज के फर्जी मैसेज में क्या सबसे बड़ा फर्क होता है?",
                "बँकेच्या खऱ्या मेसेजमध्ये आणि फसव्या मेसेजमध्ये सर्वात मोठा फरक कोणता?",
                "Official bank SMS comes from verified sender headers (like SBINB), never an ordinary 10-digit mobile number.",
                "असली बैंक मैसेज के ऊपर बैंक का रजिस्टर्ड कोड (जैसे SBINB) होता है, आम 10 अंकों का मोबाइल नंबर नहीं।",
                "खऱ्या बँकेच्या मेसेजवर बँकेचा अधिकृत कोड (उदा. SBINB) असतो, कोणताही साधा मोबाईल नंबर नसतो.",
                new String[]{"Official SMS comes from recognized bank sender IDs (like SBINB), not random 10-digit mobile numbers", "Official SMS is written in red color", "Official SMS plays music", "There is no difference at all"},
                new String[]{"असली एसएमएस 10 अंकों के नंबर से नहीं, बैंक के नाम वाले कोड (जैसे SBINB) से आता है", "असली एसएमएस लाल रंग में लिखा होता है", "असली एसएमएस गाना बजाता है", "कोई फर्क नहीं होता"},
                new String[]{"खरा मेसेज १० अंकी नंबरवरून येत नाही, तर अधिकृत कोडवरून (उदा. SBINB) येतो", "खरा मेसेज लाल अक्षरात असतो", "खरा मेसेज गाणे वाजवतो", "काहीच फरक नसतो"}, 0);

        // L26: ATM Card Safety & Keypad Privacy
        int l26 = DatabaseSeeder.insertLesson(conn, 26, 8, "ATM Card Safety & Keypad Privacy", "एटीएम कार्ड की सुरक्षा और सावधानी", "एटीएम कार्डची सुरक्षा आणि दक्षता",
                "Withdraw pension safely from ATM machines and protect your secret 4-digit PIN.",
                "एटीएम मशीन से सुरक्षित पेंशन निकालना और 4 अंकों का गुप्त एटीएम पिन बचाना सीखें।",
                "एटीएम मशीनमधून सुरक्षित पैसे काढणे आणि ४ अंकी गुप्त एटीएम पिन सुरक्षित ठेवणे शिका.",
                "BEGINNER", 4, "NONE", 2,
                "• Cover the keypad with your free hand while typing your 4-digit ATM PIN.\n• Never take help from strangers in the ATM room.\n• Always collect your card and cash before leaving.\n• Never write your PIN on the card.",
                "• एटीएम पिन डालते समय दूसरे हाथ से कीपैड को छिपाएं।\n• एटीएम रूम में खड़े किसी अनजान व्यक्ति से मदद न लें।\n• जाने से पहले अपना कार्ड और नकदी जरूर लें।\n• कार्ड पर कभी भी पिन लिखकर न रखें।",
                "• एटीएम पिन टाकताना दुसऱ्या हाताने कीपॅड झाकून ठेवा.\n• एटीएम रूममधील अनोळखी व्यक्तीची मदत घेऊ नका.\n• निघण्यापूर्वी आपले कार्ड आणि रोख पैसे आठवणीने घ्या.\n• कार्डवर कधीही पिन लिहून ठेवू नका.");

        DatabaseSeeder.insertStep(conn, l26, 1, "Cover the Keypad with Your Free Hand", "दूसरे हाथ से कीपैड को छिपाएं", "दुसऱ्या हाताने कीपॅड झाकून ठेवा",
                "When you insert your debit card and type your secret 4-digit PIN, hold your wallet or free hand right above the keypad. Prevents hidden cameras from seeing.",
                "एटीएम में कार्ड डालकर जब आप 4 अंकों का गुप्त पिन दबाएं, तो दूसरे हाथ या पर्स से कीपैड को ऊपर से ढक लें। इससे कोई गुप्त कैमरा आपके नंबर नहीं देख पाता।",
                "एटीएममध्ये ४ अंकी पिन टाकताना दुसऱ्या हाताने किंवा पाकिटाने कीपॅड वरून झाका. यामुळे कोणताही छुपा कॅमेरा तुमचा पिन पाहू शकणार नाही.",
                "PHONE_UI", "ATM_SAFETY",
                "Shield the keypad with your other hand while typing your 4-digit ATM PIN.",
                "एटीएम पिन डालते समय कीपैड को हाथ से ढंक कर रखें।",
                "एटीएम पिन टाकताना कीपॅड हाताने झाकून ठेवा.");

        DatabaseSeeder.insertStep(conn, l26, 2, "Never Ask Strangers in the Queue to Help", "लाइन में खड़े अनजान लोगों से मदद न लें", "रांगेतील अनोळखी व्यक्तींची मदत घेऊ नका",
                "If the machine screen is confusing, cancel the transaction. Never hand your card and tell your secret PIN to a stranger in the queue. They can swap your card!",
                "अगर मशीन में कोई परेशानी आए, तो 'Cancel' दबाकर बाहर आ जाएं। लाइन में खड़े किसी अनजान व्यक्ति को अपना कार्ड और पिन कभी न दें। वे कार्ड बदल लेते हैं!",
                "काही अडचण आल्यास 'Cancel' दाबून बाहेर या. रांगेतील अनोळखी व्यक्तीला कार्ड आणि पिन देऊ नका. ते कार्ड बदलून फसवणूक करू शकतात!",
                "WARNING_BOX", "STRANGER_DANGER",
                "Never accept help or reveal your ATM PIN to helpful-looking strangers in the ATM booth.",
                "एटीएम के अंदर किसी भी अनजान व्यक्ति से मदद न लें।",
                "एटीएममध्ये अनोळखी व्यक्तीची मदत कधीही घेऊ नका.");

        DatabaseSeeder.insertStep(conn, l26, 3, "Collect Cash and Retrieve Your Card", "नकदी और अपना कार्ड लेना न भूलें", "पैसे आणि कार्ड घ्यायला विसरू नका",
                "Collect the cash dispensed, wait for the green slot to flash, and pull out your ATM card. Check your name printed on the card.",
                "पैसे निकलते ही गिने, फिर हरी लाइट जलने पर अपना कार्ड बाहर निकालें। कार्ड पर अपना नाम जरूर देखें कि आपका ही कार्ड है।",
                "पैसे घ्या, हिरवा दिवा लागताच आपले कार्ड बाहेर काढा. कार्डवर स्वतःचे नाव तपासा.",
                "PHONE_UI", "COLLECT_CASH",
                "Always ensure you take your ATM card back before walking away from the machine.",
                "मशीन से निकलने से पहले अपना कार्ड लेना कभी न भूलें।",
                "मशीन सोडण्यापूर्वी आपले कार्ड परत घ्यायला विसरू नका.");

        DatabaseSeeder.insertStep(conn, l26, 4, "Never Write Your PIN on the Card", "कार्ड पर कभी भी पिन न लिखें", "कार्डवर कधीही पिन लिहू नका",
                "Never write your 4-digit PIN on the card with a pen, or on a piece of paper in your wallet. If the wallet is lost, money can be stolen easily.",
                "कार्ड पर पेन से कभी भी अपना पिन न लिखें, और न ही पर्स में पर्ची पर लिखकर रखें। अगर पर्स खो गया तो सारे पैसे निकाले जा सकते हैं।",
                "कार्डवर पेनने किंवा कागदाच्या तुकड्यावर पिन लिहून पाकिटात ठेवू नका. पाकीट हरवल्यास पैसे चोरीला जाऊ शकतात.",
                "WARNING_BOX", "NO_PIN_WRITE",
                "Never write down your secret PIN on your card or keep it inside your wallet.",
                "कार्ड या पर्स में कभी भी अपना पिन लिखकर न रखें।",
                "कार्डवर किंवा पाकिटात पिन लिहून ठेवणे टाळा.");

        DatabaseSeeder.insertQuiz(conn, l26, "Why should you cover the ATM keypad with your free hand while typing your secret PIN?",
                "एटीएम में गुप्त पिन दबाते समय कीपैड को दूसरे हाथ से ढकना क्यों जरूरी है?",
                "एटीएममध्ये पिन टाकताना कीपॅड दुसऱ्या हाताने झाकणे का गरजेचे आहे?",
                "It blocks any hidden pinhole cameras or people standing behind from seeing your numbers.",
                "यह किसी छुपे हुए कैमरे या पीछे खड़े लोगों को आपके गुप्त नंबर देखने से रोकता है।",
                "हे छुपा कॅमेरा किंवा मागे उभ्या असलेल्या व्यक्तीला तुमचा पिन पाहण्यापासून रोखते.",
                new String[]{"To keep your hand warm", "To prevent hidden cameras or onlookers from seeing your secret PIN", "To make the cash come out faster", "Because of bank traditions"},
                new String[]{"हाथ गर्म रखने के लिए", "छिपे हुए कैमरों और पीछे खड़े लोगों से पिन को सुरक्षित रखने के लिए", "ताकि पैसे जल्दी बाहर आएं", "बैंक के रीति-रिवाज के लिए"},
                new String[]{"हात उबदार ठेवण्यासाठी", "छुपे कॅमेरे आणि इतरांना पिन दिसू नये म्हणून", "पैसे लवकर बाहेर येण्यासाठी", "बँकेचा नियम म्हणून"}, 1);

        DatabaseSeeder.insertQuiz(conn, l26, "If you get confused at an ATM, what is the safest thing to do?",
                "अगर एटीएम मशीन पर कोई बात समझ न आए, तो सबसे सुरक्षित तरीका क्या है?",
                "एटीएम मशीनवर काही अडचण आल्यास सर्वात सुरक्षित मार्ग कोणता?",
                "Press 'Cancel', take back your card, and ask your child or bank staff inside the branch.",
                "लाल 'Cancel' बटन दबाएं, अपना कार्ड वापस लें और अपने बेटे-बेटी या बैंक के काउंटर पर जाकर पूछें।",
                "लाल 'Cancel' बटण दाबा, कार्ड परत घ्या आणि मुलांशी किंवा बँकेच्या कर्मचाऱ्यांशी बोला.",
                new String[]{"Give your card and PIN to a stranger in the queue", "Press Cancel, retrieve your card, and consult family or bank branch staff", "Leave the card inside the machine", "Shout at the security guard"},
                new String[]{"लाइन में खड़े किसी अनजान व्यक्ति को कार्ड और पिन दे दें", "Cancel दबाएं, कार्ड वापस लें और परिवार या बैंक स्टाफ से पूछें", "कार्ड मशीन में ही छोड़ दें", "गार्ड पर गुस्सा करें"},
                new String[]{"रांगेतील अनोळखी व्यक्तीला कार्ड आणि पिन द्या", "Cancel दाबा, कार्ड परत घ्या आणि कुटुंबीयांशी किंवा बँक कर्मचाऱ्यांशी बोला", "कार्ड मशीनमध्येच सोडून जा", "सुरक्षारक्षकावर ओरडा"}, 1);

        DatabaseSeeder.insertQuiz(conn, l26, "Is it safe to write your 4-digit ATM PIN with a marker pen directly on your debit card?",
                "क्या अपने एटीएम कार्ड पर पेन या मार्कर से अपना 4 अंकों का पिन लिखकर रखना सुरक्षित है?",
                "एटीएम कार्डवर पेनने ४ अंकी पिन लिहून ठेवणे सुरक्षित आहे का?",
                "No, never! If you lose your card, anyone who finds it can empty your entire bank account.",
                "बिल्कुल नहीं! यदि कार्ड कहीं गिर गया, तो पाने वाला व्यक्ति आपके खाते से सारे पैसे निकाल लेगा।",
                "मुळीच नाही! कार्ड हरवल्यास कोणालाही सापडले तरी तो खात्यातील सर्व पैसे काढून घेऊ शकतो.",
                new String[]{"Yes, so you never forget it", "No, never! If lost, anyone can withdraw all your savings immediately", "Only if written in small letters", "Only if approved by family"},
                new String[]{"हां, ताकि भूलें नहीं", "नहीं, बिल्कुल नहीं! खो जाने पर कोई भी तुरंत सारे पैसे निकाल लेगा", "केवल छोटे अक्षरों में", "परिवार की मंजूरी से"},
                new String[]{"होय, विसरायला नको म्हणून", "नाही, मुळीच नाही! कार्ड हरवल्यास कोणीही लगेच सर्व पैसे काढू शकतो", "फक्त बारीक अक्षरात", "कुटुंबाच्या संमतीने"}, 1);

        // L27: Spotting Fake Bank Callers & Phishing
        int l27 = DatabaseSeeder.insertLesson(conn, 27, 8, "Spotting Fake Bank Callers & Phishing", "फर्जी बैंक मैनेजर के फोन कॉल्स से सावधान", "बनावट बँक मॅनेजरच्या फोनपासून सावधान",
                "Recognize fraudsters pretending to be bank managers asking for card expiry, CVV, and OTP.",
                "बैंक मैनेजर बनकर कार्ड नंबर, सीवीवी और ओटीपी मांगने वाले ठगों को पहचानना सीखें।",
                "बँक मॅनेजर सांगून कार्ड नंबर, सीव्हीव्ही आणि ओटीपी मागणारे भामटे कसे ओळखायचे ते शिका.",
                "BEGINNER", 5, "NONE", 3,
                "• Scammers claim: 'I am Sharma from SBI head office, your ATM card is expiring today'.\n• They ask for 16-digit card number, 3-digit CVV on back, and OTP.\n• Real bank staff will NEVER ask for CVV or OTP over the phone.\n• Hang up immediately and inform your children.",
                "• धोखेबाज कहते हैं: 'मैं एसबीआई मुख्यालय से बोल रहा हूं, आपका एटीएम कार्ड आज बंद हो रहा है'।\n• वे कार्ड का 16 अंकों का नंबर, पीछे का 3 अंकों का सीवीवी और ओटीपी मांगते हैं।\n• बैंक कर्मचारी कभी भी फोन पर सीवीवी या ओटीपी नहीं मांगते।\n• तुरंत फोन काटें और अपने बच्चों को बताएं।",
                "• भामटे म्हणतात: 'मी स्टेट बँकेतून बोलतोय, तुमचे एटीएम कार्ड आज बंद होणार आहे'.\n• ते १६ अंकी कार्ड नंबर, मागचा ३ अंकी सीव्हीव्ही आणि ओटीपी मागतात.\n• बँकेचे खरे कर्मचारी फोनवर कधीही सीव्हीव्ही किंवा ओटीपी मागत नाहीत.\n• तात्काळ फोन कट करा आणि मुलांना सांगा.");

        DatabaseSeeder.insertStep(conn, l27, 1, "The 'Card Expiring Today' Phone Script", "कार्ड बंद होने का बहाना पहचानें", "कार्ड बंद होण्याची बतावणी ओळखा",
                "A caller speaks very politely or authoritatively: 'Namaste Sharma ji, I am calling from bank branch. Your ATM card will be blocked tonight unless verified.'",
                "कॉलर बहुत आदर या सख्ती से बोलता है: 'नमस्ते शर्मा जी, मैं बैंक से बोल रहा हूं। आपका एटीएम कार्ड आज रात ब्लॉक हो जाएगा अगर रीन्यू नहीं कराया।'",
                "फोन करणारा अत्यंत नम्रतेने किंवा अधिकाराने बोलतो: 'नमस्कार, मी बँकेतून बोलतोय. तुमचे एटीएम कार्ड आज रात्री बंद होईल जर नूतनीकरण केले नाही.'",
                "WARNING_BOX", "FAKE_CALLER",
                "Scammers use official-sounding language and create panic about card expiration.",
                "धोखेबाज बैंक अधिकारी बनकर डराते हैं ताकि आप घबरा जाएं।",
                "भामटे बँक अधिकारी असल्याचा आव आणून भीती दाखवतात.");

        DatabaseSeeder.insertStep(conn, l27, 2, "What They Ask For (The Trap)", "वे क्या मांगते हैं (धोखे का जाल)", "ते काय मागतात (फसवणुकीचा सापळा)",
                "They ask you to read out the 16 digits on the front of your card, the expiry date, and the 3-digit CVV number on the back.",
                "वे आपसे कार्ड के ऊपर लिखे 16 अंक, एक्सपायरी तारीख और पीछे का 3 अंकों का सीवीवी (CVV) नंबर पूछते हैं।",
                "ते तुमच्या कार्डवरील १६ अंक, एक्सपायरी तारीख आणि कार्डच्या मागचा ३ अंकी सीव्हीव्ही (CVV) नंबर विचारतात.",
                "WARNING_BOX", "CVV_TRAP",
                "The 3-digit CVV on the back of your card is your secret financial security key. Never read it out to callers.",
                "कार्ड के पीछे लिखा 3 अंकों का सीवीवी नंबर आपका गुप्त सुरक्षा कोड है। इसे कभी किसी को न बताएं।",
                "कार्डच्या मागचा ३ अंकी सीव्हीव्ही कोड ही तुमची गुप्त सुरक्षा आहे. तो कोणालाही सांगू नका.");

        DatabaseSeeder.insertStep(conn, l27, 3, "The Final Strike: Demanding the OTP", "अंतिम जाल: ओटीपी मांगना", "शेवटचा डाव: ओटीपी मागणे",
                "They say: 'I have sent an SMS for verification. Read out the 6-digit OTP to unblock your card'. THE OTP IS ACTUALLY TO DEDUCT YOUR MONEY!",
                "वे कहते हैं: 'मैंने वेरिफिकेशन के लिए एसएमएस भेजा है, 6 अंकों का ओटीपी बताएं'। याद रखें: वह ओटीपी आपके खाते से पैसे निकालने के लिए होता है!",
                "ते म्हणतात: 'मी पडताळणीसाठी मेसेज पाठवला आहे, ६ अंकी ओटीपी सांगा'. लक्षात ठेवा: तो ओटीपी तुमचेच पैसे लुटण्यासाठी आलेला असतो!",
                "WARNING_BOX", "OTP_DANGER",
                "Never share your OTP with any phone caller under any circumstances.",
                "फोन पर किसी को भी अपना 6 अंकों का ओटीपी कभी न बताएं।",
                "फोनवर कोणालाही आपला ६ अंकी ओटीपी कधीही सांगू नका.");

        DatabaseSeeder.insertStep(conn, l27, 4, "How to Respond: Hang Up Immediately", "सही जवाब: तुरंत फोन काटें", "योग्य कृती: लगेच फोन कट करा",
                "Do not argue. Simply press the red button to hang up. If you are worried, visit your local bank branch in person with your passbook.",
                "बहस न करें। तुरंत लाल बटन दबाकर फोन काट दें। यदि चिंता हो तो अपनी पासबुक लेकर सीधे अपनी बैंक शाखा जाएं।",
                "वाद घालू नका. लाल बटण दाबून फोन कट करा. काळजी वाटल्यास पासबुक घेऊन थेट स्वतःच्या बँकेच्या शाखेत जा.",
                "PHONE_UI", "HANGUP_SCAM",
                "Hang up on suspicious callers and consult your children or visit your bank branch directly.",
                "धोखेबाजों का फोन तुरंत काटें और बच्चों या बैंक शाखा को बताएं।",
                "संशयास्पद कॉल लगेच कट करा आणि मुलांना किंवा बँकेत सांगा.");

        DatabaseSeeder.insertQuiz(conn, l27, "Will a genuine bank manager ever call you on the phone and ask for your 3-digit CVV and OTP?",
                "क्या कोई असली बैंक मैनेजर कभी फोन करके आपसे कार्ड का 3 अंकों का CVV और OTP मांगेगा?",
                "कोणताही खरा बँक मॅनेजर कधी फोन करून तुमच्याकडे कार्डचा ३ अंकी CVV आणि OTP मागेल का?",
                "NEVER! Legitimate banks explicitly prohibit staff from asking customers for CVV or OTP over the phone.",
                "कभी नहीं! असली बैंक कभी भी फोन पर सीवीवी या गुप्त ओटीपी नहीं मांगता।",
                "कधीही नाही! खरी बँक कधीही फोनवर सीव्हीव्ही किंवा गुप्त ओटीपी मागत नाही.",
                new String[]{"Yes, every Monday", "NEVER! Real bank staff never ask for CVV or OTP over the phone", "Only if your balance is low", "Only during festivals"},
                new String[]{"हां, हर सोमवार को", "कभी नहीं! असली बैंक कर्मचारी कभी भी फोन पर सीवीवी या ओटीपी नहीं मांगते", "केवल बैलेंस कम होने पर", "केवल त्योहारों पर"},
                new String[]{"होय, प्रत्येक सोमवारी", "कधीही नाही! बँकेचे खरे कर्मचारी फोनवर कधीही सीव्हीव्ही किंवा ओटीपी मागत नाहीत", "फक्त पैसे कमी असल्यास", "फक्त सणासुदीला"}, 1);

        DatabaseSeeder.insertQuiz(conn, l27, "What is the 3-digit number printed on the back of your ATM / Debit card called?",
                "एटीएम या डेबिट कार्ड के पीछे लिखे 3 अंकों के गुप्त नंबर को क्या कहा जाता है?",
                "एटीएम किंवा डेबिट कार्डच्या मागे लिहिलेल्या ३ अंकी गुप्त नंबरला काय म्हणतात?",
                "It is the CVV (Card Verification Value) code used to authorize online payments.",
                "इसे सीवीवी (CVV) कहते हैं। यह ऑनलाइन खरीदारी और पैसे ट्रांसफर की गुप्त चाबी है।",
                "याला सीव्हीव्ही (CVV) म्हणतात. ही ऑनलाइन पेमेंटची गुप्त किल्ली आहे.",
                new String[]{"The PIN number", "The CVV (Card Verification Value) code", "The account number", "The IFSC code"},
                new String[]{"पिन नंबर", "सीवीवी (CVV) कोड", "खाता नंबर", "आईएफएससी कोड"},
                new String[]{"पिन नंबर", "सीव्हीव्ही (CVV) कोड", "खाते नंबर", "आयएफएससी कोड"}, 1);

        DatabaseSeeder.insertQuiz(conn, l27, "What is the single best action to take when someone calls demanding bank verification codes?",
                "जब कोई फोन पर बैंक सत्यापन कोड मांगे, तो सबसे सही कदम क्या होता है?",
                "फोनवर कोणीही बँकेचा कोड विचारल्यास सर्वात योग्य पाऊल कोणते?",
                "Disconnect the call immediately and tell your family or visit your branch.",
                "तुरंत फोन काट दें और अपने बच्चों को बताएं या बैंक शाखा जाएं।",
                "तात्काळ फोन कट करा आणि आपल्या मुलांना किंवा बँकेत जाऊन सांगा.",
                new String[]{"Read out all numbers slowly", "Hang up the phone immediately and consult family or bank branch", "Give your neighbor's numbers", "Argue for one hour"},
                new String[]{"सारे नंबर धीरे-धीरे पढ़कर सुनाएं", "तुरंत फोन काट दें और परिवार या बैंक शाखा से संपर्क करें", "पड़ोसी का नंबर दें", "एक घंटे तक बहस करें"},
                new String[]{"सर्व नंबर हळूहळू सांगा", "लगेच फोन कट करा आणि कुटुंबाला किंवा बँकेला सांगा", "शेजाऱ्यांचा नंबर द्या", "एक तास वाद घाला"}, 1);
    }
}
