package com.seniortutor;

/**
 * Main launcher entry point for standalone executable JAR execution.
 * Does not extend javafx.application.Application directly to ensure seamless
 * launching with java -jar across all modern Java runtimes.
 */
public class Main {
    public static void main(String[] args) {
        SeniorTutorApp.main(args);
    }
}
