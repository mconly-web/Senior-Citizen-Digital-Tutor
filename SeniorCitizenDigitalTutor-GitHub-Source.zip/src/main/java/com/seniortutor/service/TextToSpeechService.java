package com.seniortutor.service;

/**
 * Clean abstraction interface for local Text-to-Speech synthesis.
 */
public interface TextToSpeechService {
    void speak(String text);
    void speak(String text, String lang);
    void stop();
    boolean isSpeaking();
    boolean isAvailable();
}
