package com.seniortutor.service;

import com.seniortutor.database.DatabaseManager;
import com.seniortutor.model.SafetyCheckResult;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Advanced educational rule-based analyzer for scam, phishing, and fraudulent messages.
 * Includes Indian cybercrime patterns (Digital Arrest, QR trick, fake KYC, electricity bill,
 * courier/customs, job offer, loan app, fake customer care), regex detection for links and phone numbers,
 * weighted scoring, and detailed "Why this is risky" explanations in English, Hindi, and Marathi.
 */
public class SafetyCheckerService {
    private static SafetyCheckerService instance;

    // Regex patterns
    private static final Pattern IP_URL_PATTERN = Pattern.compile("https?://\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}(:\\d+)?(/\\S*)?", Pattern.CASE_INSENSITIVE);
    private static final Pattern SHORTENER_PATTERN = Pattern.compile("(bit\\.ly|tinyurl\\.com|cutt\\.ly|is\\.gd|t\\.co|rb\\.gy|shorturl\\.at|tiny\\.cc)/[a-zA-Z0-9]+", Pattern.CASE_INSENSITIVE);
    private static final Pattern APK_LINK_PATTERN = Pattern.compile("https?://\\S+\\.apk\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern FAKE_BANK_DOMAIN_PATTERN = Pattern.compile("(sbi-kyc|icici-verify|hdfc-update|pnb-service|paytm-kyc|yono-update)\\.[a-zA-Z]{2,}", Pattern.CASE_INSENSITIVE);
    private static final Pattern FOREIGN_NUMBER_PATTERN = Pattern.compile("\\+(92|234|44|876)\\d{7,12}");
    private static final Pattern FAKE_HELPLINE_PATTERN = Pattern.compile("(?i)(toll\\s*free|customer\\s*care|helpline|support|electricity)[^0-9]{0,25}(\\+?91[\\-\\s]?)?[6-9]\\d{9}");

    private SafetyCheckerService() {}

    public static synchronized SafetyCheckerService getInstance() {
        if (instance == null) {
            instance = new SafetyCheckerService();
        }
        return instance;
    }

    public SafetyCheckResult analyzeMessage(String rawInput, int userId) {
        String lang = LocalizationService.getInstance().getLanguage();
        return analyzeMessage(rawInput, userId, lang);
    }

    public SafetyCheckResult analyzeMessage(String rawInput, int userId, String lang) {
        if (lang == null || (!lang.equals("hi") && !lang.equals("mr"))) {
            lang = "en";
        }

        SafetyCheckResult result = new SafetyCheckResult();
        result.setAnalyzedText(rawInput);

        if (rawInput == null || rawInput.isBlank()) {
            result.setRiskLevel(SafetyCheckResult.RiskLevel.APPEARS_SAFE);
            result.setScore(0);
            if ("hi".equals(lang)) {
                result.getRecommendations().add("कृपया जांच के लिए कोई संदेश दर्ज करें या पेस्ट करें।");
            } else if ("mr".equals(lang)) {
                result.getRecommendations().add("कृपया तपासणीसाठी मेसेज टाका किंवा पेस्ट करा.");
            } else {
                result.getRecommendations().add("Please enter or paste a message to analyze.");
            }
            return result;
        }

        String text = rawInput.toLowerCase();
        List<String> flags = new ArrayList<>();
        List<String> whyRisky = new ArrayList<>();
        List<String> advice = new ArrayList<>();
        int riskScore = 0;

        // 1. Digital Arrest / CBI / Police Impersonation (Extreme Risk +50)
        if (containsAny(text, "digital arrest", "cbi", "narcotics bureau", "cyber crime branch", "arrest warrant", "customs narcotics", "police commissioner", "court summons")) {
            riskScore += 50;
            if ("hi".equals(lang)) {
                flags.add("🚨 डिजिटल अरेस्ट / पुलिस / सीबीआई का झूठा डर (गंभीर धोखाधड़ी)");
                whyRisky.add("कानूनी सच्चाई: भारतीय कानून और पुलिस कभी भी वीडियो कॉल पर 'डिजिटल अरेस्ट' नहीं करती। असली पुलिस डाक द्वारा लिखित समन भेजती है।");
                advice.add("❌ तुरंत कॉल काटें। डरने की कोई बात नहीं है। 1930 साइबर हेल्पलाइन पर शिकायत करें।");
            } else if ("mr".equals(lang)) {
                flags.add("🚨 डिजिटल अरेस्ट / पोलीस / सीबीआयची खोटी भीती (गंभीर फसवणूक)");
                whyRisky.add("कायदेशीर सत्य: भारतीय कायदा आणि पोलीस कधीही व्हिडिओ कॉलवर 'डिजिटल अरेस्ट' करत नाहीत. ही १००% खोटी भीती आहे.");
                advice.add("❌ त्वरित फोन कट करा. अजिबात घाबरू नका. १९३० या सायबर हेल्पलाइनवर तक्रार नोंदवा.");
            } else {
                flags.add("🚨 Digital Arrest / Police / CBI Impersonation Trap (CRITICAL FRAUD)");
                whyRisky.add("Why this is risky: Indian law and police NEVER conduct 'Digital Arrest' or court hearings over video calls. Real police summon in person with physical paperwork.");
                advice.add("❌ Disconnect immediately! Do not panic or pay any 'clearance fee'. Report immediately to 1930.");
            }
        }

        // 2. QR "Receive Money" Trick (Critical Risk +50)
        if (containsAny(text, "scan qr to receive", "scan qr code to get money", "scan to accept payment", "scan for refund", "qr code receive", "scan this qr", "scan qr", "enter your upi pin to receive", "enter upi pin to accept", "पैसे पाने के लिए क्यूआर", "पैसे मिळवण्यासाठी क्यूआर")) {
            riskScore += 50;
            if ("hi".equals(lang)) {
                flags.add("📱 क्यूआर कोड स्कैन करके पैसे पाने का धोखा (CRITICAL TRAP)");
                whyRisky.add("जोखिम का कारण: क्यूआर कोड केवल पैसे भेजने के लिए होता है। पैसे प्राप्त करने के लिए कभी भी क्यूआर स्कैन या यूपीआई पिन नहीं डालना पड़ता।");
                advice.add("❌ क्यूआर कोड कभी स्कैन न करें! ऐसा करने पर आपके बैंक खाते से पैसे कट जाएंगे।");
            } else if ("mr".equals(lang)) {
                flags.add("📱 क्यूआर कोड स्कॅन करून पैसे मिळवण्याचा ट्रॅप (CRITICAL TRAP)");
                whyRisky.add("धोक्याचे कारण: क्यूआर कोड स्कॅन केल्यास पैसे जमा होत नाहीत, तर खात्यातून पैसे कापले जातात.");
                advice.add("❌ क्यूआर कोड कधीही स्कॅन करू नका! पैसे मिळवण्यासाठी पिन किंवा स्कॅन लागत नाही.");
            } else {
                flags.add("📱 QR Code 'Receive Money' Deception (CRITICAL TRAP)");
                whyRisky.add("Why this is risky: Scanning a QR code or entering your UPI PIN ALWAYS transfers money OUT of your account. You NEVER need a PIN or QR scan to receive funds.");
                advice.add("❌ Do NOT scan the QR code! Entering your PIN will drain your money to the fraudster.");
            }
        }

        // 3. OTP & One Time Password Trap (+50)
        if (containsAny(text, "otp", "one time password", "one-time password", "ओटीपी", "वन टाइम पासवर्ड")) {
            riskScore += 50;
            if ("hi".equals(lang)) {
                flags.add("🔑 ओटीपी (OTP) की मांग की गई है (अत्यंत गंभीर खतरा)");
                whyRisky.add("जोखिम का कारण: ओटीपी आपके बैंक खाते की डिजिटल चाबी है। इसे बताते ही धोखेबाज आपके खाते से पैसे निकाल लेते हैं।");
                advice.add("❌ किसी भी परिस्थिति में किसी के साथ भी ओटीपी साझा न करें। बैंक कर्मचारी कभी भी फोन पर ओटीपी नहीं मांगते।");
            } else if ("mr".equals(lang)) {
                flags.add("🔑 ओटीपी (OTP) विचारला जात आहे (अत्यंत धोकादायक)");
                whyRisky.add("धोक्याचे कारण: ओटीपी म्हणजे तुमच्या खात्याची गुप्त चावी. ती दिल्यास बँक खाते रिकामे होऊ शकते.");
                advice.add("❌ कोणत्याही परिस्थितीत कोणाशीही ओटीपी शेअर करू नका. बँकेचे खरे कर्मचारी कधीही ओटीपी मागत नाहीत.");
            } else {
                flags.add("🔑 Asks for Secret OTP / One Time Password (CRITICAL RED FLAG)");
                whyRisky.add("Why this is risky: The OTP is your master payment authorization. Sharing it grants fraudsters full access to authorize transactions on your behalf.");
                advice.add("❌ NEVER share your OTP under any pretext. Bank managers and government officers NEVER request OTPs.");
            }
        }

        // 4. UPI PIN / ATM PIN / CVV (+50)
        if (containsAny(text, "upi pin", "atm pin", "netbanking password", "cvv", "card expiry", "पिन", "पासवर्ड")) {
            riskScore += 50;
            if ("hi".equals(lang)) {
                flags.add("💳 बैंक पिन (PIN), पासवर्ड या सीवीवी मांगा गया है");
                whyRisky.add("जोखिम का कारण: गुप्त पिन केवल आपके व्यक्तिगत उपयोग के लिए है।");
                advice.add("❌ अपना पिन या सीवीवी कभी किसी को न बताएं।");
            } else if ("mr".equals(lang)) {
                flags.add("💳 बँकेचा गुप्त पिन किंवा सीव्हीव्ही मागितला आहे");
                whyRisky.add("धोक्याचे कारण: गुप्त पिन कोणालाही सांगितल्यास खात्यातील पैसे चोरीला जाऊ शकतात.");
                advice.add("❌ तुमचा पिन किंवा सीव्हीव्ही कधीही कोणाला सांगू नका.");
            } else {
                flags.add("💳 Requests Secret Bank PIN or CVV (CRITICAL RED FLAG)");
                whyRisky.add("Why this is risky: Your PIN and CVV are your most confidential payment credentials.");
                advice.add("❌ NEVER enter or reveal your PIN or CVV.");
            }
        }

        // 5. Remote Access & Screen Sharing Traps (+40)
        if (containsAny(text, "anydesk", "teamviewer", "quicksupport", "rustdesk", "screen share", "screen sharing", "download app to verify")) {
            riskScore += 40;
            if ("hi".equals(lang)) {
                flags.add("📱 स्क्रीन शेयरिंग या रिमोट कंट्रोल ऐप (AnyDesk / TeamViewer) का उल्लेख है");
                whyRisky.add("जोखिम का कारण: यह ऐप धोखेबाज को आपके फोन की स्क्रीन देखने और पासवर्ड पढ़ने की पूरी अनुमति दे देता है।");
                advice.add("❌ किसी के कहने पर AnyDesk या रिमोट ऐप कभी डाउनलोड न करें।");
            } else if ("mr".equals(lang)) {
                flags.add("📱 स्क्रीन शेअरिंग किंवा रिमोट ॲप (AnyDesk / TeamViewer) इन्स्टॉल करण्यास सांगितले आहे");
                whyRisky.add("धोक्याचे कारण: या ॲपमुळे भामट्यांना तुमच्या फोनमधील सर्व स्क्रीन आणि पासवर्ड दिसतात.");
                advice.add("❌ कोणाच्याही सांगण्यावरून AnyDesk किंवा इतर ॲप इन्स्टॉल करू नका.");
            } else {
                flags.add("📱 Mentions Remote Access / Screen Sharing Tools");
                whyRisky.add("Why this is risky: Remote apps allow a caller to see your screen in real time and read incoming OTPs and banking passwords.");
                advice.add("❌ DO NOT install AnyDesk or remote control apps on caller instructions.");
            }
        }

        // 6. Fake Electricity Bill & Power Cut Threat (+40)
        if (containsAny(text, "power cut", "disconnected tonight", "electricity disconnect", "electricity", "electricity will be disconnected", "unpaid bill tonight", "बिजली", "लाईट", "वीज")) {
            riskScore += 40;
            if ("hi".equals(lang)) {
                flags.add("⏳ बिजली कटने का झूठा डर पैदा किया जा रहा है");
                whyRisky.add("जोखिम का कारण: धोखेबाज बिजली कटने का डर दिखाकर फर्जी नंबर पर कॉल करवाते हैं और पैसे ऐंठते हैं। असली बिजली बोर्ड डाक से लिखित नोटिस भेजता है।");
                advice.add("⚠️ दिए गए नंबर पर कॉल न करें। यदि बिल बाकी है, तो केवल आधिकारिक बिजली काउंटर या अधिकृत ऐप से ही भुगतान करें।");
            } else if ("mr".equals(lang)) {
                flags.add("⏳ वीज कापण्याची खोटी भीती दाखवली जात आहे");
                whyRisky.add("धोक्याचे कारण: वीज मंडळ कधीही १ तासात वीज कापण्याचा असा मेसेज पाठवत नाही.");
                advice.add("⚠️ मेसेजमधील नंबरवर फोन करू नका. अधिकृत वीज बिलावर दिलेल्या केंद्रातच चौकशी करा.");
            } else {
                flags.add("⏳ Electricity Power Cut Threat Tactic");
                whyRisky.add("Why this is risky: Scammers use threats of immediate darkness tonight to induce panic so you call their rogue mobile number without consulting family.");
                advice.add("⚠️ Do NOT call the number in the SMS. Power companies issue written postal notices days in advance.");
            }
        }

        // 7. Fake Courier & Customs Parcel Seizure (+35)
        if (containsAny(text, "customs", "fedex parcel", "dhl courier", "parcel seized", "narcotics parcel", "illegal parcel")) {
            riskScore += 35;
            if ("hi".equals(lang)) {
                flags.add("📦 कूरियर या कस्टम पार्सल जब्ती का डर");
                whyRisky.add("जोखिम का कारण: यह डर दिखाकर वसूली करने का पुराना तरीका है। जिस पार्सल को आपने भेजा ही नहीं, उसके लिए आप जिम्मेदार नहीं हैं।");
                advice.add("⚠️ ऐसे कॉल पर ध्यान न दें और तुरंत काट दें।");
            } else if ("mr".equals(lang)) {
                flags.add("📦 कुरिअर किंवा कस्टम पार्सल जप्त केल्याची भीती");
                whyRisky.add("धोक्याचे कारण: तुम्ही न पाठवलेल्या पार्सलचे खोटे कारण सांगून पैसे उकळण्याचा हा प्रकार आहे.");
                advice.add("⚠️ अशा कॉल्सकडे दुर्लक्ष करा आणि त्वरित फोन कट करा.");
            } else {
                flags.add("📦 Fake Courier / Customs Seizure Threat");
                whyRisky.add("Why this is risky: Fraudsters pretend you sent a parcel containing illegal items to extort 'clearance and penalty' fees.");
                advice.add("⚠️ Hang up immediately. You cannot be penalized for parcels you never sent.");
            }
        }

        // 8. Part-Time Job Offer / Telegram Task Scam (+30)
        if (containsAny(text, "part time job", "work from home daily", "like youtube videos to earn", "earn 3000 daily", "telegram task", "investment task")) {
            riskScore += 30;
            if ("hi".equals(lang)) {
                flags.add("💼 वर्क फ्रॉम होम या यूट्यूब लाइक करने का फर्जी जॉब ऑफर");
                whyRisky.add("जोखिम का कारण: यह 'टास्क फ्रॉड' है। पहले 150-200 रुपये देकर भरोसा जीतते हैं, फिर लाखों रुपये जमा करवा लेते हैं।");
                advice.add("❌ कभी भी ऐसे ऑनलाइन टास्क के झांसे में न आएं। कोई भी वास्तविक कंपनी वीडियो लाइक करने के हजारों रुपये नहीं देती।");
            } else if ("mr".equals(lang)) {
                flags.add("💼 वर्क फ्रॉम होम किंवा यूट्यूब लाइकचा खोटा जॉब ऑफर");
                whyRisky.add("धोक्याचे कारण: हा टास्क फ्रॉड आहे. आधी थोडे पैसे देऊन विश्वास संपादन करतात आणि नंतर मोठी रक्कम लुटतात.");
                advice.add("❌ अशा मेसेजवर विश्वास ठेवू नका.");
            } else {
                flags.add("💼 Work-From-Home / Telegram Task Job Fraud");
                whyRisky.add("Why this is risky: Task fraud promises easy money for liking videos, lures you into Telegram groups, and traps your savings.");
                advice.add("❌ Legitimate companies never pay ₹3,000 daily for liking videos. Block and report.");
            }
        }

        // 9. Instant Loan App Trap (+30)
        if (containsAny(text, "instant loan without cibil", "7 day loan", "loan approved 50000", "instant cash loan")) {
            riskScore += 30;
            if ("hi".equals(lang)) {
                flags.add("💸 बिना दस्तावेज तुरंत लोन का लालच");
                whyRisky.add("जोखिम का कारण: यह गैरकानूनी लोन ऐप्स होते हैं जो फोन का डेटा चुराकर ब्लैकमेल करते हैं।");
                advice.add("❌ ऐसे किसी भी ऐप को अपने फोन में इंस्टॉल न करें।");
            } else if ("mr".equals(lang)) {
                flags.add("💸 विना कागदपत्रे झटपट लोनचे आमिष");
                whyRisky.add("धोक्याचे कारण: हे बेकायदेशीर लोन ॲप्स फोनमधील फोटो आणि संपर्क चोरून ब्लॅकमेल करतात.");
                advice.add("❌ असे कोणतेही ॲप डाऊनलोड करू नका.");
            } else {
                flags.add("💸 Predatory Instant Loan Trap");
                whyRisky.add("Why this is risky: Illegal 7-day loan apps steal contacts and gallery photos to extort money through abusive blackmail.");
                advice.add("❌ Never install unverified loan APKs.");
            }
        }

        // 10. Fake KYC & Government / Bank Impersonation (+25)
        if (containsAny(text, "kyc update", "pan linked", "aadhaar verification", "update kyc immediately", "केवाईसी")) {
            riskScore += 25;
            if ("hi".equals(lang)) {
                flags.add("🏛️ बैंक या सरकारी केवाईसी (KYC) अपडेट का झूठा नाटक किया जा रहा है");
                whyRisky.add("जोखिम का कारण: असली बैंक कभी भी एसएमएस लिंक से केवाईसी नहीं कराता।");
                advice.add("✅ अगर बैंक केवाईसी की आवश्यकता है, तो सीधे अपनी बैंक शाखा जाकर संपर्क करें।");
            } else if ("mr".equals(lang)) {
                flags.add("🏛️ बँक किंवा सरकारी केवायसी (KYC) अपडेटचे खोटे नाटक केले जात आहे");
                whyRisky.add("धोक्याचे कारण: खरी बँक कधीही मेसेजमधील लिंकवरून केवायसी अपडेट करायला सांगत नाही.");
                advice.add("✅ केवायसी अपडेट करायचे असल्यास थेट तुमच्या बँक शाखेत जा.");
            } else {
                flags.add("🏛️ Pretends to be Bank or Government KYC Verification");
                whyRisky.add("Why this is risky: Legitimate banks never update KYC via third-party SMS links.");
                advice.add("✅ If KYC is truly pending, visit your local bank branch directly with your passbook.");
            }
        }

        // 11. Lottery & Unearned Prizes (+30)
        if (containsAny(text, "lottery", "won", "winner", "prize", "jackpot", "kbc", "लॉटरी", "इनाम", "बक्षीस")) {
            riskScore += 30;
            if ("hi".equals(lang)) {
                flags.add("🎁 बिना टिकट लॉटरी या इनाम का लालच दिया गया है");
                whyRisky.add("जोखिम का कारण: बिना टिकट कोई लॉटरी नहीं जीती जा सकती। यह 'एडवांस फीस' ठगी है।");
                advice.add("⚠️ ऐसे किसी भी इनाम के संदेश पर कभी विश्वास न करें।");
            } else if ("mr".equals(lang)) {
                flags.add("🎁 लॉटरी किंवा बक्षिसाचे खोटे आमिष दाखवले आहे");
                whyRisky.add("धोक्याचे कारण: तिकीट न काढता लॉटरी जिंकणे अशक्य आहे. ही निव्वळ फसवणूक आहे.");
                advice.add("⚠️ अशा मेसेजवर विश्वास ठेवू नका.");
            } else {
                flags.add("🎁 Unsolicited Prize or Lottery Claim");
                whyRisky.add("Why this is risky: You cannot win a lottery you never bought a ticket for. Scammers ask for processing fees and vanish.");
                advice.add("⚠️ Ignore and delete. Legitimate lotteries do not operate via SMS.");
            }
        }

        // 12. Regex Link Detections
        if (IP_URL_PATTERN.matcher(rawInput).find()) {
            riskScore += 35;
            flags.add("🌐 " + ("hi".equals(lang) ? "आईपी एड्रेस वाला संदेहास्पद लिंक मिला (गंभीर)" : "Suspicious IP address link detected"));
            whyRisky.add("Why this is risky: Legitimate institutions use registered domain names (e.g. sbi.co.in), never raw IP addresses.");
        }

        if (SHORTENER_PATTERN.matcher(rawInput).find()) {
            riskScore += 25;
            flags.add("🔗 " + ("hi".equals(lang) ? "छुपा हुआ छोटा लिंक (bit.ly/tinyurl) पाया गया" : "URL shortener detected (bit.ly, tinyurl)"));
            whyRisky.add("Why this is risky: URL shorteners hide the real destination address to trick seniors into visiting malware pages.");
        }

        if (APK_LINK_PATTERN.matcher(rawInput).find()) {
            riskScore += 40;
            flags.add("📥 " + ("hi".equals(lang) ? "खतरनाक APK फाइल डाउनलोड लिंक मिला" : "Direct APK application download link detected"));
            whyRisky.add("Why this is risky: APK files bypass official app stores and can install spyware to read your SMS and bank OTPs.");
            advice.add("❌ NEVER download APK files from SMS or WhatsApp links.");
        }

        if (FAKE_BANK_DOMAIN_PATTERN.matcher(rawInput).find()) {
            riskScore += 45;
            flags.add("🏦 " + ("hi".equals(lang) ? "नकली बैंक डोमेन पाया गया (फिशिंग)" : "Phishing domain impersonating a major bank detected"));
            whyRisky.add("Why this is risky: Fraudsters register look-alike domains to steal netbanking logins.");
        }

        // 13. Regex Phone Number Detections
        if (FOREIGN_NUMBER_PATTERN.matcher(rawInput).find()) {
            riskScore += 30;
            flags.add("📞 " + ("hi".equals(lang) ? "अंतर्राष्ट्रीय कॉल कोड (+92/+234) पाया गया" : "Suspicious foreign international country code detected"));
            whyRisky.add("Why this is risky: International cybercrime syndicates frequently route WhatsApp calls through spoofed foreign country codes.");
        }

        if (FAKE_HELPLINE_PATTERN.matcher(rawInput).find()) {
            riskScore += 25;
            flags.add("📱 " + ("hi".equals(lang) ? "कस्टमर केयर के नाम पर 10-अंकों का व्यक्तिगत मोबाइल नंबर मिला" : "Personal 10-digit mobile number posing as official helpline"));
            whyRisky.add("Why this is risky: Official corporate/bank customer cares use verified toll-free 1800 numbers, never personal mobile numbers.");
        }

        // Determine final verdict
        SafetyCheckResult.RiskLevel level;
        if (riskScore >= 40) {
            level = SafetyCheckResult.RiskLevel.HIGH_RISK;
        } else if (riskScore >= 15) {
            level = SafetyCheckResult.RiskLevel.SUSPICIOUS;
        } else {
            level = SafetyCheckResult.RiskLevel.APPEARS_SAFE;
            if ("hi".equals(lang)) {
                flags.add("✅ कोई ज्ञात धोखाधड़ी या पासवर्ड/ओटीपी की मांग नहीं पाई गई");
                advice.add("✅ यह संदेश सामान्य प्रतीत होता है, लेकिन यदि कोई पैसे या निजी जानकारी मांगे तो हमेशा सतर्क रहें।");
            } else if ("mr".equals(lang)) {
                flags.add("✅ कोणतीही संशयास्पद लक्षणे किंवा गुप्त माहिती मागितल्याचे आढळले नाही");
                advice.add("✅ हा मेसेज सामान्य वाटतो, तरीही कोणी पैसे किंवा वैयक्तिक माहिती मागितल्यास सतर्क राहा.");
            } else {
                flags.add("✅ No common fraud patterns or credential requests found");
                advice.add("✅ This message appears standard, but always stay vigilant if someone asks for money or personal details.");
            }
        }

        // Always include educational disclaimer and 1930 guidance
        if ("hi".equals(lang)) {
            advice.add("ℹ️ राष्ट्रीय साइबर अपराध हेल्पलाइन: 1930 डायल करें या cybercrime.gov.in पर रिपोर्ट करें।");
        } else if ("mr".equals(lang)) {
            advice.add("ℹ️ राष्ट्रीय सायबर गुन्हे हेल्पलाइन: १९३० वर संपर्क साधा किंवा cybercrime.gov.in वर तक्रार करा.");
        } else {
            advice.add("ℹ️ National Cybercrime Helpline: Dial 1930 immediately or report on cybercrime.gov.in.");
        }

        result.setRiskLevel(level);
        result.setScore(Math.min(100, riskScore));
        result.setDetectedFlags(flags);
        result.setRiskExplanations(whyRisky);
        result.setRecommendations(advice);

        // Record log into database
        logSafetyCheck(userId, rawInput, level.name(), result.getScore(), String.join("; ", flags));

        return result;
    }

    private boolean containsAny(String text, String... words) {
        for (String w : words) {
            if (text.contains(w.toLowerCase())) return true;
        }
        return false;
    }

    private void logSafetyCheck(int userId, String text, String level, int score, String flags) {
        String sql = """
            INSERT INTO safety_logs (user_id, input_text, risk_level, score, detected_flags)
            VALUES (?, ?, ?, ?, ?);
        """;
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setString(2, text.length() > 200 ? text.substring(0, 197) + "..." : text);
            ps.setString(3, level);
            ps.setInt(4, score);
            ps.setString(5, flags);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<String[]> getRecentSafetyChecks(int userId) {
        List<String[]> list = new ArrayList<>();
        String sql = "SELECT input_text, risk_level, score, checked_at FROM safety_logs WHERE user_id = ? ORDER BY id DESC LIMIT 5;";
        try (Connection conn = DatabaseManager.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new String[]{
                        rs.getString("input_text"),
                        rs.getString("risk_level"),
                        String.valueOf(rs.getInt("score")),
                        rs.getString("checked_at")
                    });
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
