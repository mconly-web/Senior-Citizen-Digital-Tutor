package com.seniortutor.service;

import com.seniortutor.database.DatabaseManager;
import com.seniortutor.model.AppSettings;
import com.seniortutor.model.User;
import com.seniortutor.repository.SettingsRepository;
import com.seniortutor.repository.UserRepository;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Service for backing up and restoring user learning progress, achievements,
 * and accessibility settings to/from an offline JSON file.
 */
public class BackupService {
    private static BackupService instance;

    private BackupService() {}

    public static synchronized BackupService getInstance() {
        if (instance == null) {
            instance = new BackupService();
        }
        return instance;
    }

    public boolean exportBackup(int userId, File targetFile) {
        if (targetFile == null) return false;

        try {
            UserRepository userRepo = new UserRepository();
            User user = userRepo.getUserById(userId);
            String userName = user != null ? user.getName() : "Senior";

            SettingsRepository settingsRepo = new SettingsRepository();
            AppSettings s = settingsRepo.getSettingsForUser(userId);

            // Fetch progress entries
            List<String> progressEntries = new ArrayList<>();
            String progressSql = "SELECT lesson_id, is_completed, last_step, quiz_score, quiz_passed, completed_at FROM user_progress WHERE user_id = ?;";
            try (Connection conn = DatabaseManager.getInstance().getConnection();
                 PreparedStatement ps = conn.prepareStatement(progressSql)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        progressEntries.add(String.format(
                            "{\"lesson_id\": %d, \"is_completed\": %d, \"last_step\": %d, \"quiz_score\": %d, \"quiz_passed\": %d, \"completed_at\": \"%s\"}",
                            rs.getInt("lesson_id"),
                            rs.getInt("is_completed"),
                            rs.getInt("last_step"),
                            rs.getInt("quiz_score"),
                            rs.getInt("quiz_passed"),
                            rs.getString("completed_at") != null ? rs.getString("completed_at") : ""
                        ));
                    }
                }
            }

            // Fetch achievement entries
            List<String> achievementEntries = new ArrayList<>();
            String achSql = "SELECT achievement_id, unlocked_at FROM user_achievements WHERE user_id = ?;";
            try (Connection conn = DatabaseManager.getInstance().getConnection();
                 PreparedStatement ps = conn.prepareStatement(achSql)) {
                ps.setInt(1, userId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        achievementEntries.add(String.format(
                            "{\"achievement_id\": %d, \"unlocked_at\": \"%s\"}",
                            rs.getInt("achievement_id"),
                            rs.getString("unlocked_at") != null ? rs.getString("unlocked_at") : ""
                        ));
                    }
                }
            }

            // Build JSON output
            StringBuilder sb = new StringBuilder();
            sb.append("{\n");
            sb.append("  \"version\": 1,\n");
            sb.append("  \"export_date\": \"").append(LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)).append("\",\n");
            sb.append("  \"user_name\": \"").append(userName).append("\",\n");
            sb.append("  \"user_id\": ").append(userId).append(",\n");

            // Settings
            sb.append("  \"settings\": {\n");
            sb.append("    \"language\": \"").append(s.getLanguage()).append("\",\n");
            sb.append("    \"font_scale\": ").append(s.getFontScale()).append(",\n");
            sb.append("    \"speech_rate\": ").append(s.getSpeechRate()).append(",\n");
            sb.append("    \"high_contrast\": ").append(s.isHighContrast()).append(",\n");
            sb.append("    \"voice_enabled\": ").append(s.isVoiceEnabled()).append(",\n");
            sb.append("    \"blood_group\": \"").append(s.getEmergencyBloodGroup()).append("\",\n");
            sb.append("    \"medications\": \"").append(s.getEmergencyMedications()).append("\"\n");
            sb.append("  },\n");

            // Progress array
            sb.append("  \"progress\": [\n");
            for (int i = 0; i < progressEntries.size(); i++) {
                sb.append("    ").append(progressEntries.get(i));
                if (i < progressEntries.size() - 1) sb.append(",");
                sb.append("\n");
            }
            sb.append("  ],\n");

            // Achievements array
            sb.append("  \"achievements\": [\n");
            for (int i = 0; i < achievementEntries.size(); i++) {
                sb.append("    ").append(achievementEntries.get(i));
                if (i < achievementEntries.size() - 1) sb.append(",");
                sb.append("\n");
            }
            sb.append("  ]\n");
            sb.append("}\n");

            try (FileWriter writer = new FileWriter(targetFile)) {
                writer.write(sb.toString());
            }

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean restoreBackup(int userId, File sourceFile) {
        if (sourceFile == null || !sourceFile.exists()) return false;

        try {
            StringBuilder sb = new StringBuilder();
            try (FileReader reader = new FileReader(sourceFile)) {
                char[] buf = new char[1024];
                int read;
                while ((read = reader.read(buf)) != -1) {
                    sb.append(buf, 0, read);
                }
            }

            String content = sb.toString();

            // Extract and restore progress records
            int progressStart = content.indexOf("\"progress\": [");
            int progressEnd = content.indexOf("]", progressStart);
            if (progressStart != -1 && progressEnd != -1) {
                String progressSub = content.substring(progressStart + 13, progressEnd);
                String[] entries = progressSub.split("\\},\\s*\\{");
                for (String raw : entries) {
                    String clean = raw.replace("{", "").replace("}", "").trim();
                    if (clean.isBlank()) continue;

                    int lessonId = extractInt(clean, "lesson_id");
                    int isCompleted = extractInt(clean, "is_completed");
                    int lastStep = extractInt(clean, "last_step");
                    int quizScore = extractInt(clean, "quiz_score");
                    int quizPassed = extractInt(clean, "quiz_passed");

                    if (lessonId > 0) {
                        String insertSql = """
                            INSERT INTO user_progress (user_id, lesson_id, is_completed, last_step, quiz_score, quiz_passed, completed_at)
                            VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                            ON CONFLICT(user_id, lesson_id) DO UPDATE SET
                                is_completed = excluded.is_completed,
                                last_step = excluded.last_step,
                                quiz_score = excluded.quiz_score,
                                quiz_passed = excluded.quiz_passed;
                        """;
                        try (Connection conn = DatabaseManager.getInstance().getConnection();
                             PreparedStatement ps = conn.prepareStatement(insertSql)) {
                            ps.setInt(1, userId);
                            ps.setInt(2, lessonId);
                            ps.setInt(3, isCompleted);
                            ps.setInt(4, lastStep);
                            ps.setInt(5, quizScore);
                            ps.setInt(6, quizPassed);
                            ps.executeUpdate();
                        }
                    }
                }
            }

            // Extract and restore achievements
            int achStart = content.indexOf("\"achievements\": [");
            int achEnd = content.indexOf("]", achStart);
            if (achStart != -1 && achEnd != -1) {
                String achSub = content.substring(achStart + 17, achEnd);
                String[] entries = achSub.split("\\},\\s*\\{");
                for (String raw : entries) {
                    String clean = raw.replace("{", "").replace("}", "").trim();
                    if (clean.isBlank()) continue;

                    int achId = extractInt(clean, "achievement_id");
                    if (achId > 0) {
                        String insertSql = "INSERT OR IGNORE INTO user_achievements (user_id, achievement_id, unlocked_at) VALUES (?, ?, CURRENT_TIMESTAMP);";
                        try (Connection conn = DatabaseManager.getInstance().getConnection();
                             PreparedStatement ps = conn.prepareStatement(insertSql)) {
                            ps.setInt(1, userId);
                            ps.setInt(2, achId);
                            ps.executeUpdate();
                        }
                    }
                }
            }

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private int extractInt(String content, String key) {
        try {
            int idx = content.indexOf("\"" + key + "\":");
            if (idx == -1) return 0;
            int start = idx + key.length() + 3;
            int end = content.indexOf(",", start);
            if (end == -1) end = content.indexOf("\n", start);
            if (end == -1) end = content.length();
            return Integer.parseInt(content.substring(start, end).trim());
        } catch (Exception e) {
            return 0;
        }
    }
}
