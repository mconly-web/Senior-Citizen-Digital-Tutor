package com.seniortutor.service;

import com.seniortutor.model.Achievement;
import com.seniortutor.repository.AchievementRepository;
import com.seniortutor.repository.ProgressRepository;

import java.util.List;

public class ProgressService {
    private static ProgressService instance;
    private final ProgressRepository progressRepository = new ProgressRepository();
    private final AchievementRepository achievementRepository = new AchievementRepository();

    private ProgressService() {}

    public static synchronized ProgressService getInstance() {
        if (instance == null) {
            instance = new ProgressService();
        }
        return instance;
    }

    public void updateStep(int userId, int lessonId, int step) {
        progressRepository.updateStepProgress(userId, lessonId, step);
    }

    public void completeLesson(int userId, int lessonId) {
        progressRepository.markLessonCompleted(userId, lessonId);
        checkAndUnlockAchievements(userId);
    }

    public int getCompletedCount(int userId) {
        return progressRepository.getCompletedLessonsCount(userId);
    }

    public int getTotalCount() {
        return progressRepository.getTotalLessonsCount();
    }

    public double getAverageQuizScore(int userId) {
        return progressRepository.getAverageQuizScore(userId);
    }

    public int getWeeklyCompletedCount(int userId) {
        return progressRepository.getWeeklyCompletedCount(userId);
    }

    public int getUserStreak(int userId) {
        return progressRepository.getUserStreak(userId);
    }

    public List<Achievement> getAchievements(int userId) {
        return achievementRepository.getAllAchievements(userId);
    }

    public void checkAndUnlockAchievements(int userId) {
        int completed = progressRepository.getCompletedLessonsCount(userId);
        if (completed >= 1) {
            achievementRepository.unlockAchievement(userId, "FIRST_LESSON");
        }
        if (completed >= 10) {
            achievementRepository.unlockAchievement(userId, "TEN_LESSONS");
        }
    }

    public void unlockAchievementDirect(int userId, String code) {
        achievementRepository.unlockAchievement(userId, code);
    }

    public void resetProgress(int userId) {
        progressRepository.resetUserProgress(userId);
    }
}
