package com.seniortutor.service;

import com.seniortutor.model.Category;
import com.seniortutor.model.Lesson;
import com.seniortutor.repository.CategoryRepository;
import com.seniortutor.repository.LessonRepository;

import java.util.List;

public class LessonService {
    private static LessonService instance;
    private final CategoryRepository categoryRepository = new CategoryRepository();
    private final LessonRepository lessonRepository = new LessonRepository();

    private LessonService() {}

    public static synchronized LessonService getInstance() {
        if (instance == null) {
            instance = new LessonService();
        }
        return instance;
    }

    public List<Category> getCategories(int userId) {
        return categoryRepository.getAllCategories(userId);
    }

    public Category getCategory(int categoryId, int userId) {
        return categoryRepository.getCategoryById(categoryId, userId);
    }

    public List<Lesson> getLessonsForCategory(int categoryId, int userId) {
        return lessonRepository.getLessonsByCategory(categoryId, userId);
    }

    public Lesson getLesson(int lessonId, int userId) {
        return lessonRepository.getLessonById(lessonId, userId);
    }

    public Lesson getContinueLearningLesson(int userId) {
        return lessonRepository.getLatestUnfinishedLesson(userId);
    }
}
