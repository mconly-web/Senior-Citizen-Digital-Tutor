package com.seniortutor.service;

import com.seniortutor.util.AppConfig;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * Offline local Text-To-Speech (TTS) and Speech-To-Text (STT) service.
 * Supports Windows SAPI (with automatic Hindi/Marathi voice selection and graceful fallback),
 * macOS ('say'), and Linux ('espeak').
 */
public class WindowsSpeechService implements TextToSpeechService {
    private static WindowsSpeechService instance;
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "VoiceTutorThread");
        t.setDaemon(true);
        return t;
    });

    private Process currentProcess;
    private volatile boolean speaking = false;
    private final boolean isWindows;
    private final boolean isMac;
    private final boolean isLinux;

    private WindowsSpeechService() {
        String os = System.getProperty("os.name", "").toLowerCase();
        this.isWindows = os.contains("win");
        this.isMac = os.contains("mac");
        this.isLinux = os.contains("nix") || os.contains("nux") || os.contains("aix");
    }

    public static synchronized WindowsSpeechService getInstance() {
        if (instance == null) {
            instance = new WindowsSpeechService();
        }
        return instance;
    }

    @Override
    public void speak(final String text) {
        String currentLang = LocalizationService.getInstance().getLanguage();
        speak(text, currentLang);
    }

    @Override
    public synchronized void speak(final String text, final String lang) {
        if (text == null || text.isBlank()) return;

        stop(); // Stop previous utterance if any

        executor.submit(() -> {
            try {
                speaking = true;
                double userRate = AppConfig.getInstance().getCurrentSettings().getSpeechRate();
                int sapiRate = (int) Math.round(userRate);
                if (sapiRate < -10) sapiRate = -1;
                if (sapiRate > 10) sapiRate = 0;

                String targetLang = (lang != null && (lang.equals("hi") || lang.equals("mr"))) ? lang : "en";

                if (isWindows) {
                    speakWindows(text, targetLang, sapiRate);
                } else if (isMac) {
                    speakMac(text, targetLang, sapiRate);
                } else if (isLinux) {
                    speakLinux(text, targetLang, sapiRate);
                } else {
                    // Generic console fallback
                    System.out.println("[Voice Tutor Audio (" + targetLang + ")]: " + text);
                    Thread.sleep(1200);
                }
            } catch (Exception e) {
                // Audio synthesis interrupted or unavailable
            } finally {
                speaking = false;
            }
        });
    }

    private void speakWindows(String text, String targetLang, int sapiRate) {
        try {
            File script = File.createTempFile("tts_tutor_", ".ps1");
            script.deleteOnExit();

            // Escape single quotes for PowerShell
            String cleanText = text.replace("'", "''");

            // Write with UTF-8 BOM so PowerShell parses Devanagari Unicode correctly
            try (FileOutputStream fos = new FileOutputStream(script);
                 OutputStreamWriter writer = new OutputStreamWriter(fos, StandardCharsets.UTF_8)) {
                fos.write(new byte[]{(byte) 0xEF, (byte) 0xBB, (byte) 0xBF}); // UTF-8 BOM

                writer.write("[Console]::OutputEncoding = [System.Text.Encoding]::UTF8;\n");
                writer.write("Add-Type -AssemblyName System.Speech;\n");
                writer.write("$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer;\n");
                writer.write("$synth.Rate = " + sapiRate + ";\n");
                writer.write("$synth.Volume = 100;\n");

                // Voice selection logic based on requested language
                writer.write("$target = '" + targetLang + "';\n");
                writer.write("$matchedVoice = $null;\n");
                writer.write("if ($target -eq 'hi') {\n");
                writer.write("    $matchedVoice = $synth.GetInstalledVoices() | Where-Object {\n");
                writer.write("        $_.Enabled -and (\n");
                writer.write("            $_.VoiceInfo.Culture.Name -like 'hi*' -or\n");
                writer.write("            $_.VoiceInfo.Name -match 'Kalpana|Hemant|Hindi'\n");
                writer.write("        )\n");
                writer.write("    } | Select-Object -First 1;\n");
                writer.write("} elseif ($target -eq 'mr') {\n");
                writer.write("    $matchedVoice = $synth.GetInstalledVoices() | Where-Object {\n");
                writer.write("        $_.Enabled -and (\n");
                writer.write("            $_.VoiceInfo.Culture.Name -like 'mr*' -or\n");
                writer.write("            $_.VoiceInfo.Name -match 'Marathi'\n");
                writer.write("        )\n");
                writer.write("    } | Select-Object -First 1;\n");
                writer.write("}\n");

                // If found, select voice. If not found, graceful fallback to default voice
                writer.write("if ($matchedVoice) {\n");
                writer.write("    try { $synth.SelectVoice($matchedVoice.VoiceInfo.Name); } catch {}\n");
                writer.write("}\n");

                writer.write("$synth.Speak('" + cleanText + "');\n");
            }

            ProcessBuilder pb = new ProcessBuilder(
                "powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script.getAbsolutePath()
            );
            pb.redirectErrorStream(true);

            synchronized (this) {
                currentProcess = pb.start();
            }

            currentProcess.waitFor();
            script.delete();
        } catch (Exception e) {
            // Audio synthesis gracefully handled
        }
    }

    private void speakMac(String text, String targetLang, int sapiRate) {
        try {
            // macOS 'say' command with words-per-minute rate mapping
            int wordsPerMinute = 160 + (sapiRate * 20); // e.g. -2 -> 120, -1 -> 140, 0 -> 160
            ProcessBuilder pb = new ProcessBuilder("say", "-r", String.valueOf(wordsPerMinute), text);
            synchronized (this) {
                currentProcess = pb.start();
            }
            currentProcess.waitFor();
        } catch (Exception e) {
            System.out.println("[macOS Voice Tutor]: " + text);
        }
    }

    private void speakLinux(String text, String targetLang, int sapiRate) {
        try {
            // Linux 'espeak' fallback
            String espeakLang = "hi".equals(targetLang) ? "hi" : ("mr".equals(targetLang) ? "mr" : "en");
            int speed = 140 + (sapiRate * 20);
            ProcessBuilder pb = new ProcessBuilder("espeak", "-v", espeakLang, "-s", String.valueOf(speed), text);
            synchronized (this) {
                currentProcess = pb.start();
            }
            currentProcess.waitFor();
        } catch (Exception e) {
            System.out.println("[Linux Voice Tutor]: " + text);
        }
    }

    /**
     * Offline speech recognition using Windows System.Speech.Recognition.
     * Listens for user's voice for up to timeoutSeconds and returns transcribed text.
     * Returns empty string if microphone or recognition is unavailable.
     */
    public String recognizeSpeech(int timeoutSeconds) {
        if (!isWindows) {
            return "";
        }

        try {
            File script = File.createTempFile("stt_listener_", ".ps1");
            script.deleteOnExit();

            try (FileOutputStream fos = new FileOutputStream(script);
                 OutputStreamWriter writer = new OutputStreamWriter(fos, StandardCharsets.UTF_8)) {
                fos.write(new byte[]{(byte) 0xEF, (byte) 0xBB, (byte) 0xBF});

                writer.write("[Console]::OutputEncoding = [System.Text.Encoding]::UTF8;\n");
                writer.write("try {\n");
                writer.write("    Add-Type -AssemblyName System.Speech;\n");
                writer.write("    $engine = New-Object System.Speech.Recognition.SpeechRecognitionEngine;\n");
                writer.write("    $engine.SetInputToDefaultAudioDevice();\n");
                writer.write("    $grammar = New-Object System.Speech.Recognition.DictationGrammar;\n");
                writer.write("    $engine.LoadGrammar($grammar);\n");
                writer.write("    $res = $engine.Recognize([TimeSpan]::FromSeconds(" + timeoutSeconds + "));\n");
                writer.write("    if ($res) { Write-Output $res.Text; } else { Write-Output ''; }\n");
                writer.write("} catch {\n");
                writer.write("    Write-Output '';\n");
                writer.write("}\n");
            }

            ProcessBuilder pb = new ProcessBuilder(
                "powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script.getAbsolutePath()
            );
            pb.redirectErrorStream(true);

            Process proc = pb.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isBlank()) {
                    sb.append(line.trim()).append(" ");
                }
            }
            proc.waitFor(timeoutSeconds + 2, TimeUnit.SECONDS);
            script.delete();
            return sb.toString().trim();
        } catch (Exception e) {
            return "";
        }
    }

    @Override
    public synchronized void stop() {
        if (currentProcess != null && currentProcess.isAlive()) {
            currentProcess.destroyForcibly();
            currentProcess = null;
        }
        speaking = false;
    }

    @Override
    public boolean isSpeaking() {
        return speaking;
    }

    @Override
    public boolean isAvailable() {
        return true;
    }
}
