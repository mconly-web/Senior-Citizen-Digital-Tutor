package com.seniortutor.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Provides comprehensive localized labels for English, Hindi, and Marathi.
 * Supports dynamic language change listeners for reactive UI updating.
 */
public class LocalizationService {
    private static LocalizationService instance;
    private String currentLanguage = "en";
    private final List<Consumer<String>> languageListeners = new ArrayList<>();

    private final Map<String, Map<String, String>> strings = new HashMap<>();

    private LocalizationService() {
        initStrings();
    }

    public static synchronized LocalizationService getInstance() {
        if (instance == null) {
            instance = new LocalizationService();
        }
        return instance;
    }

    public void addLanguageListener(Consumer<String> listener) {
        if (listener != null && !languageListeners.contains(listener)) {
            languageListeners.add(listener);
        }
    }

    public void setLanguage(String lang) {
        if (lang != null && (lang.equals("en") || lang.equals("hi") || lang.equals("mr"))) {
            this.currentLanguage = lang;
            for (Consumer<String> listener : new ArrayList<>(languageListeners)) {
                try {
                    listener.accept(lang);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public String getLanguage() {
        return currentLanguage;
    }

    public String getString(String key) {
        Map<String, String> langMap = strings.getOrDefault(currentLanguage, strings.get("en"));
        if (langMap != null && langMap.containsKey(key)) {
            return langMap.get(key);
        }
        Map<String, String> enMap = strings.get("en");
        if (enMap != null && enMap.containsKey(key)) {
            return enMap.get(key);
        }
        return key;
    }

    public String getString(String key, Object... args) {
        String pattern = getString(key);
        try {
            return String.format(pattern, args);
        } catch (Exception e) {
            return pattern;
        }
    }

    private void initStrings() {
        // ==========================================
        // ENGLISH (en)
        // ==========================================
        Map<String, String> en = new HashMap<>();
        // App & Navigation
        en.put("app.title", "Senior Citizen Digital Tutor 🌿");
        en.put("app.tagline", "\"Learn. Practice. Use. Stay Connected.\"");
        en.put("nav.home", "Home");
        en.put("nav.learn", "Learn");
        en.put("nav.practice", "Practice");
        en.put("nav.safety", "Stay Safe");
        en.put("nav.progress", "Progress");
        en.put("nav.achievements", "Badges");
        en.put("nav.family", "Family Care");
        en.put("nav.emergency", "Emergency");
        en.put("nav.settings", "Settings");

        // Top bar
        en.put("topbar.voice_on", "🔊 Voice ON");
        en.put("topbar.voice_off", "🔇 Voice OFF");

        // Home View
        en.put("home.greeting", "Good Morning 👋");
        en.put("home.subheading", "What would you like to learn today? Remember: Learn technology without fear.");
        en.put("home.search_title", "🎤 Teach Me Anything");
        en.put("home.search_prompt", "Type or ask e.g., 'How do I send a photo?' or 'How do I video call?'");
        en.put("home.search_btn", "Search");
        en.put("home.speak_btn", "Speak");
        en.put("home.popular_searches", "Popular searches:");
        en.put("home.continue_learning", "CONTINUE LEARNING");
        en.put("home.resume_btn", "Resume Lesson →");
        en.put("home.all_categories", "Explore Learning Categories");
        en.put("home.categories_sub", "Tap any topic below to begin step-by-step guidance.");
        en.put("home.tip_of_day", "💡 Daily Digital Tip");
        en.put("home.family_recommended", "Family Recommendation");
        en.put("home.start_learning", "Start Your First Lesson →");
        en.put("home.ready_to_learn", "Ready to explore the digital world?");
        en.put("home.weekly_summary", "Weekly Learning Summary");
        en.put("home.weekly_lessons", "Lessons Completed");
        en.put("home.weekly_quiz", "Avg Quiz Score");
        en.put("home.weekly_streak", "Day Streak");

        // Learn Categories & Curriculum
        en.put("learn.title", "Digital Learning Curriculum");
        en.put("learn.sub", "Choose any topic to start learning at your own calm pace.");
        en.put("learn.back_categories", "← All Categories");
        en.put("learn.completed", "Completed");
        en.put("learn.mins", "mins");
        en.put("learn.practice_included", "Practice Mode Included");
        en.put("learn.review", "Review Lesson 🔁");
        en.put("learn.start", "Start Lesson →");
        en.put("learn.lessons_count", "%d of %d lessons (%d%%)");
        en.put("learn.empty_lessons", "Lessons for this category are being prepared.");

        // Lesson Detail View
        en.put("lesson.back", "← Back to Lessons");
        en.put("lesson.step_of", "STEP %d OF %d");
        en.put("lesson.listen", "🔊 Listen");
        en.put("lesson.repeat", "🔁 Repeat");
        en.put("lesson.prev", "← Previous Step");
        en.put("lesson.next", "Next Step →");
        en.put("lesson.practice", "🎮 Practice It Now");
        en.put("lesson.quiz", "📝 Take Quick Quiz");
        en.put("lesson.completed", "✅ Complete Lesson");
        en.put("lesson.recap_title", "💡 Lesson Recap — Key Takeaways:");
        en.put("lesson.finished_title", "Lesson Completed! 🌟");
        en.put("lesson.congrats", "Congratulations!");
        en.put("lesson.finished_msg", "You have successfully finished: %s!\n\nYour progress has been saved.");

        // Quiz View
        en.put("quiz.back", "← Back to Lesson");
        en.put("quiz.header", "Quick Knowledge Check 📝");
        en.put("quiz.subtitle", "Quiz for: %s");
        en.put("quiz.question_of", "QUESTION %d OF %d");
        en.put("quiz.correct", "✅ Correct! Great Job!");
        en.put("quiz.incorrect", "❌ Not Quite, But Keep Trying!");
        en.put("quiz.next_q", "Next Question →");
        en.put("quiz.see_results", "See Final Score 🏆");
        en.put("quiz.completed_title", "Quiz Completed Successfully!");
        en.put("quiz.good_effort", "Good Effort!");
        en.put("quiz.score", "Your Score: %d / %d (%d%%)");
        en.put("quiz.passed_msg", "Fantastic! You've mastered the key concepts of this lesson.");
        en.put("quiz.failed_msg", "Reviewing makes you stronger. Feel free to re-read the lesson and try again anytime.");
        en.put("quiz.retry", "Retake Quiz 🔁");
        en.put("quiz.finish", "Finish & Back to Lessons");

        // Safety Hub & Scam Checker
        en.put("safety.title", "Digital Safety & Scam Protection");
        en.put("safety.subtitle", "Learn to spot fraudsters and inspect suspicious SMS, calls, or links before acting.");
        en.put("safety.golden_rules_title", "The 6 Golden Rules to Protect Your Life Savings");
        en.put("safety.checker_title", "\"Is This Safe?\" Educational Message Checker");
        en.put("safety.checker_sub", "Paste any suspicious SMS, WhatsApp forward, or email below to check for known scam patterns.");
        en.put("safety.paste_prompt", "Paste or type suspicious message here (e.g. 'Congratulations! You won ₹25,000 lottery')...");
        en.put("safety.sample_label", "Or try a sample real-world scam scenario:");
        en.put("safety.analyze_btn", "Analyze Message Safety 🔍");
        en.put("safety.risk_score", "Risk Score: %d / 100");
        en.put("safety.warning_signs", "Detected Warning Signs:");
        en.put("safety.recommended_actions", "Recommended Actions for Senior Citizens:");
        en.put("safety.common_scams", "Common Digital Scams Targeting Seniors");
        en.put("safety.empty_error", "Please paste or type a message, or select one of the sample buttons above.");
        en.put("safety.high_risk", "🚨 HIGH RISK (DANGER)");
        en.put("safety.suspicious", "⚠️ SUSPICIOUS");
        en.put("safety.safe", "✅ APPEARS SAFE");
        en.put("safety.helpline_title", "📞 Emergency Cyber Helpline: Dial 1930");
        en.put("safety.helpline_sub", "Report any financial cyber fraud immediately to National Cyber Crime Portal (cybercrime.gov.in)");

        // Practice Hub
        en.put("practice.title", "Hands-On Practice Simulators");
        en.put("practice.sub", "A safe place to practice with zero fear of making mistakes or losing money.");
        en.put("practice.whatsapp", "WhatsApp Chat & Call");
        en.put("practice.dialer", "Phone Dialer");
        en.put("practice.upi", "UPI Payment Simulation");
        en.put("practice.maps", "Google Maps Navigation");
        en.put("practice.email", "Email Composition");
        en.put("practice.aadhaar", "Aadhaar / DigiLocker");
        en.put("practice.billpay", "Bill Payment & Recharge");

        // Emergency View
        en.put("emergency.title", "Emergency Assistance & Quick Help");
        en.put("emergency.sub", "Tap below to get immediate help or contact your loved ones.");
        en.put("emergency.call_doctor", "Call Doctor");
        en.put("emergency.call_family", "Call Family Member");
        en.put("emergency.police", "Police (112)");
        en.put("emergency.ambulance", "Ambulance (108)");
        en.put("emergency.senior_helpline", "Elderly Helpline (14567)");
        en.put("emergency.cyber_helpline", "Cyber Fraud (1930)");

        // Settings View
        en.put("settings.title", "Settings & Accessibility");
        en.put("settings.sub", "Customize font size, contrast, voice instructions, and emergency contacts to suit your comfort.");
        en.put("settings.display_heading", "Display & Text Size");
        en.put("settings.voice_heading", "Voice Tutor & Sound Effects");
        en.put("settings.lang_heading", "Language Preference");
        en.put("settings.contacts_heading", "Emergency Numbers Configuration");
        en.put("settings.danger_heading", "Reset Learning Progress");
        en.put("settings.save_btn", "Save Emergency Contacts");
        en.put("settings.reset_btn", "Reset All Progress 🗑️");
        en.put("settings.speech_speed", "Speech Pace:");

        // Common
        en.put("btn.back", "← Back");
        en.put("btn.save", "Save");
        en.put("btn.cancel", "Cancel");
        en.put("btn.close", "Close");
        en.put("btn.ok", "OK");

        strings.put("en", en);

        // ==========================================
        // HINDI (हिंदी - hi)
        // ==========================================
        Map<String, String> hi = new HashMap<>();
        // App & Navigation
        hi.put("app.title", "सीनियर सिटीजन डिजिटल ट्यूटर 🌿");
        hi.put("app.tagline", "\"सीखें। अभ्यास करें। उपयोग करें। जुड़े रहें।\"");
        hi.put("nav.home", "मुख्य पृष्ठ");
        hi.put("nav.learn", "सीखें");
        hi.put("nav.practice", "अभ्यास करें");
        hi.put("nav.safety", "सुरक्षा");
        hi.put("nav.progress", "प्रगति");
        hi.put("nav.achievements", "उपलब्धियां");
        hi.put("nav.family", "परिवार सहायता");
        hi.put("nav.emergency", "आपातकालीन");
        hi.put("nav.settings", "सेटिंग्स");

        // Top bar
        hi.put("topbar.voice_on", "🔊 आवाज चालू");
        hi.put("topbar.voice_off", "🔇 आवाज बंद");

        // Home View
        hi.put("home.greeting", "नमस्ते एवं शुभ प्रभात 👋");
        hi.put("home.subheading", "आज आप क्या सीखना चाहेंगे? याद रखें: बिना किसी डर के शांत मन से तकनीक सीखें।");
        hi.put("home.search_title", "🎤 कुछ भी पूछें");
        hi.put("home.search_prompt", "लिखें या बोलें, जैसे: 'फोटो कैसे भेजें?' या 'वीडियो कॉल कैसे करें?'");
        hi.put("home.search_btn", "खोजें");
        hi.put("home.speak_btn", "बोलें");
        hi.put("home.popular_searches", "लोकप्रिय खोजें:");
        hi.put("home.continue_learning", "पढ़ाई जारी रखें");
        hi.put("home.resume_btn", "पाठ शुरू करें →");
        hi.put("home.all_categories", "सीखने के सभी विषय");
        hi.put("home.categories_sub", "कदम-दर-कदम मार्गदर्शन के लिए नीचे किसी भी विषय पर टैप करें।");
        hi.put("home.tip_of_day", "💡 आज का डिजिटल सुझाव");
        hi.put("home.family_recommended", "परिवार द्वारा सुझाया गया पाठ");
        hi.put("home.start_learning", "पहला पाठ शुरू करें →");
        hi.put("home.ready_to_learn", "क्या आप डिजिटल दुनिया में आगे बढ़ने के लिए तैयार हैं?");
        hi.put("home.weekly_summary", "साप्ताहिक प्रगति सारांश");
        hi.put("home.weekly_lessons", "पूर्ण पाठ");
        hi.put("home.weekly_quiz", "औसत क्विज़ स्कोर");
        hi.put("home.weekly_streak", "दिनों का सिलसिला");

        // Learn Categories & Curriculum
        hi.put("learn.title", "डिजिटल शिक्षण पाठ्यक्रम");
        hi.put("learn.sub", "अपनी गति से शांतिपूर्वक सीखने के लिए कोई भी विषय चुनें।");
        hi.put("learn.back_categories", "← सभी श्रेणियां");
        hi.put("learn.completed", "पूर्ण हुआ");
        hi.put("learn.mins", "मिनट");
        hi.put("learn.practice_included", "अभ्यास मोड उपलब्ध");
        hi.put("learn.review", "दोहराएं 🔁");
        hi.put("learn.start", "पाठ शुरू करें →");
        hi.put("learn.lessons_count", "%d / %d पाठ पूर्ण (%d%%)");
        hi.put("learn.empty_lessons", "इस श्रेणी के पाठ जल्द उपलब्ध होंगे।");

        // Lesson Detail View
        hi.put("lesson.back", "← वापस पाठों पर जाएं");
        hi.put("lesson.step_of", "चरण %d / %d");
        hi.put("lesson.listen", "🔊 सुनें");
        hi.put("lesson.repeat", "🔁 दोहराएं");
        hi.put("lesson.prev", "← पिछला चरण");
        hi.put("lesson.next", "अगला चरण →");
        hi.put("lesson.practice", "🎮 खुद अभ्यास करें");
        hi.put("lesson.quiz", "📝 छोटा क्विज़ खेलें");
        hi.put("lesson.completed", "✅ पाठ पूरा करें");
        hi.put("lesson.recap_title", "💡 पाठ का सार — मुख्य बातें:");
        hi.put("lesson.finished_title", "पाठ पूरा हुआ! 🌟");
        hi.put("lesson.congrats", "बहुत-बहुत बधाई!");
        hi.put("lesson.finished_msg", "आपने सफलता पूर्वक पूरा किया: %s!\n\nआपकी प्रगति सुरक्षित कर ली गई है।");

        // Quiz View
        hi.put("quiz.back", "← पाठ पर वापस जाएं");
        hi.put("quiz.header", "ज्ञान की त्वरित जांच 📝");
        hi.put("quiz.subtitle", "क्विज़: %s");
        hi.put("quiz.question_of", "प्रश्न %d / %d");
        hi.put("quiz.correct", "✅ बिल्कुल सही! बहुत बढ़िया!");
        hi.put("quiz.incorrect", "❌ सही नहीं, कोई बात नहीं फिर प्रयास करें!");
        hi.put("quiz.next_q", "अगला प्रश्न →");
        hi.put("quiz.see_results", "अंतिम स्कोर देखें 🏆");
        hi.put("quiz.completed_title", "क्विज़ सफलतापूर्वक पूरा हुआ!");
        hi.put("quiz.good_effort", "अच्छा प्रयास!");
        hi.put("quiz.score", "आपका स्कोर: %d / %d (%d%%)");
        hi.put("quiz.passed_msg", "शानदार! आपने इस पाठ के सभी मुख्य विचार समझ लिए हैं।");
        hi.put("quiz.failed_msg", "अभ्यास से ही सिद्धि मिलती है। आप कभी भी पाठ दोबारा पढ़कर फिर से प्रयास कर सकते हैं।");
        hi.put("quiz.retry", "क्विज़ दोबारा खेलें 🔁");
        hi.put("quiz.finish", "समाप्त करें और पाठों पर जाएं");

        // Safety Hub & Scam Checker
        hi.put("safety.title", "डिजिटल सुरक्षा एवं धोखाधड़ी से बचाव");
        hi.put("safety.subtitle", "धोखेबाजों की चालें समझें और किसी भी संदिग्ध कॉल, एसएमएस या लिंक की तुरंत जांच करें।");
        hi.put("safety.golden_rules_title", "जीवन भर की कमाई सुरक्षित रखने के 6 स्वर्णिम नियम");
        hi.put("safety.checker_title", "🚨 \"क्या यह सुरक्षित है?\" संदेश जांच");
        hi.put("safety.checker_sub", "धोखाधड़ी के पैटर्न जांचने के लिए कोई भी संदिग्ध एसएमएस या व्हाट्सएप संदेश नीचे पेस्ट करें।");
        hi.put("safety.paste_prompt", "संदिग्ध संदेश यहां पेस्ट या टाइप करें (उदा. 'बधाई! आपने ₹25,000 की लॉटरी जीती है')...");
        hi.put("safety.sample_label", "या इनमें से किसी वास्तविक उदाहरण को आजमाएं:");
        hi.put("safety.analyze_btn", "संदेश की सुरक्षा जांचें 🔍");
        hi.put("safety.risk_score", "जोखिम स्कोर: %d / 100");
        hi.put("safety.warning_signs", "पाए गए खतरे के संकेत:");
        hi.put("safety.recommended_actions", "वरिष्ठ नागरिकों के लिए जरूरी सुझाव:");
        hi.put("safety.common_scams", "वरिष्ठ नागरिकों को निशाना बनाने वाले प्रमुख फ्रॉड");
        hi.put("safety.empty_error", "कृपया कोई संदेश पेस्ट करें या ऊपर दिए गए उदाहरण बटन पर टैप करें।");
        hi.put("safety.high_risk", "🚨 गंभीर खतरा (धोखाधड़ी)");
        hi.put("safety.suspicious", "⚠️ संदेहास्पद संदेश");
        hi.put("safety.safe", "✅ सुरक्षित प्रतीत होता है");
        hi.put("safety.helpline_title", "📞 आपातकालीन साइबर हेल्पलाइन: 1930 डायल करें");
        hi.put("safety.helpline_sub", "वित्तीय साइबर धोखाधड़ी की तुरंत शिकायत राष्ट्रीय साइबर पोर्टल (cybercrime.gov.in) पर दर्ज कराएं।");

        // Practice Hub
        hi.put("practice.title", "सुरक्षित अभ्यास सिमुलेटर");
        hi.put("practice.sub", "गलती होने या पैसे कटने के डर के बिना निडर होकर अभ्यास करने का सुरक्षित स्थान।");
        hi.put("practice.whatsapp", "व्हाट्सएप चैट एवं कॉल");
        hi.put("practice.dialer", "फोन डायलर");
        hi.put("practice.upi", "यूपीआई भुगतान सिमुलेशन");
        hi.put("practice.maps", "गूगल मैप्स नेविगेशन");
        hi.put("practice.email", "ईमेल लिखना");
        hi.put("practice.aadhaar", "आधार / डिजिलॉकर डाउनलोड");
        hi.put("practice.billpay", "बिजली बिल भुगतान व रिचार्ज");

        // Emergency View
        hi.put("emergency.title", "आपातकालीन सहायता एवं त्वरित संपर्क");
        hi.put("emergency.sub", "तुरंत मदद पाने या परिवार को सूचित करने के लिए नीचे टैप करें।");
        hi.put("emergency.call_doctor", "डॉक्टर को कॉल करें");
        hi.put("emergency.call_family", "परिवार के सदस्य को कॉल करें");
        hi.put("emergency.police", "पुलिस (112)");
        hi.put("emergency.ambulance", "एम्बुलेंस (108)");
        hi.put("emergency.senior_helpline", "वरिष्ठ नागरिक हेल्पलाइन (14567)");
        hi.put("emergency.cyber_helpline", "साइबर अपराध हेल्पलाइन (1930)");

        // Settings View
        hi.put("settings.title", "सेटिंग्स और सुगमता");
        hi.put("settings.sub", "अपनी सुविधा अनुसार फ़ॉन्ट आकार, कंट्रास्ट, आवाज और आपातकालीन संपर्क बदलें।");
        hi.put("settings.display_heading", "प्रदर्शन और लिखावट का आकार");
        hi.put("settings.voice_heading", "आवाज शिक्षक एवं ध्वनि प्रभाव");
        hi.put("settings.lang_heading", "भाषा प्राथमिकता");
        hi.put("settings.contacts_heading", "आपातकालीन नंबर सेट करें");
        hi.put("settings.danger_heading", "सीखने की प्रगति रीसेट करें");
        hi.put("settings.save_btn", "आपातकालीन संपर्क सुरक्षित करें");
        hi.put("settings.reset_btn", "सभी प्रगति रीसेट करें 🗑️");
        hi.put("settings.speech_speed", "बोलने की गति:");

        // Common
        hi.put("btn.back", "← वापस");
        hi.put("btn.save", "सुरक्षित करें");
        hi.put("btn.cancel", "रद्द करें");
        hi.put("btn.close", "बंद करें");
        hi.put("btn.ok", "ठीक है");

        strings.put("hi", hi);

        // ==========================================
        // MARATHI (मराठी - mr)
        // ==========================================
        Map<String, String> mr = new HashMap<>();
        // App & Navigation
        mr.put("app.title", "ज्येष्ठ नागरिक डिजिटल शिक्षक 🌿");
        mr.put("app.tagline", "\"शिका. सराव करा. वापरा. जोडलेले राहा.\"");
        mr.put("nav.home", "मुख्य पान");
        mr.put("nav.learn", "शिका");
        mr.put("nav.practice", "सराव करा");
        mr.put("nav.safety", "सुरक्षित राहा");
        mr.put("nav.progress", "प्रगती");
        mr.put("nav.achievements", "बक्षिसे");
        mr.put("nav.family", "कुटुंब मदत");
        mr.put("nav.emergency", "तातडीची मदत");
        mr.put("nav.settings", "सेटिंग्ज");

        // Top bar
        mr.put("topbar.voice_on", "🔊 आवाज चालू");
        mr.put("topbar.voice_off", "🔇 आवाज बंद");

        // Home View
        mr.put("home.greeting", "शुभ प्रभात 👋");
        mr.put("home.subheading", "आज तुम्हाला काय शिकायचे आहे? लक्षात ठेवा: भीती न बाळगता शांतपणे तंत्रज्ञान शिका.");
        mr.put("home.search_title", "🎤 काहीही विचारा");
        mr.put("home.search_prompt", "टाईप करा किंवा बोला, उदा. 'फोटो कसा पाठवायचा?' किंवा 'व्हिडिओ कॉल कसा करायचा?'");
        mr.put("home.search_btn", "शोधा");
        mr.put("home.speak_btn", "बोला");
        mr.put("home.popular_searches", "नेहमीचे शोध:");
        mr.put("home.continue_learning", "शिकणे सुरू ठेवा");
        mr.put("home.resume_btn", "धडा सुरू करा →");
        mr.put("home.all_categories", "शिकण्याचे सर्व विषय");
        mr.put("home.categories_sub", "पायरी-दर-पायरी शिकण्यासाठी खालील विषयावर टॅप करा.");
        mr.put("home.tip_of_day", "💡 आजची डिजिटल टीप");
        mr.put("home.family_recommended", "कुटुंबियांनी सुचवलेला धडा");
        mr.put("home.start_learning", "पहिला धडा सुरू करा →");
        mr.put("home.ready_to_learn", "डिजिटल जगात आत्मविश्वासाने पुढे जाण्यासाठी तयार आहात का?");
        mr.put("home.weekly_summary", "साप्ताहिक प्रगती सारांश");
        mr.put("home.weekly_lessons", "पूर्ण झालेले धडे");
        mr.put("home.weekly_quiz", "सरासरी क्विझ गुण");
        mr.put("home.weekly_streak", "शिकण्याचे सातत्य (दिवस)");

        // Learn Categories & Curriculum
        mr.put("learn.title", "डिजिटल शिक्षण अभ्यासक्रम");
        mr.put("learn.sub", "आपल्या शांत गतीने शिकण्यासाठी कोणताही विषय निवडा.");
        mr.put("learn.back_categories", "← सर्व विषय");
        mr.put("learn.completed", "पूर्ण झाले");
        mr.put("learn.mins", "मिनिटे");
        mr.put("learn.practice_included", "सराव मोड समाविष्ट");
        mr.put("learn.review", "पुन्हा पहा 🔁");
        mr.put("learn.start", "धडा सुरू करा →");
        mr.put("learn.lessons_count", "%d / %d धडे पूर्ण (%d%%)");
        mr.put("learn.empty_lessons", "या विषयाचे धडे लवकरच तयार होत आहेत.");

        // Lesson Detail View
        mr.put("lesson.back", "← धड्यांकडे परत जा");
        mr.put("lesson.step_of", "पायरी %d / %d");
        mr.put("lesson.listen", "🔊 ऐका");
        mr.put("lesson.repeat", "🔁 पुन्हा ऐका");
        mr.put("lesson.prev", "← मागील पायरी");
        mr.put("lesson.next", "पुढील पायरी →");
        mr.put("lesson.practice", "🎮 आता सराव करा");
        mr.put("lesson.quiz", "📝 प्रश्नमंजुषा खेळा");
        mr.put("lesson.completed", "✅ धडा पूर्ण करा");
        mr.put("lesson.recap_title", "💡 धड्याचा सारांश — महत्त्वाचे मुद्दे:");
        mr.put("lesson.finished_title", "धडा पूर्ण झाला! 🌟");
        mr.put("lesson.congrats", "मनःपूर्वक अभिनंदन!");
        mr.put("lesson.finished_msg", "तुम्ही यशस्वीरीत्या पूर्ण केला आहे: %s!\n\nतुमची प्रगती जतन करण्यात आली आहे.");

        // Quiz View
        mr.put("quiz.back", "← धड्यावर परत जा");
        mr.put("quiz.header", "ज्ञानाची छोटी चाचणी 📝");
        mr.put("quiz.subtitle", "प्रश्नमंजुषा: %s");
        mr.put("quiz.question_of", "प्रश्न %d / %d");
        mr.put("quiz.correct", "✅ अगदी बरोबर! उत्तम काम!");
        mr.put("quiz.incorrect", "❌ बरोबर नाही, पण प्रयत्न चालू ठेवा!");
        mr.put("quiz.next_q", "पुढील प्रश्न →");
        mr.put("quiz.see_results", "अंतिम निकाल पहा 🏆");
        mr.put("quiz.completed_title", "चाचणी यशस्वीरीत्या पूर्ण झाली!");
        mr.put("quiz.good_effort", "छान प्रयत्न!");
        mr.put("quiz.score", "तुमचे गुण: %d / %d (%d%%)");
        mr.put("quiz.passed_msg", "खूप छान! तुम्ही या धड्यातील मुख्य संकल्पना चांगल्या प्रकारे समजून घेतल्या आहेत.");
        mr.put("quiz.failed_msg", "सरावाने माणूस परिपूर्ण होतो. हा धडा पुन्हा वाचून तुम्ही कधीही चाचणी पुन्हा देऊ शकता.");
        mr.put("quiz.retry", "चाचणी पुन्हा द्या 🔁");
        mr.put("quiz.finish", "पूर्ण करा आणि धड्यांकडे परत जा");

        // Safety Hub & Scam Checker
        mr.put("safety.title", "डिजिटल सुरक्षा आणि फसवणूक प्रतिबंध");
        mr.put("safety.subtitle", "फसवणूक ओळखायला शिका आणि संशयास्पद फोन, मेसेज किंवा लिंकची आधी खात्री करा.");
        mr.put("safety.golden_rules_title", "आयुष्यभराची पुंजी सुरक्षित ठेवण्याचे ६ सोनेरी नियम");
        mr.put("safety.checker_title", "🚨 \"हे सुरक्षित आहे का?\" मेसेज तपासणी");
        mr.put("safety.checker_sub", "संशयास्पद एसएमएस किंवा व्हॉट्सॲप मेसेज खाली पेस्ट करून फसवणुकीची लक्षणे तपासा.");
        mr.put("safety.paste_prompt", "संशयास्पद मेसेज येथे पेस्ट किंवा टाईप करा (उदा. 'अभिनंदन! तुम्ही ₹25,000 लॉटरी जिंकली आहे')...");
        mr.put("safety.sample_label", "किंवा यापैकी एखादा खरा नमुना तपासून पहा:");
        mr.put("safety.analyze_btn", "मेसेजची सुरक्षा तपासा 🔍");
        mr.put("safety.risk_score", "धोका गुण: %d / 100");
        mr.put("safety.warning_signs", "आढळलेली धोक्याची लक्षणे:");
        mr.put("safety.recommended_actions", "ज्येष्ठ नागरिकांसाठी महत्त्वाचा सल्ला:");
        mr.put("safety.common_scams", "ज्येष्ठ नागरिकांना फसवणारे नेहमीचे प्रकार");
        mr.put("safety.empty_error", "कृपया मेसेज पेस्ट करा किंवा वरील नमुना बटनावर क्लिक करा.");
        mr.put("safety.high_risk", "🚨 मोठा धोका (फसवणूक)");
        mr.put("safety.suspicious", "⚠️ संशयास्पद मेसेज");
        mr.put("safety.safe", "✅ सुरक्षित वाटते");
        mr.put("safety.helpline_title", "📞 सायबर मदत हेल्पलाइन: 1930 वर कॉल करा");
        mr.put("safety.helpline_sub", "आर्थिक सायबर फसवणूक झाल्यास त्वरित राष्ट्रीय पोर्टलवर (cybercrime.gov.in) तक्रार नोंदवा.");

        // Practice Hub
        mr.put("practice.title", "सुरक्षित सराव सिम्युलेटर");
        mr.put("practice.sub", "चूक होण्याची किंवा पैसे जाण्याची अजिबात भीती न बाळगता सराव करण्याचे सुरक्षित ठिकाण.");
        mr.put("practice.whatsapp", "व्हॉट्सॲप चॅट आणि कॉल");
        mr.put("practice.dialer", "फोन डायलर");
        mr.put("practice.upi", "यूपीआय पेमेंट सराव");
        mr.put("practice.maps", "गूगल मॅप्स नेव्हिगेशन");
        mr.put("practice.email", "ईमेल लिहिणे");
        mr.put("practice.aadhaar", "आधार / डिजीलॉकर डाउनलोड");
        mr.put("practice.billpay", "लाईट बिल भरणे व मोबाईल रिचार्ज");

        // Emergency View
        mr.put("emergency.title", "तातडीची मदत आणि त्वरित संपर्क");
        mr.put("emergency.sub", "तातडीने मदत मिळवण्यासाठी किंवा कुटुंबियांना कळवण्यासाठी खाली टॅप करा.");
        mr.put("emergency.call_doctor", "डॉक्टरांना फोन करा");
        mr.put("emergency.call_family", "कुटुंबातील सदस्याला फोन करा");
        mr.put("emergency.police", "पोलीस (112)");
        mr.put("emergency.ambulance", "रुग्णवाहिका (108)");
        mr.put("emergency.senior_helpline", "ज्येष्ठ नागरिक हेल्पलाइन (14567)");
        mr.put("emergency.cyber_helpline", "सायबर गुन्हे हेल्पलाइन (1930)");

        // Settings View
        mr.put("settings.title", "सेटिंग्ज आणि सुलभता");
        mr.put("settings.sub", "तुमच्या सोयीनुसार अक्षरांचा आकार, आवाज आणि तातडीचे संपर्क फोन नंबर बदला.");
        mr.put("settings.display_heading", "डिस्प्ले आणि अक्षरांचा आकार");
        mr.put("settings.voice_heading", "आवाज मार्गदर्शक आणि ध्वनी प्रभाव");
        mr.put("settings.lang_heading", "भाषेची निवड");
        mr.put("settings.contacts_heading", "तातडीचे संपर्क नंबर");
        mr.put("settings.danger_heading", "शिकण्याची प्रगती रीसेट करा");
        mr.put("settings.save_btn", "तातडीचे संपर्क जतन करा");
        mr.put("settings.reset_btn", "सर्व प्रगती रीसेट करा 🗑️");
        mr.put("settings.speech_speed", "बोलण्याचा वेग:");

        // Common
        mr.put("btn.back", "← मागे");
        mr.put("btn.save", "जतन करा");
        mr.put("btn.cancel", "रद्द करा");
        mr.put("btn.close", "बंद करा");
        mr.put("btn.ok", "ठीक आहे");

        strings.put("mr", mr);
    }
}
