package com.seniortutor.service;

import com.seniortutor.model.Lesson;
import com.seniortutor.repository.LessonRepository;

import java.util.*;

/**
 * Intelligent typo-tolerant and multilingual search service.
 * Supports Hindi/Marathi keywords, phonetic Indian transliterations,
 * and fuzzy typo matching for seniors.
 */
public class SearchService {
    private static SearchService instance;
    private final LessonRepository lessonRepository = new LessonRepository();

    private static final Set<String> STOP_WORDS = Set.of(
        "how", "do", "i", "to", "a", "an", "the", "in", "on", "of", "for", "is", "can",
        "my", "me", "please", "make", "use", "want", "kare", "kaise", "karen", "aani", "ani",
        "kay", "kasa", "kashi", "kase", "karo", "bataye", "sikho"
    );

    // Phonetic & common senior typo dictionary
    private static final Map<String, String> TYPO_MAP = new HashMap<>();
    static {
        // WhatsApp & messaging
        TYPO_MAP.put("watsapp", "whatsapp");
        TYPO_MAP.put("whatsap", "whatsapp");
        TYPO_MAP.put("watsap", "whatsapp");
        TYPO_MAP.put("whatapp", "whatsapp");
        TYPO_MAP.put("wtsp", "whatsapp");
        TYPO_MAP.put("mesag", "message");
        TYPO_MAP.put("msg", "message");
        TYPO_MAP.put("msj", "message");

        // Video & Audio Calls
        TYPO_MAP.put("vedio", "video");
        TYPO_MAP.put("vidio", "video");
        TYPO_MAP.put("vdo", "video");
        TYPO_MAP.put("vcall", "video call");
        TYPO_MAP.put("kol", "call");
        TYPO_MAP.put("fon", "phone");
        TYPO_MAP.put("fone", "phone");

        // Photos & Camera
        TYPO_MAP.put("camra", "camera");
        TYPO_MAP.put("cemera", "camera");
        TYPO_MAP.put("foto", "photo");
        TYPO_MAP.put("phto", "photo");
        TYPO_MAP.put("tasveer", "photo");

        // UPI & Payments
        TYPO_MAP.put("upii", "upi");
        TYPO_MAP.put("gpay", "google pay");
        TYPO_MAP.put("g-pay", "google pay");
        TYPO_MAP.put("fonpe", "phonepe");
        TYPO_MAP.put("pese", "money");
        TYPO_MAP.put("paisa", "money");
        TYPO_MAP.put("paise", "money");
        TYPO_MAP.put("rupay", "payment");
        TYPO_MAP.put("paymnt", "payment");
        TYPO_MAP.put("skan", "scan");
        TYPO_MAP.put("qrcod", "qr code");

        // Maps & Navigation
        TYPO_MAP.put("naksha", "maps");
        TYPO_MAP.put("rasta", "maps");
        TYPO_MAP.put("disha", "maps");
        TYPO_MAP.put("locashun", "location");
        TYPO_MAP.put("lokashan", "location");

        // Government & Bills
        TYPO_MAP.put("aadhar", "aadhaar");
        TYPO_MAP.put("adhar", "aadhaar");
        TYPO_MAP.put("adhaar", "aadhaar");
        TYPO_MAP.put("digiloker", "digilocker");
        TYPO_MAP.put("dglocker", "digilocker");
        TYPO_MAP.put("bijli", "electricity");
        TYPO_MAP.put("light", "electricity");
        TYPO_MAP.put("rechrg", "recharge");

        // Safety & Scams
        TYPO_MAP.put("skam", "scam");
        TYPO_MAP.put("frod", "fraud");
        TYPO_MAP.put("faud", "fraud");
        TYPO_MAP.put("chori", "scam");
        TYPO_MAP.put("dokha", "scam");
        TYPO_MAP.put("dhoka", "scam");

        // Entertainment
        TYPO_MAP.put("youtub", "youtube");
        TYPO_MAP.put("yotube", "youtube");
        TYPO_MAP.put("utube", "youtube");
        TYPO_MAP.put("yt", "youtube");
        TYPO_MAP.put("bhajan", "youtube");
        TYPO_MAP.put("katha", "youtube");
    }

    private static final List<String> CANONICAL_WORDS = List.of(
        "whatsapp", "video", "call", "photo", "camera", "phone", "dialer", "message",
        "upi", "payment", "bank", "maps", "location", "email", "aadhaar", "digilocker",
        "electricity", "recharge", "doctor", "health", "youtube", "scam", "safety",
        "battery", "power", "contact", "emergency"
    );

    private SearchService() {}

    public static synchronized SearchService getInstance() {
        if (instance == null) {
            instance = new SearchService();
        }
        return instance;
    }

    public List<Lesson> search(String query, int userId) {
        if (query == null || query.isBlank()) {
            return new ArrayList<>();
        }

        Set<Integer> seenIds = new HashSet<>();
        List<Lesson> results = new ArrayList<>();

        // 1. Direct search with raw cleaned query
        String clean = query.trim().toLowerCase()
            .replace("how do i", "")
            .replace("how to", "")
            .replace("how can i", "")
            .replace("teach me", "")
            .replace("tell me about", "")
            .replace("?", "")
            .trim();

        if (!clean.isEmpty()) {
            for (Lesson l : lessonRepository.searchLessons(clean, userId)) {
                if (seenIds.add(l.getId())) {
                    results.add(l);
                }
            }
        }

        // 2. Normalize typos and expand query
        String expandedQuery = expandQuery(clean);
        if (!expandedQuery.equalsIgnoreCase(clean)) {
            for (Lesson l : lessonRepository.searchLessons(expandedQuery, userId)) {
                if (seenIds.add(l.getId())) {
                    results.add(l);
                }
            }
        }

        // 3. Multilingual word tokenization (preserves Devanagari and Latin letters)
        String[] words = query.toLowerCase().replaceAll("[^\\p{L}\\p{Nd} ]", " ").split("\\s+");
        for (String w : words) {
            w = w.trim();
            if (w.length() >= 2 && !STOP_WORDS.contains(w)) {
                // Check if w is a known typo
                String corrected = TYPO_MAP.getOrDefault(w, w);

                // Fuzzy match against canonical keywords if not already matched
                if (corrected.equals(w) && w.length() >= 4) {
                    corrected = findFuzzyMatch(w);
                }

                for (Lesson l : lessonRepository.searchLessons(corrected, userId)) {
                    if (seenIds.add(l.getId())) {
                        results.add(l);
                    }
                }
            }
        }

        return results;
    }

    private String expandQuery(String text) {
        String[] tokens = text.split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String t : tokens) {
            String corr = TYPO_MAP.getOrDefault(t.toLowerCase(), t);
            if (corr.equals(t) && t.length() >= 4) {
                corr = findFuzzyMatch(t);
            }
            sb.append(corr).append(" ");
        }
        return sb.toString().trim();
    }

    private String findFuzzyMatch(String word) {
        String lower = word.toLowerCase();
        for (String target : CANONICAL_WORDS) {
            if (levenshteinDistance(lower, target) <= 1) {
                return target;
            }
        }
        return word;
    }

    private int levenshteinDistance(String s1, String s2) {
        int[] prev = new int[s2.length() + 1];
        int[] curr = new int[s2.length() + 1];

        for (int j = 0; j <= s2.length(); j++) prev[j] = j;

        for (int i = 1; i <= s1.length(); i++) {
            curr[0] = i;
            for (int j = 1; j <= s2.length(); j++) {
                int cost = (s1.charAt(i - 1) == s2.charAt(j - 1)) ? 0 : 1;
                curr[j] = Math.min(Math.min(curr[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            System.arraycopy(curr, 0, prev, 0, curr.length);
        }
        return prev[s2.length()];
    }
}
