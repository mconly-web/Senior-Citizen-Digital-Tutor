package com.seniortutor.service;

import com.seniortutor.model.Category;
import com.seniortutor.model.Lesson;
import com.seniortutor.model.Recommendation;
import com.seniortutor.model.User;
import com.seniortutor.repository.CategoryRepository;
import com.seniortutor.repository.LessonRepository;
import com.seniortutor.repository.RecommendationRepository;
import com.seniortutor.repository.UserRepository;

import java.util.List;

public class FamilyHelperService {
    private static FamilyHelperService instance;
    private final UserRepository userRepository = new UserRepository();
    private final CategoryRepository categoryRepository = new CategoryRepository();
    private final LessonRepository lessonRepository = new LessonRepository();
    private final RecommendationRepository recommendationRepository = new RecommendationRepository();

    private FamilyHelperService() {}

    public static synchronized FamilyHelperService getInstance() {
        if (instance == null) {
            instance = new FamilyHelperService();
        }
        return instance;
    }

    public User getSeniorUser(int seniorId) {
        return userRepository.getUserById(seniorId);
    }

    public List<Category> getCategoryProgress(int seniorId) {
        return categoryRepository.getAllCategories(seniorId);
    }

    public List<Recommendation> getActiveRecommendations(int seniorId) {
        return recommendationRepository.getActiveRecommendations(seniorId);
    }

    public void recommendLesson(int seniorId, int helperId, int lessonId, String note) {
        recommendationRepository.addRecommendation(seniorId, helperId, lessonId, note);
    }

    public void markRecommendationDone(int recId) {
        recommendationRepository.markCompleted(recId);
    }
}
