package com.seniortutor.service;

import com.seniortutor.model.QuizQuestion;
import com.seniortutor.repository.ProgressRepository;
import com.seniortutor.repository.QuizRepository;

import java.util.List;

public class QuizService {
    private static QuizService instance;
    private final QuizRepository quizRepository = new QuizRepository();
    private final ProgressRepository progressRepository = new ProgressRepository();

    private QuizService() {}

    public static synchronized QuizService getInstance() {
        if (instance == null) {
            instance = new QuizService();
        }
        return instance;
    }

    public List<QuizQuestion> getQuestionsForLesson(int lessonId) {
        return quizRepository.getQuizQuestionsForLesson(lessonId);
    }

    public void recordQuizCompletion(int userId, int lessonId, int score, boolean passed) {
        progressRepository.recordQuizResult(userId, lessonId, score, passed);
        if (passed) {
            progressRepository.markLessonCompleted(userId, lessonId);
            // Check achievement triggers
            ProgressService.getInstance().checkAndUnlockAchievements(userId);
        }
    }
}
