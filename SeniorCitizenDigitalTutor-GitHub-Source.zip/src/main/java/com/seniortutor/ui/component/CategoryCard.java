package com.seniortutor.ui.component;

import com.seniortutor.model.Category;
import com.seniortutor.service.LocalizationService;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.*;

import java.util.function.Consumer;

/**
 * Large senior-friendly card representing a learning category with progress indicator
 * and multilingual label support.
 */
public class CategoryCard extends VBox {

    public CategoryCard(Category category, Consumer<Category> onSelect) {
        String lang = LocalizationService.getInstance().getLanguage();

        setSpacing(10);
        setPadding(new Insets(20));
        setPrefWidth(340);
        setMinHeight(180);
        setAlignment(Pos.TOP_LEFT);

        setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: rgba(111, 128, 104, 0.25);" +
            "-fx-border-width: 1.5px;" +
            "-fx-border-radius: 16px;" +
            "-fx-background-radius: 16px;" +
            "-fx-cursor: hand;" +
            "-fx-effect: dropshadow(gaussian, rgba(23, 63, 53, 0.06), 8, 0, 0, 2);"
        );

        // Hover effect
        setOnMouseEntered(e -> setStyle(
            "-fx-background-color: " + UiUtils.COLOR_CREAM_LIGHT + ";" +
            "-fx-border-color: " + UiUtils.COLOR_FOREST_GREEN + ";" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 16px;" +
            "-fx-background-radius: 16px;" +
            "-fx-cursor: hand;" +
            "-fx-effect: dropshadow(gaussian, rgba(23, 63, 53, 0.15), 12, 0, 0, 4);"
        ));

        setOnMouseExited(e -> setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: rgba(111, 128, 104, 0.25);" +
            "-fx-border-width: 1.5px;" +
            "-fx-border-radius: 16px;" +
            "-fx-background-radius: 16px;" +
            "-fx-cursor: hand;" +
            "-fx-effect: dropshadow(gaussian, rgba(23, 63, 53, 0.06), 8, 0, 0, 2);"
        ));

        setOnMouseClicked(e -> {
            SoundUtil.playClick();
            if (onSelect != null) {
                onSelect.accept(category);
            }
        });

        // Icon + Name Header
        HBox header = new HBox(12);
        header.setAlignment(Pos.CENTER_LEFT);

        Label iconLbl = new Label(category.getIcon());
        iconLbl.setStyle("-fx-font-size: 32px; -fx-padding: 4px;");

        Label nameLbl = new Label(category.getLocalizedName(lang));
        nameLbl.setWrapText(true);
        nameLbl.setStyle(
            "-fx-font-size: 20px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";"
        );
        HBox.setHgrow(nameLbl, Priority.ALWAYS);

        header.getChildren().addAll(iconLbl, nameLbl);

        // Description
        Label descLbl = new Label(category.getLocalizedDescription(lang));
        descLbl.setWrapText(true);
        descLbl.setStyle(
            "-fx-font-size: 14px;" +
            "-fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";" +
            "-fx-opacity: 0.85;"
        );
        VBox.setVgrow(descLbl, Priority.ALWAYS);

        // Progress Bar & Count
        ProgressBar bar = new ProgressBar(category.getProgressPercentage());
        bar.setMaxWidth(Double.MAX_VALUE);
        bar.setPrefHeight(10);
        bar.setStyle("-fx-accent: " + (category.getProgressPercentage() >= 1.0 ? "#28A745" : UiUtils.COLOR_MUTED_GOLD) + ";");

        HBox stats = new HBox(8);
        stats.setAlignment(Pos.CENTER_LEFT);

        int pct = (int) (category.getProgressPercentage() * 100);
        String progressMsg = LocalizationService.getInstance().getString("learn.lessons_count", category.getCompletedLessonCount(), category.getLessonCount(), pct);
        Label progressText = new Label(progressMsg);
        progressText.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_SOFT_SAGE + ";");

        stats.getChildren().add(progressText);

        getChildren().addAll(header, descLbl, bar, stats);
    }
}
