package com.seniortutor.ui.component;

import com.seniortutor.model.LessonStep;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;

/**
 * Renders realistic visual representations and mock UI screens for lesson steps.
 */
public class StepIllustrationNode extends StackPane {

    public StepIllustrationNode(LessonStep step) {
        setAlignment(Pos.CENTER);
        setPadding(new Insets(10));
        setMinHeight(280);
        setMaxHeight(320);
        setStyle("-fx-background-color: transparent;");

        renderIllustration(step);
    }

    private void renderIllustration(LessonStep step) {
        String type = step.getVisualType() != null ? step.getVisualType() : "PHONE_UI";
        String data = step.getVisualData() != null ? step.getVisualData() : "";

        switch (type) {
            case "WARNING_BOX" -> getChildren().add(createWarningIllustration(step));
            case "WHATSAPP_UI" -> getChildren().add(createWhatsAppIllustration(data));
            case "UPI_UI" -> getChildren().add(createUpiIllustration(data));
            case "MAPS_UI" -> getChildren().add(createMapsIllustration(data));
            default -> getChildren().add(createPhoneIllustration(data));
        }
    }

    private VBox createPhoneIllustration(String data) {
        // Styled Smartphone Frame
        VBox phoneFrame = new VBox();
        phoneFrame.setAlignment(Pos.TOP_CENTER);
        phoneFrame.setMaxWidth(260);
        phoneFrame.setPrefHeight(270);
        phoneFrame.setStyle(
            "-fx-background-color: #1E293B;" +
            "-fx-background-radius: 28px;" +
            "-fx-border-color: #0F172A;" +
            "-fx-border-width: 4px;" +
            "-fx-border-radius: 28px;" +
            "-fx-padding: 10px 10px 14px 10px;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 12, 0, 0, 4);"
        );

        // Top speaker slit & camera notch
        HBox topNotch = new HBox(6);
        topNotch.setAlignment(Pos.CENTER);
        topNotch.setPadding(new Insets(0, 0, 6, 0));
        Rectangle speaker = new Rectangle(40, 4, Color.web("#475569"));
        speaker.setArcWidth(4);
        speaker.setArcHeight(4);
        Circle cameraLens = new Circle(3, Color.web("#334155"));
        topNotch.getChildren().addAll(speaker, cameraLens);

        // Inner Phone Screen
        VBox screen = new VBox(10);
        screen.setAlignment(Pos.CENTER);
        screen.setStyle(
            "-fx-background-color: #FFFFFF;" +
            "-fx-background-radius: 16px;" +
            "-fx-padding: 12px;"
        );
        VBox.setVgrow(screen, Priority.ALWAYS);

        if (data.contains("POWER")) {
            Label pIcon = new Label("⏻");
            pIcon.setStyle("-fx-font-size: 38px; -fx-text-fill: #DC2626;");
            Label tip = new Label("Press & hold Power button on the right side");
            tip.setWrapText(true);
            tip.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-alignment: center; -fx-text-fill: #1E293B;");
            screen.getChildren().addAll(pIcon, tip);
        } else if (data.contains("LOCK")) {
            Label lIcon = new Label("🔒");
            lIcon.setStyle("-fx-font-size: 38px;");
            Label tip = new Label("Swipe Up from bottom to unlock");
            tip.setWrapText(true);
            tip.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-alignment: center;");
            screen.getChildren().addAll(lIcon, tip);
        } else if (data.contains("VOLUME")) {
            Label vIcon = new Label("🔊");
            vIcon.setStyle("-fx-font-size: 38px;");
            Label tip = new Label("Press Top Button to increase volume");
            tip.setWrapText(true);
            tip.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-alignment: center;");
            screen.getChildren().addAll(vIcon, tip);
        } else if (data.contains("CALL")) {
            Label cIcon = new Label("📞");
            cIcon.setStyle("-fx-font-size: 42px; -fx-text-fill: #16A34A;");
            Label tip = new Label("Green button starts call\nRed button ends call");
            tip.setWrapText(true);
            tip.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-alignment: center;");
            screen.getChildren().addAll(cIcon, tip);
        } else {
            Label defIcon = new Label("📱");
            defIcon.setStyle("-fx-font-size: 42px;");
            Label tip = new Label("Follow step instructions carefully");
            tip.setWrapText(true);
            tip.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-alignment: center;");
            screen.getChildren().addAll(defIcon, tip);
        }

        phoneFrame.getChildren().addAll(topNotch, screen);
        return phoneFrame;
    }

    private VBox createWhatsAppIllustration(String data) {
        VBox waFrame = new VBox();
        waFrame.setAlignment(Pos.CENTER);
        waFrame.setMaxWidth(360);
        waFrame.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 16px;" +
            "-fx-border-color: #25D366;" +
            "-fx-border-width: 2.5px;" +
            "-fx-border-radius: 16px;" +
            "-fx-padding: 16px;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 8, 0, 0, 3);"
        );

        Label waHeader = new Label("💬 WhatsApp Chat Interface");
        waHeader.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #075E54;");

        HBox highlightRow = new HBox(12);
        highlightRow.setAlignment(Pos.CENTER);
        highlightRow.setStyle("-fx-background-color: #E8F5E9; -fx-padding: 12px; -fx-background-radius: 10px;");

        if (data.contains("VIDEO")) {
            Label icon = new Label("📹");
            icon.setStyle("-fx-font-size: 36px; -fx-background-color: #C97855; -fx-background-radius: 8px; -fx-padding: 4px 10px;");
            Label text = new Label("Look at the TOP RIGHT corner\nTap the Video Camera icon");
            text.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #1B5E20;");
            highlightRow.getChildren().addAll(icon, text);
        } else {
            Label icon = new Label("📎");
            icon.setStyle("-fx-font-size: 32px;");
            Label text = new Label("Tap Paperclip icon to attach photos,\nor Microphone to speak");
            text.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #1B5E20;");
            highlightRow.getChildren().addAll(icon, text);
        }

        waFrame.getChildren().addAll(waHeader, new Region() {{ setMinHeight(10); }}, highlightRow);
        return waFrame;
    }

    private VBox createUpiIllustration(String data) {
        VBox upiFrame = new VBox(10);
        upiFrame.setAlignment(Pos.CENTER);
        upiFrame.setMaxWidth(380);
        upiFrame.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 16px;" +
            "-fx-border-color: " + UiUtils.COLOR_MUTED_GOLD + ";" +
            "-fx-border-width: 2.5px;" +
            "-fx-border-radius: 16px;" +
            "-fx-padding: 18px;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 8, 0, 0, 3);"
        );

        Label icon = new Label("💳");
        icon.setStyle("-fx-font-size: 40px;");

        Label label = new Label("UPI Secure QR Verification");
        label.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        Label note = new Label("Point camera until square frame beeps.\nAlways check merchant name before proceeding.");
        note.setWrapText(true);
        note.setStyle("-fx-font-size: 13px; -fx-text-alignment: center; -fx-text-fill: #475569;");

        upiFrame.getChildren().addAll(icon, label, note);
        return upiFrame;
    }

    private VBox createMapsIllustration(String data) {
        VBox mapFrame = new VBox(10);
        mapFrame.setAlignment(Pos.CENTER);
        mapFrame.setMaxWidth(380);
        mapFrame.setStyle(
            "-fx-background-color: white;" +
            "-fx-background-radius: 16px;" +
            "-fx-border-color: #3B82F6;" +
            "-fx-border-width: 2.5px;" +
            "-fx-border-radius: 16px;" +
            "-fx-padding: 18px;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 8, 0, 0, 3);"
        );

        Label icon = new Label("🗺️");
        icon.setStyle("-fx-font-size: 40px;");

        Label label = new Label("Turn-by-Turn GPS Guidance");
        label.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #1E3A8A;");

        Label note = new Label("Blue line shows the route.\nGreen 'Start' button speaks directions aloud.");
        note.setWrapText(true);
        note.setStyle("-fx-font-size: 13px; -fx-text-alignment: center; -fx-text-fill: #475569;");

        mapFrame.getChildren().addAll(icon, label, note);
        return mapFrame;
    }

    private VBox createWarningIllustration(LessonStep step) {
        VBox box = new VBox(10);
        box.setAlignment(Pos.CENTER);
        box.setMaxWidth(440);
        box.setStyle(
            "-fx-background-color: #FEF2F2;" +
            "-fx-border-color: #EF4444;" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 16px;" +
            "-fx-background-radius: 16px;" +
            "-fx-padding: 20px;" +
            "-fx-effect: dropshadow(gaussian, rgba(239,68,68,0.15), 10, 0, 0, 3);"
        );

        Label shield = new Label("🛡️ ❌ CRITICAL SAFETY RULE");
        shield.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #991B1B;");

        Label exp = new Label(step.getExplanation());
        exp.setWrapText(true);
        exp.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #7F1D1D; -fx-text-alignment: center;");

        box.getChildren().addAll(shield, exp);
        return box;
    }
}
