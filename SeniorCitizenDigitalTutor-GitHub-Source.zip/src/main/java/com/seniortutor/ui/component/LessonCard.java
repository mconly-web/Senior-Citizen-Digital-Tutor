package com.seniortutor.ui.component;

import com.seniortutor.model.Lesson;
import com.seniortutor.service.LocalizationService;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;

import java.util.function.Consumer;

/**
 * Senior-friendly card for listing and launching lessons with multilingual support.
 */
public class LessonCard extends VBox {

    public LessonCard(Lesson lesson, Consumer<Lesson> onLaunch) {
        LocalizationService loc = LocalizationService.getInstance();
        String lang = loc.getLanguage();

        setSpacing(12);
        setPadding(new Insets(20));
        setPrefWidth(540);
        setAlignment(Pos.TOP_LEFT);

        setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: rgba(111, 128, 104, 0.25);" +
            "-fx-border-width: 1.5px;" +
            "-fx-border-radius: 14px;" +
            "-fx-background-radius: 14px;" +
            "-fx-effect: dropshadow(gaussian, rgba(23, 63, 53, 0.05), 6, 0, 0, 2);"
        );

        // Header with Category Tag and Completion Status
        HBox topRow = new HBox(10);
        topRow.setAlignment(Pos.CENTER_LEFT);

        Label catTag = new Label(lesson.getCategoryIcon() + " " + lesson.getCategoryName());
        catTag.setStyle(
            "-fx-background-color: #E8F0EA;" +
            "-fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";" +
            "-fx-font-size: 13px;" +
            "-fx-font-weight: bold;" +
            "-fx-padding: 4px 10px;" +
            "-fx-background-radius: 8px;"
        );

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label statusLbl = new Label(lesson.isCompleted()
            ? "✅ " + loc.getString("learn.completed")
            : "⏱️ " + lesson.getEstimatedMinutes() + " " + loc.getString("learn.mins"));
        statusLbl.setStyle(
            lesson.isCompleted()
                ? "-fx-text-fill: #28A745; -fx-font-size: 13px; -fx-font-weight: bold;"
                : "-fx-text-fill: #64748B; -fx-font-size: 13px;"
        );

        topRow.getChildren().addAll(catTag, spacer, statusLbl);

        // Title
        Label titleLbl = new Label(lesson.getLocalizedTitle(lang));
        titleLbl.setWrapText(true);
        titleLbl.setStyle(
            "-fx-font-size: 19px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";"
        );

        // Description
        Label descLbl = new Label(lesson.getLocalizedDescription(lang));
        descLbl.setWrapText(true);
        descLbl.setStyle(
            "-fx-font-size: 15px;" +
            "-fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";" +
            "-fx-opacity: 0.85;"
        );

        // Footer Row with Practice Badge and Action Button
        HBox bottomRow = new HBox(12);
        bottomRow.setAlignment(Pos.CENTER_LEFT);

        if (lesson.hasSimulation()) {
            Label simTag = new Label("🎮 " + loc.getString("learn.practice_included"));
            simTag.setStyle(
                "-fx-background-color: #FFF3CD;" +
                "-fx-text-fill: #856404;" +
                "-fx-font-size: 12px;" +
                "-fx-font-weight: bold;" +
                "-fx-padding: 4px 8px;" +
                "-fx-background-radius: 6px;"
            );
            bottomRow.getChildren().add(simTag);
        }

        Region bottomSpacer = new Region();
        HBox.setHgrow(bottomSpacer, Priority.ALWAYS);
        bottomRow.getChildren().add(bottomSpacer);

        Button startBtn = lesson.isCompleted()
            ? UiUtils.createSecondaryButton(loc.getString("learn.review"), "")
            : UiUtils.createPrimaryButton(loc.getString("learn.start"), "");
        startBtn.setStyle(startBtn.getStyle() + "-fx-font-size: 15px; -fx-padding: 8px 18px;");
        startBtn.setMinHeight(42);

        startBtn.setOnAction(e -> {
            SoundUtil.playClick();
            if (onLaunch != null) {
                onLaunch.accept(lesson);
            }
        });

        bottomRow.getChildren().add(startBtn);

        getChildren().addAll(topRow, titleLbl, descLbl, bottomRow);
    }
}
