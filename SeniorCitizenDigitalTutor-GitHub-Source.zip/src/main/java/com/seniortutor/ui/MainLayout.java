package com.seniortutor.ui;

import com.seniortutor.model.AppSettings;
import com.seniortutor.model.Category;
import com.seniortutor.model.Lesson;
import com.seniortutor.model.User;
import com.seniortutor.repository.UserRepository;
import com.seniortutor.service.LocalizationService;
import com.seniortutor.service.WindowsSpeechService;
import com.seniortutor.simulation.PracticeHubView;
import com.seniortutor.ui.dialog.ProfileManagementDialog;
import com.seniortutor.ui.view.*;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.util.Optional;

/**
 * Main Application Layout implementing responsive tablet-style container,
 * persistent top bar with accessibility shortcuts, live language adaptation,
 * profile switcher dialog, PIN-protected helper mode, and smooth view transitions.
 */
public class MainLayout extends BorderPane {

    private final NavigationBar navBar;
    private final StackPane contentArea = new StackPane();
    private final Label titleLbl = new Label();
    private final Label taglineLbl = new Label();
    private final Label voiceToggleLabel = new Label("🔊 Voice ON");
    private final Button userProfileBtn = new Button();
    private String currentTarget = "home";

    public MainLayout() {
        setStyle("-fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");

        // 1. Navigation Sidebar
        navBar = new NavigationBar(this::navigateTo);
        setLeft(navBar);

        // 2. Top Application Bar
        HBox topBar = createTopBar();
        setTop(topBar);

        // 3. Central Dynamic Content Area
        contentArea.setStyle("-fx-background-color: transparent;");
        setCenter(contentArea);

        // Listen for setting changes to adapt font scale & high contrast
        AppConfig.getInstance().addSettingsListener(this::applySettingsUpdate);
        applySettingsUpdate(AppConfig.getInstance().getCurrentSettings());

        // Listen for language changes to update top bar and refresh current view
        LocalizationService.getInstance().addLanguageListener(lang -> {
            updateLanguageStrings();
            navigateTo(currentTarget);
        });
        updateLanguageStrings();

        // Default initial view
        navigateTo("home");
    }

    private HBox createTopBar() {
        HBox bar = new HBox(16);
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setStyle(
            "-fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";" +
            "-fx-border-color: rgba(111, 128, 104, 0.3);" +
            "-fx-border-width: 0 0 1.5px 0;" +
            "-fx-padding: 12px 24px;"
        );

        // Brand Title & Tagline
        VBox brandBox = new VBox(2);
        titleLbl.setStyle(
            "-fx-font-size: 21px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";"
        );

        taglineLbl.setStyle(
            "-fx-font-size: 13px;" +
            "-fx-font-style: italic;" +
            "-fx-text-fill: " + UiUtils.COLOR_MUTED_TERRACOTTA + ";"
        );
        brandBox.getChildren().addAll(titleLbl, taglineLbl);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Accessibility Quick Controls
        HBox accessBar = new HBox(10);
        accessBar.setAlignment(Pos.CENTER);

        // Font scaling buttons
        Button fontSmaller = new Button("A-");
        styleQuickBtn(fontSmaller);
        fontSmaller.setOnAction(e -> {
            AppSettings s = AppConfig.getInstance().getCurrentSettings();
            s.setFontScale(Math.max(0.85, s.getFontScale() - 0.15));
            AppConfig.getInstance().saveCurrentSettings(s);
        });

        Button fontLarger = new Button("A+");
        styleQuickBtn(fontLarger);
        fontLarger.setOnAction(e -> {
            AppSettings s = AppConfig.getInstance().getCurrentSettings();
            s.setFontScale(Math.min(1.4, s.getFontScale() + 0.15));
            AppConfig.getInstance().saveCurrentSettings(s);
        });

        // Voice Tutor Quick Toggle
        Button voiceBtn = new Button();
        voiceBtn.setGraphic(voiceToggleLabel);
        styleQuickBtn(voiceBtn);
        voiceBtn.setOnAction(e -> {
            AppSettings s = AppConfig.getInstance().getCurrentSettings();
            s.setVoiceEnabled(!s.isVoiceEnabled());
            AppConfig.getInstance().saveCurrentSettings(s);
            if (!s.isVoiceEnabled()) {
                WindowsSpeechService.getInstance().stop();
            }
        });

        // User Switcher Profile Button
        updateProfileButton();
        userProfileBtn.setOnAction(e -> openProfileManager());

        accessBar.getChildren().addAll(fontSmaller, fontLarger, voiceBtn, userProfileBtn);

        bar.getChildren().addAll(brandBox, spacer, accessBar);
        return bar;
    }

    private void updateLanguageStrings() {
        LocalizationService loc = LocalizationService.getInstance();
        titleLbl.setText(loc.getString("app.title"));
        taglineLbl.setText(loc.getString("app.tagline"));

        boolean voiceOn = AppConfig.getInstance().getCurrentSettings().isVoiceEnabled();
        voiceToggleLabel.setText(voiceOn ? loc.getString("topbar.voice_on") : loc.getString("topbar.voice_off"));
    }

    private void styleQuickBtn(Button btn) {
        btn.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + ";" +
            "-fx-border-radius: 8px;" +
            "-fx-background-radius: 8px;" +
            "-fx-font-size: 14px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";" +
            "-fx-padding: 6px 12px;" +
            "-fx-cursor: hand;"
        );
    }

    private void updateProfileButton() {
        User u = AppConfig.getInstance().getCurrentUser();
        userProfileBtn.setText(u.getAvatar() + " " + u.getName() + " (" + u.getRole() + ")");
        userProfileBtn.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: " + UiUtils.COLOR_MUTED_GOLD + ";" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 10px;" +
            "-fx-background-radius: 10px;" +
            "-fx-font-size: 14px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";" +
            "-fx-padding: 6px 14px;" +
            "-fx-cursor: hand;"
        );
    }

    private void openProfileManager() {
        SoundUtil.playClick();
        Stage stage = (Stage) getScene().getWindow();
        ProfileManagementDialog.show(stage, newUser -> {
            updateProfileButton();
            navigateTo(newUser.isSenior() ? "home" : "family");
        });
    }

    public void navigateTo(String target) {
        // Protect Family Helper screen with optional 4-digit PIN
        if ("family".equalsIgnoreCase(target)) {
            AppSettings s = AppConfig.getInstance().getCurrentSettings();
            if (s.getHelperPin() != null && !s.getHelperPin().isBlank()) {
                TextInputDialog pinPrompt = new TextInputDialog();
                pinPrompt.setTitle("Helper Mode PIN Required");
                pinPrompt.setHeaderText("Enter 4-Digit Helper PIN");
                pinPrompt.setContentText("PIN:");
                Optional<String> entered = pinPrompt.showAndWait();
                if (entered.isEmpty() || !entered.get().equals(s.getHelperPin())) {
                    UiUtils.showErrorDialog("Access Denied", "Incorrect PIN", "The PIN you entered is incorrect. Access to Family Helper mode is protected.");
                    return;
                }
            }
        }

        this.currentTarget = target;
        contentArea.getChildren().clear();
        navBar.setActive(target);

        switch (target.toLowerCase()) {
            case "home" -> contentArea.getChildren().add(new HomeView(this::launchLesson, this::openCategory, this::navigateTo));
            case "learn" -> contentArea.getChildren().add(new LearnCategoriesView(this::launchLesson));
            case "practice" -> contentArea.getChildren().add(new PracticeHubView());
            case "safety" -> contentArea.getChildren().add(new SafetyHubView(this::navigateTo));
            case "scamspotter" -> contentArea.getChildren().add(new ScamSpotterView(this::navigateTo));
            case "progress" -> contentArea.getChildren().add(new ProgressView(this::launchLesson));
            case "achievements" -> contentArea.getChildren().add(new AchievementsView());
            case "family" -> contentArea.getChildren().add(new FamilyCareView());
            case "emergency" -> contentArea.getChildren().add(new EmergencyHelpView());
            case "settings" -> contentArea.getChildren().add(new SettingsView());
            default -> contentArea.getChildren().add(new HomeView(this::launchLesson, this::openCategory, this::navigateTo));
        }
    }

    public void launchLesson(Lesson lesson) {
        contentArea.getChildren().clear();
        navBar.setActive("learn");
        contentArea.getChildren().add(
            new LessonDetailView(lesson, this::navigateTo, this::launchQuiz, this::launchPractice)
        );
    }

    public void openCategory(Category cat) {
        contentArea.getChildren().clear();
        navBar.setActive("learn");
        contentArea.getChildren().add(new LearnCategoriesView(this::launchLesson, cat));
    }

    public void launchQuiz(Lesson lesson) {
        contentArea.getChildren().clear();
        navBar.setActive("learn");
        contentArea.getChildren().add(new QuizView(lesson, this::navigateTo));
    }

    public void launchPractice(String practiceType) {
        contentArea.getChildren().clear();
        navBar.setActive("practice");
        contentArea.getChildren().add(new PracticeHubView(practiceType));
    }

    private void applySettingsUpdate(AppSettings s) {
        if (s == null) return;

        LocalizationService loc = LocalizationService.getInstance();
        voiceToggleLabel.setText(s.isVoiceEnabled() ? loc.getString("topbar.voice_on") : loc.getString("topbar.voice_off"));

        // Scale root font size
        double scale = s.getFontScale();
        int baseSize = (int) (15 * scale);
        contentArea.setStyle("-fx-font-size: " + baseSize + "px;");

        // High contrast toggle
        if (s.isHighContrast()) {
            setStyle("-fx-background-color: #121212; -fx-text-fill: #FFF8E7;");
        } else {
            setStyle("-fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");
        }
    }
}
