package com.seniortutor.ui.dialog;

import com.seniortutor.model.AppSettings;
import com.seniortutor.model.User;
import com.seniortutor.repository.UserRepository;
import com.seniortutor.service.LocalizationService;
import com.seniortutor.service.WindowsSpeechService;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * First-Run Welcome Wizard:
 * Guides new seniors through Name, Language, Font Size & Contrast, and a 1-Minute Guided Tour.
 */
public class WelcomeWizardDialog {

    private int currentStep = 0;
    private final Stage stage;
    private final Runnable onComplete;

    private final TextField nameField = new TextField("Shanti Sharma");
    private final ComboBox<String> avatarCombo = new ComboBox<>();
    private String selectedLanguage = "en";
    private double selectedFontScale = 1.15;
    private boolean selectedHighContrast = false;

    private final StackPane contentContainer = new StackPane();
    private final Button prevBtn = UiUtils.createSecondaryButton("← Previous", "");
    private final Button nextBtn = UiUtils.createPrimaryButton("Next Step →", "");
    private final Label stepTracker = new Label("STEP 1 OF 4");

    public static void showWizard(Stage owner, Runnable onComplete) {
        new WelcomeWizardDialog(owner, onComplete).show();
    }

    private WelcomeWizardDialog(Stage owner, Runnable onComplete) {
        this.onComplete = onComplete;
        this.stage = new Stage();
        stage.initOwner(owner);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Welcome to Senior Citizen Digital Tutor 🌿");
        stage.setResizable(false);

        avatarCombo.getItems().addAll("👵", "👴", "👩", "👨", "🌸", "🌿");
        avatarCombo.setValue("👵");
    }

    private void show() {
        VBox root = new VBox(20);
        root.setPadding(new Insets(28));
        root.setPrefWidth(680);
        root.setPrefHeight(600);
        root.setStyle("-fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");

        // Top indicator
        HBox topRow = new HBox();
        topRow.setAlignment(Pos.CENTER_LEFT);
        stepTracker.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_MUTED_GOLD + ";");
        topRow.getChildren().add(stepTracker);

        contentContainer.setStyle("-fx-background-color: transparent;");
        VBox.setVgrow(contentContainer, Priority.ALWAYS);

        // Navigation bottom row
        HBox navRow = new HBox(16);
        navRow.setAlignment(Pos.CENTER);

        prevBtn.setOnAction(e -> {
            if (currentStep > 0) {
                currentStep--;
                renderStep();
            }
        });

        nextBtn.setOnAction(e -> {
            if (currentStep < 3) {
                currentStep++;
                renderStep();
            } else {
                finishWizard();
            }
        });

        navRow.getChildren().addAll(prevBtn, nextBtn);

        root.getChildren().addAll(topRow, contentContainer, navRow);

        renderStep();

        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.showAndWait();
    }

    private void renderStep() {
        contentContainer.getChildren().clear();
        stepTracker.setText("STEP " + (currentStep + 1) + " OF 4");
        prevBtn.setVisible(currentStep > 0);

        if (currentStep == 0) {
            contentContainer.getChildren().add(createStep1Welcome());
            nextBtn.setText("Next: Choose Language →");
        } else if (currentStep == 1) {
            contentContainer.getChildren().add(createStep2Language());
            nextBtn.setText("Next: Display & Text Size →");
        } else if (currentStep == 2) {
            contentContainer.getChildren().add(createStep3Display());
            nextBtn.setText("Next: 1-Minute Guided Tour →");
        } else {
            contentContainer.getChildren().add(createStep4Tour());
            nextBtn.setText("Start Learning Now! 🌟");
        }
    }

    private VBox createStep1Welcome() {
        VBox card = UiUtils.createCard();
        card.setSpacing(16);
        card.setAlignment(Pos.CENTER_LEFT);

        Label title = UiUtils.createTitle("🌿 Welcome to Senior Citizen Digital Tutor");
        Label subtitle = UiUtils.createSubtitle("Learn smartphones, WhatsApp, and digital payments calmly, with zero fear.");

        Label prompt = new Label("What is your name?");
        prompt.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        HBox inputRow = new HBox(12);
        inputRow.setAlignment(Pos.CENTER_LEFT);

        nameField.setStyle("-fx-font-size: 16px; -fx-padding: 10px; -fx-border-radius: 8px; -fx-background-radius: 8px;");
        HBox.setHgrow(nameField, Priority.ALWAYS);

        inputRow.getChildren().addAll(avatarCombo, nameField);

        Label tip = new Label("💡 Tip: Everything in this app is completely safe. You can practice without worrying about making mistakes or losing money.");
        tip.setWrapText(true);
        tip.setStyle("-fx-font-size: 14px; -fx-text-fill: #166534; -fx-background-color: #F0FDF4; -fx-padding: 12px; -fx-background-radius: 10px;");

        card.getChildren().addAll(title, subtitle, prompt, inputRow, tip);
        return card;
    }

    private VBox createStep2Language() {
        VBox card = UiUtils.createCard();
        card.setSpacing(16);

        Label title = UiUtils.createTitle("🌍 Choose Your Preferred Language");
        Label subtitle = UiUtils.createSubtitle("आपकी पसंदीदा भाषा / तुमची सोयीची भाषा निवडा");

        VBox list = new VBox(12);

        list.getChildren().addAll(
            createLanguageOption("English", "All lessons, voice tutor, and buttons in English", "en"),
            createLanguageOption("हिंदी (Hindi)", "सभी पाठ, बोलकर सिखाने वाली आवाज और बटन हिंदी में", "hi"),
            createLanguageOption("मराठी (Marathi)", "सर्व धडे, आवाज मार्गदर्शक आणि बटणे मराठीत", "mr")
        );

        card.getChildren().addAll(title, subtitle, list);
        return card;
    }

    private HBox createLanguageOption(String title, String desc, String code) {
        HBox row = new HBox(14);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(14, 18, 14, 18));
        boolean selected = code.equals(selectedLanguage);

        row.setStyle(
            "-fx-background-color: " + (selected ? "#ECFDF5" : "white") + ";" +
            "-fx-border-color: " + (selected ? UiUtils.COLOR_FOREST_GREEN : "#E2E8F0") + ";" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-cursor: hand;"
        );

        VBox textCol = new VBox(2);
        Label t = new Label(title);
        t.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");
        Label d = new Label(desc);
        d.setStyle("-fx-font-size: 13px; -fx-text-fill: #64748B;");
        textCol.getChildren().addAll(t, d);

        row.getChildren().add(textCol);
        row.setOnMouseClicked(e -> {
            SoundUtil.playClick();
            selectedLanguage = code;
            renderStep();
        });

        return row;
    }

    private VBox createStep3Display() {
        VBox card = UiUtils.createCard();
        card.setSpacing(16);

        Label title = UiUtils.createTitle("👁️ Text Size & Screen Contrast");
        Label subtitle = UiUtils.createSubtitle("Customize text size and high contrast so reading is comfortable for your eyes.");

        // Size radio buttons
        HBox sizeRow = new HBox(16);
        sizeRow.setAlignment(Pos.CENTER_LEFT);

        ToggleGroup group = new ToggleGroup();
        RadioButton rbStd = new RadioButton("Standard (16px)");
        rbStd.setToggleGroup(group);
        rbStd.setSelected(selectedFontScale <= 1.0);

        RadioButton rbLarge = new RadioButton("Large (18px)");
        rbLarge.setToggleGroup(group);
        rbLarge.setSelected(selectedFontScale > 1.0 && selectedFontScale <= 1.2);

        RadioButton rbExtra = new RadioButton("Extra Large (22px)");
        rbExtra.setToggleGroup(group);
        rbExtra.setSelected(selectedFontScale > 1.2);

        Label preview = new Label("Preview: Welcome! This is how your digital tutor text will look.");
        preview.setWrapText(true);
        preview.setStyle("-fx-font-size: 18px; -fx-padding: 16px; -fx-background-color: #FAF8F5; -fx-border-color: #CBD5E1; -fx-border-radius: 10px; -fx-background-radius: 10px; -fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";");

        group.selectedToggleProperty().addListener((obs, old, nv) -> {
            if (nv == rbExtra) {
                selectedFontScale = 1.3;
                preview.setStyle(preview.getStyle() + "-fx-font-size: 22px;");
            } else if (nv == rbLarge) {
                selectedFontScale = 1.15;
                preview.setStyle(preview.getStyle() + "-fx-font-size: 18px;");
            } else {
                selectedFontScale = 1.0;
                preview.setStyle(preview.getStyle() + "-fx-font-size: 16px;");
            }
        });

        sizeRow.getChildren().addAll(rbStd, rbLarge, rbExtra);

        CheckBox contrastCheck = new CheckBox("High Contrast Mode (Deep dark mode for low vision)");
        contrastCheck.setStyle("-fx-font-size: 15px; -fx-font-weight: bold;");
        contrastCheck.setSelected(selectedHighContrast);
        contrastCheck.setOnAction(e -> selectedHighContrast = contrastCheck.isSelected());

        card.getChildren().addAll(title, subtitle, sizeRow, preview, contrastCheck);
        return card;
    }

    private VBox createStep4Tour() {
        VBox card = UiUtils.createCard();
        card.setSpacing(14);

        Label title = UiUtils.createTitle("🧭 1-Minute Guided Tour: What You Can Do");
        Label subtitle = UiUtils.createSubtitle("Four powerful features designed specially for Indian senior citizens:");

        GridPane grid = new GridPane();
        grid.setHgap(16);
        grid.setVgap(14);

        grid.add(createTourPill("📚 1. Calm Learning Curriculum", "42 lessons covering WhatsApp, Google Maps, video calls, DigiLocker, and bill payments with voice instructions."), 0, 0);
        grid.add(createTourPill("🎮 2. Risk-Free Simulators", "Practice dialing numbers, sending WhatsApp photos, and scanning UPI QR codes with zero chance of making mistakes."), 1, 0);
        grid.add(createTourPill("🔐 3. Scam Checker & 1930", "Paste any suspicious SMS to check if it's fraud, and learn the 6 Golden Safety Rules to protect your life savings."), 0, 1);
        grid.add(createTourPill("🆘 4. One-Touch Emergency Help", "Giant buttons to call your family, medical ambulance (108), or police (112) with a single tap."), 1, 1);

        card.getChildren().addAll(title, subtitle, grid);
        return card;
    }

    private VBox createTourPill(String header, String desc) {
        VBox box = new VBox(6);
        box.setPadding(new Insets(12, 14, 12, 14));
        box.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #E2E8F0;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;"
        );
        box.setPrefWidth(280);

        Label h = new Label(header);
        h.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        Label d = new Label(desc);
        d.setWrapText(true);
        d.setStyle("-fx-font-size: 13px; -fx-text-fill: #334155;");

        box.getChildren().addAll(h, d);
        return box;
    }

    private void finishWizard() {
        SoundUtil.playSuccess();

        // Save User info
        User user = AppConfig.getInstance().getCurrentUser();
        if (user != null) {
            String name = nameField.getText().trim();
            if (!name.isEmpty()) {
                user.setName(name);
            }
            user.setAvatar(avatarCombo.getValue());
        }

        // Save Settings
        AppSettings s = AppConfig.getInstance().getCurrentSettings();
        s.setLanguage(selectedLanguage);
        s.setFontScale(selectedFontScale);
        s.setHighContrast(selectedHighContrast);
        AppConfig.getInstance().saveCurrentSettings(s);
        LocalizationService.getInstance().setLanguage(selectedLanguage);

        stage.close();
        if (onComplete != null) {
            onComplete.run();
        }
    }
}
