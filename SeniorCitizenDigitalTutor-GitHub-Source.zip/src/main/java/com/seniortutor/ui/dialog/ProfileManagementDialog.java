package com.seniortutor.ui.dialog;

import com.seniortutor.model.AppSettings;
import com.seniortutor.model.User;
import com.seniortutor.repository.UserRepository;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

/**
 * Senior & Helper Profile Switcher & Management Dialog.
 * Allows creating new profiles, switching profiles (with optional PIN lock for helpers),
 * and safely deleting profiles.
 */
public class ProfileManagementDialog {

    public static void show(Stage owner, Consumer<User> onProfileSwitched) {
        Stage dialog = new Stage();
        dialog.initOwner(owner);
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setTitle("Manage Profiles — Senior Citizen Digital Tutor");

        VBox root = new VBox(20);
        root.setPadding(new Insets(24));
        root.setStyle("-fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");
        root.setPrefWidth(580);

        Label title = UiUtils.createTitle("👥 User Profiles & Modes");
        Label subtitle = UiUtils.createSubtitle("Switch between senior learners or family helpers, or create a new profile.");

        VBox userListBox = new VBox(12);
        Runnable refreshList = () -> {
            userListBox.getChildren().clear();
            UserRepository repo = new UserRepository();
            List<User> users = repo.getAllUsers();
            User current = AppConfig.getInstance().getCurrentUser();

            for (User u : users) {
                HBox card = new HBox(14);
                card.setAlignment(Pos.CENTER_LEFT);
                card.setPadding(new Insets(12, 16, 12, 16));
                boolean isCurrent = (current != null && current.getId() == u.getId());

                card.setStyle(
                    "-fx-background-color: white;" +
                    "-fx-border-color: " + (isCurrent ? UiUtils.COLOR_FOREST_GREEN : "#E2E8F0") + ";" +
                    "-fx-border-width: " + (isCurrent ? "2.5px" : "1.5px") + ";" +
                    "-fx-border-radius: 12px;" +
                    "-fx-background-radius: 12px;"
                );

                Label avatar = new Label(u.getAvatar());
                avatar.setStyle("-fx-font-size: 28px;");

                VBox details = new VBox(2);
                Label name = new Label(u.getName() + (isCurrent ? " (Active)" : ""));
                name.setStyle("-fx-font-size: 17px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");
                Label role = new Label(u.getRole().equalsIgnoreCase("SENIOR") ? "Senior Citizen Learner" : "Family Helper / Carer");
                role.setStyle("-fx-font-size: 13px; -fx-text-fill: #64748B;");
                details.getChildren().addAll(name, role);

                Region sp = new Region();
                HBox.setHgrow(sp, Priority.ALWAYS);

                Button switchBtn = new Button(isCurrent ? "Active ✓" : "Switch →");
                switchBtn.setDisable(isCurrent);
                switchBtn.setStyle(
                    "-fx-background-color: " + (isCurrent ? "#E2E8F0" : UiUtils.COLOR_FOREST_GREEN) + ";" +
                    "-fx-text-fill: " + (isCurrent ? "#64748B" : "white") + ";" +
                    "-fx-font-size: 14px; -fx-font-weight: bold; -fx-background-radius: 8px; -fx-cursor: hand;"
                );
                switchBtn.setOnAction(e -> {
                    if (u.isHelper()) {
                        AppSettings s = AppConfig.getInstance().getCurrentSettings();
                        if (s.getHelperPin() != null && !s.getHelperPin().isBlank()) {
                            TextInputDialog pinPrompt = new TextInputDialog();
                            pinPrompt.setTitle("Helper Mode PIN Required");
                            pinPrompt.setHeaderText("Enter 4-Digit Helper PIN");
                            pinPrompt.setContentText("PIN:");
                            Optional<String> entered = pinPrompt.showAndWait();
                            if (entered.isEmpty() || !entered.get().equals(s.getHelperPin())) {
                                UiUtils.showErrorDialog("Access Denied", "Incorrect PIN", "The PIN you entered is incorrect. Access to Family Helper mode is protected.");
                                return;
                            }
                        }
                    }

                    AppConfig.getInstance().setCurrentUser(u);
                    SoundUtil.playSuccess();
                    if (onProfileSwitched != null) {
                        onProfileSwitched.accept(u);
                    }
                    dialog.close();
                });

                Button deleteBtn = new Button("🗑️");
                deleteBtn.setStyle("-fx-background-color: #FEE2E2; -fx-text-fill: #DC2626; -fx-font-size: 13px; -fx-background-radius: 8px; -fx-cursor: hand;");
                deleteBtn.setDisable(users.size() <= 1);
                deleteBtn.setOnAction(e -> {
                    Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "Delete profile for " + u.getName() + "? All learning progress will be removed.", ButtonType.YES, ButtonType.NO);
                    confirm.setHeaderText("Confirm Profile Deletion");
                    confirm.showAndWait().ifPresent(res -> {
                        if (res == ButtonType.YES) {
                            repo.deleteUser(u.getId());
                            SoundUtil.playSuccess();
                            if (isCurrent) {
                                List<User> remaining = repo.getAllUsers();
                                if (!remaining.isEmpty()) {
                                    AppConfig.getInstance().setCurrentUser(remaining.get(0));
                                    if (onProfileSwitched != null) onProfileSwitched.accept(remaining.get(0));
                                }
                            }
                            dialog.close();
                        }
                    });
                });

                card.getChildren().addAll(avatar, details, sp, switchBtn, deleteBtn);
                userListBox.getChildren().add(card);
            }
        };

        refreshList.run();

        // Create New Profile Card
        VBox createCard = UiUtils.createCard();
        createCard.setSpacing(12);

        Label createHdr = new Label("➕ Add New Profile");
        createHdr.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        HBox inputRow = new HBox(10);
        inputRow.setAlignment(Pos.CENTER_LEFT);

        TextField nameField = new TextField();
        nameField.setPromptText("Name (e.g., Ramesh Kumar)");
        HBox.setHgrow(nameField, Priority.ALWAYS);

        ComboBox<String> roleCombo = new ComboBox<>();
        roleCombo.getItems().addAll("Senior Learner", "Family Helper");
        roleCombo.setValue("Senior Learner");

        ComboBox<String> avatarCombo = new ComboBox<>();
        avatarCombo.getItems().addAll("👵", "👴", "👩", "👨", "🌸", "🌿");
        avatarCombo.setValue("👵");

        Button createBtn = UiUtils.createPrimaryButton("Create", "");
        createBtn.setOnAction(e -> {
            String name = nameField.getText().trim();
            if (name.isEmpty()) {
                UiUtils.showInfoDialog("Missing Name", "Please enter a profile name", "Name cannot be empty.");
                return;
            }

            String role = roleCombo.getValue().contains("Helper") ? "HELPER" : "SENIOR";
            String avatar = avatarCombo.getValue();

            UserRepository repo = new UserRepository();
            User newUser = repo.createUser(name, role, avatar);
            if (newUser != null) {
                SoundUtil.playSuccess();
                nameField.clear();
                refreshList.run();
            }
        });

        inputRow.getChildren().addAll(avatarCombo, nameField, roleCombo, createBtn);
        createCard.getChildren().addAll(createHdr, inputRow);

        Button closeBtn = UiUtils.createSecondaryButton("Close", "");
        closeBtn.setOnAction(e -> dialog.close());

        root.getChildren().addAll(title, subtitle, userListBox, createCard, closeBtn);

        Scene scene = new Scene(root);
        dialog.setScene(scene);
        dialog.showAndWait();
    }
}
