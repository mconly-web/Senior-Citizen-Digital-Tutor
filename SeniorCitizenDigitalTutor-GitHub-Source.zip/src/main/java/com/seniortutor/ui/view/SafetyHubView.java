package com.seniortutor.ui.view;

import com.seniortutor.model.SafetyCheckResult;
import com.seniortutor.service.LocalizationService;
import com.seniortutor.service.ProgressService;
import com.seniortutor.service.SafetyCheckerService;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.List;
import java.util.function.Consumer;

/**
 * Dedicated Digital Safety Center featuring educational scam prevention,
 * 1930 Cyber Helpline card, and the interactive "Is This Safe?" rule-based message checker
 * with multilingual advice in English, Hindi, and Marathi.
 */
public class SafetyHubView extends ScrollPane {

    private final Consumer<String> onNavigate;
    private final TextArea messageInput = new TextArea();
    private final VBox resultContainer = new VBox(12);
    private final VBox historyContainer = new VBox(10);

    public SafetyHubView() {
        this(null);
    }

    public SafetyHubView(Consumer<String> onNavigate) {
        this.onNavigate = onNavigate;

        setFitToWidth(true);
        setStyle("-fx-background: " + UiUtils.COLOR_WARM_CREAM + "; -fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");

        int userId = AppConfig.getInstance().getCurrentUser().getId();
        VBox root = new VBox(24);
        root.setPadding(new Insets(24));
        root.setFillWidth(true);

        LocalizationService loc = LocalizationService.getInstance();

        // Header
        VBox headerBox = new VBox(4);
        Label title = UiUtils.createTitle(loc.getString("safety.title"));
        Label subtitle = UiUtils.createSubtitle(loc.getString("safety.subtitle"));
        headerBox.getChildren().addAll(title, subtitle);

        // Section 1: Official Cyber Helpline 1930 Banner & Portal
        VBox helplineCard = createHelplineCard();

        // Section 2: Scam Spotter Interactive Game Banner
        VBox scamSpotterCard = createScamSpotterBannerCard();

        // Section 3: The 6 Golden Rules (High visibility alert banner)
        VBox goldenRulesCard = createGoldenRulesCard();

        // Section 4: "Is This Safe?" Interactive Checker
        VBox checkerCard = createSafetyCheckerCard();

        // Section 5: Recent Safety Checks History
        VBox historyCard = createRecentHistoryCard(userId);

        // Section 6: Educational Scam Breakdown Cards
        VBox scamTypesCard = createCommonScamsCard();

        root.getChildren().addAll(headerBox, helplineCard, scamSpotterCard, goldenRulesCard, checkerCard, historyCard, scamTypesCard);
        setContent(root);
    }

    private VBox createHelplineCard() {
        LocalizationService loc = LocalizationService.getInstance();

        VBox card = UiUtils.createCard();
        card.setStyle(
            "-fx-background-color: #EFF6FF;" +
            "-fx-border-color: #3B82F6;" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 14px;" +
            "-fx-background-radius: 14px;" +
            "-fx-padding: 16px 20px;"
        );

        HBox row = new HBox(14);
        row.setAlignment(Pos.CENTER_LEFT);

        Label badge = new Label("📞 1930");
        badge.setStyle(
            "-fx-background-color: #1D4ED8;" +
            "-fx-text-fill: white;" +
            "-fx-font-size: 22px;" +
            "-fx-font-weight: bold;" +
            "-fx-padding: 8px 16px;" +
            "-fx-background-radius: 10px;"
        );

        VBox textCol = new VBox(4);
        Label h = new Label(loc.getString("safety.helpline_title") + " & Official Reporting Portal");
        h.setStyle("-fx-font-size: 17px; -fx-font-weight: bold; -fx-text-fill: #1E3A8A;");

        Label desc = new Label(loc.getString("safety.helpline_sub"));
        desc.setWrapText(true);
        desc.setStyle("-fx-font-size: 14px; -fx-text-fill: #1E40AF;");

        HBox portalRow = new HBox(8);
        portalRow.setAlignment(Pos.CENTER_LEFT);
        Label portalTag = new Label("🌐 Official Reporting Portal:");
        portalTag.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: #1E3A8A;");
        Label portalLink = new Label("https://cybercrime.gov.in (Govt. of India)");
        portalLink.setStyle("-fx-font-size: 13px; -fx-text-fill: #2563EB; -fx-font-weight: bold; -fx-underline: true;");
        portalRow.getChildren().addAll(portalTag, portalLink);

        textCol.getChildren().addAll(h, desc, portalRow);
        row.getChildren().addAll(badge, textCol);
        card.getChildren().add(row);
        return card;
    }

    private VBox createScamSpotterBannerCard() {
        LocalizationService loc = LocalizationService.getInstance();
        String lang = loc.getLanguage();

        VBox card = UiUtils.createCard();
        card.setStyle(
            "-fx-background-color: #FFFBEB;" +
            "-fx-border-color: #F59E0B;" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 16px;" +
            "-fx-background-radius: 16px;" +
            "-fx-padding: 18px 24px;"
        );

        HBox row = new HBox(18);
        row.setAlignment(Pos.CENTER_LEFT);

        Label icon = new Label("🕵️");
        icon.setStyle("-fx-font-size: 38px;");

        VBox textCol = new VBox(4);
        Label title = new Label("hi".equals(lang) ? "स्कैम स्पॉटर मिनी-गेम 🎮" : ("mr".equals(lang) ? "स्कॅम स्पॉटर मिनी-गेम 🎮" : "Scam Spotter Mini-Game 🎮"));
        title.setStyle("-fx-font-size: 19px; -fx-font-weight: bold; -fx-text-fill: #92400E;");

        Label desc = new Label("hi".equals(lang)
            ? "वास्तविक भारतीय धोखाधड़ी संदेशों की पहचान करें! संदेश पढ़ें और 'सुरक्षित' या 'धोखाधड़ी' बटन दबाएं।"
            : ("mr".equals(lang)
                ? "खरे भारतीय फसवणूक मेसेज ओळखा! मेसेज वाचून 'सुरक्षित' किंवा 'फसवणूक' बटण निवडा."
                : "Challenge yourself with real-world Indian scam messages! Read the SMS and tap SAFE or SCAM."));
        desc.setWrapText(true);
        desc.setStyle("-fx-font-size: 14px; -fx-text-fill: #78350F;");
        textCol.getChildren().addAll(title, desc);
        HBox.setHgrow(textCol, Priority.ALWAYS);

        Button playBtn = UiUtils.createPrimaryButton("hi".equals(lang) ? "गेम खेलें →" : ("mr".equals(lang) ? "खेळ खेळा →" : "Play Scam Spotter →"), "🎮");
        playBtn.setStyle(playBtn.getStyle() + "-fx-font-size: 15px; -fx-padding: 10px 22px;");
        playBtn.setOnAction(e -> {
            SoundUtil.playClick();
            if (onNavigate != null) {
                onNavigate.accept("scamspotter");
            }
        });

        row.getChildren().addAll(icon, textCol, playBtn);
        card.getChildren().add(row);
        return card;
    }

    private VBox createGoldenRulesCard() {
        LocalizationService loc = LocalizationService.getInstance();
        String lang = loc.getLanguage();

        VBox card = UiUtils.createCard();
        card.setStyle(
            "-fx-background-color: #FEF2F2;" +
            "-fx-border-color: #EF4444;" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 16px;" +
            "-fx-background-radius: 16px;" +
            "-fx-padding: 24px;"
        );
        card.setSpacing(14);

        Label heading = new Label("🛡️ " + loc.getString("safety.golden_rules_title"));
        heading.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: #991B1B;");

        GridPane grid = new GridPane();
        grid.setHgap(20);
        grid.setVgap(12);

        String[] rules;
        if ("hi".equals(lang)) {
            rules = new String[]{
                "❌ किसी के साथ भी कभी अपना ओटीपी (OTP) साझा न करें।",
                "❌ पैसे पाने के लिए कभी यूपीआई पिन दर्ज न करें।",
                "❌ अपना एटीएम पिन या कार्ड सीवीवी कभी किसी को न बताएं।",
                "❌ किसी के कहने पर AnyDesk या TeamViewer ऐप डाउनलोड न करें।",
                "❌ बिना टिकट खरीदे लॉटरी जीतने के झांसे में न आएं।",
                "❌ 'आज रात बिजली कटेगी' वाली धमकियों से घबराएं नहीं।"
            };
        } else if ("mr".equals(lang)) {
            rules = new String[]{
                "❌ कोणाशीही कधीही तुमचा ओटीपी (OTP) शेअर करू नका.",
                "❌ पैसे मिळवण्यासाठी कधीही यूपीआय पिन टाकू नका.",
                "❌ तुमचा एटीएम पिन किंवा कार्ड सीव्हीव्ही कोणालाही सांगू नका.",
                "❌ कोणाच्याही सांगण्यावरून AnyDesk किंवा TeamViewer इन्स्टॉल करू नका.",
                "❌ तिकीट न काढता लॉटरी लागल्याच्या खोट्या मेसेजवर विश्वास ठेवू नका.",
                "❌ 'आज रात्री वीज कापली जाईल' अशा धमक्यांना अजिबात घाबरू नका."
            };
        } else {
            rules = new String[]{
                "❌ NEVER share your OTP with anyone under any pretext.",
                "❌ NEVER enter or reveal your UPI PIN to receive money.",
                "❌ NEVER share your ATM PIN or card CVV number.",
                "❌ NEVER install AnyDesk or TeamViewer on caller instructions.",
                "❌ NEVER believe you won a lottery without buying a ticket.",
                "❌ NEVER panic from 'Electricity Disconnection Tonight' threats."
            };
        }

        for (int i = 0; i < rules.length; i++) {
            Label ruleLbl = new Label(rules[i]);
            ruleLbl.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #7F1D1D;");
            grid.add(ruleLbl, i % 2, i / 2);
        }

        card.getChildren().addAll(heading, grid);
        return card;
    }

    private VBox createSafetyCheckerCard() {
        LocalizationService loc = LocalizationService.getInstance();
        String lang = loc.getLanguage();

        VBox card = UiUtils.createCard();
        card.setSpacing(16);
        card.setPadding(new Insets(24));

        Label heading = UiUtils.createTitle(loc.getString("safety.checker_title"));
        Label desc = UiUtils.createSubtitle(loc.getString("safety.checker_sub"));

        // Input Area
        messageInput.setPromptText(loc.getString("safety.paste_prompt"));
        messageInput.setPrefRowCount(4);
        messageInput.setStyle(
            "-fx-font-size: 16px;" +
            "-fx-background-color: white;" +
            "-fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + ";" +
            "-fx-border-radius: 10px;" +
            "-fx-background-radius: 10px;" +
            "-fx-padding: 10px;"
        );
        messageInput.setWrapText(true);

        // Pre-filled Real-World Sample Buttons
        Label sampleLbl = new Label(loc.getString("safety.sample_label"));
        sampleLbl.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        FlowPane samplesPane = new FlowPane(10, 8);
        if ("hi".equals(lang)) {
            samplesPane.getChildren().addAll(
                createSampleChip("🎁 लॉटरी फ्रॉड", "बधाई! आपने ₹25,000 का नकद इनाम जीता है। इनाम पाने के लिए तुरंत bit.ly/claim-prize पर क्लिक करें!"),
                createSampleChip("⚡ बिजली काटने की धमकी", "प्रिय उपभोक्ता, बिल न भरने के कारण आज रात 9:30 बजे आपकी बिजली काट दी जाएगी। तुरंत 9876543210 पर कॉल करें।"),
                createSampleChip("🔑 बैंक ओटीपी मांगना", "प्रिय एसबीआई ग्राहक, आपका डेबिट कार्ड ब्लॉक हो गया है। दोबारा शुरू करने के लिए फोन पर आया 6 अंकों का ओटीपी बताएं।"),
                createSampleChip("📱 AnyDesk ऐप डाउनलोड", "आपका पार्सल डिलीवरी फेल हो गया है। अपना पता सत्यापित करने के लिए AnyDesk ऐप डाउनलोड करें।"),
                createSampleChip("🟢 सुरक्षित पारिवारिक संदेश", "नमस्ते मां, मैं रात 7 बजे घर पहुंच रहा हूं। कृपया गरम चाय तैयार रखना!")
            );
        } else if ("mr".equals(lang)) {
            samplesPane.getChildren().addAll(
                createSampleChip("🎁 लॉटरी फसवणूक", "अभिनंदन! तुम्ही ₹25,000 चे रोख बक्षीस जिंकले आहे. बक्षीस मिळवण्यासाठी bit.ly/claim-prize वर क्लिक करा!"),
                createSampleChip("⚡ वीज कापण्याची धमकी", "प्रिय ग्राहक, लाईट बिल न भरल्यामुळे आज रात्री ९:३० वाजता तुमची वीज बंद केली जाईल. त्वरित ९८७६५४३२१० वर फोन करा."),
                createSampleChip("🔑 बँकेचा ओटीपी ट्रॅप", "प्रिय बँक ग्राहक, तुमचे डेबिट कार्ड ब्लॉक झाले आहे. चालू करण्यासाठी आलेला ६ अंकी ओटीपी त्वरित सांगा."),
                createSampleChip("📱 AnyDesk ॲप ट्रॅप", "तुमचे कुरिअर पोहोचले नाही. पत्ता तपासण्यासाठी त्वरित AnyDesk ॲप डाउनलोड करा."),
                createSampleChip("🟢 सुरक्षित कौटुंबिक मेसेज", "आई, मी संध्याकाळी ७ वाजता घरी येत आहे. चहा तयार ठेव!")
            );
        } else {
            samplesPane.getChildren().addAll(
                createSampleChip("🎁 Lottery Scam", "Congratulations! You won ₹25,000 cash prize. Click bit.ly/claim-prize immediately to claim your reward!"),
                createSampleChip("⚡ Electricity Threat", "Dear consumer, your electricity will be disconnected tonight at 9:30 PM due to unpaid bill. Call 9876543210 immediately."),
                createSampleChip("🔑 Bank OTP Trap", "Dear SBI customer, your debit card is blocked. Please share the 6-digit OTP sent to your phone to reactivate."),
                createSampleChip("📱 Remote App Trap", "Your courier delivery has failed. Download AnyDesk to verify your address with our customer care officer."),
                createSampleChip("🟢 Safe Family Text", "Hi Mom, I am reaching home at 7:00 PM for dinner. Please keep hot tea ready!")
            );
        }

        // Check Button
        Button checkBtn = UiUtils.createPrimaryButton(loc.getString("safety.analyze_btn"), "");
        checkBtn.setStyle(checkBtn.getStyle() + "-fx-font-size: 18px; -fx-padding: 12px 32px;");
        checkBtn.setOnAction(e -> runAnalysis());

        resultContainer.setPadding(new Insets(10, 0, 0, 0));

        card.getChildren().addAll(heading, desc, messageInput, sampleLbl, samplesPane, checkBtn, resultContainer);
        return card;
    }

    private Button createSampleChip(String title, String sampleText) {
        Button btn = new Button(title);
        btn.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + ";" +
            "-fx-border-radius: 14px;" +
            "-fx-background-radius: 14px;" +
            "-fx-font-size: 13px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";" +
            "-fx-padding: 6px 12px;" +
            "-fx-cursor: hand;"
        );
        btn.setOnAction(e -> {
            SoundUtil.playClick();
            messageInput.setText(sampleText);
        });
        return btn;
    }

    private void runAnalysis() {
        LocalizationService loc = LocalizationService.getInstance();
        String lang = loc.getLanguage();

        String text = messageInput.getText().trim();
        if (text.isEmpty()) {
            UiUtils.showInfoDialog(loc.getString("safety.title"), loc.getString("safety.empty_error"), "");
            return;
        }

        SoundUtil.playSuccess();
        int userId = AppConfig.getInstance().getCurrentUser().getId();
        SafetyCheckResult result = SafetyCheckerService.getInstance().analyzeMessage(text, userId, lang);

        resultContainer.getChildren().clear();

        VBox resultCard = new VBox(14);
        resultCard.setStyle(
            "-fx-background-color: #F8FAFC;" +
            "-fx-border-color: " + result.getRiskLevel().getColorHex() + ";" +
            "-fx-border-width: 2.5px;" +
            "-fx-border-radius: 14px;" +
            "-fx-background-radius: 14px;" +
            "-fx-padding: 20px;"
        );

        // Verdict Row
        HBox verdictRow = new HBox(16);
        verdictRow.setAlignment(Pos.CENTER_LEFT);

        Label verdictBadge = new Label(result.getRiskLevel().getLocalizedDisplayName(lang));
        verdictBadge.setStyle(
            "-fx-font-size: 20px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: white;" +
            "-fx-background-color: " + result.getRiskLevel().getColorHex() + ";" +
            "-fx-background-radius: 8px;" +
            "-fx-padding: 6px 16px;"
        );

        Label scoreLbl = new Label(loc.getString("safety.risk_score", result.getScore()));
        scoreLbl.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #475569;");

        verdictRow.getChildren().addAll(verdictBadge, scoreLbl);

        // Detected Flags
        VBox flagsBox = new VBox(6);
        Label flagTitle = new Label(loc.getString("safety.warning_signs"));
        flagTitle.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");
        flagsBox.getChildren().add(flagTitle);

        for (String flag : result.getDetectedFlags()) {
            Label fLbl = new Label("• " + flag);
            fLbl.setStyle("-fx-font-size: 15px; -fx-text-fill: #1E293B;");
            flagsBox.getChildren().add(fLbl);
        }

        // Why This is Risky Section
        VBox riskyBox = new VBox(6);
        if (result.getRiskExplanations() != null && !result.getRiskExplanations().isEmpty()) {
            Label riskyTitle = new Label("⚠️ " + ("hi".equals(lang) ? "यह जोखिम भरा क्यों है?" : ("mr".equals(lang) ? "हे धोकादायक का आहे?" : "Why This is Risky:")));
            riskyTitle.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #B91C1C;");
            riskyBox.getChildren().add(riskyTitle);

            for (String expl : result.getRiskExplanations()) {
                Label rLbl = new Label("• " + expl);
                rLbl.setWrapText(true);
                rLbl.setStyle("-fx-font-size: 14px; -fx-text-fill: #7F1D1D;");
                riskyBox.getChildren().add(rLbl);
            }
        }

        // Recommended Actions
        VBox adviceBox = new VBox(6);
        Label adviceTitle = new Label(loc.getString("safety.recommended_actions"));
        adviceTitle.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #1B5E20;");
        adviceBox.getChildren().add(adviceTitle);

        for (String adv : result.getRecommendations()) {
            Label aLbl = new Label(adv);
            aLbl.setWrapText(true);
            aLbl.setStyle("-fx-font-size: 15px; -fx-text-fill: #0F172A; -fx-font-weight: bold;");
            adviceBox.getChildren().add(aLbl);
        }

        resultCard.getChildren().addAll(verdictRow, flagsBox);
        if (!riskyBox.getChildren().isEmpty()) {
            resultCard.getChildren().addAll(new Separator(), riskyBox);
        }
        resultCard.getChildren().addAll(new Separator(), adviceBox);
        resultContainer.getChildren().add(resultCard);

        ProgressService.getInstance().unlockAchievementDirect(userId, "SAFETY_HERO");
        refreshRecentHistory(userId);
    }

    private VBox createRecentHistoryCard(int userId) {
        VBox card = UiUtils.createCard();
        card.setSpacing(12);
        card.setPadding(new Insets(20));

        Label heading = UiUtils.createTitle("🕒 Recent Safety Checks History");
        Label sub = UiUtils.createSubtitle("Your last analyzed messages and risk ratings");
        card.getChildren().addAll(heading, sub, historyContainer);

        refreshRecentHistory(userId);
        return card;
    }

    private void refreshRecentHistory(int userId) {
        historyContainer.getChildren().clear();
        List<String[]> recents = SafetyCheckerService.getInstance().getRecentSafetyChecks(userId);
        if (recents == null || recents.isEmpty()) {
            Label emptyLbl = new Label("No recent message checks yet. Try typing or pasting any SMS above!");
            emptyLbl.setStyle("-fx-font-size: 14px; -fx-font-style: italic; -fx-text-fill: #64748B;");
            historyContainer.getChildren().add(emptyLbl);
            return;
        }

        for (String[] check : recents) {
            String text = check[0];
            String level = check[1];
            String score = check[2];
            String time = check[3];

            HBox row = new HBox(12);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setStyle("-fx-background-color: #F8FAFC; -fx-padding: 8px 14px; -fx-background-radius: 8px; -fx-border-color: #E2E8F0; -fx-border-radius: 8px;");

            Label levelBadge = new Label(level);
            String badgeBg = "HIGH_RISK".equals(level) ? "#DC2626" : ("SUSPICIOUS".equals(level) ? "#D97706" : "#16A34A");
            levelBadge.setStyle("-fx-background-color: " + badgeBg + "; -fx-text-fill: white; -fx-font-size: 12px; -fx-font-weight: bold; -fx-padding: 4px 8px; -fx-background-radius: 6px;");

            Label scoreLbl = new Label("Score: " + score);
            scoreLbl.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: #475569;");

            Label textSnippet = new Label("\"" + text + "\"");
            textSnippet.setStyle("-fx-font-size: 13px; -fx-text-fill: #1E293B;");
            HBox.setHgrow(textSnippet, Priority.ALWAYS);

            Label timeLbl = new Label(time != null && time.length() > 16 ? time.substring(0, 16) : (time == null ? "" : time));
            timeLbl.setStyle("-fx-font-size: 12px; -fx-text-fill: #94A3B8;");

            row.getChildren().addAll(levelBadge, scoreLbl, textSnippet, timeLbl);
            historyContainer.getChildren().add(row);
        }
    }

    private VBox createCommonScamsCard() {
        LocalizationService loc = LocalizationService.getInstance();
        String lang = loc.getLanguage();

        VBox card = UiUtils.createCard();
        card.setSpacing(14);
        card.setPadding(new Insets(24));

        Label heading = UiUtils.createTitle(loc.getString("safety.common_scams"));

        GridPane grid = new GridPane();
        grid.setHgap(16);
        grid.setVgap(16);

        if ("hi".equals(lang)) {
            grid.add(createScamCard("📞 नकली बैंक अधिकारी के कॉल", "कॉलर कहता है: 'पेंशन चालू रखने के लिए अपना ओटीपी बताएं।'", "असली बैंक कभी फोन पर ओटीपी नहीं मांगते।"), 0, 0);
            grid.add(createScamCard("⚡ बिजली कटने की धमकी", "संदेश: 'बिल जमा नहीं हुआ, आज रात 1 घंटे में बिजली कट जाएगी।'", "बिजली विभाग डाक से नोटिस भेजता है, अचानक धमकी भरे एसएमएस नहीं।"), 1, 0);
            grid.add(createScamCard("📱 स्क्रीन शेयरिंग ऐप्स", "कॉलर कहता है: 'पेमेंट ठीक करने के लिए AnyDesk डाउनलोड करें।'", "AnyDesk से धोखेबाज आपके फोन के पासवर्ड देख लेते हैं।"), 0, 1);
            grid.add(createScamCard("👥 'नमस्ते मां, फोन खो गया' फ्रॉड", "अनजान नंबर से व्हाट्सएप संदेश कि आपका बच्चा मुसीबत में है और पैसे चाहिए।", "पहले अपने बच्चे के पुराने जाने-पहचाने नंबर पर सीधे फोन मिलाएं।"), 1, 1);
        } else if ("mr".equals(lang)) {
            grid.add(createScamCard("📞 खोटे बँक अधिकारी", "कॉलर म्हणतो: 'पेन्शन चालू ठेवण्यासाठी ओटीपी सांगा.'", "खरे बँक कर्मचारी फोनवर कधीही ओटीपी मागत नाहीत."), 0, 0);
            grid.add(createScamCard("⚡ वीज कापण्याची खोटी धमकी", "मेसेज: 'बिल भरले नाही, १ तासात वीज कापली जाईल.'", "वीज मंडळ पोस्टाने पत्र पाठवते, अशा धमक्यांचा मेसेज नाही."), 1, 0);
            grid.add(createScamCard("📱 स्क्रीन शेअरिंग ॲप्स", "कॉलर म्हणतो: 'पेमेंट नीट करण्यासाठी AnyDesk डाउनलोड करा.'", "AnyDesk मुळे भामटे तुमच्या फोनचे पासवर्ड बघू शकतात."), 0, 1);
            grid.add(createScamCard("👥 'आई/बाबा फोन हरवला' मेसेज", "अनोळखी नंबरवरून व्हॉट्सॲप मेसेज करून तातडीने पैसे मागणे.", "आधी मुलांच्या नेहमीच्या फोन नंबरवर थेट फोन करून खात्री करा."), 1, 1);
        } else {
            grid.add(createScamCard("📞 Fake Bank Executive Calls", "Caller says: 'Your KYC expired, tell me OTP to keep pension active.'", "Real banks will NEVER call you to ask for OTP or passwords."), 0, 0);
            grid.add(createScamCard("⚡ Electricity Power Cut Threat", "SMS says: 'Bill unpaid, electricity disconnected in 1 hour.'", "Electric boards send official postal letters, never urgent SMS with random mobile numbers."), 1, 0);
            grid.add(createScamCard("📱 Screen Sharing Traps", "Caller asks you to download 'AnyDesk' to fix a payment error.", "AnyDesk lets stranger see your screen and read your banking passwords."), 0, 1);
            grid.add(createScamCard("👥 'Hi Mum / Dad, Lost Phone' Scam", "WhatsApp message from unknown number claiming to be your child asking for cash.", "Always call your child on their regular saved phone number first."), 1, 1);
        }

        card.getChildren().addAll(heading, grid);
        return card;
    }

    private VBox createScamCard(String title, String example, String defense) {
        VBox box = new VBox(6);
        box.setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #E2E8F0;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 16px;"
        );
        box.setPrefWidth(540);

        Label t = new Label(title);
        t.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        Label ex = new Label("\"" + example + "\"");
        ex.setWrapText(true);
        ex.setStyle("-fx-font-size: 14px; -fx-font-style: italic; -fx-text-fill: #DC2626;");

        Label def = new Label("💡 " + defense);
        def.setWrapText(true);
        def.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #166534;");

        box.getChildren().addAll(t, ex, def);
        return box;
    }
}
