package com.seniortutor.ui.view;

import com.seniortutor.model.Category;
import com.seniortutor.model.Lesson;
import com.seniortutor.model.Recommendation;
import com.seniortutor.service.FamilyHelperService;
import com.seniortutor.service.LessonService;
import com.seniortutor.service.LocalizationService;
import com.seniortutor.service.ProgressService;
import com.seniortutor.service.SearchService;
import com.seniortutor.service.WindowsSpeechService;
import com.seniortutor.ui.component.CategoryCard;
import com.seniortutor.ui.component.LessonCard;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.time.LocalDate;
import java.util.List;
import java.util.function.Consumer;

/**
 * Welcoming Home Dashboard with greeting, daily digital tip, "Teach Me Anything" voice search,
 * Continue Learning card, Family recommendations, and all 12 category cards.
 * Full multilingual support (English, Hindi, Marathi).
 */
public class HomeView extends ScrollPane {

    private final Consumer<Lesson> onLaunchLesson;
    private final Consumer<Category> onSelectCategory;
    private final Consumer<String> onNavigate;
    private final VBox root = new VBox(24);
    private final VBox searchResultsBox = new VBox(12);

    public HomeView(Consumer<Lesson> onLaunchLesson, Consumer<Category> onSelectCategory, Consumer<String> onNavigate) {
        this.onLaunchLesson = onLaunchLesson;
        this.onSelectCategory = onSelectCategory;
        this.onNavigate = onNavigate;

        setFitToWidth(true);
        setStyle("-fx-background: " + UiUtils.COLOR_WARM_CREAM + "; -fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");

        root.setPadding(new Insets(24));
        root.setFillWidth(true);

        buildDashboard();
        setContent(root);
    }

    private void buildDashboard() {
        int userId = AppConfig.getInstance().getCurrentUser().getId();
        LocalizationService loc = LocalizationService.getInstance();
        String userName = AppConfig.getInstance().getCurrentUser().getName();

        // 1. Warm Greeting & Title
        VBox greetingBox = new VBox(4);
        Label greeting = UiUtils.createTitle(loc.getString("home.greeting") + ", " + userName + " Ji");
        Label subheading = UiUtils.createSubtitle(loc.getString("home.subheading"));
        greetingBox.getChildren().addAll(greeting, subheading);

        // 2. Daily Digital Tip Card & Weekly Progress Summary
        HBox tipsAndWeeklyRow = new HBox(16);
        tipsAndWeeklyRow.setFillHeight(true);
        VBox tipCard = createDailyTipCard();
        VBox weeklySummaryCard = createWeeklySummaryCard(userId);
        HBox.setHgrow(tipCard, Priority.ALWAYS);
        HBox.setHgrow(weeklySummaryCard, Priority.ALWAYS);
        tipsAndWeeklyRow.getChildren().addAll(tipCard, weeklySummaryCard);

        // 3. Large Search / Voice Section: "🎤 Teach Me Anything"
        VBox searchCard = createTeachMeAnythingCard(userId);

        // 4. Pinned Family Recommendation (if any)
        VBox recommendationCard = createFamilyRecommendationCard(userId);

        // 5. "CONTINUE LEARNING" Card
        VBox continueLearningCard = createContinueLearningCard(userId);

        // 6. Category Cards Section Header
        Label catHeading = UiUtils.createTitle(loc.getString("home.all_categories"));
        Label catSub = UiUtils.createSubtitle(loc.getString("home.categories_sub"));

        // 12 Category Cards Grid
        GridPane categoryGrid = createCategoryGrid(userId);

        root.getChildren().addAll(greetingBox, tipsAndWeeklyRow, searchCard, searchResultsBox);
        if (recommendationCard != null) {
            root.getChildren().add(recommendationCard);
        }
        root.getChildren().addAll(continueLearningCard, new VBox(4, catHeading, catSub), categoryGrid);
    }

    private VBox createDailyTipCard() {
        LocalizationService loc = LocalizationService.getInstance();
        String lang = loc.getLanguage();

        int day = LocalDate.now().getDayOfMonth() % 7;
        String tipText;

        switch (day) {
            case 0 -> tipText = "hi".equals(lang)
                ? "💡 कभी भी किसी को ओटीपी (OTP) न बताएं, चाहे वह बैंक अधिकारी ही क्यों न कहे।"
                : ("mr".equals(lang) ? "💡 बँकेचा अधिकारी बोलतोय असे कोणी सांगितले तरीही ओटीपी कधीही देऊ नका."
                                     : "💡 Never share an OTP with anyone, even if they claim to be a bank manager.");
            case 1 -> tipText = "hi".equals(lang)
                ? "💡 पैसे पाने के लिए कभी यूपीआई पिन नहीं डालना होता। पिन डालने से खाते से पैसे कटते हैं।"
                : ("mr".equals(lang) ? "💡 पैसे मिळवण्यासाठी कधीही यूपीआय पिन टाकू नका. पिन टाकल्यास खात्यातून पैसे जातात."
                                     : "💡 Entering your UPI PIN always sends money OUT. You never need a PIN to receive money.");
            case 2 -> tipText = "hi".equals(lang)
                ? "💡 असली बिजली बोर्ड 1 घंटे में लाइन काटने की धमकी वाले एसएमएस कभी नहीं भेजता।"
                : ("mr".equals(lang) ? "💡 वीज मंडळ कधीही १ तासात वीज कापण्याची धमकी देणारा असा मेसेज पाठवत नाही."
                                     : "💡 Real electricity boards send official written letters, never urgent SMS threats.");
            case 3 -> tipText = "hi".equals(lang)
                ? "💡 अनजान नंबर से आने वाले किसी भी लिंक पर कभी क्लिक न करें।"
                : ("mr".equals(lang) ? "💡 अनोळखी नंबरवरून आलेल्या लिंकवर कधीही क्लिक करू नका."
                                     : "💡 Never tap on links received from unknown numbers or strangers.");
            case 4 -> tipText = "hi".equals(lang)
                ? "💡 जब कोई अनजान व्यक्ति पैसे मांगे, तो पहले अपने बच्चों के पुराने नंबर पर फोन करके पुष्टि करें।"
                : ("mr".equals(lang) ? "💡 कोणी पैसे मागितल्यास आधी मुलांच्या जुन्या नंबरवर फोन करून खात्री करा."
                                     : "💡 Before sending money to an urgent caller, call your child on their known number first.");
            case 5 -> tipText = "hi".equals(lang)
                ? "💡 फोन को हफ्ते में एक बार रीस्टार्ट करने से वह तेज और सुरक्षित चलता है।"
                : ("mr".equals(lang) ? "💡 फोन चांगला चालण्यासाठी आठवड्यातून एकदा रीस्टार्ट करा."
                                     : "💡 Restart your smartphone once a week to keep it running smoothly.");
            default -> tipText = "hi".equals(lang)
                ? "💡 किसी भी साइबर धोखाधड़ी की तुरंत शिकायत राष्ट्रीय हेल्पलाइन 1930 पर दर्ज कराएं।"
                : ("mr".equals(lang) ? "💡 सायबर फसवणूक झाल्यास त्वरित १९३० या राष्ट्रीय हेल्पलाइनवर तक्रार करा."
                                     : "💡 Call the National Cybercrime Helpline 1930 immediately if you suspect any fraud.");
        }

        VBox card = UiUtils.createCard();
        card.setStyle(
            "-fx-background-color: #ECFDF5;" +
            "-fx-border-color: #6EE7B7;" +
            "-fx-border-width: 1.5px;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 14px 20px;"
        );

        HBox row = new HBox(12);
        row.setAlignment(Pos.CENTER_LEFT);

        Label icon = new Label("💡");
        icon.setStyle("-fx-font-size: 24px;");

        VBox textCol = new VBox(2);
        Label hdr = new Label(loc.getString("home.tip_of_day"));
        hdr.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #065F46;");

        Label body = new Label(tipText);
        body.setWrapText(true);
        body.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #047857;");

        textCol.getChildren().addAll(hdr, body);
        HBox.setHgrow(textCol, Priority.ALWAYS);

        row.getChildren().addAll(icon, textCol);
        card.getChildren().add(row);
        return card;
    }

    private VBox createWeeklySummaryCard(int userId) {
        LocalizationService loc = LocalizationService.getInstance();
        int weeklyDone = ProgressService.getInstance().getWeeklyCompletedCount(userId);
        double avgQuiz = ProgressService.getInstance().getAverageQuizScore(userId);
        int streak = ProgressService.getInstance().getUserStreak(userId);

        VBox card = UiUtils.createCard();
        card.setStyle(
            "-fx-background-color: #F0FDF4;" +
            "-fx-border-color: #86EFAC;" +
            "-fx-border-width: 1.5px;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 14px 20px;"
        );
        card.setSpacing(10);

        HBox headerRow = new HBox(8);
        headerRow.setAlignment(Pos.CENTER_LEFT);
        Label icon = new Label("📊");
        icon.setStyle("-fx-font-size: 20px;");
        Label title = new Label(loc.getString("home.weekly_summary"));
        title.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #166534;");
        headerRow.getChildren().addAll(icon, title);

        HBox statsRow = new HBox(16);
        statsRow.setAlignment(Pos.CENTER_LEFT);

        VBox col1 = createSummaryStatCol(String.valueOf(weeklyDone), loc.getString("home.weekly_lessons"), "#15803D");
        VBox col2 = createSummaryStatCol(String.format("%.0f%%", avgQuiz), loc.getString("home.weekly_quiz"), "#0284C7");
        VBox col3 = createSummaryStatCol(streak + " 🔥", loc.getString("home.weekly_streak"), "#C2410C");

        statsRow.getChildren().addAll(col1, new Separator(javafx.geometry.Orientation.VERTICAL), col2, new Separator(javafx.geometry.Orientation.VERTICAL), col3);

        card.getChildren().addAll(headerRow, statsRow);
        return card;
    }

    private VBox createSummaryStatCol(String value, String label, String colorHex) {
        VBox col = new VBox(2);
        col.setAlignment(Pos.CENTER_LEFT);
        Label valLbl = new Label(value);
        valLbl.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + colorHex + ";");
        Label descLbl = new Label(label);
        descLbl.setStyle("-fx-font-size: 12px; -fx-text-fill: #475569; -fx-font-weight: bold;");
        col.getChildren().addAll(valLbl, descLbl);
        return col;
    }

    private VBox createTeachMeAnythingCard(int userId) {
        LocalizationService loc = LocalizationService.getInstance();
        String lang = loc.getLanguage();

        VBox card = UiUtils.createCard();
        card.setStyle(card.getStyle() + "-fx-background-color: #FAF8F5; -fx-padding: 20px;");
        card.setSpacing(12);

        Label label = new Label(loc.getString("home.search_title"));
        label.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        HBox searchRow = new HBox(12);
        searchRow.setAlignment(Pos.CENTER_LEFT);

        TextField searchInput = new TextField();
        searchInput.setPromptText(loc.getString("home.search_prompt"));
        searchInput.setStyle(
            "-fx-font-size: 17px;" +
            "-fx-background-color: white;" +
            "-fx-border-color: " + UiUtils.COLOR_SOFT_SAGE + ";" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 12px 18px;"
        );
        HBox.setHgrow(searchInput, Priority.ALWAYS);

        Button searchBtn = UiUtils.createPrimaryButton(loc.getString("home.search_btn"), "🔍");
        searchBtn.setOnAction(e -> executeSearch(searchInput.getText(), userId));
        searchInput.setOnAction(e -> executeSearch(searchInput.getText(), userId));

        Button voiceSearchBtn = UiUtils.createAccentButton(loc.getString("home.speak_btn"), "🎤");
        voiceSearchBtn.setOnAction(e -> {
            SoundUtil.playClick();
            voiceSearchBtn.setText("Listening... 👂");
            new Thread(() -> {
                String spoken = WindowsSpeechService.getInstance().recognizeSpeech(3);
                Platform.runLater(() -> {
                    voiceSearchBtn.setText(loc.getString("home.speak_btn"));
                    if (spoken != null && !spoken.isBlank()) {
                        searchInput.setText(spoken);
                        executeSearch(spoken, userId);
                    } else {
                        // Fallback speech guidance
                        String promptVoice = "hi".equals(lang)
                            ? "आप क्या सीखना चाहते हैं? जैसे वीडियो कॉल या फोटो।"
                            : ("mr".equals(lang) ? "तुम्हाला काय शिकायचे आहे? जसे की व्हिडिओ कॉल किंवा फोटो."
                                                 : "What would you like to learn today? You can search for video call, photos, UPI, or maps.");
                        WindowsSpeechService.getInstance().speak(promptVoice, lang);
                        searchInput.setText("WhatsApp Video Call");
                        executeSearch("WhatsApp Video Call", userId);
                    }
                });
            }).start();
        });

        searchRow.getChildren().addAll(searchInput, searchBtn, voiceSearchBtn);

        // Quick query chips
        HBox chips = new HBox(10);
        chips.setAlignment(Pos.CENTER_LEFT);
        Label quickLbl = new Label(loc.getString("home.popular_searches"));
        quickLbl.setStyle("-fx-font-size: 13px; -fx-text-fill: #64748B; -fx-font-weight: bold;");

        chips.getChildren().add(quickLbl);
        String[] sampleQueries = "hi".equals(lang)
            ? new String[]{"वीडियो कॉल", "फोटो भेजना", "क्यूआर कोड यूपीआई", "अस्पताल खोजना", "सुरक्षा नियम"}
            : ("mr".equals(lang) ? new String[]{"व्हिडिओ कॉल", "फोटो पाठवणे", "यूपीआय स्कॅन", "दवाखाना शोधणे", "सुरक्षा नियम"}
                                 : new String[]{"Video call", "Send photos", "Scan QR UPI", "Find hospital", "Safety rules"});

        for (String q : sampleQueries) {
            Button chip = new Button(q);
            chip.setStyle("-fx-background-color: white; -fx-border-color: #CBD5E1; -fx-border-radius: 14px; -fx-background-radius: 14px; -fx-font-size: 13px; -fx-padding: 4px 12px; -fx-cursor: hand;");
            chip.setOnAction(e -> {
                searchInput.setText(q);
                executeSearch(q, userId);
            });
            chips.getChildren().add(chip);
        }

        card.getChildren().addAll(label, searchRow, chips);
        return card;
    }

    private void executeSearch(String query, int userId) {
        if (query == null || query.isBlank()) {
            searchResultsBox.getChildren().clear();
            return;
        }

        SoundUtil.playClick();
        List<Lesson> results = SearchService.getInstance().search(query, userId);
        searchResultsBox.getChildren().clear();

        VBox resultsCard = UiUtils.createCard();
        resultsCard.setSpacing(12);

        HBox top = new HBox(12);
        top.setAlignment(Pos.CENTER_LEFT);
        Label header = new Label("Results for: \"" + query + "\" (" + results.size() + " matches)");
        header.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        Region sp = new Region();
        HBox.setHgrow(sp, Priority.ALWAYS);

        Button closeBtn = new Button("✕ Clear");
        closeBtn.setOnAction(e -> searchResultsBox.getChildren().clear());
        top.getChildren().addAll(header, sp, closeBtn);

        resultsCard.getChildren().add(top);

        if (results.isEmpty()) {
            Label noRes = new Label("No exact lessons found. Try browsing the categories below!");
            noRes.setStyle("-fx-font-size: 15px; -fx-text-fill: #64748B;");
            resultsCard.getChildren().add(noRes);
        } else {
            for (Lesson l : results) {
                resultsCard.getChildren().add(new LessonCard(l, onLaunchLesson));
            }
        }

        searchResultsBox.getChildren().add(resultsCard);
    }

    private VBox createFamilyRecommendationCard(int userId) {
        List<Recommendation> recs = FamilyHelperService.getInstance().getActiveRecommendations(userId);
        if (recs.isEmpty()) return null;

        Recommendation topRec = recs.get(0);
        VBox card = UiUtils.createCard();
        card.setStyle(
            "-fx-background-color: #FFFBEB;" +
            "-fx-border-color: " + UiUtils.COLOR_MUTED_GOLD + ";" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 16px;" +
            "-fx-background-radius: 16px;" +
            "-fx-padding: 20px;"
        );
        card.setSpacing(10);

        HBox topRow = new HBox(12);
        topRow.setAlignment(Pos.CENTER_LEFT);

        Label icon = new Label("📌 👩");
        icon.setStyle("-fx-font-size: 26px;");

        VBox titleCol = new VBox(2);
        Label recFrom = new Label(LocalizationService.getInstance().getString("home.family_recommended") + ":");
        recFrom.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #92400E;");

        Label note = new Label("\"" + topRec.getNote() + "\"");
        note.setStyle("-fx-font-size: 15px; -fx-font-style: italic; -fx-text-fill: #78350F;");
        titleCol.getChildren().addAll(recFrom, note);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Lesson targetLesson = LessonService.getInstance().getLesson(topRec.getLessonId(), userId);
        Button openBtn = UiUtils.createAccentButton("Open Lesson →", "");
        openBtn.setOnAction(e -> {
            if (targetLesson != null && onLaunchLesson != null) {
                onLaunchLesson.accept(targetLesson);
            }
        });

        topRow.getChildren().addAll(icon, titleCol, spacer, openBtn);
        card.getChildren().add(topRow);
        return card;
    }

    private VBox createContinueLearningCard(int userId) {
        Lesson unfinished = LessonService.getInstance().getContinueLearningLesson(userId);
        if (unfinished == null) return new VBox();

        LocalizationService loc = LocalizationService.getInstance();
        String lang = loc.getLanguage();

        VBox card = UiUtils.createCard();
        card.setSpacing(14);
        card.setPadding(new Insets(20));

        Label sectionTag = new Label(loc.getString("home.continue_learning"));
        sectionTag.setStyle(
            "-fx-font-size: 13px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + UiUtils.COLOR_MUTED_TERRACOTTA + ";" +
            "-fx-background-color: #FDF2E9;" +
            "-fx-padding: 4px 10px;" +
            "-fx-background-radius: 6px;"
        );

        HBox row = new HBox(16);
        row.setAlignment(Pos.CENTER_LEFT);

        Label catIcon = new Label(unfinished.getCategoryIcon());
        catIcon.setStyle("-fx-font-size: 40px;");

        VBox details = new VBox(4);
        Label title = new Label(unfinished.getLocalizedTitle(lang));
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        int currentStep = Math.max(1, unfinished.getLastCompletedStep());
        int totalSteps = (unfinished.getSteps() != null && !unfinished.getSteps().isEmpty()) ? unfinished.getSteps().size() : 4;
        Label progressInfo = new Label(loc.getString("lesson.step_of", currentStep, totalSteps) + " • ⏱️ " + unfinished.getEstimatedMinutes() + " " + loc.getString("learn.mins"));
        progressInfo.setStyle("-fx-font-size: 14px; -fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";");
        details.getChildren().addAll(title, progressInfo);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button resumeBtn = UiUtils.createPrimaryButton(loc.getString("home.resume_btn"), "");
        resumeBtn.setOnAction(e -> {
            if (onLaunchLesson != null) {
                onLaunchLesson.accept(unfinished);
            }
        });

        row.getChildren().addAll(catIcon, details, spacer, resumeBtn);
        card.getChildren().addAll(sectionTag, row);
        return card;
    }

    private GridPane createCategoryGrid(int userId) {
        List<Category> categories = LessonService.getInstance().getCategories(userId);

        GridPane grid = new GridPane();
        grid.setHgap(20);
        grid.setVgap(20);

        int row = 0;
        int col = 0;
        for (Category cat : categories) {
            CategoryCard card = new CategoryCard(cat, onSelectCategory);
            grid.add(card, col, row);

            col++;
            if (col > 2) { // 3 columns for 1280px screen width
                col = 0;
                row++;
            }
        }

        return grid;
    }
}
