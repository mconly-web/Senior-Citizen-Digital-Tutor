package com.seniortutor.ui.view;

import com.seniortutor.model.Achievement;
import com.seniortutor.service.ProgressService;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.*;

import java.util.List;

/**
 * Achievements View: displays unlockable badges and milestones celebrating senior literacy accomplishments.
 */
public class AchievementsView extends ScrollPane {

    public AchievementsView() {
        setFitToWidth(true);
        setStyle("-fx-background: " + UiUtils.COLOR_WARM_CREAM + "; -fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");

        int userId = AppConfig.getInstance().getCurrentUser().getId();
        List<Achievement> achievements = ProgressService.getInstance().getAchievements(userId);

        VBox root = new VBox(24);
        root.setPadding(new Insets(24));
        root.setFillWidth(true);

        // Header
        VBox headerBox = new VBox(4);
        Label title = UiUtils.createTitle("🏆 Achievements & Milestones");
        Label subtitle = UiUtils.createSubtitle("Every small digital step is a triumph! Celebrate your learning badges here.");
        headerBox.getChildren().addAll(title, subtitle);

        // Badges Grid
        GridPane grid = new GridPane();
        grid.setHgap(20);
        grid.setVgap(20);

        int row = 0;
        int col = 0;
        for (Achievement ach : achievements) {
            VBox badgeCard = createBadgeCard(ach);
            grid.add(badgeCard, col, row);

            col++;
            if (col > 2) { // 3 badges per row
                col = 0;
                row++;
            }
        }

        root.getChildren().addAll(headerBox, grid);
        setContent(root);
    }

    private VBox createBadgeCard(Achievement ach) {
        VBox card = UiUtils.createCard();
        card.setPrefWidth(340);
        card.setMinHeight(200);
        card.setAlignment(Pos.CENTER);
        card.setSpacing(10);

        boolean unlocked = ach.isUnlocked();

        if (unlocked) {
            card.setStyle(
                "-fx-background-color: #FFFDF9;" +
                "-fx-border-color: " + UiUtils.COLOR_MUTED_GOLD + ";" +
                "-fx-border-width: 2.5px;" +
                "-fx-border-radius: 16px;" +
                "-fx-background-radius: 16px;" +
                "-fx-padding: 20px;" +
                "-fx-effect: dropshadow(gaussian, rgba(214, 168, 79, 0.25), 10, 0, 0, 3);"
            );
        } else {
            card.setStyle(
                "-fx-background-color: #F8FAFC;" +
                "-fx-border-color: #E2E8F0;" +
                "-fx-border-width: 1.5px;" +
                "-fx-border-radius: 16px;" +
                "-fx-background-radius: 16px;" +
                "-fx-padding: 20px;" +
                "-fx-opacity: 0.7;"
            );
        }

        Label iconLbl = new Label(ach.getIcon());
        iconLbl.setStyle("-fx-font-size: 48px;");

        Label titleLbl = new Label(ach.getTitle());
        titleLbl.setStyle(
            "-fx-font-size: 18px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + (unlocked ? UiUtils.COLOR_FOREST_GREEN : "#64748B") + ";"
        );

        Label descLbl = new Label(ach.getDescription());
        descLbl.setWrapText(true);
        descLbl.setStyle(
            "-fx-font-size: 14px;" +
            "-fx-text-alignment: center;" +
            "-fx-text-fill: " + (unlocked ? UiUtils.COLOR_CHARCOAL : "#94A3B8") + ";"
        );

        Label statusLbl = new Label(unlocked ? "🌟 UNLOCKED" : "🔒 IN PROGRESS");
        statusLbl.setStyle(
            "-fx-font-size: 12px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-color: " + (unlocked ? "#FEF3C7" : "#E2E8F0") + ";" +
            "-fx-text-fill: " + (unlocked ? "#92400E" : "#64748B") + ";" +
            "-fx-padding: 4px 10px;" +
            "-fx-background-radius: 10px;"
        );

        card.getChildren().addAll(iconLbl, titleLbl, descLbl, statusLbl);
        return card;
    }
}
