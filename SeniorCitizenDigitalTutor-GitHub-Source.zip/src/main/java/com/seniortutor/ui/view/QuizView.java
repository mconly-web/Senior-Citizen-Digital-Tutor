package com.seniortutor.ui.view;

import com.seniortutor.model.Lesson;
import com.seniortutor.model.QuizOption;
import com.seniortutor.model.QuizQuestion;
import com.seniortutor.service.LocalizationService;
import com.seniortutor.service.QuizService;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;

import java.util.List;
import java.util.function.Consumer;

/**
 * Interactive Quiz View providing senior-friendly multiple-choice questions with instant feedback
 * and full multilingual support (English, Hindi, Marathi).
 */
public class QuizView extends VBox {

    private final Lesson lesson;
    private final Consumer<String> onNavigate;
    private final List<QuizQuestion> questions;
    private int currentQuestionIndex = 0;
    private int correctCount = 0;

    private final StackPane quizContainer = new StackPane();

    public QuizView(Lesson lesson, Consumer<String> onNavigate) {
        this.lesson = lesson;
        this.onNavigate = onNavigate;
        this.questions = QuizService.getInstance().getQuestionsForLesson(lesson.getId());

        setSpacing(16);
        setPadding(new Insets(24));
        setStyle("-fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");
        setFillWidth(true);

        buildHeader();

        quizContainer.setStyle("-fx-background-color: transparent;");
        VBox.setVgrow(quizContainer, Priority.ALWAYS);
        getChildren().add(quizContainer);

        showCurrentQuestion();
    }

    private void buildHeader() {
        LocalizationService loc = LocalizationService.getInstance();
        String lang = loc.getLanguage();

        HBox topRow = new HBox(16);
        topRow.setAlignment(Pos.CENTER_LEFT);

        Button backBtn = UiUtils.createSecondaryButton(loc.getString("quiz.back"), "");
        backBtn.setOnAction(e -> onNavigate.accept("learn"));

        VBox titleBox = new VBox(2);
        Label subtitle = new Label(loc.getString("quiz.subtitle", lesson.getLocalizedTitle(lang)));
        subtitle.setStyle("-fx-font-size: 14px; -fx-text-fill: " + UiUtils.COLOR_SOFT_SAGE + "; -fx-font-weight: bold;");

        Label title = new Label(loc.getString("quiz.header"));
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");
        titleBox.getChildren().addAll(subtitle, title);

        topRow.getChildren().addAll(backBtn, titleBox);
        getChildren().add(topRow);
    }

    private void showCurrentQuestion() {
        quizContainer.getChildren().clear();
        LocalizationService loc = LocalizationService.getInstance();
        String lang = loc.getLanguage();

        if (questions == null || questions.isEmpty()) {
            VBox emptyCard = UiUtils.createCard();
            emptyCard.setAlignment(Pos.CENTER);
            emptyCard.getChildren().addAll(
                new Label(loc.getString("learn.empty_lessons")),
                UiUtils.createPrimaryButton(loc.getString("quiz.finish"), "")
            );
            quizContainer.getChildren().add(emptyCard);
            return;
        }

        QuizQuestion q = questions.get(currentQuestionIndex);

        VBox card = UiUtils.createCard();
        card.setMaxWidth(720);
        card.setSpacing(18);
        card.setPadding(new Insets(28));
        card.setAlignment(Pos.TOP_LEFT);

        // Tracker: Question 1 of 3
        Label progressLbl = new Label(loc.getString("quiz.question_of", (currentQuestionIndex + 1), questions.size()));
        progressLbl.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_MUTED_GOLD + ";");

        // Question Title
        Label qText = new Label(q.getLocalizedQuestionText(lang));
        qText.setWrapText(true);
        qText.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        // Options Box
        VBox optionsBox = new VBox(12);
        optionsBox.setFillWidth(true);

        char optLetter = 'A';
        for (QuizOption opt : q.getOptions()) {
            Button optBtn = createOptionButton(optLetter + ". " + opt.getLocalizedOptionText(lang), opt, q);
            optionsBox.getChildren().add(optBtn);
            optLetter++;
        }

        card.getChildren().addAll(progressLbl, qText, optionsBox);

        VBox centerWrap = new VBox(card);
        centerWrap.setAlignment(Pos.CENTER);
        quizContainer.getChildren().add(centerWrap);
    }

    private Button createOptionButton(String text, QuizOption option, QuizQuestion question) {
        Button btn = new Button(text);
        btn.setMaxWidth(Double.MAX_VALUE);
        btn.setAlignment(Pos.CENTER_LEFT);
        btn.setStyle(
            "-fx-font-size: 17px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";" +
            "-fx-background-color: white;" +
            "-fx-border-color: #E2E8F0;" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 14px 20px;" +
            "-fx-cursor: hand;"
        );

        btn.setOnAction(e -> handleAnswer(option, question));
        return btn;
    }

    private void handleAnswer(QuizOption option, QuizQuestion question) {
        LocalizationService loc = LocalizationService.getInstance();
        String lang = loc.getLanguage();
        boolean isCorrect = option.isCorrect();

        if (isCorrect) {
            SoundUtil.playSuccess();
            correctCount++;
        } else {
            SoundUtil.playWarning();
        }

        // Display feedback card
        quizContainer.getChildren().clear();

        VBox card = UiUtils.createCard();
        card.setMaxWidth(680);
        card.setSpacing(20);
        card.setAlignment(Pos.CENTER);
        card.setPadding(new Insets(32));

        Label feedbackIcon = new Label(isCorrect ? loc.getString("quiz.correct") : loc.getString("quiz.incorrect"));
        feedbackIcon.setStyle(
            "-fx-font-size: 24px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + (isCorrect ? "#28A745;" : "#DC3545;")
        );

        Label explanationLbl = new Label(question.getLocalizedExplanation(lang));
        explanationLbl.setWrapText(true);
        explanationLbl.setStyle(
            "-fx-font-size: 17px;" +
            "-fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";" +
            "-fx-text-alignment: center;" +
            "-fx-background-color: #F8FAFC;" +
            "-fx-padding: 16px 20px;" +
            "-fx-background-radius: 12px;"
        );

        Button continueBtn = UiUtils.createPrimaryButton(
            (currentQuestionIndex < questions.size() - 1) ? loc.getString("quiz.next_q") : loc.getString("quiz.see_results"), ""
        );

        continueBtn.setOnAction(e -> {
            if (currentQuestionIndex < questions.size() - 1) {
                currentQuestionIndex++;
                showCurrentQuestion();
            } else {
                showQuizResults();
            }
        });

        card.getChildren().addAll(feedbackIcon, explanationLbl, continueBtn);

        VBox centerWrap = new VBox(card);
        centerWrap.setAlignment(Pos.CENTER);
        quizContainer.getChildren().add(centerWrap);
    }

    private void showQuizResults() {
        quizContainer.getChildren().clear();
        LocalizationService loc = LocalizationService.getInstance();

        int total = questions.size();
        int scorePct = (int) (((double) correctCount / total) * 100);
        boolean passed = scorePct >= 60;

        int userId = AppConfig.getInstance().getCurrentUser().getId();
        QuizService.getInstance().recordQuizCompletion(userId, lesson.getId(), scorePct, passed);

        VBox card = UiUtils.createCard();
        card.setMaxWidth(640);
        card.setSpacing(18);
        card.setAlignment(Pos.CENTER);
        card.setPadding(new Insets(36));

        Label trophy = new Label(passed ? "🏆" : "💪");
        trophy.setStyle("-fx-font-size: 64px;");

        Label resultTitle = new Label(passed ? loc.getString("quiz.completed_title") : loc.getString("quiz.good_effort"));
        resultTitle.setStyle("-fx-font-size: 26px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        Label scoreLbl = new Label(loc.getString("quiz.score", correctCount, total, scorePct));
        scoreLbl.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_MUTED_GOLD + ";");

        Label encouragement = new Label(passed ? loc.getString("quiz.passed_msg") : loc.getString("quiz.failed_msg"));
        encouragement.setWrapText(true);
        encouragement.setStyle("-fx-font-size: 16px; -fx-text-fill: " + UiUtils.COLOR_CHARCOAL + "; -fx-text-alignment: center;");

        HBox btns = new HBox(16);
        btns.setAlignment(Pos.CENTER);

        Button retryBtn = UiUtils.createSecondaryButton(loc.getString("quiz.retry"), "");
        retryBtn.setOnAction(e -> {
            currentQuestionIndex = 0;
            correctCount = 0;
            showCurrentQuestion();
        });

        Button doneBtn = UiUtils.createPrimaryButton(loc.getString("quiz.finish"), "✓");
        doneBtn.setOnAction(e -> onNavigate.accept("learn"));

        btns.getChildren().addAll(retryBtn, doneBtn);

        card.getChildren().addAll(trophy, resultTitle, scoreLbl, encouragement, btns);

        VBox centerWrap = new VBox(card);
        centerWrap.setAlignment(Pos.CENTER);
        quizContainer.getChildren().add(centerWrap);
    }
}
