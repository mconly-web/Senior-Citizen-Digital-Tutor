package com.seniortutor.ui.view;

import com.seniortutor.model.Category;
import com.seniortutor.model.Lesson;
import com.seniortutor.model.Recommendation;
import com.seniortutor.model.User;
import com.seniortutor.service.FamilyHelperService;
import com.seniortutor.service.LessonService;
import com.seniortutor.service.ProgressService;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.List;

/**
 * Family / Helper Mode Dashboard: allows family members to monitor the senior's progress,
 * identify difficult topics, and recommend specific lessons.
 */
public class FamilyCareView extends ScrollPane {

    private final VBox recommendationsListBox = new VBox(10);
    private final ComboBox<Lesson> lessonComboBox = new ComboBox<>();
    private final TextField noteField = new TextField();

    public FamilyCareView() {
        setFitToWidth(true);
        setStyle("-fx-background: " + UiUtils.COLOR_WARM_CREAM + "; -fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");

        int seniorId = 1; // Shanti Sharma
        User senior = FamilyHelperService.getInstance().getSeniorUser(seniorId);

        VBox root = new VBox(24);
        root.setPadding(new Insets(24));
        root.setFillWidth(true);

        // Header
        VBox headerBox = new VBox(4);
        Label title = UiUtils.createTitle("👨‍👩‍👧 Family & Caregiver Dashboard");
        Label subtitle = UiUtils.createSubtitle("Support your elderly loved one's digital journey. View weak topics and send encouraging lesson recommendations.");
        headerBox.getChildren().addAll(title, subtitle);

        // Caregiver & Senior Profile Banner
        HBox profileBanner = createProfileBanner(senior);

        // Senior Progress & Needs Practice Card
        HBox analyticsRow = createAnalyticsRow(seniorId);

        // Recommend Lesson Tool Card
        VBox recommendCard = createRecommendToolCard(seniorId);

        root.getChildren().addAll(headerBox, profileBanner, analyticsRow, recommendCard);
        setContent(root);
    }

    private HBox createProfileBanner(User senior) {
        HBox banner = new HBox(16);
        banner.setStyle(
            "-fx-background-color: #E8F0EA;" +
            "-fx-border-color: rgba(111, 128, 104, 0.35);" +
            "-fx-border-width: 1.5px;" +
            "-fx-border-radius: 16px;" +
            "-fx-background-radius: 16px;" +
            "-fx-padding: 18px 24px;"
        );
        banner.setAlignment(Pos.CENTER_LEFT);

        Label helperAvatar = new Label("👩");
        helperAvatar.setStyle("-fx-font-size: 32px;");

        VBox helperInfo = new VBox(2);
        Label hName = new Label("Active Caregiver: Anita Sharma (Daughter)");
        hName.setStyle("-fx-font-size: 17px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");
        Label hRole = new Label("Logged in as Family Helper • Connected to Mother's Profile");
        hRole.setStyle("-fx-font-size: 13px; -fx-text-fill: #4B6358;");
        helperInfo.getChildren().addAll(hName, hRole);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox seniorPill = new HBox(8);
        seniorPill.setAlignment(Pos.CENTER);
        seniorPill.setStyle("-fx-background-color: white; -fx-padding: 8px 16px; -fx-background-radius: 20px; -fx-border-color: #CBD5E1; -fx-border-radius: 20px;");
        Label sAvatar = new Label(senior != null ? senior.getAvatar() : "👵");
        sAvatar.setStyle("-fx-font-size: 20px;");
        Label sName = new Label("Senior: " + (senior != null ? senior.getName() : "Grandmother"));
        sName.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");
        seniorPill.getChildren().addAll(sAvatar, sName);

        banner.getChildren().addAll(helperAvatar, helperInfo, spacer, seniorPill);
        return banner;
    }

    private HBox createAnalyticsRow(int seniorId) {
        HBox row = new HBox(20);
        row.setAlignment(Pos.TOP_LEFT);

        // Left Card: Category Breakdown
        VBox catCard = UiUtils.createCard();
        catCard.setPrefWidth(540);
        catCard.setSpacing(12);

        Label cTitle = new Label("📊 Category Progress for Shanti Ji");
        cTitle.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");
        catCard.getChildren().add(cTitle);

        List<Category> categories = FamilyHelperService.getInstance().getCategoryProgress(seniorId);
        for (Category cat : categories) {
            HBox cr = new HBox(8);
            cr.setAlignment(Pos.CENTER_LEFT);

            Label name = new Label(cat.getIcon() + " " + cat.getName());
            name.setPrefWidth(180);
            name.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

            ProgressBar pb = new ProgressBar(cat.getProgressPercentage());
            pb.setPrefWidth(200);
            pb.setStyle("-fx-accent: " + (cat.getProgressPercentage() >= 0.7 ? "#28A745;" : UiUtils.COLOR_MUTED_GOLD + ";"));

            int pct = (int) (cat.getProgressPercentage() * 100);
            Label pLbl = new Label(pct + "%");
            pLbl.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: #64748B;");

            cr.getChildren().addAll(name, pb, pLbl);
            catCard.getChildren().add(cr);
        }

        // Right Card: Topics Needing Practice
        VBox needsPracticeCard = UiUtils.createCard();
        needsPracticeCard.setPrefWidth(520);
        needsPracticeCard.setSpacing(14);
        HBox.setHgrow(needsPracticeCard, Priority.ALWAYS);

        Label npTitle = new Label("⚠️ Suggested Topics Needing Practice");
        npTitle.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #991B1B;");

        VBox list = new VBox(10);
        list.getChildren().addAll(
            createPracticeAlert("💳 UPI PIN Safety", "Essential to reinforce that PIN is never needed to receive money.", "High Priority"),
            createPracticeAlert("⚡ Electricity Scams", "Elderly citizens are frequently targeted by fake disconnection threats.", "Recommended"),
            createPracticeAlert("📹 WhatsApp Video Calls", "Practicing answering incoming video calls helps stay connected with family.", "Good Practice")
        );

        needsPracticeCard.getChildren().addAll(npTitle, list);

        row.getChildren().addAll(catCard, needsPracticeCard);
        return row;
    }

    private VBox createPracticeAlert(String topic, String reason, String badgeText) {
        VBox box = new VBox(4);
        box.setStyle("-fx-background-color: #FEF2F2; -fx-border-color: #FCA5A5; -fx-border-radius: 10px; -fx-background-radius: 10px; -fx-padding: 12px;");

        HBox top = new HBox(8);
        top.setAlignment(Pos.CENTER_LEFT);
        Label tLbl = new Label(topic);
        tLbl.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #991B1B;");
        Region sp = new Region();
        HBox.setHgrow(sp, Priority.ALWAYS);
        Label bLbl = new Label(badgeText);
        bLbl.setStyle("-fx-background-color: #FEE2E2; -fx-text-fill: #B91C1C; -fx-font-size: 12px; -fx-font-weight: bold; -fx-padding: 2px 8px; -fx-background-radius: 6px;");
        top.getChildren().addAll(tLbl, sp, bLbl);

        Label rLbl = new Label(reason);
        rLbl.setWrapText(true);
        rLbl.setStyle("-fx-font-size: 13px; -fx-text-fill: #7F1D1D;");

        box.getChildren().addAll(top, rLbl);
        return box;
    }

    private VBox createRecommendToolCard(int seniorId) {
        VBox card = UiUtils.createCard();
        card.setSpacing(16);

        Label h = UiUtils.createTitle("💡 Recommend a Lesson to Senior");
        Label d = UiUtils.createSubtitle("Select a lesson and leave a warm encouraging note. It will be pinned on their Home screen!");

        // Dropdown of lessons
        List<Lesson> lessons = LessonService.getInstance().getLessonsForCategory(7, seniorId); // Start with payments or all
        lessonComboBox.getItems().addAll(lessons);
        if (!lessons.isEmpty()) {
            lessonComboBox.setValue(lessons.get(0));
        }
        lessonComboBox.setStyle("-fx-font-size: 15px; -fx-pref-width: 400px; -fx-background-radius: 8px;");

        noteField.setPromptText("Write an encouraging note (e.g. 'Maa, please review this before our market visit!')...");
        noteField.setStyle("-fx-font-size: 15px; -fx-padding: 10px; -fx-background-radius: 8px;");
        HBox.setHgrow(noteField, Priority.ALWAYS);

        Button sendBtn = UiUtils.createPrimaryButton("Send Recommendation 🚀", "");
        sendBtn.setOnAction(e -> {
            Lesson selected = lessonComboBox.getValue();
            String note = noteField.getText().trim();
            if (selected == null || note.isEmpty()) {
                UiUtils.showInfoDialog("Recommendation", "Please fill note", "Please select a lesson and write an encouraging note.");
                return;
            }

            FamilyHelperService.getInstance().recommendLesson(seniorId, 2, selected.getId(), note);
            SoundUtil.playSuccess();
            noteField.clear();
            refreshRecommendationsList(seniorId);
            UiUtils.showInfoDialog("Lesson Recommended", "Sent to Shanti Ji!", "This recommendation has been pinned to your mother's home screen with your note.");
        });

        HBox formRow = new HBox(12, lessonComboBox, noteField, sendBtn);
        formRow.setAlignment(Pos.CENTER_LEFT);

        // Active Recommendations List
        Label activeH = new Label("Current Pinned Recommendations:");
        activeH.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        refreshRecommendationsList(seniorId);

        card.getChildren().addAll(h, d, formRow, new Separator(), activeH, recommendationsListBox);
        return card;
    }

    private void refreshRecommendationsList(int seniorId) {
        recommendationsListBox.getChildren().clear();
        List<Recommendation> list = FamilyHelperService.getInstance().getActiveRecommendations(seniorId);

        if (list.isEmpty()) {
            Label empty = new Label("No active recommendations currently pinned.");
            empty.setStyle("-fx-font-size: 14px; -fx-text-fill: #64748B; -fx-font-style: italic;");
            recommendationsListBox.getChildren().add(empty);
            return;
        }

        for (Recommendation r : list) {
            HBox row = new HBox(12);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setStyle("-fx-background-color: #F8FAFC; -fx-padding: 12px 16px; -fx-background-radius: 10px; -fx-border-color: #E2E8F0; -fx-border-radius: 10px;");

            Label icon = new Label("📌 " + (r.getCategoryIcon() != null ? r.getCategoryIcon() : "📖"));
            icon.setStyle("-fx-font-size: 20px;");

            VBox info = new VBox(2);
            Label t = new Label(r.getLessonTitle());
            t.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");
            Label n = new Label("\"" + r.getNote() + "\"");
            n.setStyle("-fx-font-size: 14px; -fx-text-fill: #475569; -fx-font-style: italic;");
            info.getChildren().addAll(t, n);

            Region sp = new Region();
            HBox.setHgrow(sp, Priority.ALWAYS);

            Button doneBtn = new Button("Mark Done ✓");
            doneBtn.setStyle("-fx-background-color: #E2E8F0; -fx-font-size: 13px; -fx-font-weight: bold; -fx-padding: 6px 12px; -fx-background-radius: 8px; -fx-cursor: hand;");
            doneBtn.setOnAction(e -> {
                FamilyHelperService.getInstance().markRecommendationDone(r.getId());
                SoundUtil.playClick();
                refreshRecommendationsList(seniorId);
            });

            row.getChildren().addAll(icon, info, sp, doneBtn);
            recommendationsListBox.getChildren().add(row);
        }
    }
}
