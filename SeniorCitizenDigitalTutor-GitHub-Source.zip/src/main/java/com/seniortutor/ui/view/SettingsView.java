package com.seniortutor.ui.view;

import com.seniortutor.model.AppSettings;
import com.seniortutor.service.BackupService;
import com.seniortutor.service.LocalizationService;
import com.seniortutor.service.ProgressService;
import com.seniortutor.ui.dialog.WelcomeWizardDialog;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.time.LocalDate;

/**
 * Settings and Accessibility View: controls text sizing, high contrast, voice instructions,
 * speech speed, language choice, emergency phone numbers & medical info, helper PIN,
 * progress backup/restore, guided tour replay, and progress reset.
 */
public class SettingsView extends ScrollPane {

    public SettingsView() {
        setFitToWidth(true);
        setStyle("-fx-background: " + UiUtils.COLOR_WARM_CREAM + "; -fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");

        AppSettings settings = AppConfig.getInstance().getCurrentSettings();
        LocalizationService loc = LocalizationService.getInstance();

        VBox root = new VBox(24);
        root.setPadding(new Insets(24));
        root.setFillWidth(true);

        // Header
        VBox headerBox = new VBox(4);
        Label title = UiUtils.createTitle("⚙️ " + loc.getString("settings.title"));
        Label subtitle = UiUtils.createSubtitle(loc.getString("settings.sub"));
        headerBox.getChildren().addAll(title, subtitle);

        // Card 1: Accessibility & Display
        VBox displayCard = createDisplayCard(settings);

        // Card 2: Voice, Sound & Speech Pace
        VBox voiceCard = createVoiceCard(settings);

        // Card 3: Language Preference
        VBox langCard = createLanguageCard(settings);

        // Card 4: Emergency Contacts & Medical Info Configuration
        VBox contactsCard = createEmergencyContactsConfigCard(settings);

        // Card 5: Helper PIN Lock Configuration
        VBox helperPinCard = createHelperPinCard(settings);

        // Card 6: Backup / Restore / Guided Tour
        VBox dataCard = createDataManagementCard();

        // Card 7: Danger Zone (Reset Progress)
        VBox dangerCard = createDangerZoneCard();

        root.getChildren().addAll(headerBox, displayCard, voiceCard, langCard, contactsCard, helperPinCard, dataCard, dangerCard);
        setContent(root);
    }

    private VBox createDisplayCard(AppSettings s) {
        LocalizationService loc = LocalizationService.getInstance();
        VBox card = UiUtils.createCard();
        card.setSpacing(16);

        Label h = new Label("👁️ " + loc.getString("settings.display_heading"));
        h.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        // Text Size Toggle Group
        HBox sizeRow = new HBox(16);
        sizeRow.setAlignment(Pos.CENTER_LEFT);
        Label sizeLbl = new Label("Text Sizing:");
        sizeLbl.setPrefWidth(140);
        sizeLbl.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        ToggleGroup sizeGroup = new ToggleGroup();
        RadioButton rbStandard = new RadioButton("Standard (16px)");
        rbStandard.setToggleGroup(sizeGroup);
        rbStandard.setSelected(s.getFontScale() <= 1.0);

        RadioButton rbLarge = new RadioButton("Large (18px)");
        rbLarge.setToggleGroup(sizeGroup);
        rbLarge.setSelected(s.getFontScale() > 1.0 && s.getFontScale() <= 1.2);

        RadioButton rbExtra = new RadioButton("Extra Large (22px)");
        rbExtra.setToggleGroup(sizeGroup);
        rbExtra.setSelected(s.getFontScale() > 1.2);

        sizeGroup.selectedToggleProperty().addListener((obs, old, nv) -> {
            if (nv == rbExtra) s.setFontScale(1.3);
            else if (nv == rbLarge) s.setFontScale(1.15);
            else s.setFontScale(1.0);
            AppConfig.getInstance().saveCurrentSettings(s);
        });

        sizeRow.getChildren().addAll(sizeLbl, rbStandard, rbLarge, rbExtra);

        // High Contrast Mode
        CheckBox contrastCheck = new CheckBox("High Contrast Mode (Bold dark contrast for low vision)");
        contrastCheck.setStyle("-fx-font-size: 15px; -fx-font-weight: bold;");
        contrastCheck.setSelected(s.isHighContrast());
        contrastCheck.setOnAction(e -> {
            s.setHighContrast(contrastCheck.isSelected());
            AppConfig.getInstance().saveCurrentSettings(s);
        });

        // Reduced Animation Mode
        CheckBox reduceAnimCheck = new CheckBox("Reduced Motion / Minimal Animations");
        reduceAnimCheck.setStyle("-fx-font-size: 15px;");
        reduceAnimCheck.setSelected(s.isReducedAnimations());
        reduceAnimCheck.setOnAction(e -> {
            s.setReducedAnimations(reduceAnimCheck.isSelected());
            AppConfig.getInstance().saveCurrentSettings(s);
        });

        card.getChildren().addAll(h, sizeRow, contrastCheck, reduceAnimCheck);
        return card;
    }

    private VBox createVoiceCard(AppSettings s) {
        LocalizationService loc = LocalizationService.getInstance();
        VBox card = UiUtils.createCard();
        card.setSpacing(14);

        Label h = new Label("🗣️ " + loc.getString("settings.voice_heading"));
        h.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        CheckBox voiceCheck = new CheckBox("Enable Voice Instructions Aloud (Speaks lesson steps automatically)");
        voiceCheck.setStyle("-fx-font-size: 15px; -fx-font-weight: bold;");
        voiceCheck.setSelected(s.isVoiceEnabled());
        voiceCheck.setOnAction(e -> {
            s.setVoiceEnabled(voiceCheck.isSelected());
            AppConfig.getInstance().saveCurrentSettings(s);
        });

        // Speech Pace Selection
        HBox rateRow = new HBox(16);
        rateRow.setAlignment(Pos.CENTER_LEFT);
        Label rateLbl = new Label(loc.getString("settings.speech_speed"));
        rateLbl.setPrefWidth(140);
        rateLbl.setStyle("-fx-font-size: 15px; -fx-font-weight: bold;");

        ToggleGroup rateGroup = new ToggleGroup();
        RadioButton rbSlow = new RadioButton("Calm & Slow");
        rbSlow.setToggleGroup(rateGroup);
        rbSlow.setSelected(s.getSpeechRate() <= -2.0);

        RadioButton rbNormal = new RadioButton("Normal Pace");
        rbNormal.setToggleGroup(rateGroup);
        rbNormal.setSelected(s.getSpeechRate() > -2.0 && s.getSpeechRate() < 0.0);

        RadioButton rbBrisk = new RadioButton("Brisk Pace");
        rbBrisk.setToggleGroup(rateGroup);
        rbBrisk.setSelected(s.getSpeechRate() >= 0.0);

        rateGroup.selectedToggleProperty().addListener((obs, old, nv) -> {
            if (nv == rbSlow) s.setSpeechRate(-2.0);
            else if (nv == rbBrisk) s.setSpeechRate(0.0);
            else s.setSpeechRate(-1.0);
            AppConfig.getInstance().saveCurrentSettings(s);
        });

        rateRow.getChildren().addAll(rateLbl, rbSlow, rbNormal, rbBrisk);

        CheckBox soundCheck = new CheckBox("Play Click & Completion Chimes");
        soundCheck.setStyle("-fx-font-size: 15px;");
        soundCheck.setSelected(s.isSoundEffects());
        soundCheck.setOnAction(e -> {
            s.setSoundEffects(soundCheck.isSelected());
            AppConfig.getInstance().saveCurrentSettings(s);
        });

        card.getChildren().addAll(h, voiceCheck, rateRow, soundCheck);
        return card;
    }

    private VBox createLanguageCard(AppSettings s) {
        LocalizationService loc = LocalizationService.getInstance();
        VBox card = UiUtils.createCard();
        card.setSpacing(14);

        Label h = new Label("🌍 " + loc.getString("settings.lang_heading") + " / भाषा / भाषा निवडा");
        h.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        HBox langRow = new HBox(20);
        langRow.setAlignment(Pos.CENTER_LEFT);

        ToggleGroup langGroup = new ToggleGroup();
        RadioButton rbEn = new RadioButton("English");
        rbEn.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        rbEn.setToggleGroup(langGroup);
        rbEn.setSelected("en".equals(s.getLanguage()));

        RadioButton rbHi = new RadioButton("हिंदी (Hindi)");
        rbHi.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        rbHi.setToggleGroup(langGroup);
        rbHi.setSelected("hi".equals(s.getLanguage()));

        RadioButton rbMr = new RadioButton("मराठी (Marathi)");
        rbMr.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        rbMr.setToggleGroup(langGroup);
        rbMr.setSelected("mr".equals(s.getLanguage()));

        langGroup.selectedToggleProperty().addListener((obs, old, nv) -> {
            if (nv == rbHi) s.setLanguage("hi");
            else if (nv == rbMr) s.setLanguage("mr");
            else s.setLanguage("en");

            LocalizationService.getInstance().setLanguage(s.getLanguage());
            AppConfig.getInstance().saveCurrentSettings(s);
        });

        langRow.getChildren().addAll(rbEn, rbHi, rbMr);
        card.getChildren().addAll(h, langRow);
        return card;
    }

    private VBox createEmergencyContactsConfigCard(AppSettings s) {
        LocalizationService loc = LocalizationService.getInstance();
        VBox card = UiUtils.createCard();
        card.setSpacing(16);

        Label h = new Label("👨‍👩‍👧 " + loc.getString("settings.contacts_heading"));
        h.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        GridPane grid = new GridPane();
        grid.setHgap(16);
        grid.setVgap(12);

        TextField c1Name = new TextField(s.getEmergencyContact1Name());
        TextField c1Phone = new TextField(s.getEmergencyContact1Phone());

        TextField c2Name = new TextField(s.getEmergencyContact2Name());
        TextField c2Phone = new TextField(s.getEmergencyContact2Phone());

        TextField docName = new TextField(s.getDoctorName());
        TextField docPhone = new TextField(s.getDoctorPhone());

        TextField bloodGroup = new TextField(s.getEmergencyBloodGroup());
        TextField medications = new TextField(s.getEmergencyMedications());

        grid.add(new Label("Primary Contact Name:"), 0, 0);
        grid.add(c1Name, 1, 0);
        grid.add(new Label("Phone Number:"), 2, 0);
        grid.add(c1Phone, 3, 0);

        grid.add(new Label("Secondary Contact Name:"), 0, 1);
        grid.add(c2Name, 1, 1);
        grid.add(new Label("Phone Number:"), 2, 1);
        grid.add(c2Phone, 3, 1);

        grid.add(new Label("Doctor Name:"), 0, 2);
        grid.add(docName, 1, 2);
        grid.add(new Label("Doctor Phone:"), 2, 2);
        grid.add(docPhone, 3, 2);

        grid.add(new Label("Blood Group:"), 0, 3);
        grid.add(bloodGroup, 1, 3);
        grid.add(new Label("Regular Medicines:"), 2, 3);
        grid.add(medications, 3, 3);

        Button saveBtn = UiUtils.createPrimaryButton(loc.getString("settings.save_btn"), "💾");
        saveBtn.setOnAction(e -> {
            s.setEmergencyContact1Name(c1Name.getText().trim());
            s.setEmergencyContact1Phone(c1Phone.getText().trim());
            s.setEmergencyContact2Name(c2Name.getText().trim());
            s.setEmergencyContact2Phone(c2Phone.getText().trim());
            s.setDoctorName(docName.getText().trim());
            s.setDoctorPhone(docPhone.getText().trim());
            s.setEmergencyBloodGroup(bloodGroup.getText().trim());
            s.setEmergencyMedications(medications.getText().trim());

            AppConfig.getInstance().saveCurrentSettings(s);
            SoundUtil.playSuccess();
            UiUtils.showInfoDialog("Saved", "Emergency Information Updated", "Your emergency contacts and medical information have been saved.");
        });

        card.getChildren().addAll(h, grid, saveBtn);
        return card;
    }

    private VBox createHelperPinCard(AppSettings s) {
        VBox card = UiUtils.createCard();
        card.setSpacing(12);

        Label h = new Label("🔒 Family Helper Mode 4-Digit PIN (Optional)");
        h.setStyle("-fx-font-size: 17px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        Label desc = new Label("Set a 4-digit PIN to restrict helper controls and prevent accidental setting changes.");
        desc.setStyle("-fx-font-size: 14px; -fx-text-fill: #64748B;");

        HBox pinRow = new HBox(12);
        pinRow.setAlignment(Pos.CENTER_LEFT);

        PasswordField pinField = new PasswordField();
        pinField.setPromptText("4-digit PIN (e.g. 1234)");
        pinField.setText(s.getHelperPin() != null ? s.getHelperPin() : "");
        pinField.setPrefWidth(180);

        Button savePinBtn = UiUtils.createSecondaryButton("Save PIN", "🔑");
        savePinBtn.setOnAction(e -> {
            String pin = pinField.getText().trim();
            s.setHelperPin(pin);
            AppConfig.getInstance().saveCurrentSettings(s);
            SoundUtil.playSuccess();
            UiUtils.showInfoDialog("PIN Saved", "Helper PIN Updated", pin.isEmpty() ? "PIN protection disabled." : "Helper mode PIN protection enabled.");
        });

        pinRow.getChildren().addAll(pinField, savePinBtn);
        card.getChildren().addAll(h, desc, pinRow);
        return card;
    }

    private VBox createDataManagementCard() {
        VBox card = UiUtils.createCard();
        card.setSpacing(14);

        Label h = new Label("💾 Data Backup & Guided Tour");
        h.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        Label desc = new Label("Export your learning progress to a file to keep it safe or transfer it to another computer.");
        desc.setStyle("-fx-font-size: 14px; -fx-text-fill: #64748B;");

        HBox btnRow = new HBox(14);
        btnRow.setAlignment(Pos.CENTER_LEFT);

        Button backupBtn = UiUtils.createPrimaryButton("Backup Progress 📤", "");
        backupBtn.setOnAction(e -> {
            FileChooser chooser = new FileChooser();
            chooser.setTitle("Save Progress Backup");
            chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Senior Tutor Backup (*.json)", "*.json"));
            chooser.setInitialFileName("seniortutor_backup_" + LocalDate.now() + ".json");
            Stage stage = (Stage) getScene().getWindow();
            File file = chooser.showSaveDialog(stage);
            if (file != null) {
                int userId = AppConfig.getInstance().getCurrentUser().getId();
                boolean ok = BackupService.getInstance().exportBackup(userId, file);
                if (ok) {
                    SoundUtil.playSuccess();
                    UiUtils.showInfoDialog("Backup Successful", "Progress Exported", "Your progress and achievements were saved to:\n" + file.getAbsolutePath());
                } else {
                    UiUtils.showErrorDialog("Backup Failed", "Could not export progress", "Please check file write permissions.");
                }
            }
        });

        Button restoreBtn = UiUtils.createSecondaryButton("Restore Progress 📥", "");
        restoreBtn.setOnAction(e -> {
            FileChooser chooser = new FileChooser();
            chooser.setTitle("Select Backup File to Restore");
            chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Senior Tutor Backup (*.json)", "*.json"));
            Stage stage = (Stage) getScene().getWindow();
            File file = chooser.showOpenDialog(stage);
            if (file != null) {
                int userId = AppConfig.getInstance().getCurrentUser().getId();
                boolean ok = BackupService.getInstance().restoreBackup(userId, file);
                if (ok) {
                    SoundUtil.playSuccess();
                    UiUtils.showInfoDialog("Restore Successful", "Progress Restored", "All your completed lessons and badges have been restored!");
                } else {
                    UiUtils.showErrorDialog("Restore Failed", "Invalid backup file", "Could not read progress from the selected file.");
                }
            }
        });

        Button tourBtn = UiUtils.createAccentButton("Replay Guided Tour 🧭", "");
        tourBtn.setOnAction(e -> {
            Stage stage = (Stage) getScene().getWindow();
            WelcomeWizardDialog.showWizard(stage, () -> {});
        });

        btnRow.getChildren().addAll(backupBtn, restoreBtn, tourBtn);
        card.getChildren().addAll(h, desc, btnRow);
        return card;
    }

    private VBox createDangerZoneCard() {
        LocalizationService loc = LocalizationService.getInstance();
        VBox card = UiUtils.createCard();
        card.setStyle(card.getStyle() + "-fx-border-color: #FCA5A5;");
        card.setSpacing(12);

        Label h = new Label("⚠️ " + loc.getString("settings.danger_heading"));
        h.setStyle("-fx-font-size: 17px; -fx-font-weight: bold; -fx-text-fill: #DC2626;");

        Label desc = new Label("If you wish to practice all lessons from the very beginning, you can reset your progress.");
        desc.setStyle("-fx-font-size: 14px; -fx-text-fill: #64748B;");

        Button resetBtn = new Button(loc.getString("settings.reset_btn"));
        resetBtn.setStyle("-fx-background-color: #DC2626; -fx-text-fill: white; -fx-font-size: 15px; -fx-font-weight: bold; -fx-background-radius: 8px; -fx-padding: 8px 18px; -fx-cursor: hand;");
        resetBtn.setOnAction(e -> {
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "Are you sure you want to reset all completed lessons, quiz scores, and badges?", ButtonType.YES, ButtonType.NO);
            confirm.setHeaderText("Confirm Progress Reset");
            confirm.showAndWait().ifPresent(res -> {
                if (res == ButtonType.YES) {
                    ProgressService.getInstance().resetProgress(AppConfig.getInstance().getCurrentUser().getId());
                    SoundUtil.playSuccess();
                    UiUtils.showInfoDialog("Reset Complete", "Progress has been reset", "You can now start lessons afresh!");
                }
            });
        });

        card.getChildren().addAll(h, desc, resetBtn);
        return card;
    }
}
