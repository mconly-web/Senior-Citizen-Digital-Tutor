package com.seniortutor.ui.view;

import com.seniortutor.model.Category;
import com.seniortutor.model.Lesson;
import com.seniortutor.service.LessonService;
import com.seniortutor.service.ProgressService;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.*;

import java.util.List;
import java.util.function.Consumer;

/**
 * Progress Dashboard: visualizes category completion %, streak, average quiz accuracy, and next recommended lesson.
 */
public class ProgressView extends ScrollPane {

    private final Consumer<Lesson> onLaunchLesson;

    public ProgressView(Consumer<Lesson> onLaunchLesson) {
        this.onLaunchLesson = onLaunchLesson;

        setFitToWidth(true);
        setStyle("-fx-background: " + UiUtils.COLOR_WARM_CREAM + "; -fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");

        int userId = AppConfig.getInstance().getCurrentUser().getId();
        int completed = ProgressService.getInstance().getCompletedCount(userId);
        int total = ProgressService.getInstance().getTotalCount();
        double avgScore = ProgressService.getInstance().getAverageQuizScore(userId);
        int streak = AppConfig.getInstance().getCurrentUser().getCurrentStreak();

        VBox root = new VBox(24);
        root.setPadding(new Insets(24));
        root.setFillWidth(true);

        // Header
        VBox headerBox = new VBox(4);
        Label title = UiUtils.createTitle("📊 My Learning Progress");
        Label subtitle = UiUtils.createSubtitle("Track how much digital confidence you've built step-by-step.");
        headerBox.getChildren().addAll(title, subtitle);

        // Top Summary Metric Cards (Completed, Streak, Quiz Score)
        HBox metricsRow = createMetricsRow(completed, total, streak, avgScore);

        // Recommended Next Lesson Card
        VBox nextLessonCard = createNextLessonCard(userId);

        // Category Breakdown Progress Bars
        VBox categoryProgressCard = createCategoryBreakdownCard(userId);

        root.getChildren().addAll(headerBox, metricsRow, nextLessonCard, categoryProgressCard);
        setContent(root);
    }

    private HBox createMetricsRow(int completed, int total, int streak, double avgScore) {
        HBox row = new HBox(16);
        row.setAlignment(Pos.CENTER);

        row.getChildren().addAll(
            createMetricCard("🎯 Lessons Completed", completed + " / " + total, (completed * 100 / Math.max(1, total)) + "% Complete", UiUtils.COLOR_FOREST_GREEN),
            createMetricCard("🔥 Learning Streak", streak + " Days", "Practicing regularly!", UiUtils.COLOR_MUTED_TERRACOTTA),
            createMetricCard("⭐ Quiz Accuracy", String.format("%.0f%%", avgScore > 0 ? avgScore : 100), "Knowledge checks", UiUtils.COLOR_MUTED_GOLD)
        );

        return row;
    }

    private VBox createMetricCard(String title, String val, String sub, String colorHex) {
        VBox card = UiUtils.createCard();
        card.setPrefWidth(340);
        card.setSpacing(8);

        Label tLbl = new Label(title);
        tLbl.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";");

        Label vLbl = new Label(val);
        vLbl.setStyle("-fx-font-size: 32px; -fx-font-weight: bold; -fx-text-fill: " + colorHex + ";");

        Label sLbl = new Label(sub);
        sLbl.setStyle("-fx-font-size: 13px; -fx-text-fill: #64748B;");

        card.getChildren().addAll(tLbl, vLbl, sLbl);
        return card;
    }

    private VBox createNextLessonCard(int userId) {
        VBox card = UiUtils.createCard();
        card.setSpacing(12);

        Label h = new Label("🚀 Recommended Next Step For You");
        h.setStyle("-fx-font-size: 17px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        Lesson nextLesson = LessonService.getInstance().getContinueLearningLesson(userId);
        if (nextLesson != null) {
            HBox row = new HBox(16);
            row.setAlignment(Pos.CENTER_LEFT);

            Label icon = new Label(nextLesson.getCategoryIcon());
            icon.setStyle("-fx-font-size: 34px;");

            VBox info = new VBox(4);
            Label t = new Label(nextLesson.getTitle());
            t.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

            Label d = new Label(nextLesson.getDescription() + " • ⏱️ " + nextLesson.getEstimatedMinutes() + " mins");
            d.setStyle("-fx-font-size: 14px; -fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";");
            info.getChildren().addAll(t, d);

            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);

            Button startBtn = UiUtils.createPrimaryButton("Resume Lesson →", "");
            startBtn.setOnAction(e -> {
                if (onLaunchLesson != null) onLaunchLesson.accept(nextLesson);
            });

            row.getChildren().addAll(icon, info, spacer, startBtn);
            card.getChildren().addAll(h, row);
        } else {
            Label done = new Label("🎉 Incredible! You have completed all digital lessons.");
            done.setStyle("-fx-font-size: 16px; -fx-text-fill: #28A745; -fx-font-weight: bold;");
            card.getChildren().addAll(h, done);
        }

        return card;
    }

    private VBox createCategoryBreakdownCard(int userId) {
        VBox card = UiUtils.createCard();
        card.setSpacing(16);

        Label h = UiUtils.createTitle("Category Mastery Breakdown");
        card.getChildren().add(h);

        List<Category> categories = LessonService.getInstance().getCategories(userId);
        GridPane grid = new GridPane();
        grid.setHgap(24);
        grid.setVgap(16);

        int row = 0;
        int col = 0;
        for (Category cat : categories) {
            VBox catBox = new VBox(6);
            catBox.setPrefWidth(500);

            HBox labelRow = new HBox(8);
            labelRow.setAlignment(Pos.CENTER_LEFT);

            Label name = new Label(cat.getIcon() + " " + cat.getName());
            name.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";");

            Region sp = new Region();
            HBox.setHgrow(sp, Priority.ALWAYS);

            int pct = (int) (cat.getProgressPercentage() * 100);
            Label count = new Label(cat.getCompletedLessonCount() + "/" + cat.getLessonCount() + " (" + pct + "%)");
            count.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_SOFT_SAGE + ";");

            labelRow.getChildren().addAll(name, sp, count);

            ProgressBar pb = new ProgressBar(cat.getProgressPercentage());
            pb.setMaxWidth(Double.MAX_VALUE);
            pb.setPrefHeight(10);
            pb.setStyle("-fx-accent: " + (pct == 100 ? "#28A745;" : UiUtils.COLOR_FOREST_GREEN + ";"));

            catBox.getChildren().addAll(labelRow, pb);
            grid.add(catBox, col, row);

            col++;
            if (col > 1) {
                col = 0;
                row++;
            }
        }

        card.getChildren().add(grid);
        return card;
    }
}
