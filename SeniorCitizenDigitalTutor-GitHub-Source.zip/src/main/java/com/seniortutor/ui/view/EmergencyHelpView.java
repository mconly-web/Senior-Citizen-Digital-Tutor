package com.seniortutor.ui.view;

import com.seniortutor.model.AppSettings;
import com.seniortutor.service.LocalizationService;
import com.seniortutor.service.WindowsSpeechService;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.*;

import java.util.Optional;

/**
 * Emergency & Assistance Screen: giant high-contrast buttons for immediate help,
 * medical profile summary card, 2-step confirmation to avoid accidental taps,
 * and full multilingual support (English, Hindi, Marathi).
 */
public class EmergencyHelpView extends ScrollPane {

    public EmergencyHelpView() {
        setFitToWidth(true);
        setStyle("-fx-background: " + UiUtils.COLOR_WARM_CREAM + "; -fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");

        AppSettings settings = AppConfig.getInstance().getCurrentSettings();
        LocalizationService loc = LocalizationService.getInstance();

        VBox root = new VBox(24);
        root.setPadding(new Insets(24));
        root.setFillWidth(true);

        // Header
        VBox headerBox = new VBox(4);
        Label title = UiUtils.createTitle("🆘 " + loc.getString("emergency.title"));
        Label subtitle = UiUtils.createSubtitle(loc.getString("emergency.sub"));
        headerBox.getChildren().addAll(title, subtitle);

        // 2x2 Grid of Giant Emergency Action Buttons
        GridPane grid = new GridPane();
        grid.setHgap(24);
        grid.setVgap(24);
        grid.setAlignment(Pos.CENTER);

        // 1. Call Family
        Button callFamilyBtn = createGiantButton(
            "👨‍👩‍👧 " + loc.getString("emergency.call_family"),
            settings.getEmergencyContact1Name() + " (" + settings.getEmergencyContact1Phone() + ")",
            "#173F35",
            "#1E5044"
        );
        callFamilyBtn.setOnAction(e -> confirmAndCall(
            "Call Family Member",
            "Are you sure you want to call " + settings.getEmergencyContact1Name() + "?",
            () -> handleCallFamily(settings)
        ));

        // 2. Medical Emergency (Ambulance 108)
        Button ambulanceBtn = createGiantButton(
            "🚑 " + loc.getString("emergency.ambulance"),
            "Dial 108 • Immediate Medical & Ambulance Response",
            "#DC2626",
            "#B91C1C"
        );
        ambulanceBtn.setOnAction(e -> confirmAndCall(
            "Call Ambulance (108)",
            "Are you experiencing a medical emergency and need an ambulance?",
            this::handleMedicalCall
        ));

        // 3. Police Emergency (112)
        Button policeBtn = createGiantButton(
            "🚓 " + loc.getString("emergency.police"),
            "Dial 112 • All-India National Emergency Helpline",
            "#2563EB",
            "#1D4ED8"
        );
        policeBtn.setOnAction(e -> confirmAndCall(
            "Call Police / Emergency (112)",
            "Do you need urgent police assistance or disaster relief?",
            this::handlePoliceCall
        ));

        // 4. Cyber Fraud Helpline (1930)
        Button cyberBtn = createGiantButton(
            "🔐 " + loc.getString("emergency.cyber_helpline"),
            "Dial 1930 • National Financial Cyber Fraud Hotline",
            "#D97706",
            "#B45309"
        );
        cyberBtn.setOnAction(e -> confirmAndCall(
            "Call Cyber Fraud Helpline (1930)",
            "Have you noticed unauthorized bank deductions or fraud?",
            this::handleCyberCall
        ));

        grid.add(callFamilyBtn, 0, 0);
        grid.add(ambulanceBtn, 1, 0);
        grid.add(policeBtn, 0, 1);
        grid.add(cyberBtn, 1, 1);

        // Medical Profile Summary Card
        VBox medicalCard = createMedicalInfoCard(settings);

        // Emergency Contacts Info Card
        VBox contactsCard = createContactsCard(settings);

        root.getChildren().addAll(headerBox, grid, medicalCard, contactsCard);
        setContent(root);
    }

    private Button createGiantButton(String title, String subtitle, String bgColor, String hoverColor) {
        VBox content = new VBox(8);
        content.setAlignment(Pos.CENTER);

        Label t = new Label(title);
        t.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: white;");

        Label s = new Label(subtitle);
        s.setStyle("-fx-font-size: 14px; -fx-text-fill: rgba(255,255,255,0.9);");

        content.getChildren().addAll(t, s);

        Button btn = new Button();
        btn.setGraphic(content);
        btn.setPrefSize(480, 140);
        btn.setStyle(
            "-fx-background-color: " + bgColor + ";" +
            "-fx-background-radius: 20px;" +
            "-fx-padding: 20px;" +
            "-fx-cursor: hand;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.15), 10, 0, 0, 4);"
        );

        btn.setOnMouseEntered(e -> btn.setStyle(
            "-fx-background-color: " + hoverColor + ";" +
            "-fx-background-radius: 20px;" +
            "-fx-padding: 20px;" +
            "-fx-cursor: hand;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.25), 14, 0, 0, 6);"
        ));

        btn.setOnMouseExited(e -> btn.setStyle(
            "-fx-background-color: " + bgColor + ";" +
            "-fx-background-radius: 20px;" +
            "-fx-padding: 20px;" +
            "-fx-cursor: hand;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.15), 10, 0, 0, 4);"
        ));

        return btn;
    }

    private void confirmAndCall(String title, String question, Runnable onConfirm) {
        SoundUtil.playClick();
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(title);
        alert.setHeaderText("Confirm Emergency Action");
        alert.setContentText(question + "\n\n(Tap YES to initiate connection, or NO to cancel)");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            onConfirm.run();
        }
    }

    private void handleCallFamily(AppSettings s) {
        SoundUtil.playSuccess();
        String lang = LocalizationService.getInstance().getLanguage();
        String msg = "hi".equals(lang) ? "पारिवारिक संपर्क को कॉल किया जा रहा है: " + s.getEmergencyContact1Name()
                     : ("mr".equals(lang) ? "कुटुंबातील व्यक्तीला फोन केला जात आहे: " + s.getEmergencyContact1Name()
                                          : "Dialing family emergency contact: " + s.getEmergencyContact1Name());
        WindowsSpeechService.getInstance().speak(msg, lang);
        UiUtils.showInfoDialog(
            "Emergency Assistance (Simulated)",
            "Calling Primary Contact: " + s.getEmergencyContact1Name(),
            "📞 Simulated Call Initiated to: " + s.getEmergencyContact1Phone() + "\n\n" +
            "In real life, your smartphone will automatically place a loud speakerphone call to your loved ones."
        );
    }

    private void handleMedicalCall() {
        SoundUtil.playWarning();
        String lang = LocalizationService.getInstance().getLanguage();
        String msg = "hi".equals(lang) ? "108 एम्बुलेंस हेल्पलाइन पर संपर्क किया जा रहा है"
                     : ("mr".equals(lang) ? "१०८ रुग्णवाहिका हेल्पलाइनवर संपर्क केला जात आहे"
                                          : "Simulating emergency ambulance call to helpline 108");
        WindowsSpeechService.getInstance().speak(msg, lang);
        UiUtils.showInfoDialog(
            "Medical Emergency Assistance (Simulated)",
            "Dialing National Ambulance Helpline: 108",
            "🚑 Calling Government Emergency Ambulance (108)...\n\n" +
            "In real life, 108 dispatches a trained paramedic vehicle to your registered home address."
        );
    }

    private void handlePoliceCall() {
        SoundUtil.playWarning();
        String lang = LocalizationService.getInstance().getLanguage();
        String msg = "hi".equals(lang) ? "112 राष्ट्रीय आपातकालीन पुलिस सेवा पर कॉल किया जा रहा है"
                     : ("mr".equals(lang) ? "११२ राष्ट्रीय आपत्कालीन पोलीस सेवेवर संपर्क केला जात आहे"
                                          : "Simulating emergency call to police helpline 112");
        WindowsSpeechService.getInstance().speak(msg, lang);
        UiUtils.showInfoDialog(
            "Police Emergency (Simulated)",
            "Dialing National Police & Disaster Helpline: 112",
            "🚓 Calling Universal Emergency Service (112)...\n\n" +
            "112 is the single emergency contact across India."
        );
    }

    private void handleCyberCall() {
        SoundUtil.playSuccess();
        String lang = LocalizationService.getInstance().getLanguage();
        String msg = "hi".equals(lang) ? "1930 राष्ट्रीय साइबर वित्तीय अपराध हेल्पलाइन पर कॉल किया जा रहा है"
                     : ("mr".equals(lang) ? "१९३० राष्ट्रीय सायबर गुन्हे हेल्पलाइनवर संपर्क केला जात आहे"
                                          : "Dialing national financial cyber fraud helpline 1930");
        WindowsSpeechService.getInstance().speak(msg, lang);
        UiUtils.showInfoDialog(
            "Cyber Fraud Assistance (Simulated)",
            "Dialing Cybercrime Helpline: 1930",
            "📞 Calling National Cyber Crime Reporting Portal (1930)...\n\n" +
            "If defrauded online or by phone, reporting within 2 hours enables bank authorities to freeze fraudulent transfers!"
        );
    }

    private VBox createMedicalInfoCard(AppSettings s) {
        VBox card = UiUtils.createCard();
        card.setStyle(card.getStyle() + "-fx-background-color: #FEF2F2; -fx-border-color: #F87171;");
        card.setSpacing(12);

        Label h = new Label("🩺 Emergency Medical Profile (Available to Paramedics)");
        h.setStyle("-fx-font-size: 17px; -fx-font-weight: bold; -fx-text-fill: #991B1B;");

        HBox row = new HBox(30);
        row.getChildren().addAll(
            createContactPill("🩸 Blood Group", s.getEmergencyBloodGroup(), "Ready for Transfusion"),
            createContactPill("💊 Regular Medicines", s.getEmergencyMedications(), "Daily Prescriptions"),
            createContactPill("👨‍⚕️ Family Doctor", s.getDoctorName(), s.getDoctorPhone())
        );

        card.getChildren().addAll(h, row);
        return card;
    }

    private VBox createContactsCard(AppSettings s) {
        VBox card = UiUtils.createCard();
        card.setSpacing(12);

        Label h = new Label("📋 Configured Emergency Contacts (Editable in Settings)");
        h.setStyle("-fx-font-size: 17px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        HBox contactsRow = new HBox(30);
        contactsRow.getChildren().addAll(
            createContactPill("👩 Primary Family", s.getEmergencyContact1Name(), s.getEmergencyContact1Phone()),
            createContactPill("👨 Secondary Family", s.getEmergencyContact2Name(), s.getEmergencyContact2Phone()),
            createContactPill("🩺 Family Doctor", s.getDoctorName(), s.getDoctorPhone())
        );

        card.getChildren().addAll(h, contactsRow);
        return card;
    }

    private VBox createContactPill(String role, String name, String phone) {
        VBox box = new VBox(2);
        Label r = new Label(role);
        r.setStyle("-fx-font-size: 12px; -fx-text-fill: #64748B; -fx-font-weight: bold;");

        Label n = new Label(name != null && !name.isBlank() ? name : "Not specified");
        n.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        Label p = new Label(phone != null && !phone.isBlank() ? phone : "");
        p.setStyle("-fx-font-size: 14px; -fx-text-fill: #334155;");

        box.getChildren().addAll(r, n, p);
        return box;
    }
}
