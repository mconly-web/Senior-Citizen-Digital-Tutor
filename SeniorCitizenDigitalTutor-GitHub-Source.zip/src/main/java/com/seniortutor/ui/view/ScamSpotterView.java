package com.seniortutor.ui.view;

import com.seniortutor.service.LocalizationService;
import com.seniortutor.service.ProgressService;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * "Scam Spotter" Interactive Mini-Game.
 * Shows real-world Indian text scenarios where seniors tap SAFE or SCAM,
 * receiving instant explanations and scoring badges.
 */
public class ScamSpotterView extends VBox {

    private final Consumer<String> onNavigate;
    private int currentIndex = 0;
    private int score = 0;
    private final List<Scenario> scenarios = new ArrayList<>();
    private final StackPane gameContainer = new StackPane();

    public static class Scenario {
        public final String message;
        public final boolean isScam;
        public final String scamType;
        public final String explanation;

        public Scenario(String message, boolean isScam, String scamType, String explanation) {
            this.message = message;
            this.isScam = isScam;
            this.scamType = scamType;
            this.explanation = explanation;
        }
    }

    public ScamSpotterView(Consumer<String> onNavigate) {
        this.onNavigate = onNavigate;

        setSpacing(16);
        setPadding(new Insets(24));
        setStyle("-fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");
        setFillWidth(true);

        initScenarios();
        buildHeader();

        gameContainer.setStyle("-fx-background-color: transparent;");
        VBox.setVgrow(gameContainer, Priority.ALWAYS);
        getChildren().add(gameContainer);

        showCurrentScenario();
    }

    private void initScenarios() {
        scenarios.add(new Scenario(
            "Dear consumer, your electricity will be disconnected tonight at 9:30 PM due to previous month unpaid bill. Call our officer on 9876543210 immediately.",
            true,
            "⚡ Fake Electricity Power Cut Threat",
            "This is a classic fraud. Genuine electricity boards send official written notices by post weeks in advance, never sudden threatening SMS with personal mobile numbers."
        ));

        scenarios.add(new Scenario(
            "Hi Grandpa, our school picnic photos are uploaded! Sending you the family album on WhatsApp right now. Hope you like them!",
            false,
            "🟢 Genuine Family Message",
            "Safe! This is a standard friendly family text. It does not ask for money, OTPs, PINs, or suspicious app downloads."
        ));

        scenarios.add(new Scenario(
            "Congratulations! Your mobile number won ₹25,00,000 in KBC All-India Lucky Draw. To receive your prize cheque, transfer ₹1,500 registration fee to UPI ID kbc@upi.",
            true,
            "🎁 Advance-Fee Lottery Fraud",
            "Scam! You can never win a lottery you never bought a ticket for. Genuine lotteries or game shows NEVER ask winners to pay 'registration fees' to get prizes."
        ));

        scenarios.add(new Scenario(
            "Your State Bank of India account XXXX1234 has been credited with ₹18,500 towards Monthly Pension on 01-Nov. Avail balance: ₹34,210. — SBI",
            false,
            "🟢 Standard Bank Pension SMS",
            "Safe! Standard official SMS from a registered banking header informing you of credited pension. It does not contain links or ask for personal details."
        ));

        scenarios.add(new Scenario(
            "FedEx Customs Alert: A parcel sent in your name to Taiwan containing 5 expired passports and narcotics has been seized. Delhi Cyber Police has placed you under Digital Arrest. Connect to Skype immediately.",
            true,
            "🚨 Fake Digital Arrest & Customs Trap",
            "Scam! Indian law and police agencies NEVER conduct 'Digital Arrest' over Skype or WhatsApp calls. Disconnect immediately."
        ));

        scenarios.add(new Scenario(
            "Buyer on OLX says: 'I am sending you ₹2,000 for your old study table. Please scan this QR code and enter your UPI PIN to accept payment into your bank account.'",
            true,
            "📱 QR Code 'Receive Money' Trap",
            "Scam! Scanning a QR code or entering your UPI PIN ALWAYS transfers money OUT of your account. You NEVER need to enter a PIN to receive money."
        ));

        scenarios.add(new Scenario(
            "Your LPG Gas cylinder booking ref #87621 is confirmed. Delivery scheduled for tomorrow between 10 AM - 2 PM. Cash or UPI on delivery: ₹950. — Indane Gas",
            false,
            "🟢 Official Utility Booking Confirmation",
            "Safe! Routine confirmation of your requested service. Legitimate delivery person will bring physical cylinder to your doorstep."
        ));

        scenarios.add(new Scenario(
            "Earn ₹3,000 daily from home! Just like 10 YouTube videos and take screenshots. No experience needed. Message our Telegram HR @EarnDaily77 now.",
            true,
            "💼 Part-Time Job / Telegram Task Fraud",
            "Scam! This is 'task fraud'. Scammers give ₹150 initially to build false confidence, then trap your life savings demanding thousands in 'recharge fees'."
        ));

        scenarios.add(new Scenario(
            "Hi Mom, I am reaching home slightly late around 8:30 PM due to metro train delay. Please don't wait for dinner, have your medicine on time!",
            false,
            "🟢 Normal Family Chat",
            "Safe! An ordinary family update caring for your health."
        ));

        scenarios.add(new Scenario(
            "Urgent: Your SIM card KYC is expired. Outgoing calls will be stopped in 2 hours. Download QuickSupport app from bit.ly/sim-kyc to verify your identity.",
            true,
            "📱 Remote Screen Share & Phishing APK Trap",
            "Scam! Telecom companies do not disconnect SIM cards via 2-hour SMS threats. Downloading QuickSupport lets fraudsters control your phone."
        ));
    }

    private void buildHeader() {
        HBox topRow = new HBox(16);
        topRow.setAlignment(Pos.CENTER_LEFT);

        Button backBtn = UiUtils.createSecondaryButton("← Back to Safety Center", "");
        backBtn.setOnAction(e -> onNavigate.accept("safety"));

        VBox titleBox = new VBox(2);
        Label title = new Label("🕵️ Scam Spotter Mini-Game");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");
        Label subtitle = new Label("Test your fraud detection skills! Read the scenario and tap SAFE or SCAM.");
        subtitle.setStyle("-fx-font-size: 15px; -fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";");
        titleBox.getChildren().addAll(title, subtitle);

        topRow.getChildren().addAll(backBtn, titleBox);
        getChildren().add(topRow);
    }

    private void showCurrentScenario() {
        gameContainer.getChildren().clear();

        if (currentIndex >= scenarios.size()) {
            showFinalResults();
            return;
        }

        Scenario s = scenarios.get(currentIndex);

        VBox card = UiUtils.createCard();
        card.setMaxWidth(720);
        card.setSpacing(18);
        card.setPadding(new Insets(28));
        card.setAlignment(Pos.TOP_LEFT);

        // Progress tracker
        Label progressLbl = new Label("SCENARIO " + (currentIndex + 1) + " OF " + scenarios.size() + "  •  Current Score: " + score);
        progressLbl.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_MUTED_GOLD + ";");

        // Message Box simulating SMS / WhatsApp card
        VBox messageBubble = new VBox(8);
        messageBubble.setStyle(
            "-fx-background-color: #F8FAFC;" +
            "-fx-border-color: #CBD5E1;" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 14px;" +
            "-fx-background-radius: 14px;" +
            "-fx-padding: 20px;"
        );

        Label senderTag = new Label("📩 Incoming SMS / Forwarded Message:");
        senderTag.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: #64748B;");

        Label msgText = new Label("\"" + s.message + "\"");
        msgText.setWrapText(true);
        msgText.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: #0F172A; -fx-line-spacing: 4px;");

        messageBubble.getChildren().addAll(senderTag, msgText);

        Label questionLbl = new Label("What do you think? Is this message SAFE or a SCAM?");
        questionLbl.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        // Action Buttons: Big Green SAFE vs Big Red SCAM
        HBox btnRow = new HBox(20);
        btnRow.setAlignment(Pos.CENTER);

        Button safeBtn = new Button("🟢 SAFE (सुरक्षित)");
        safeBtn.setPrefSize(280, 70);
        safeBtn.setStyle(
            "-fx-background-color: #16A34A; -fx-text-fill: white; -fx-font-size: 20px; -fx-font-weight: bold;" +
            "-fx-background-radius: 14px; -fx-cursor: hand;"
        );
        safeBtn.setOnAction(e -> handleChoice(false, s));

        Button scamBtn = new Button("🔴 SCAM (धोखा)");
        scamBtn.setPrefSize(280, 70);
        scamBtn.setStyle(
            "-fx-background-color: #DC2626; -fx-text-fill: white; -fx-font-size: 20px; -fx-font-weight: bold;" +
            "-fx-background-radius: 14px; -fx-cursor: hand;"
        );
        scamBtn.setOnAction(e -> handleChoice(true, s));

        btnRow.getChildren().addAll(safeBtn, scamBtn);

        card.getChildren().addAll(progressLbl, messageBubble, questionLbl, btnRow);

        VBox centerWrap = new VBox(card);
        centerWrap.setAlignment(Pos.CENTER);
        gameContainer.getChildren().add(centerWrap);
    }

    private void handleChoice(boolean userChoseScam, Scenario s) {
        boolean isCorrect = (userChoseScam == s.isScam);

        if (isCorrect) {
            score++;
            SoundUtil.playSuccess();
        } else {
            SoundUtil.playWarning();
        }

        gameContainer.getChildren().clear();

        VBox card = UiUtils.createCard();
        card.setMaxWidth(680);
        card.setSpacing(18);
        card.setAlignment(Pos.CENTER);
        card.setPadding(new Insets(32));

        Label icon = new Label(isCorrect ? "✅ Correct! Spot On!" : "❌ Watch Out!");
        icon.setStyle(
            "-fx-font-size: 24px; -fx-font-weight: bold;" +
            "-fx-text-fill: " + (isCorrect ? "#16A34A;" : "#DC2626;")
        );

        Label verdict = new Label(s.isScam ? "This message was indeed a: " + s.scamType : "This was a: " + s.scamType);
        verdict.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        Label explanation = new Label(s.explanation);
        explanation.setWrapText(true);
        explanation.setStyle(
            "-fx-font-size: 16px; -fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";" +
            "-fx-background-color: #F8FAFC; -fx-padding: 18px; -fx-background-radius: 12px; -fx-line-spacing: 3px;"
        );

        Button continueBtn = UiUtils.createPrimaryButton(
            (currentIndex < scenarios.size() - 1) ? "Next Scenario →" : "See Final Score 🏆", ""
        );
        continueBtn.setOnAction(e -> {
            currentIndex++;
            showCurrentScenario();
        });

        card.getChildren().addAll(icon, verdict, explanation, continueBtn);

        VBox centerWrap = new VBox(card);
        centerWrap.setAlignment(Pos.CENTER);
        gameContainer.getChildren().add(centerWrap);
    }

    private void showFinalResults() {
        gameContainer.getChildren().clear();

        int total = scenarios.size();
        int pct = (score * 100) / total;
        boolean passed = pct >= 70;

        int userId = AppConfig.getInstance().getCurrentUser().getId();
        if (passed) {
            ProgressService.getInstance().unlockAchievementDirect(userId, "SAFETY_HERO");
        }

        VBox card = UiUtils.createCard();
        card.setMaxWidth(640);
        card.setSpacing(18);
        card.setAlignment(Pos.CENTER);
        card.setPadding(new Insets(36));

        Label trophy = new Label(passed ? "🕵️‍♂️ 🌟" : "🛡️");
        trophy.setStyle("-fx-font-size: 60px;");

        Label title = new Label(passed ? "Scam Detective Badge Earned!" : "Good Training Session!");
        title.setStyle("-fx-font-size: 26px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        Label scoreLbl = new Label("You Correctly Identified: " + score + " / " + total + " (" + pct + "%)");
        scoreLbl.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_MUTED_GOLD + ";");

        Label msg = new Label(passed
            ? "Outstanding! You have sharp eyes for identifying fraud tactics. Your life savings and personal data remain well-guarded!"
            : "Fraudsters use clever tricks, but practicing builds immunity. Review the 6 Golden Rules and play again anytime!");
        msg.setWrapText(true);
        msg.setStyle("-fx-font-size: 16px; -fx-text-fill: " + UiUtils.COLOR_CHARCOAL + "; -fx-text-alignment: center;");

        HBox btns = new HBox(16);
        btns.setAlignment(Pos.CENTER);

        Button replayBtn = UiUtils.createSecondaryButton("Play Again 🔁", "");
        replayBtn.setOnAction(e -> {
            currentIndex = 0;
            score = 0;
            showCurrentScenario();
        });

        Button backBtn = UiUtils.createPrimaryButton("Back to Safety Center", "✓");
        backBtn.setOnAction(e -> onNavigate.accept("safety"));

        btns.getChildren().addAll(replayBtn, backBtn);

        card.getChildren().addAll(trophy, title, scoreLbl, msg, btns);

        VBox centerWrap = new VBox(card);
        centerWrap.setAlignment(Pos.CENTER);
        gameContainer.getChildren().add(centerWrap);
    }
}
