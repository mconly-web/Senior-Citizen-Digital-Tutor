package com.seniortutor.ui.view;

import com.seniortutor.model.Lesson;
import com.seniortutor.model.LessonStep;
import com.seniortutor.service.LocalizationService;
import com.seniortutor.service.ProgressService;
import com.seniortutor.service.WindowsSpeechService;
import com.seniortutor.ui.component.StepIllustrationNode;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.*;

import java.util.List;
import java.util.function.Consumer;

/**
 * Reusable Lesson Engine: displays step-by-step instructions, visual representations,
 * voice playback (Listen / Repeat) in user's selected language, progress tracking,
 * and links to Practice & Quiz.
 */
public class LessonDetailView extends VBox {

    private final Lesson lesson;
    private final Consumer<String> onNavigate;
    private final Consumer<Lesson> onLaunchQuiz;
    private final Consumer<String> onLaunchPractice;

    private int currentStepIndex = 0;
    private final List<LessonStep> steps;

    private final Label stepCounterLabel = new Label();
    private final ProgressBar progressBar = new ProgressBar();
    private final Label stepTitleLabel = new Label();
    private final Label stepExplanationLabel = new Label();
    private final StackPane illustrationContainer = new StackPane();
    private final VBox recapBox = new VBox(8);
    private final HBox navigationControls = new HBox(16);

    private Button prevBtn;
    private Button nextBtn;
    private Button listenBtn;
    private Button repeatBtn;

    public LessonDetailView(Lesson lesson, Consumer<String> onNavigate, Consumer<Lesson> onLaunchQuiz, Consumer<String> onLaunchPractice) {
        this.lesson = lesson;
        this.steps = lesson.getSteps();
        this.onNavigate = onNavigate;
        this.onLaunchQuiz = onLaunchQuiz;
        this.onLaunchPractice = onLaunchPractice;

        setSpacing(16);
        setPadding(new Insets(24));
        setStyle("-fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");
        setFillWidth(true);

        // Resume from user's last step if available
        if (lesson.getLastCompletedStep() > 1 && lesson.getLastCompletedStep() <= steps.size()) {
            this.currentStepIndex = lesson.getLastCompletedStep() - 1;
        }

        buildHeader();
        buildLessonCard();
        updateStepDisplay();
    }

    private void buildHeader() {
        LocalizationService loc = LocalizationService.getInstance();
        String lang = loc.getLanguage();

        HBox topRow = new HBox(16);
        topRow.setAlignment(Pos.CENTER_LEFT);

        Button backBtn = UiUtils.createSecondaryButton(loc.getString("lesson.back"), "");
        backBtn.setOnAction(e -> onNavigate.accept("learn"));

        VBox titleBox = new VBox(2);
        Label catLabel = new Label(lesson.getCategoryIcon() + " " + lesson.getCategoryName());
        catLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_SOFT_SAGE + ";");

        Label titleLabel = new Label(lesson.getLocalizedTitle(lang));
        titleLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");
        titleBox.getChildren().addAll(catLabel, titleLabel);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Voice Listen & Repeat Quick Controls
        listenBtn = UiUtils.createPrimaryButton(loc.getString("lesson.listen"), "");
        listenBtn.setOnAction(e -> speakCurrentStep());

        repeatBtn = UiUtils.createSecondaryButton(loc.getString("lesson.repeat"), "");
        repeatBtn.setOnAction(e -> speakCurrentStep());

        topRow.getChildren().addAll(backBtn, titleBox, spacer, listenBtn, repeatBtn);
        getChildren().add(topRow);
    }

    private void buildLessonCard() {
        VBox card = UiUtils.createCard();
        card.setSpacing(18);
        card.setPadding(new Insets(24));
        VBox.setVgrow(card, Priority.ALWAYS);

        // Progress Bar & Step Counter
        HBox progressRow = new HBox(16);
        progressRow.setAlignment(Pos.CENTER_LEFT);

        stepCounterLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");

        progressBar.setMaxWidth(Double.MAX_VALUE);
        progressBar.setPrefHeight(12);
        progressBar.setStyle("-fx-accent: " + UiUtils.COLOR_MUTED_GOLD + ";");
        HBox.setHgrow(progressBar, Priority.ALWAYS);

        progressRow.getChildren().addAll(stepCounterLabel, progressBar);

        // Step Title
        stepTitleLabel.setStyle(
            "-fx-font-size: 22px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";"
        );
        stepTitleLabel.setWrapText(true);

        // Visual Illustration Node Container
        illustrationContainer.setStyle(
            "-fx-background-color: #FAF8F5;" +
            "-fx-border-color: #E2E8F0;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 12px;"
        );
        VBox.setVgrow(illustrationContainer, Priority.ALWAYS);

        // Step Explanation
        stepExplanationLabel.setStyle(
            "-fx-font-size: 18px;" +
            "-fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";" +
            "-fx-line-spacing: 4px;"
        );
        stepExplanationLabel.setWrapText(true);

        // End-of-Lesson Recap Box
        recapBox.setStyle(
            "-fx-background-color: #F0FDF4;" +
            "-fx-border-color: #86EFAC;" +
            "-fx-border-width: 1.5px;" +
            "-fx-border-radius: 12px;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 14px 18px;"
        );
        recapBox.setVisible(false);
        recapBox.setManaged(false);

        // Bottom Navigation Bar
        navigationControls.setAlignment(Pos.CENTER);
        navigationControls.setPadding(new Insets(12, 0, 0, 0));

        card.getChildren().addAll(progressRow, stepTitleLabel, illustrationContainer, stepExplanationLabel, recapBox, navigationControls);
        getChildren().add(card);
    }

    private void updateStepDisplay() {
        LocalizationService loc = LocalizationService.getInstance();
        String lang = loc.getLanguage();

        if (steps == null || steps.isEmpty()) {
            stepTitleLabel.setText(loc.getString("learn.empty_lessons"));
            stepExplanationLabel.setText("");
            return;
        }

        LessonStep step = steps.get(currentStepIndex);

        int total = steps.size();
        stepCounterLabel.setText(loc.getString("lesson.step_of", (currentStepIndex + 1), total));
        progressBar.setProgress((double) (currentStepIndex + 1) / total);

        stepTitleLabel.setText(step.getLocalizedTitle(lang));
        stepExplanationLabel.setText(step.getLocalizedExplanation(lang));

        // Update Illustration Node
        illustrationContainer.getChildren().clear();
        illustrationContainer.getChildren().add(new StepIllustrationNode(step));

        // Show Recap if on last step
        String recap = lesson.getLocalizedRecap(lang);
        if (currentStepIndex == total - 1 && recap != null && !recap.isBlank()) {
            recapBox.getChildren().clear();
            Label recapHdr = new Label(loc.getString("lesson.recap_title"));
            recapHdr.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #166534;");
            Label recapBody = new Label(recap);
            recapBody.setStyle("-fx-font-size: 15px; -fx-text-fill: #14532D; -fx-line-spacing: 3px;");
            recapBody.setWrapText(true);
            recapBox.getChildren().addAll(recapHdr, recapBody);
            recapBox.setVisible(true);
            recapBox.setManaged(true);
        } else {
            recapBox.setVisible(false);
            recapBox.setManaged(false);
        }

        // Save progress to database
        int userId = AppConfig.getInstance().getCurrentUser().getId();
        ProgressService.getInstance().updateStep(userId, lesson.getId(), currentStepIndex + 1);

        // Rebuild Navigation Buttons
        navigationControls.getChildren().clear();

        // Previous Button
        if (currentStepIndex > 0) {
            prevBtn = UiUtils.createSecondaryButton(loc.getString("lesson.prev"), "");
            prevBtn.setOnAction(e -> {
                currentStepIndex--;
                updateStepDisplay();
            });
            navigationControls.getChildren().add(prevBtn);
        }

        Region navSpacer = new Region();
        HBox.setHgrow(navSpacer, Priority.ALWAYS);
        navigationControls.getChildren().add(navSpacer);

        // Next Button or Final Step Actions
        if (currentStepIndex < total - 1) {
            nextBtn = UiUtils.createPrimaryButton(loc.getString("lesson.next"), "");
            nextBtn.setOnAction(e -> {
                currentStepIndex++;
                updateStepDisplay();
            });
            navigationControls.getChildren().add(nextBtn);
        } else {
            // End of lesson actions
            if (lesson.hasSimulation()) {
                Button practiceBtn = UiUtils.createAccentButton(loc.getString("lesson.practice"), "");
                practiceBtn.setOnAction(e -> onLaunchPractice.accept(lesson.getPracticeType()));
                navigationControls.getChildren().add(practiceBtn);
            }

            Button quizBtn = UiUtils.createPrimaryButton(loc.getString("lesson.quiz"), "");
            quizBtn.setOnAction(e -> onLaunchQuiz.accept(lesson));
            navigationControls.getChildren().add(quizBtn);

            Button finishBtn = UiUtils.createSecondaryButton(loc.getString("lesson.completed"), "");
            finishBtn.setOnAction(e -> {
                ProgressService.getInstance().completeLesson(userId, lesson.getId());
                SoundUtil.playSuccess();
                UiUtils.showInfoDialog(
                    loc.getString("lesson.finished_title"),
                    loc.getString("lesson.congrats"),
                    loc.getString("lesson.finished_msg", lesson.getLocalizedTitle(lang))
                );
                onNavigate.accept("learn");
            });
            navigationControls.getChildren().add(finishBtn);
        }

        // Auto speak in user's active language if voice tutor is enabled
        if (AppConfig.getInstance().getCurrentSettings().isVoiceEnabled()) {
            speakCurrentStep();
        }
    }

    private void speakCurrentStep() {
        if (steps != null && !steps.isEmpty()) {
            LessonStep step = steps.get(currentStepIndex);
            String lang = LocalizationService.getInstance().getLanguage();
            WindowsSpeechService.getInstance().speak(step.getLocalizedVoiceText(lang), lang);
        }
    }
}
