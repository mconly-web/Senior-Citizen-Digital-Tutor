package com.seniortutor.ui.view;

import com.seniortutor.model.Category;
import com.seniortutor.model.Lesson;
import com.seniortutor.service.LessonService;
import com.seniortutor.service.LocalizationService;
import com.seniortutor.ui.component.CategoryCard;
import com.seniortutor.ui.component.LessonCard;
import com.seniortutor.util.AppConfig;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.*;

import java.util.List;
import java.util.function.Consumer;

/**
 * Learn Hub: lists all 12 curriculum categories and drill-down into specific lessons
 * with multilingual support (English, Hindi, Marathi).
 */
public class LearnCategoriesView extends ScrollPane {

    private final Consumer<Lesson> onLaunchLesson;
    private final VBox root = new VBox(24);
    private Category currentSelectedCategory = null;

    public LearnCategoriesView(Consumer<Lesson> onLaunchLesson) {
        this(onLaunchLesson, null);
    }

    public LearnCategoriesView(Consumer<Lesson> onLaunchLesson, Category initialCategory) {
        this.onLaunchLesson = onLaunchLesson;
        this.currentSelectedCategory = initialCategory;

        setFitToWidth(true);
        setStyle("-fx-background: " + UiUtils.COLOR_WARM_CREAM + "; -fx-background-color: " + UiUtils.COLOR_WARM_CREAM + ";");

        root.setPadding(new Insets(24));
        root.setFillWidth(true);
        setContent(root);

        if (initialCategory != null) {
            showLessonsForCategory(initialCategory);
        } else {
            showAllCategories();
        }
    }

    public void showAllCategories() {
        root.getChildren().clear();
        int userId = AppConfig.getInstance().getCurrentUser().getId();
        LocalizationService loc = LocalizationService.getInstance();

        VBox headerBox = new VBox(4);
        Label title = UiUtils.createTitle(loc.getString("learn.title"));
        Label subtitle = UiUtils.createSubtitle(loc.getString("learn.sub"));
        headerBox.getChildren().addAll(title, subtitle);

        List<Category> categories = LessonService.getInstance().getCategories(userId);

        GridPane grid = new GridPane();
        grid.setHgap(20);
        grid.setVgap(20);

        int row = 0;
        int col = 0;
        for (Category cat : categories) {
            CategoryCard card = new CategoryCard(cat, this::showLessonsForCategory);
            grid.add(card, col, row);

            col++;
            if (col > 2) { // 3 columns
                col = 0;
                row++;
            }
        }

        root.getChildren().addAll(headerBox, grid);
    }

    public void showLessonsForCategory(Category cat) {
        this.currentSelectedCategory = cat;
        root.getChildren().clear();
        int userId = AppConfig.getInstance().getCurrentUser().getId();
        LocalizationService loc = LocalizationService.getInstance();
        String lang = loc.getLanguage();

        // Header with Back Button
        HBox topRow = new HBox(16);
        topRow.setAlignment(Pos.CENTER_LEFT);

        Button backBtn = UiUtils.createSecondaryButton(loc.getString("learn.back_categories"), "");
        backBtn.setOnAction(e -> showAllCategories());

        VBox titleBox = new VBox(2);
        Label title = new Label(cat.getIcon() + " " + cat.getLocalizedName(lang));
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: " + UiUtils.COLOR_FOREST_GREEN + ";");
        Label subtitle = new Label(cat.getLocalizedDescription(lang));
        subtitle.setStyle("-fx-font-size: 15px; -fx-text-fill: " + UiUtils.COLOR_CHARCOAL + ";");
        titleBox.getChildren().addAll(title, subtitle);

        topRow.getChildren().addAll(backBtn, titleBox);

        // Lesson list
        List<Lesson> lessons = LessonService.getInstance().getLessonsForCategory(cat.getId(), userId);

        VBox lessonListBox = new VBox(14);
        if (lessons.isEmpty()) {
            Label emptyLbl = new Label(loc.getString("learn.empty_lessons"));
            emptyLbl.setStyle("-fx-font-size: 16px; -fx-text-fill: #64748B; -fx-padding: 20px;");
            lessonListBox.getChildren().add(emptyLbl);
        } else {
            for (Lesson l : lessons) {
                LessonCard card = new LessonCard(l, onLaunchLesson);
                lessonListBox.getChildren().add(card);
            }
        }

        root.getChildren().addAll(topRow, lessonListBox);
    }
}
