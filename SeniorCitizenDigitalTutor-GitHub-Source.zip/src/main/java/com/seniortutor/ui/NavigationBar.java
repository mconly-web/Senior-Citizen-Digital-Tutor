package com.seniortutor.ui;

import com.seniortutor.service.LocalizationService;
import com.seniortutor.util.SoundUtil;
import com.seniortutor.util.UiUtils;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.*;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Clean senior-friendly tablet navigation rail / sidebar with live multilingual label updating.
 */
public class NavigationBar extends VBox {

    private final Consumer<String> onNavigate;
    private final Map<String, Button> navButtons = new HashMap<>();
    private String currentActive = "home";

    public NavigationBar(Consumer<String> onNavigate) {
        this.onNavigate = onNavigate;

        setPrefWidth(220);
        setSpacing(10);
        setPadding(new Insets(20, 12, 20, 12));
        setStyle(
            "-fx-background-color: " + UiUtils.COLOR_FOREST_GREEN + ";" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.15), 8, 0, 2, 0);"
        );

        buildNavItems();
        setActive("home");

        // Listen for language changes to update sidebar button labels immediately
        LocalizationService.getInstance().addLanguageListener(lang -> updateLabels());
    }

    private void buildNavItems() {
        LocalizationService loc = LocalizationService.getInstance();

        addNavItem("home", "🏠 " + loc.getString("nav.home"));
        addNavItem("learn", "📚 " + loc.getString("nav.learn"));
        addNavItem("practice", "🎮 " + loc.getString("nav.practice"));
        addNavItem("safety", "🔐 " + loc.getString("nav.safety"));
        addNavItem("progress", "📊 " + loc.getString("nav.progress"));
        addNavItem("achievements", "🏆 " + loc.getString("nav.achievements"));
        addNavItem("family", "👨‍👩‍👧 " + loc.getString("nav.family"));

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);
        getChildren().add(spacer);

        addEmergencyItem("emergency", "🆘 " + loc.getString("nav.emergency"));
        addNavItem("settings", "⚙️ " + loc.getString("nav.settings"));
    }

    public void updateLabels() {
        LocalizationService loc = LocalizationService.getInstance();
        setButtonText("home", "🏠 " + loc.getString("nav.home"));
        setButtonText("learn", "📚 " + loc.getString("nav.learn"));
        setButtonText("practice", "🎮 " + loc.getString("nav.practice"));
        setButtonText("safety", "🔐 " + loc.getString("nav.safety"));
        setButtonText("progress", "📊 " + loc.getString("nav.progress"));
        setButtonText("achievements", "🏆 " + loc.getString("nav.achievements"));
        setButtonText("family", "👨‍👩‍👧 " + loc.getString("nav.family"));
        setButtonText("emergency", "🆘 " + loc.getString("nav.emergency"));
        setButtonText("settings", "⚙️ " + loc.getString("nav.settings"));
    }

    private void setButtonText(String key, String text) {
        Button b = navButtons.get(key);
        if (b != null) {
            b.setText(text);
        }
    }

    private void addNavItem(String key, String label) {
        Button btn = new Button(label);
        btn.setMaxWidth(Double.MAX_VALUE);
        btn.setAlignment(Pos.CENTER_LEFT);
        btn.setMinHeight(48);

        btn.setStyle(
            "-fx-font-size: 16px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: #E2EAE5;" +
            "-fx-background-color: transparent;" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 10px 16px;" +
            "-fx-cursor: hand;"
        );

        btn.setOnAction(e -> {
            SoundUtil.playClick();
            setActive(key);
            onNavigate.accept(key);
        });

        navButtons.put(key, btn);
        getChildren().add(btn);
    }

    private void addEmergencyItem(String key, String label) {
        Button btn = new Button(label);
        btn.setMaxWidth(Double.MAX_VALUE);
        btn.setAlignment(Pos.CENTER_LEFT);
        btn.setMinHeight(48);

        btn.setStyle(
            "-fx-font-size: 16px;" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: white;" +
            "-fx-background-color: " + UiUtils.COLOR_MUTED_TERRACOTTA + ";" +
            "-fx-background-radius: 12px;" +
            "-fx-padding: 10px 16px;" +
            "-fx-cursor: hand;"
        );

        btn.setOnAction(e -> {
            SoundUtil.playClick();
            setActive(key);
            onNavigate.accept(key);
        });

        navButtons.put(key, btn);
        getChildren().add(btn);
    }

    public void setActive(String key) {
        this.currentActive = key;

        for (Map.Entry<String, Button> entry : navButtons.entrySet()) {
            Button btn = entry.getValue();
            boolean isEmergency = "emergency".equals(entry.getKey());

            if (entry.getKey().equals(key)) {
                btn.setStyle(
                    "-fx-font-size: 16px;" +
                    "-fx-font-weight: bold;" +
                    "-fx-text-fill: " + (isEmergency ? "white" : UiUtils.COLOR_FOREST_GREEN) + ";" +
                    "-fx-background-color: " + (isEmergency ? "#B91C1C" : UiUtils.COLOR_WARM_CREAM) + ";" +
                    "-fx-background-radius: 12px;" +
                    "-fx-padding: 10px 16px;" +
                    "-fx-cursor: hand;"
                );
            } else {
                btn.setStyle(
                    "-fx-font-size: 16px;" +
                    "-fx-font-weight: bold;" +
                    "-fx-text-fill: " + (isEmergency ? "white" : "#E2EAE5") + ";" +
                    "-fx-background-color: " + (isEmergency ? UiUtils.COLOR_MUTED_TERRACOTTA : "transparent") + ";" +
                    "-fx-background-radius: 12px;" +
                    "-fx-padding: 10px 16px;" +
                    "-fx-cursor: hand;"
                );
            }
        }
    }
}
