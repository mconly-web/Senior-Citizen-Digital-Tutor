@echo off
echo ========================================================
echo Packaging Senior Citizen Digital Tutor for Windows
echo ========================================================

REM Step 1: Clean build and package fat JAR
echo [1/3] Compiling and packaging standalone JAR...
call mvn clean package -DskipTests
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Maven build failed!
    exit /b %ERRORLEVEL%
)

REM Step 2: Locate jpackage
echo [2/3] Checking for jpackage...
set JPACKAGE_CMD=jpackage
where jpackage >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    if exist "C:\Program Files\Java\jdk-25\bin\jpackage.exe" (
        set "JPACKAGE_CMD=C:\Program Files\Java\jdk-25\bin\jpackage.exe"
    ) else if defined JAVA_HOME (
        set "JPACKAGE_CMD=%JAVA_HOME%\bin\jpackage.exe"
    ) else (
        echo [ERROR] jpackage could not be found. Please ensure JDK 21+ is installed.
        exit /b 1
    )
)

REM Step 3: Run jpackage to create standalone bundle with embedded runtime
echo [3/3] Running jpackage to bundle native Windows runtime...
rmdir /s /q dist 2>nul
"%JPACKAGE_CMD%" --type app-image ^
    --name "SeniorCitizenDigitalTutor" ^
    --input target ^
    --main-jar SeniorCitizenDigitalTutor.jar ^
    --main-class com.seniortutor.Main ^
    --dest dist ^
    --vendor "SeniorTutor Community" ^
    --app-version "1.0.0" ^
    --description "A Calm, Respectful Digital Literacy Desktop Tutor for Senior Citizens"

if %ERRORLEVEL% EQU 0 (
    echo ========================================================
    echo SUCCESS! Standalone Windows app packaged in:
    echo   dist\SeniorCitizenDigitalTutor\SeniorCitizenDigitalTutor.exe
    echo   No Java installation needed on end user machines!
    echo ========================================================
) else (
    echo [ERROR] jpackage failed!
)
