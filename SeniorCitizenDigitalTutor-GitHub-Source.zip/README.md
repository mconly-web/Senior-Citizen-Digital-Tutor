# Senior Citizen Digital Tutor 🌿
> *"Learn. Practice. Use. Stay Connected."*

A calm, respectful, production-ready desktop application designed specifically to empower senior citizens to learn everyday digital tasks with confidence, practice fearlessly in risk-free sandboxes, and stay protected from cyber fraud.

Built strictly in **Java 21 LTS**, **JavaFX**, and **SQLite** without any Electron bloat, web dependencies, cloud servers, or paid APIs. **100% Offline, Private, and Self-Contained.**

---

## 🌟 Upgraded Highlights & Core Features

### 1. 📚 Complete 42-Lesson Curriculum (12 Categories)
- **42 comprehensive lessons** (3–6 steps each) spanning all 12 essential digital literacy categories:
  1. Smartphone Basics (Power, volume, screen brightness, battery care)
  2. Phone Calls & Contacts (Dialing, saving family numbers, speakerphone, blocking spam)
  3. WhatsApp & Messaging (Chat, voice notes, photos, video calls, family groups)
  4. Calls & Video Calling (Clear audio, front camera, quiet rooms, WhatsApp calls)
  5. UPI & Digital Payments (GPay, PhonePe, QR code scanning, never entering PIN to receive)
  6. Online Banking & ATM Safety (ATM PIN covering, statement checking, OTP secrecy)
  7. Google Maps & Navigation (Searching clinics, hospitals, turn-by-turn directions)
  8. Email Essentials (Gmail composing, reading emails, spotting fake messages)
  9. Aadhaar & DigiLocker (Government identity, vaccine certificates, driving license)
  10. Online Shopping & Bill Payments (Electricity bills, mobile recharge, cash on delivery)
  11. Digital Safety & Scam Awareness (6 Golden Rules, fake electricity cuts, digital arrest, parcel traps)
  12. Entertainment & Telemedicine (YouTube spiritual videos, doctor video consults, 112/1930 helplines)
- **Every lesson includes 3–5 interactive quiz questions** with clear explanations and a calm end-of-lesson recap.

### 2. 🇮🇳 Full Trilingual Localization (English, Hindi हिंदी, Marathi मराठी)
- Every single lesson title, description, step explanation, quiz question, multiple-choice option, recap, and scam advice is fully translated and localized.
- **Multilingual Voice Tutor:** Automatically picks the native Indian SAPI voice (`hi-IN` Kalpana/Hemant, `mr-IN` Marathi, or standard English voice) with smooth offline fallback.
- Dynamic runtime language switching via `LocalizationService` without restarting the application.

### 3. 🎙️ Voice Search & Cross-Platform Speech
- **Voice-Activated Search:** Seniors can tap the microphone button on the Home screen to speak their search query naturally (uses offline Windows Speech Recognition via `System.Speech`, with graceful fallback to typing).
- **Speech Speed Control:** Adjustable voice pace in Settings:
  - *Calm & Slow* (-2.0 pace for elders with hearing difficulties)
  - *Normal Pace* (-1.0 pace)
  - *Brisk Pace* (0.0 standard pace)
- **Cross-Platform Compatibility:** Native speech fallbacks for macOS (`say`) and Linux (`espeak`) so the app never fails outside Windows.

### 4. 🚀 Onboarding & Profile Management
- **First-Run Welcome Wizard:** Automatically guides new users through setting their name, avatar, preferred language (English/Hindi/Marathi), text size, and a 1-minute guided tour.
- **Multi-Profile Support:** Create new senior or caregiver profiles, switch users instantly, or delete profiles cleanly from the top bar.
- **Helper Dashboard Protection:** Optional 4-digit PIN prevents seniors from accidentally altering caregiver settings.
- **Offline Data Portability:** Full JSON Backup & Restore for progress, achievements, and settings, plus a one-click progress reset.

### 5. 🛡️ Advanced Scam Defense & "Scam Spotter" Mini-Game
- **Weighted Scam Analysis Engine:** Detects modern Indian fraud tactics:
  - Fake Electricity Disconnection threats
  - Fake Police / CBI "Digital Arrest" calls
  - QR Code "Receive Money" traps
  - Secret OTP, PIN, and CVV harvesting
  - Remote Screen-Sharing tools (AnyDesk, TeamViewer, QuickSupport)
  - Fake Job / YouTube Like / Telegram task schemes
  - Fake Courier / Narcotics seizure traps
  - Suspicious links (IPs, shorteners, `.apk` files) and international spoofed numbers (`+92`, `+234`)
- **"Why This Is Risky" Explanations:** Explains the psychological tricks behind each red flag in simple language.
- **Recent Checks History:** Automatically saves and displays past analyzed messages and risk ratings.
- **1930 Cyber Helpline & cybercrime.gov.in:** Direct guidance on reporting fraud to the Indian Ministry of Home Affairs.
- **"Scam Spotter" Mini-Game:** Interactive 10-scenario challenge where elders read realistic Indian SMS/WhatsApp messages and tap **SAFE** or **SCAM** to earn score badges and learn defenses.

### 6. 🎮 7 Risk-Free Practice Simulators
1. **💬 WhatsApp Simulator:** Messaging, voice notes, photo sharing, live location, and full video calling screen.
2. **📞 Phone Dialer Simulator:** 3x4 dialpad, family speed-dial chips, ringing and connected call screens.
3. **💳 UPI Payment Simulator:** QR viewfinder, merchant name verification, safety alert, secret PIN pad, and audio receipt.
4. **🗺️ Google Maps Simulator:** Interactive canvas, clinic/hospital pins, route drawing, and spoken directions.
5. **📧 Email Simulator:** Senior-friendly Gmail composer, recipient autofill, attachment simulation, and inbox.
6. **📄 Aadhaar & DigiLocker Simulator:** Safe simulation of requesting UIDAI documents, entering masked Aadhaar numbers, verifying simulated OTPs, previewing digital certificates, and learning the e-Aadhaar PDF password formula (`RAME1952`).
7. **⚡ Online Bill Payment Simulator:** Safe electricity bill and mobile recharge simulation with consumer number fetching, verified due date reminder (15-day notice vs scam 1-hour threats), and instant PDF receipt generation.

### 7. 🚑 Configurable Emergency Help & Medical Card
- Editable emergency contacts (Anita Daughter, Rohan Son, Family Doctor) configured directly in Settings.
- Giant high-contrast touch buttons with confirmation dialogs to prevent accidental calls.
- **Senior Medical Information Card:** Displays blood group (`O+`, etc.), daily medications, and family physician phone for emergency responders.

### 8. ♿ Accessibility & Ergonomic Polish
- Minimum **48px touch targets** across all interactive elements (WCAG AAA).
- High-visibility focus rings and complete keyboard navigation (`Tab`, `Shift+Tab`, `Enter`, `Escape`).
- Resilient text scaling and responsive layouts that downscale gracefully to **1024x700**.
- Colorblind-safe indicators using distinct icons alongside color coding (`✅ Passed`, `❌ Incomplete`, `🚨 High Risk`, `🟢 Safe`).
- **Zero Stack Traces:** Senior-friendly error dialogs that reassure users their progress is safe.
- Native application icon (`app_icon.png`).

---

## 🎨 Visual Identity & Palette

- **Warm Cream:** `#FAF8F5` / `#F4EFE6` (Calm, paper-like background that reduces glare)
- **Deep Forest Green:** `#173F35` / `#1E5044` (Primary brand, high-contrast text and action buttons)
- **Soft Sage:** `#6F8068` (Borders, secondary tags, and subtle dividers)
- **Muted Terracotta:** `#C97855` / `#B86744` (Accents, practice chips, and voice buttons)
- **Muted Gold:** `#D6A84F` (Focus rings, achievement badges, and ratings)
- **Charcoal:** `#242424` / `#2C3E35` (High-legibility typography)

---

## 🛠️ Technology Stack

| Layer | Technology |
|---|---|
| **Language** | Java 21 LTS (tested with JDK 21 and JDK 25) |
| **GUI Framework** | OpenJFX 21 (Controls, Graphics, Media, CSS) |
| **Database** | SQLite 3.45 via SQLite-JDBC (`database/seniortutor.db`) |
| **Packaging** | Maven Shade Plugin (Fat JAR) & `jpackage` (Native Windows Bundle) |
| **Testing** | JUnit 5 Jupiter (21 Automated Tests) + Custom Smoke Test Suite |
| **Voice & Speech** | Windows SAPI Speech Engine via PowerShell (100% Offline) |

---

## 🚀 Running the Application

### Option 1: Standalone Windows App (No Java Needed!)
Run the pre-bundled Windows application from `dist`:
```powershell
dist\SeniorCitizenDigitalTutor\SeniorCitizenDigitalTutor.exe
```
To re-package the installer at any time:
```cmd
build-installer.bat
```

### Option 2: Running the Shaded Fat JAR
```powershell
java -jar target/SeniorCitizenDigitalTutor.jar
```

### Option 3: Building from Source with Maven
```powershell
mvn clean package -DskipTests
java -jar target/SeniorCitizenDigitalTutor.jar
```

### Running the Test Suite
```powershell
# Run all 21 JUnit 5 unit tests
mvn test

# Run backend smoke test verifying database, curriculum, and speech
java -cp "target/test-classes;target/SeniorCitizenDigitalTutor.jar" com.seniortutor.AppSmokeTest
```

---

## 📸 Application Screenshots

| Screen | Preview | File Path |
|---|---|---|
| **Home Dashboard** | Welcoming greeting, daily tip, weekly summary, voice search | `screenshots/01_home_screen.png` |
| **Lesson Viewer** | Step tracker, dynamic illustration mockup, trilingual voice controls | `screenshots/02_lesson_viewer.png` |
| **Quiz Interface** | Multiple-choice questions with feedback and recap | `screenshots/03_quiz_interface.png` |
| **WhatsApp Sandbox** | Interactive chat, voice notes, video call screen | `screenshots/04_practice_whatsapp.png` |
| **UPI Sandbox** | QR viewfinder, amount check, mock PIN pad, audio receipt | `screenshots/05_practice_upi.png` |
| **Maps Sandbox** | Map canvas, hospitals/pharmacies, turn-by-turn route | `screenshots/06_practice_maps.png` |
| **Safety Hub** | "Is This Safe?" scam checker, risk explanation, recent history | `screenshots/07_safety_checker.png` |
| **Progress Dashboard** | Category completion progress bars and streak metrics | `screenshots/08_progress_dashboard.png` |
| **Badges & Milestones** | 8 unlockable milestone badges | `screenshots/09_achievements_milestones.png` |
| **Family Helper Mode** | Caregiver analytics and lesson recommendation tool | `screenshots/10_family_helper_mode.png` |
| **Emergency Help** | Giant one-touch assistance buttons and Senior Medical Card | `screenshots/11_emergency_assistance.png` |
| **Settings & Accessibility** | Font size, speech speed, backup/restore, PIN protection | `screenshots/12_accessibility_settings.png` |
| **Aadhaar & DigiLocker** | Document fetch, Aadhaar masking, simulated OTP, verified PDF | `screenshots/13_practice_aadhaar.png` |
| **Online Bill Payment** | Electricity & mobile recharge, 15-day notice check, UPI receipt | `screenshots/14_practice_bill.png` |
| **Scam Spotter Game** | 10 Indian scenario mini-game with instant SAFE/SCAM scoring | `screenshots/15_scam_spotter_game.png` |

---

## 👥 Demo Profiles

1. **👵 Shanti Sharma (Senior Learner)**
   - Role: `SENIOR`
   - Active Streak: `3 Days`
   - Initial State: First lesson completed, Lesson #5 (Phone Call) in progress at Step 2.
   - Pinned Recommendation: Anita recommended "NEVER Share Your UPI PIN - Crucial Rules".
2. **👩 Anita Sharma (Daughter & Caregiver)**
   - Role: `HELPER`
   - Access to Family Care dashboard, senior analytics, and lesson recommender.

*(Easily add or delete profiles anytime via the top-bar profile manager!)*

---

## 📜 License & Acknowledgments
Developed for academic mini-project demonstration. Free to use and extend for digital literacy and elder empowerment initiatives.
