import os
import docx
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn, nsdecls

# ----------------------------------------------------------------------
# Brand Colors
# ----------------------------------------------------------------------
RGB_FOREST     = RGBColor(0x17, 0x3F, 0x35)
RGB_TERRACOTTA = RGBColor(0xC9, 0x78, 0x55)
RGB_SAGE       = RGBColor(0x6F, 0x80, 0x68)
RGB_GOLD       = RGBColor(0xD6, 0xA8, 0x4F)
RGB_CHARCOAL   = RGBColor(0x24, 0x24, 0x24)
HEX_CREAM      = "F3EDE2"
HEX_FOREST     = "173F35"
HEX_CARD_BG    = "FAF7F2"
HEX_BORDER     = "E2D8C7"
HEX_DANGER_BG  = "FFEBEE"
HEX_DANGER_BOR = "D32F2F"

def set_cell_background(cell, hex_color):
    shading_xml = f'<w:shd {nsdecls("w")} w:fill="{hex_color}"/>'
    cell._tc.get_or_add_tcPr().append(parse_xml(shading_xml))

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for m, val in [('w:top', top), ('w:bottom', bottom), ('w:left', left), ('w:right', right)]:
        node = OxmlElement(m)
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def add_callout_box(doc, title, paragraphs, border_color_hex=HEX_FOREST, bg_color_hex=HEX_CARD_BG):
    tbl = doc.add_table(rows=1, cols=1)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = tbl.cell(0, 0)
    set_cell_background(cell, bg_color_hex)
    set_cell_margins(cell, top=140, bottom=140, left=200, right=200)
    
    # Left border highlight
    tcPr = cell._tc.get_or_add_tcPr()
    tcBorders = parse_xml(f'''
        <w:tcBorders {nsdecls("w")}>
            <w:top w:val="none"/>
            <w:left w:val="single" w:sz="36" w:space="0" w:color="{border_color_hex}"/>
            <w:bottom w:val="none"/>
            <w:right w:val="none"/>
        </w:tcBorders>
    ''')
    tcPr.append(tcBorders)
    
    p0 = cell.paragraphs[0]
    p0.paragraph_format.space_before = Pt(2)
    p0.paragraph_format.space_after = Pt(4)
    run_t = p0.add_run(title)
    run_t.font.name = "Segoe UI"
    run_t.font.size = Pt(11)
    run_t.font.bold = True
    run_t.font.color.rgb = RGB_FOREST
    
    for text in paragraphs:
        p = cell.add_paragraph()
        p.paragraph_format.space_before = Pt(2)
        p.paragraph_format.space_after = Pt(4)
        run = p.add_run(text)
        run.font.name = "Segoe UI"
        run.font.size = Pt(9.5)
        run.font.color.rgb = RGB_CHARCOAL
        
    doc.add_paragraph().paragraph_format.space_after = Pt(6)

def generate_docx():
    print("Generating PROJECT_USER_MANUAL.docx...")
    doc = Document()
    
    # Set page margins
    sections = doc.sections
    for section in sections:
        section.top_margin = Inches(0.7)
        section.bottom_margin = Inches(0.7)
        section.left_margin = Inches(0.75)
        section.right_margin = Inches(0.75)
        
        # Header & Footer
        header = section.header
        p_head = header.paragraphs[0]
        p_head.text = "Senior Citizen Digital Tutor — Official Functional Handover & User Operations Manual"
        p_head.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p_head.style.font.name = "Segoe UI"
        p_head.style.font.size = Pt(8)
        p_head.style.font.color.rgb = RGB_SAGE
        
        footer = section.footer
        p_foot = footer.paragraphs[0]
        p_foot.text = "Learn. Practice. Use. Stay Connected. • Standalone Desktop Application Handover Manual"
        p_foot.alignment = WD_ALIGN_PARAGRAPH.LEFT
        p_foot.style.font.name = "Segoe UI"
        p_foot.style.font.size = Pt(8)
        p_foot.style.font.color.rgb = RGB_SAGE

    # ------------------------------------------------------------------
    # TITLE SECTION
    # ------------------------------------------------------------------
    p_title = doc.add_paragraph()
    p_title.paragraph_format.space_before = Pt(10)
    p_title.paragraph_format.space_after = Pt(2)
    run_title = p_title.add_run("SENIOR CITIZEN DIGITAL TUTOR")
    run_title.font.name = "Segoe UI"
    run_title.font.size = Pt(24)
    run_title.font.bold = True
    run_title.font.color.rgb = RGB_FOREST

    p_sub = doc.add_paragraph()
    p_sub.paragraph_format.space_after = Pt(8)
    run_sub = p_sub.add_run("Official Functional Software Handover & User Operations Manual")
    run_sub.font.name = "Segoe UI"
    run_sub.font.size = Pt(13)
    run_sub.font.bold = True
    run_sub.font.color.rgb = RGB_TERRACOTTA

    p_meta = doc.add_paragraph()
    p_meta.paragraph_format.space_after = Pt(14)
    run_meta = p_meta.add_run(
        "Tagline: \"Learn. Practice. Use. Stay Connected.\" | Primary Deliverable: SeniorCitizenDigitalTutor.jar\n"
        "Application Type: Standalone Desktop Application (JavaFX 21 LTS + SQLite JDBC) | Target Resolution: 1280x800"
    )
    run_meta.font.name = "Segoe UI"
    run_meta.font.size = Pt(9.5)
    run_meta.font.italic = True
    run_meta.font.color.rgb = RGB_SAGE

    # Quick Start Box
    quick_start_items = [
        "1. Ensure Java is installed: Requires Java 21 LTS or modern LTS (verify via 'java -version').",
        "2. Locate Executable File: Find 'SeniorCitizenDigitalTutor.jar' in the project root folder.",
        "3. Launch Method 1 (Direct): Double-click 'SeniorCitizenDigitalTutor.jar'.",
        "4. Launch Method 2 (Terminal): Open Command Prompt or PowerShell and run: java -jar SeniorCitizenDigitalTutor.jar",
        "5. Desktop Application Window: Launches immediately at 1280x800 resolution with zero network setup."
    ]
    add_callout_box(doc, "⚡ QUICK START INSTRUCTIONS (HOW TO RUN IN 30 SECONDS)", quick_start_items, border_color_hex="D6A84F", bg_color_hex=HEX_CREAM)

    # ------------------------------------------------------------------
    # SECTION 1: DISCLAIMER
    # ------------------------------------------------------------------
    h1 = doc.add_heading("1. Important Safety & Educational Disclaimer", level=1)
    h1.style.font.color.rgb = RGB_FOREST
    
    safety_items = [
        "1. ALL SIMULATIONS ARE 100% LOCAL AND VIRTUAL: The mock environments for WhatsApp, Phone Calling, UPI Payments, Google Maps, and Email run entirely within the application. NO REAL MONEY is ever transferred, NO REAL BANK ACCOUNTS are accessed, NO REAL CALLS are made, and NO REAL SMS/EMAILS are dispatched. Senior citizens can practice fearlessly.",
        "2. SCAM CHECKER IS AN EDUCATIONAL AID, NOT AN ORACLE: The 'Is This Safe?' analyzer uses local heuristic pattern matching to detect common deception indicators (urgency, lottery lures, OTP requests, remote access tools). It does NOT guarantee 100% detection of all evolving cyber threats. Always verify directly with trusted family members."
    ]
    add_callout_box(doc, "CRITICAL BOUNDARY GUARANTEES & DISCLAIMER", safety_items, border_color_hex=HEX_DANGER_BOR, bg_color_hex=HEX_DANGER_BG)

    # ------------------------------------------------------------------
    # SECTION 2: HOW TO RUN
    # ------------------------------------------------------------------
    h2 = doc.add_heading("2. How to Run the Application (Complete Beginner Guide)", level=1)
    h2.style.font.color.rgb = RGB_FOREST

    doc.add_heading("Which File Do I Run?", level=2).style.font.color.rgb = RGB_TERRACOTTA
    doc.add_paragraph(
        "Always run SeniorCitizenDigitalTutor.jar located in the project root directory. "
        "Do NOT run .java source code files, database/seniortutor.db, or pom.xml directly."
    )

    doc.add_heading("Execution Methods", level=2).style.font.color.rgb = RGB_TERRACOTTA
    doc.add_paragraph("• Method 1 (Double-Click): Locate SeniorCitizenDigitalTutor.jar and double-click. Opens in 2–4 seconds.")
    doc.add_paragraph("• Method 2 (Command Prompt / PowerShell): Open terminal in project folder and execute: java -jar SeniorCitizenDigitalTutor.jar")
    doc.add_paragraph("• Method 3 (Build from Source with Maven): In terminal, run: .\\mvnw.cmd clean package followed by java -jar target\\SeniorCitizenDigitalTutor.jar")

    doc.add_heading("Troubleshooting: 'The App Won't Open'", level=2).style.font.color.rgb = RGB_TERRACOTTA
    
    t_err = doc.add_table(rows=6, cols=3)
    t_err.alignment = WD_TABLE_ALIGNMENT.CENTER
    headers = ["What You See", "Likely Cause", "Exact Solution"]
    for c_idx, h in enumerate(headers):
        cell = t_err.cell(0, c_idx)
        cell.text = h
        set_cell_background(cell, HEX_FOREST)
        set_cell_margins(cell, 80, 80, 100, 100)
        p = cell.paragraphs[0]
        p.runs[0].font.name = "Segoe UI"
        p.runs[0].font.bold = True
        p.runs[0].font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        p.runs[0].font.size = Pt(9)
        
    err_rows = [
        ("'java' is not recognized", "Java not installed or not in PATH", "Install Java 21 LTS from adoptium.net; verify 'Add to PATH' is checked."),
        ("Double-clicking opens WinRAR / 7-Zip", "Archive utility file association", "Right-click JAR -> Open With -> Java Platform SE Binary, or use terminal command."),
        ("UnsupportedClassVersionError", "Outdated Java runtime (Java 8 or 11) active", "Install Java 21 LTS or modern LTS. JavaFX 21 bytecode requires modern runtime."),
        ("Window opens then closes immediately", "Write permissions missing for database/", "Ensure directory is writable. Run Command Prompt as Administrator if in restricted path."),
        ("No voice audio plays", "PC muted or non-Windows OS", "Check volume slider. Voice uses Windows SAPI; falls back cleanly on other operating systems.")
    ]
    for r_idx, (col0, col1, col2) in enumerate(err_rows, start=1):
        for c_idx, val in enumerate([col0, col1, col2]):
            cell = t_err.cell(r_idx, c_idx)
            cell.text = val
            set_cell_background(cell, HEX_CARD_BG if r_idx % 2 == 1 else "FFFFFF")
            set_cell_margins(cell, 60, 60, 80, 80)
            p = cell.paragraphs[0]
            p.runs[0].font.name = "Segoe UI"
            p.runs[0].font.size = Pt(8.5)
            p.runs[0].font.color.rgb = RGB_CHARCOAL
    
    doc.add_paragraph().paragraph_format.space_after = Pt(8)

    # ------------------------------------------------------------------
    # SECTION 3: PHILOSOPHY
    # ------------------------------------------------------------------
    h3 = doc.add_heading("3. System Overview & Operating Philosophy", level=1)
    h3.style.font.color.rgb = RGB_FOREST
    doc.add_paragraph(
        "The application is built upon the central philosophy: 'Learn technology without fear.' "
        "Every screen, button, and interaction is engineered to emulate the warmth and infinite patience of a loving family member."
    )

    t_phil = doc.add_table(rows=7, cols=2)
    t_phil.alignment = WD_TABLE_ALIGNMENT.CENTER
    phil_heads = ["Traditional Software Pattern (Impatient / Intimidating)", "Senior Citizen Digital Tutor Pattern (Patient / Accessible)"]
    for c_idx, h in enumerate(phil_heads):
        cell = t_phil.cell(0, c_idx)
        cell.text = h
        set_cell_background(cell, HEX_FOREST)
        set_cell_margins(cell, 80, 80, 100, 100)
        p = cell.paragraphs[0]
        p.runs[0].font.name = "Segoe UI"
        p.runs[0].font.bold = True
        p.runs[0].font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        p.runs[0].font.size = Pt(9)

    phil_data = [
        ("Microscopic 12px grey text with low contrast", "Large 16px–22px high-contrast typography in Warm Cream and Forest Green"),
        ("Tiny 30px touch targets prone to accidental mis-clicks", "Minimum 52px rounded touch targets with clear icons and generous padding"),
        ("Fast, jarring animations causing cognitive disorientation", "Calm, static, predictable layouts with smooth subtle transitions"),
        ("One-shot instructions that disappear upon scrolling", "Persistent 'Listen' and unlimited 'Repeat' spoken voice guidance"),
        ("Fear of real financial loss or privacy leakage", "100% sandboxed offline simulations (WhatsApp, UPI, Maps, Phone, Email)"),
        ("Complex multi-field login screens with passwords", "One-click profile switcher between Senior Learner and Family Helper")
    ]
    for r_idx, (col0, col1) in enumerate(phil_data, start=1):
        for c_idx, val in enumerate([col0, col1]):
            cell = t_phil.cell(r_idx, c_idx)
            cell.text = val
            set_cell_background(cell, HEX_CARD_BG if r_idx % 2 == 1 else "FFFFFF")
            set_cell_margins(cell, 60, 60, 80, 80)
            p = cell.paragraphs[0]
            p.runs[0].font.name = "Segoe UI"
            p.runs[0].font.size = Pt(8.5)
            p.runs[0].font.color.rgb = RGB_CHARCOAL
            if c_idx == 1:
                p.runs[0].font.bold = True

    doc.add_paragraph().paragraph_format.space_after = Pt(10)

    # ------------------------------------------------------------------
    # SECTION 4: MASTER FUNCTION MATRIX
    # ------------------------------------------------------------------
    doc.add_page_break()
    h4 = doc.add_heading("4. Master Function Matrix", level=1)
    h4.style.font.color.rgb = RGB_FOREST
    doc.add_paragraph("Comprehensive index of all major and minor interactive functions across the desktop application:")

    matrix_raw = [
        ("Text Sizing (A-)", "Top Bar", "Click 'A-' button", "Decreases interface font scale by 15%", "Saved in settings DB", "Compact view for small screens"),
        ("Text Sizing (A+)", "Top Bar", "Click 'A+' button", "Increases interface font scale by 15%", "Saved in settings DB", "Assists low-vision & presbyopia"),
        ("Voice Toggle", "Top Bar", "Click Voice button", "Toggles automated spoken narration ON/OFF", "Saved in settings DB", "Silence audio in public spaces"),
        ("Profile Switcher", "Top Bar", "Click Profile pill", "Toggles between Senior and Caregiver Helper", "Switches active user state", "Caregiver & elder share workstation"),
        ("Navigation Sidebar", "Left Rail", "Click sidebar tab", "Switches active view (Home, Learn, Practice, etc.)", "None (UI state)", "Uncluttered predictable navigation"),
        ("Search Lessons", "Home Screen", "Type query + Search", "Searches titles, categories, and keywords", "None (UI state)", "Instant access to digital topics"),
        ("Voice Search Prompt", "Home Screen", "Click 'Speak'", "Demonstrates voice query and fills sample", "None (UI state)", "Demonstrates voice interaction"),
        ("Popular Search Chips", "Home Screen", "Click chip (e.g. QR)", "Fills search bar with topic and executes search", "None (UI state)", "One-tap access to frequent topics"),
        ("Clear Search", "Home Screen", "Click 'Clear'", "Dismisses search results card", "None (UI state)", "Maintains clean home dashboard"),
        ("Pinned Lesson Card", "Home Screen", "Click 'Open Lesson'", "Opens lesson assigned by caregiver", "None (Navigates)", "Highlights family priority lesson"),
        ("Resume Lesson", "Home Screen", "Click 'Resume'", "Re-opens unfinished lesson at exact step", "None (Navigates)", "Zero friction returning to study"),
        ("Category Card", "Home / Learn", "Click category card", "Opens full lesson list for chosen category", "None (Navigates)", "Explore curriculum by subject"),
        ("Start / Review Lesson", "Lesson List", "Click action button", "Opens Lesson Engine at Step 1 or last step", "Updates last_step in DB", "Launches step-by-step viewer"),
        ("Listen Instruction", "Lesson Engine", "Click 'Listen'", "Speaks current step instruction aloud via TTS", "None (Audio)", "Auditory reinforcement of text"),
        ("Repeat Instruction", "Lesson Engine", "Click 'Repeat'", "Replays spoken instruction from start", "None (Audio)", "Unlimited patient repetitions"),
        ("Next Step", "Lesson Engine", "Click 'Next Step'", "Advances to next instructional step", "Updates last_step in DB", "Sequential learning progression"),
        ("Previous Step", "Lesson Engine", "Click 'Previous'", "Returns to preceding step", "Updates last_step in DB", "Review earlier steps without reset"),
        ("Practice It Now", "Lesson Engine", "Click 'Practice'", "Launches linked sandbox simulation directly", "None (Navigates)", "Immediate hands-on muscle memory"),
        ("Take Quick Quiz", "Lesson Engine", "Click 'Quiz'", "Launches multiple-choice comprehension check", "None (Navigates)", "Validates retention"),
        ("Complete Lesson", "Lesson Engine", "Click 'Complete'", "Marks lesson completed, plays celebration chime", "Sets completed=1 in DB", "Updates progress & awards badges"),
        ("WhatsApp Chat Send", "Practice Hub", "Type text + Send", "Dispatches chat bubble with blue ticks & reply", "Awards achievement", "Safe messaging practice"),
        ("WhatsApp Photo Send", "Practice Hub", "Click Photo attach", "Sends garden photo bubble + auto-reply", "Awards achievement", "Teaches image attachment flow"),
        ("WhatsApp Location", "Practice Hub", "Click Location attach", "Sends home GPS coordinates bubble + reply", "Awards achievement", "Teaches safe location sharing"),
        ("WhatsApp Voice Note", "Practice Hub", "Click Voice note", "Sends simulated voice clip (0:12) + reply", "Awards achievement", "Teaches voice note recording"),
        ("WhatsApp Video Call", "Practice Hub", "Click Video Call", "Opens full video call screen with live timer", "Awards achievement", "Eliminates fear of video calling"),
        ("End Active Call", "Practice Hub", "Click 'End Call'", "Terminates call and logs call duration", "None (UI state)", "Teaches how to hang up cleanly"),
        ("Phone Dialpad", "Practice Hub", "Click digits (0-9)", "Appends typed digit to large display", "None (UI state)", "Accessible number dialing"),
        ("Phone Backspace", "Practice Hub", "Click backspace", "Deletes last typed digit", "None (UI state)", "Easy mistake correction"),
        ("Family Contact Chip", "Practice Hub", "Click contact chip", "Autofills phone number into dialer", "None (UI state)", "Demonstrates speed dial"),
        ("Speakerphone Toggle", "Practice Hub", "Click Speaker", "Toggles speakerphone mode ON/OFF", "None (UI state)", "Hands-free calling practice"),
        ("UPI QR Scan", "Practice Hub", "Click 'Scan QR'", "Simulates viewfinder scanning grocery QR stand", "None (UI state)", "Teaches counter QR payment flow"),
        ("UPI Amount Input", "Practice Hub", "Type amount or chip", "Sets payment amount (e.g. Rs 150)", "None (UI state)", "Teaches checking amount first"),
        ("UPI PIN Pad", "Practice Hub", "Enter PIN + Pay", "Simulates PIN entry, displays mock receipt", "Awards achievement", "PIN enters ONLY to send money"),
        ("Map Search Chip", "Practice Hub", "Click landmark chip", "Plots blue route line to hospital/chemist", "Awards achievement", "Finding medical care offline"),
        ("Voice Navigation", "Practice Hub", "Click 'Start Voice'", "Speaks turn-by-turn driving/walking prompt", "None (Audio)", "GPS navigation confidence"),
        ("Email Compose", "Practice Hub", "Enter To/Sub/Body", "Dispatches mock email to Sent folder", "Awards achievement", "Formal email practice"),
        ("Scam Analyzer", "Safety Hub", "Enter text + Analyze", "Evaluates message for fraud patterns (0-100)", "Logs check in DB", "Identifies scams & protects money"),
        ("Scam Sample Chip", "Safety Hub", "Click sample chip", "Autofills realistic scam scenario into input", "None (UI state)", "Instant testing of scam types"),
        ("Quiz Option Select", "Quiz View", "Click Option button", "Evaluates answer, shows green/red rationale", "Updates score tally", "Immediate educational feedback"),
        ("Caregiver Recommend", "Family Care", "Select lesson + Note", "Pins lesson banner to senior's home screen", "Saves in DB table", "Caregiver guides elder remotely"),
        ("Emergency Family", "Emergency", "Click 'Call Family'", "Speaks prompt, opens family speed dial dialog", "None (Simulation)", "One-touch reassurance"),
        ("Emergency Ambulance", "Emergency", "Click 'Ambulance'", "Plays alert chime, opens 108 dispatch dialog", "None (Simulation)", "Rapid medical assistance"),
        ("Emergency Police", "Emergency", "Click 'Police'", "Plays alert chime, opens 112 dispatch dialog", "None (Simulation)", "Rapid law enforcement contact"),
        ("High Contrast Toggle", "Settings", "Toggle checkbox", "Switches background to dark charcoal (#121212)", "Saved in settings DB", "Relieves eye strain & cataracts"),
        ("Language Switcher", "Settings", "Choose language", "Updates labels to English, Hindi, or Marathi", "Saved in settings DB", "Mother-tongue accessibility"),
        ("Reset All Progress", "Settings", "Click 'Reset Progress'", "Clears completed lessons, scores, and badges", "Deletes DB rows", "Allows fresh rehearsal"),
    ]

    t_mat = doc.add_table(rows=len(matrix_raw) + 1, cols=6)
    t_mat.alignment = WD_TABLE_ALIGNMENT.CENTER
    mat_heads = ["Function Name", "Location", "User Action", "What It Does", "Persistent Effect", "Purpose"]
    for c_idx, h in enumerate(mat_heads):
        cell = t_mat.cell(0, c_idx)
        cell.text = h
        set_cell_background(cell, HEX_FOREST)
        set_cell_margins(cell, 60, 60, 80, 80)
        p = cell.paragraphs[0]
        p.runs[0].font.name = "Segoe UI"
        p.runs[0].font.bold = True
        p.runs[0].font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        p.runs[0].font.size = Pt(8)

    for r_idx, row in enumerate(matrix_raw, start=1):
        for c_idx, val in enumerate(row):
            cell = t_mat.cell(r_idx, c_idx)
            cell.text = val
            set_cell_background(cell, HEX_CARD_BG if r_idx % 2 == 1 else "FFFFFF")
            set_cell_margins(cell, 40, 40, 60, 60)
            p = cell.paragraphs[0]
            p.runs[0].font.name = "Segoe UI"
            p.runs[0].font.size = Pt(7.5)
            p.runs[0].font.color.rgb = RGB_CHARCOAL
            if c_idx == 0:
                p.runs[0].font.bold = True

    doc.add_paragraph().paragraph_format.space_after = Pt(12)

    # ------------------------------------------------------------------
    # SECTION 5: SCREEN-BY-SCREEN GUIDE WITH EMBEDDED IMAGES
    # ------------------------------------------------------------------
    doc.add_page_break()
    h5 = doc.add_heading("5. Screen-by-Screen Functional Guide", level=1)
    h5.style.font.color.rgb = RGB_FOREST

    screens = [
        ("5.1 Persistent Top Bar & Home Dashboard", "screenshots/01_home_screen.png",
         "The Top Bar remains visible across every screen. Universal controls include A-/A+ font scaling (0.85x to 1.40x), "
         "Voice Tutor toggle, and the profile switcher (Shanti Sharma <-> Anita Sharma). The Home Dashboard provides the 'Teach Me Anything' "
         "natural-language search engine, pinned caregiver recommendations, resume lesson shortcuts, and the 12 curriculum cards."),
        ("5.2 Lesson Engine & Step Viewer", "screenshots/02_lesson_viewer.png",
         "The Lesson Engine guides learners through bite-sized, sequential steps. Features Listen (offline speech) and Repeat buttons, "
         "a visual phone mockup showing exact on-screen highlights, previous/next controls, and direct links to practice simulations or quizzes."),
        ("5.3 Knowledge Check & Quiz Screen", "screenshots/03_quiz_interface.png",
         "Every lesson includes a companion multiple-choice quiz. Selecting an option displays instant green/red rationale cards explaining "
         "why the answer is correct, reinforcing memory without testing anxiety. Quizzes can be retaken infinitely."),
        ("5.4 Safe Practice Sandbox: WhatsApp Messaging & Video Calls", "screenshots/04_practice_whatsapp.png",
         "Simulates realistic texting with daughter Anita. Seniors can practice typing text, sending photos, sharing home GPS locations, "
         "recording voice notes, and answering full-screen video calls with a front-camera timer. All zero-risk and offline."),
        ("5.5 Safe Practice Sandbox: UPI Payments & QR Scanning", "screenshots/05_practice_upi.png",
         "Teaches the crucial digital payment rule: PIN deducts money, never enter PIN to receive money. Includes mock QR viewfinder scanning, "
         "verified merchant details card, rupee amount presets, secret 4-digit PIN pad, and simulated shop soundbox confirmation."),
        ("5.6 Safe Practice Sandbox: Google Maps & Turn-by-Turn Navigation", "screenshots/06_practice_maps.png",
         "Features an offline vector street map with landmark chips (Hospital, Chemist, Milk). Clicking any landmark plots an animated blue route line, "
         "calculates walking distance, displays step-by-step turns, and speaks turn-by-turn driving instructions."),
        ("5.7 Digital Safety Hub & Scam Message Checker", "screenshots/07_safety_checker.png",
         "Presents the 6 Golden Rules of Digital Protection in high-contrast alert styling. Includes the 'Is This Safe?' message analyzer that evaluates "
         "pasted SMS or WhatsApp forwards for fraud patterns, calculating danger scores (0-100) and itemizing detected red flags."),
        ("5.8 Learning Progress Dashboard & Milestone Badges", "screenshots/08_progress_dashboard.png",
         "Tracks lessons completed, active 3-day learning streaks, and quiz accuracy in real time. Also unlocks 8 milestone badges celebrating achievements."),
        ("5.9 Family Caregiver Dashboard", "screenshots/10_family_helper_mode.png",
         "Enables adult children to monitor their elder's progress, analyze identified weak areas, and pin recommended lessons with custom encouraging notes."),
        ("5.10 One-Touch Emergency Assistance", "screenshots/11_emergency_assistance.png",
         "Provides 4 giant high-visibility buttons (Call Family, Ambulance 108, Police 112, Share Location) for panic-free muscle memory training."),
        ("5.11 Settings & Accessibility Customization", "screenshots/12_accessibility_settings.png",
         "Enables full customization: 3 font sizes, High Contrast Mode (deep charcoal #121212 background), Voice Tutor toggles, multilingual support (English, Hindi, Marathi), and emergency number setup.")
    ]

    for title, img_path, desc in screens:
        doc.add_heading(title, level=2).style.font.color.rgb = RGB_TERRACOTTA
        if os.path.exists(img_path):
            doc.add_picture(img_path, width=Inches(6.0))
            p_cap = doc.add_paragraph(f"Figure: {title}")
            p_cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p_cap.runs[0].font.name = "Segoe UI"
            p_cap.runs[0].font.size = Pt(8.5)
            p_cap.runs[0].font.italic = True
            p_cap.runs[0].font.color.rgb = RGB_SAGE
        doc.add_paragraph(desc)
        doc.add_paragraph().paragraph_format.space_after = Pt(8)

    # ------------------------------------------------------------------
    # SECTION 6: COMPLETE WORKFLOWS
    # ------------------------------------------------------------------
    doc.add_page_break()
    h6 = doc.add_heading("6. Complete Operational Workflows", level=1)
    h6.style.font.color.rgb = RGB_FOREST

    workflows = [
        ("Workflow 1: Searching for and Launching a Digital Lesson", [
            "1. From the Home screen, click inside the 'Teach Me Anything' search bar.",
            "2. Type 'How do I make a video call?' and click Search (or tap the 'Video call' chip).",
            "3. The Search Results card appears showing matched lessons.",
            "4. Locate 'How to Make a WhatsApp Video Call' and click Start Lesson ->.",
            "5. The Lesson Engine opens directly at Step 1 with visual phone illustrations."
        ]),
        ("Workflow 2: Completing a Lesson, Voice Narration, and Quiz", [
            "1. In the Lesson Engine, observe STEP 1 OF 4 and the visual smartphone diagram.",
            "2. Click 'Listen' to hear the instruction read aloud via offline speech.",
            "3. Click 'Repeat' to hear the instruction again as many times as desired.",
            "4. Click 'Next Step ->' to advance sequentially through all 4 steps.",
            "5. On the final step, click 'Take Quick Quiz'.",
            "6. Read Question 1 and click option 'B. The video camera icon'.",
            "7. The instant feedback card displays 'Correct! Great Job!' with educational rationale.",
            "8. Click 'See Final Score' to view the 100% score card, then click 'Finish & Back to Lessons'.",
            "9. The lesson is saved as Completed in SQLite and progress updates across the application."
        ]),
        ("Workflow 3: Practicing a Safe UPI Grocery Payment", [
            "1. Click 'Practice' in the left sidebar navigation.",
            "2. Click the 'UPI Payments' simulation card.",
            "3. Read the safety disclaimer: 'Entering your PIN DEDUCTS money...'.",
            "4. Click 'Scan QR Code Now' to simulate scanning the shop's counter stand.",
            "5. Step 2 opens showing verified merchant: 'Sharma Fresh Groceries (Verified Business)'.",
            "6. Type '150' in the amount box (or click the Rs 150 chip) and click 'Proceed to Safe PIN Entry ->'.",
            "7. Step 3 opens showing the secret PIN pad. Enter 1 2 3 4 using the numeric keypad and click Pay.",
            "8. The screen transitions to 'Payment Successful!' with a simulated transaction receipt and soundbox voice confirmation.",
            "9. Click 'Practice Another Payment' to rehearse additional merchant transactions."
        ]),
        ("Workflow 4: Testing a Suspicious Message in the Scam Checker", [
            "1. Click 'Stay Safe' in the left sidebar navigation.",
            "2. Scroll down to the 'Is This Safe?' Educational Message Checker.",
            "3. Click the pre-filled sample chip 'Electricity Threat'.",
            "4. The text box populates with: 'Dear consumer, your electricity will be disconnected tonight at 9:30 PM due to unpaid bill. Call 9876543210...'.",
            "5. Click 'Analyze Message Safety'.",
            "6. The results card renders in high-contrast red: HIGH RISK / DANGER (Score: 70/100).",
            "7. Flags identified: Artificial Panic & Urgency, Unverified Phone Number.",
            "8. Advice: 'Scammers use panic so you don't call family. Genuine electricity boards give written notice. Do not call this number.'"
        ]),
        ("Workflow 5: Caregiver Recommending a Pinned Lesson", [
            "1. In the top-right header, click the profile pill to switch to 'Anita Sharma (HELPER)'.",
            "2. The application navigates automatically to the Family Caregiver Dashboard.",
            "3. Review Shanti Ji's category mastery bars and identified weak areas.",
            "4. In the 'Recommend a Lesson' card, select 'NEVER Share Your UPI PIN - Crucial Rules' from the dropdown.",
            "5. In the note field, type: 'Maa, please review this before our market visit this evening!'.",
            "6. Click 'Send Recommendation'.",
            "7. Switch the profile back to 'Shanti Sharma (SENIOR)'.",
            "8. On the Home screen, observe the new gold-bordered pinned recommendation card prominently displayed at the top of the dashboard."
        ]),
        ("Workflow 6: Adjusting Font Size and High Contrast", [
            "1. In the top-right header bar, click 'A+' twice. Notice all text expands across the screen.",
            "2. Click 'Settings' in the left navigation sidebar.",
            "3. Under Display & Text Size, check 'High Contrast Mode'.",
            "4. The background immediately transitions to deep charcoal (#121212) with high-contrast text, eliminating screen glare.",
            "5. Click 'A-' to scale text down to standard size whenever desired."
        ]),
    ]

    for wf_title, steps in workflows:
        doc.add_heading(wf_title, level=2).style.font.color.rgb = RGB_TERRACOTTA
        for s in steps:
            p = doc.add_paragraph(s)
            p.paragraph_format.space_after = Pt(2)
        doc.add_paragraph().paragraph_format.space_after = Pt(6)

    # ------------------------------------------------------------------
    # SECTION 7: BOUNDARIES
    # ------------------------------------------------------------------
    doc.add_page_break()
    h7 = doc.add_heading("7. Simulation vs. Reality: Sandbox Boundary Guarantees", level=1)
    h7.style.font.color.rgb = RGB_FOREST

    t_bnd = doc.add_table(rows=7, cols=3)
    t_bnd.alignment = WD_TABLE_ALIGNMENT.CENTER
    bnd_heads = ["Feature / Sandbox", "What Is Simulated in the Tutor", "What NEVER Happens (Real World Boundary)"]
    for c_idx, h in enumerate(bnd_heads):
        cell = t_bnd.cell(0, c_idx)
        cell.text = h
        set_cell_background(cell, HEX_FOREST)
        set_cell_margins(cell, 80, 80, 100, 100)
        p = cell.paragraphs[0]
        p.runs[0].font.name = "Segoe UI"
        p.runs[0].font.bold = True
        p.runs[0].font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        p.runs[0].font.size = Pt(8.5)

    bnd_data = [
        ("WhatsApp Messaging", "Chat bubbles, simulated typing, auto-replies, simulated video call overlay with front camera timer.", "Zero cellular or internet packets transmitted. No messages sent to real numbers. No contact list accessed."),
        ("Phone Dialer", "3x4 numeric keypad, large dial display, contact chips, simulated ringing, connected timer, speakerphone.", "No telephony hardware or cellular modem utilized. Zero phone calls placed. Zero carrier charges."),
        ("UPI Payments", "Mock QR viewfinder, merchant name check, amount entry, simulated PIN pad, mock transaction receipt.", "Zero money deducted. No banks, payment gateways, NPCI, or credit accounts touched. Safe practice guaranteed."),
        ("Google Maps", "Offline vector canvas, local landmark chips (Hospital, Chemist), route line calculation, turn-by-turn prompts.", "No GPS hardware queries or Google Maps API calls. No personal location data transmitted externally."),
        ("Email Client", "Mock inbox, composing emails, recipient chips, simulated PDF attachments, dispatched to Sent folder.", "No SMTP/IMAP servers contacted. Zero outbound emails transmitted across the internet."),
        ("Emergency Help", "One-touch speed-dial simulation, ambulance 108 dialog, police 112 dialog, simulated SMS GPS dispatch.", "No live emergency dispatches called. Designed exclusively for panic-free muscle memory training.")
    ]
    for r_idx, (col0, col1, col2) in enumerate(bnd_data, start=1):
        for c_idx, val in enumerate([col0, col1, col2]):
            cell = t_bnd.cell(r_idx, c_idx)
            cell.text = val
            set_cell_background(cell, HEX_CARD_BG if r_idx % 2 == 1 else "FFFFFF")
            set_cell_margins(cell, 60, 60, 80, 80)
            p = cell.paragraphs[0]
            p.runs[0].font.name = "Segoe UI"
            p.runs[0].font.size = Pt(8)
            p.runs[0].font.color.rgb = RGB_CHARCOAL
            if c_idx == 0:
                p.runs[0].font.bold = True

    doc.add_paragraph().paragraph_format.space_after = Pt(12)

    # ------------------------------------------------------------------
    # SECTION 8: PERSISTENCE
    # ------------------------------------------------------------------
    h8 = doc.add_heading("8. Data Persistence & SQLite Storage", level=1)
    h8.style.font.color.rgb = RGB_FOREST
    doc.add_paragraph(
        "All application state is preserved locally in an embedded SQLite 3.45 database file located at database/seniortutor.db. "
        "The schema includes tables for users, categories, lessons, lesson_steps, quiz_questions, quiz_options, user_progress, "
        "achievements, user_achievements, recommendations, safety_logs, and settings. "
        "Progress is committed immediately upon action, ensuring 100% offline persistence across application restarts."
    )

    # ------------------------------------------------------------------
    # SECTION 9: TROUBLESHOOTING & FAQ
    # ------------------------------------------------------------------
    doc.add_page_break()
    h9 = doc.add_heading("9. Comprehensive Troubleshooting Guide", level=1)
    h9.style.font.color.rgb = RGB_FOREST
    
    issues = [
        ("Issue 1: The application does not open when double-clicking the JAR file.",
         "Windows has associated .jar files with an archive utility (like WinRAR or 7-Zip), or Java is not installed in your PATH.\n"
         "Resolution: Open Command Prompt, navigate to the folder, and execute: java -jar SeniorCitizenDigitalTutor.jar. If Java is missing, install Java 21 LTS from adoptium.net."),
        ("Issue 2: Spoken voice audio does not play when clicking Listen or Repeat.",
         "Voice Tutor is toggled off, PC volume is muted, or the app is running on Linux/macOS.\n"
         "Resolution: Check the top header bar to ensure it displays 'Voice ON'. Check PC speaker volume. Speech uses local Windows SAPI; on macOS/Linux it gracefully falls back to visual step prompts and tone chimes."),
        ("Issue 3: I answered a quiz question incorrectly. Can I retake the quiz?",
         "User selected an incorrect answer option.\n"
         "Resolution: Complete the remaining quiz questions. On the final score card, click 'Retake Quiz'. The quiz resets to Question 1 immediately with zero penalties."),
        ("Issue 4: How do I switch between the Senior citizen view and Caregiver view?",
         "Caregiver wants to review progress and assign lessons.\n"
         "Resolution: Click the profile pill in the top-right corner ('Shanti Sharma (SENIOR)'). It instantly toggles to 'Anita Sharma (HELPER)' and opens the Caregiver Dashboard. Click it again to return."),
        ("Issue 5: How do I start all lessons from scratch?",
         "User wants to reset all progress for a new learner.\n"
         "Resolution: Click 'Settings' in the left navigation sidebar. Scroll to the bottom card labeled 'Reset Learning Progress' and click 'Reset All Progress'. All completed lessons, quiz scores, and badges will be reset.")
    ]
    for issue_title, issue_desc in issues:
        doc.add_heading(issue_title, level=2).style.font.color.rgb = RGB_TERRACOTTA
        doc.add_paragraph(issue_desc)

    h10 = doc.add_heading("10. Frequently Asked Questions (FAQ)", level=1)
    h10.style.font.color.rgb = RGB_FOREST
    
    faqs = [
        ("Q: Does this application require an active internet connection?",
         "A: No. The Senior Citizen Digital Tutor is an offline-first desktop application. All lessons, practice simulations, scam pattern evaluations, voice synthesis, and database operations run 100% locally on your computer with zero internet connectivity required."),
        ("Q: Can my real bank account lose money if I make a mistake in the UPI simulation?",
         "A: Absolutely not. The UPI simulation is an isolated, mock educational environment. It does not connect to any bank, payment gateway, or the internet. No real money can ever be transferred."),
        ("Q: Can I install this on a Windows tablet or touchscreen laptop?",
         "A: Yes. The application is optimized for standard 1280x800 desktop and tablet resolutions. All buttons feature generous 52px+ touch targets supporting both mouse clicks and touchscreen taps."),
        ("Q: Where are my learning records stored?",
         "A: All progress, scores, and settings are stored locally in an embedded file at database/seniortutor.db inside your project directory. No user data is ever sent to external cloud servers."),
        ("Q: Does the scam checker guarantee that a message is 100% safe?",
         "A: No software can guarantee 100% fraud detection. The 'Is This Safe?' tool is an educational analyzer that searches for known high-risk scam patterns to train elders in vigilance. Always consult a trusted family member if in doubt."),
        ("Q: Which languages are supported?",
         "A: The application supports English, Hindi, and Marathi. You can switch languages at any time from the Settings screen.")
    ]
    for q, a in faqs:
        doc.add_heading(q, level=2).style.font.color.rgb = RGB_TERRACOTTA
        doc.add_paragraph(a)

    # Save document
    docx_filename = "PROJECT_USER_MANUAL.docx"
    doc.save(docx_filename)
    print(f"DOCX build completed successfully: {docx_filename}")

if __name__ == "__main__":
    generate_docx()
