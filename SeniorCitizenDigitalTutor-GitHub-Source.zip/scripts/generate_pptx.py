import os
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

# Distinctive Palette
WARM_CREAM = RGBColor(0xF3, 0xED, 0xE2)
FOREST_GREEN = RGBColor(0x17, 0x3F, 0x35)
SOFT_SAGE = RGBColor(0x6F, 0x80, 0x68)
TERRACOTTA = RGBColor(0xC9, 0x78, 0x55)
MUTED_GOLD = RGBColor(0xD6, 0xA8, 0x4F)
CHARCOAL = RGBColor(0x24, 0x24, 0x24)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
blank_layout = prs.slide_layouts[6]

def set_slide_background(slide, color):
    bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid()
    bg.fill.fore_color.rgb = color
    bg.line.fill.background()
    return bg

def add_header(slide, title_text, category_text="SENIOR CITIZEN DIGITAL TUTOR"):
    # Category / Tagline
    tag_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.5), Inches(11), Inches(0.4))
    tf_tag = tag_box.text_frame
    tf_tag.word_wrap = True
    p_tag = tf_tag.paragraphs[0]
    p_tag.text = category_text.upper()
    p_tag.font.size = Pt(11)
    p_tag.font.bold = True
    p_tag.font.color.rgb = TERRACOTTA

    # Slide Title
    title_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.85), Inches(11.5), Inches(0.8))
    tf_title = title_box.text_frame
    tf_title.word_wrap = True
    p_title = tf_title.paragraphs[0]
    p_title.text = title_text
    p_title.font.size = Pt(26)
    p_title.font.bold = True
    p_title.font.color.rgb = FOREST_GREEN

def add_card(slide, left, top, width, height, bg_color=WHITE, border_color=SOFT_SAGE):
    card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
    card.fill.solid()
    card.fill.fore_color.rgb = bg_color
    if border_color:
        card.line.color.rgb = border_color
        card.line.width = Pt(1.5)
    else:
        card.line.fill.background()
    return card

# ==========================================
# SLIDE 1: TITLE SLIDE
# ==========================================
s1 = prs.slides.add_slide(blank_layout)
set_slide_background(s1, FOREST_GREEN)

# Decorative Gold Accent Bar
accent = s1.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(1.8), Inches(1.2), Inches(0.1))
accent.fill.solid()
accent.fill.fore_color.rgb = MUTED_GOLD
accent.line.fill.background()

# Title text
tb1 = s1.shapes.add_textbox(Inches(0.8), Inches(2.1), Inches(11.5), Inches(2.2))
tf1 = tb1.text_frame
tf1.word_wrap = True
p1 = tf1.paragraphs[0]
p1.text = "Senior Citizen Digital Tutor"
p1.font.size = Pt(44)
p1.font.bold = True
p1.font.color.rgb = WARM_CREAM

p1_sub = tf1.add_paragraph()
p1_sub.text = "\"Learn. Practice. Use. Stay Connected.\""
p1_sub.font.size = Pt(22)
p1_sub.font.italic = True
p1_sub.font.color.rgb = MUTED_GOLD
p1_sub.space_before = Pt(12)

# Subtitle / Details Card
meta_card = add_card(s1, Inches(0.8), Inches(4.8), Inches(11.7), Inches(1.8), WARM_CREAM, None)
tb_meta = s1.shapes.add_textbox(Inches(1.0), Inches(5.0), Inches(11.3), Inches(1.4))
tf_m = tb_meta.text_frame
p_m1 = tf_m.paragraphs[0]
p_m1.text = "A Standalone Desktop Literacy & Safety Tutor for Elders  |  College Mini-Project Viva Presentation"
p_m1.font.size = Pt(16)
p_m1.font.bold = True
p_m1.font.color.rgb = FOREST_GREEN

p_m2 = tf_m.add_paragraph()
p_m2.text = "Technology Stack: Java 21+ • JavaFX • SQLite • JDBC • Maven • Offline Voice Synthesis"
p_m2.font.size = Pt(14)
p_m2.font.color.rgb = CHARCOAL
p_m2.space_before = Pt(6)

p_m3 = tf_m.add_paragraph()
p_m3.text = "Guiding Philosophy: \"Learn technology without fear — like a patient family member.\""
p_m3.font.size = Pt(13)
p_m3.font.italic = True
p_m3.font.color.rgb = TERRACOTTA
p_m3.space_before = Pt(6)

# ==========================================
# SLIDE 2: PROBLEM STATEMENT
# ==========================================
s2 = prs.slides.add_slide(blank_layout)
set_slide_background(s2, WARM_CREAM)
add_header(s2, "Problem Statement: The Senior Digital Divide")

# 3 Column Cards
c_w = Inches(3.6)
c_h = Inches(4.8)
col_y = Inches(1.8)

# Card 1: UI Inaccessibility
add_card(s2, Inches(0.8), col_y, c_w, c_h)
tb_c1 = s2.shapes.add_textbox(Inches(1.0), col_y + Inches(0.2), c_w - Inches(0.4), c_h - Inches(0.4))
tf_c1 = tb_c1.text_frame
tf_c1.word_wrap = True
tf_c1.paragraphs[0].text = "📱 Hostile Interface Complexity"
tf_c1.paragraphs[0].font.size = Pt(18)
tf_c1.paragraphs[0].font.bold = True
tf_c1.paragraphs[0].font.color.rgb = FOREST_GREEN

bullet_points_1 = [
    "Tiny fonts and microscopic touch targets causing frequent accidental taps.",
    "Fast-paced transitions that overwhelm seniors with mild visual or motor limitations.",
    "Digital jargon (OTP, QR, Cache, Cloud, Sync) with zero contextual explanation."
]
for bp in bullet_points_1:
    p = tf_c1.add_paragraph()
    p.text = "• " + bp
    p.font.size = Pt(14)
    p.font.color.rgb = CHARCOAL
    p.space_before = Pt(12)

# Card 2: Fear of Mistakes
add_card(s2, Inches(4.8), col_y, c_w, c_h)
tb_c2 = s2.shapes.add_textbox(Inches(5.0), col_y + Inches(0.2), c_w - Inches(0.4), c_h - Inches(0.4))
tf_c2 = tb_c2.text_frame
tf_c2.word_wrap = True
tf_c2.paragraphs[0].text = "😨 The Paralysis of Fear"
tf_c2.paragraphs[0].font.size = Pt(18)
tf_c2.paragraphs[0].font.bold = True
tf_c2.paragraphs[0].font.color.rgb = TERRACOTTA

bullet_points_2 = [
    "Constant anxiety of losing bank savings, sending wrong texts, or deleting important files.",
    "Reluctance to ask busy children repeatedly for the same simple smartphone tasks.",
    "Feelings of dependency and isolation in an increasingly cashless, digital society."
]
for bp in bullet_points_2:
    p = tf_c2.add_paragraph()
    p.text = "• " + bp
    p.font.size = Pt(14)
    p.font.color.rgb = CHARCOAL
    p.space_before = Pt(12)

# Card 3: Cyber Fraud Epidemic
add_card(s2, Inches(8.8), col_y, c_w, c_h)
tb_c3 = s2.shapes.add_textbox(Inches(9.0), col_y + Inches(0.2), c_w - Inches(0.4), c_h - Inches(0.4))
tf_c3 = tb_c3.text_frame
tf_c3.word_wrap = True
tf_c3.paragraphs[0].text = "🚨 Rampant Cyber Predators"
tf_c3.paragraphs[0].font.size = Pt(18)
tf_c3.paragraphs[0].font.bold = True
tf_c3.paragraphs[0].font.color.rgb = RGBColor(0x99, 0x1B, 0x1B)

bullet_points_3 = [
    "Seniors are prime targets for fake electricity bill cuts, KYC scams, and lottery fraud.",
    "Lack of sandboxed practice environments to learn without risking real money.",
    "Need for an educational scam analyzer that explains fraud warning signs in plain language."
]
for bp in bullet_points_3:
    p = tf_c3.add_paragraph()
    p.text = "• " + bp
    p.font.size = Pt(14)
    p.font.color.rgb = CHARCOAL
    p.space_before = Pt(12)

# ==========================================
# SLIDE 3: MOTIVATION & CORE PHILOSOPHY
# ==========================================
s3 = prs.slides.add_slide(blank_layout)
set_slide_background(s3, WARM_CREAM)
add_header(s3, "Motivation: \"Learn Technology Without Fear\"")

left_card = add_card(s3, Inches(0.8), Inches(1.8), Inches(5.6), Inches(4.8), WHITE, FOREST_GREEN)
tb_lc = s3.shapes.add_textbox(Inches(1.1), Inches(2.0), Inches(5.0), Inches(4.4))
tf_lc = tb_lc.text_frame
tf_lc.word_wrap = True
tf_lc.paragraphs[0].text = "🌿 The Patient Family Member Metaphor"
tf_lc.paragraphs[0].font.size = Pt(20)
tf_lc.paragraphs[0].font.bold = True
tf_lc.paragraphs[0].font.color.rgb = FOREST_GREEN

phil_points = [
    ("Zero Pressure & Unlimited Repetition", "Seniors can tap 'Repeat' audio and review steps as many times as they wish without feeling embarrassed."),
    ("Safe Practice Sandboxes", "Realistic interactive simulations of WhatsApp, UPI, and Phone dialer where no real money is ever transferred."),
    ("Accessible Ergonomics", "Giant touch targets (>50px), high-contrast warm palette, large sans-serif typography, and offline spoken voice instructions."),
    ("Intergenerational Harmony", "Enables adult children to recommend lessons and celebrate progress together without friction.")
]
for title_p, desc_p in phil_points:
    p = tf_lc.add_paragraph()
    p.text = "• " + title_p + ": " + desc_p
    p.font.size = Pt(13)
    p.font.color.rgb = CHARCOAL
    p.space_before = Pt(10)

# Right Banner with Core Tenets
right_card = add_card(s3, Inches(6.8), Inches(1.8), Inches(5.7), Inches(4.8), FOREST_GREEN, None)
tb_rc = s3.shapes.add_textbox(Inches(7.1), Inches(2.1), Inches(5.1), Inches(4.2))
tf_rc = tb_rc.text_frame
tf_rc.word_wrap = True
tf_rc.paragraphs[0].text = "💡 What Senior Tutor Is NOT vs IS"
tf_rc.paragraphs[0].font.size = Pt(20)
tf_rc.paragraphs[0].font.bold = True
tf_rc.paragraphs[0].font.color.rgb = MUTED_GOLD

contrasts = [
    ("❌ NOT a generic school LMS", "No intimidating deadlines, complex grades, or academic tests."),
    ("✅ An empathetic digital companion", "Warm, calm editorial design, encouraging celebrations, and gentle guidance."),
    ("❌ NOT a cloud dependent web-app", "Works 100% standalone and offline on desktop with local SQLite database."),
    ("✅ Privacy-first & Zero External APIs", "No credit cards, zero telemetry, local rule-based safety evaluation.")
]
for c_title, c_desc in contrasts:
    p = tf_rc.add_paragraph()
    p.text = c_title + "\n   " + c_desc
    p.font.size = Pt(14)
    p.font.color.rgb = WARM_CREAM
    p.space_before = Pt(12)

# ==========================================
# SLIDE 4: PROPOSED SOLUTION
# ==========================================
s4 = prs.slides.add_slide(blank_layout)
set_slide_background(s4, WARM_CREAM)
add_header(s4, "Proposed Solution: Comprehensive 4-Pillar Model")

pillars = [
    ("1. LEARN", "Step-by-step visual lesson engine with offline spoken voice guidance and interactive illustrations.", MUTED_GOLD),
    ("2. PRACTICE", "5 safe sandboxed simulations (WhatsApp, UPI, Phone, Maps, Email) with zero risk.", TERRACOTTA),
    ("3. STAY SAFE", "Educational scam detection engine, 6 Golden Safety Rules, and message analyzer.", FOREST_GREEN),
    ("4. STAY CONNECTED", "One-touch emergency help, family caregiver monitoring, and multilingual support.", SOFT_SAGE)
]

for i, (p_title, p_desc, p_color) in enumerate(pillars):
    card_x = Inches(0.8 + i * 2.95)
    add_card(s4, card_x, Inches(1.8), Inches(2.8), Inches(4.8), WHITE, p_color)
    tb_p = s4.shapes.add_textbox(card_x + Inches(0.2), Inches(2.0), Inches(2.4), Inches(4.4))
    tf_p = tb_p.text_frame
    tf_p.word_wrap = True
    tf_p.paragraphs[0].text = p_title
    tf_p.paragraphs[0].font.size = Pt(18)
    tf_p.paragraphs[0].font.bold = True
    tf_p.paragraphs[0].font.color.rgb = p_color

    p_body = tf_p.add_paragraph()
    p_body.text = p_desc
    p_body.font.size = Pt(14)
    p_body.font.color.rgb = CHARCOAL
    p_body.space_before = Pt(14)

# ==========================================
# SLIDE 5: 12 CURRICULUM CATEGORIES
# ==========================================
s5 = prs.slides.add_slide(blank_layout)
set_slide_background(s5, WARM_CREAM)
add_header(s5, "Full 12-Category Digital Literacy Curriculum")

cat_data = [
    ("📱 Smartphone Basics", "Power on/off, volume, lock screen, Wi-Fi, notifications"),
    ("📞 Calling & Contacts", "Dialer, saving family, speakerphone, blocking spam"),
    ("💬 WhatsApp Mastery", "Chats, voice notes, photos, live video calls"),
    ("📸 Camera & Gallery", "Steady shots, front selfie, finding photos in albums"),
    ("🌐 Safe Internet", "Google voice search, YouTube videos, avoiding popups"),
    ("🗺️ Google Maps", "Finding nearby hospitals, chemist shops, voice GPS"),
    ("💳 Digital Payments", "UPI basics, scanning QR codes, PIN protection"),
    ("🏦 Banking Safety", "SMS balance alerts, ATM security, spotting fake SMS"),
    ("🛒 Online Services", "Cab booking simulation, grocery delivery, tracking"),
    ("📧 Email Communication", "Composing Gmail, attaching reports, spotting phishing"),
    ("🔐 Digital Safety", "6 Golden Rules, fake lottery, electricity cut scams"),
    ("🆘 Emergency Help", "One-touch 112, 108 ambulance, family speed dial")
]

for idx, (c_name, c_sub) in enumerate(cat_data):
    r = idx // 3
    c = idx % 3
    bx = Inches(0.8 + c * 3.9)
    by = Inches(1.8 + r * 1.25)
    add_card(s5, bx, by, Inches(3.7), Inches(1.1), WHITE, None)

    tb = s5.shapes.add_textbox(bx + Inches(0.15), by + Inches(0.1), Inches(3.4), Inches(0.9))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.paragraphs[0].text = c_name
    tf.paragraphs[0].font.size = Pt(15)
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].font.color.rgb = FOREST_GREEN

    p = tf.add_paragraph()
    p.text = c_sub
    p.font.size = Pt(11)
    p.font.color.rgb = CHARCOAL

# ==========================================
# SLIDE 6: LESSON ENGINE ARCHITECTURE
# ==========================================
s6 = prs.slides.add_slide(blank_layout)
set_slide_background(s6, WARM_CREAM)
add_header(s6, "Reusable Lesson Engine & Voice Tutor")

add_card(s6, Inches(0.8), Inches(1.8), Inches(5.6), Inches(4.8), WHITE, FOREST_GREEN)
tb_l1 = s6.shapes.add_textbox(Inches(1.0), Inches(2.0), Inches(5.2), Inches(4.4))
tf_l1 = tb_l1.text_frame
tf_l1.word_wrap = True
tf_l1.paragraphs[0].text = "⚙️ Interactive Lesson Workflow"
tf_l1.paragraphs[0].font.size = Pt(19)
tf_l1.paragraphs[0].font.bold = True
tf_l1.paragraphs[0].font.color.rgb = FOREST_GREEN

steps_desc = [
    ("Step 1: Step Counter & Progress Bar", "Visual progress bar showing exact position (e.g., Step 2 of 4) so users know they are close to finishing."),
    ("Step 2: Visual UI Representation", "Dynamic illustration node displaying phone screens, highlighted buttons, QR targets, or warning boxes."),
    ("Step 3: Offline Spoken Voice Guidance", "Integrated Windows Speech SAPI speaks instructions aloud at a gentle, comfortable pace."),
    ("Step 4: Repetition & Autonomy", "Giant 'Listen' and 'Repeat' buttons give users unlimited attempts with no pressure."),
    ("Step 5: Completion Triggers", "Seamlessly redirects to Practice Sandbox, Knowledge Quiz, and updates SQLite progress.")
]
for st_t, st_d in steps_desc:
    p = tf_l1.add_paragraph()
    p.text = "• " + st_t + "\n   " + st_d
    p.font.size = Pt(12)
    p.font.color.rgb = CHARCOAL
    p.space_before = Pt(8)

# Embed Lesson Screenshot on Right
if os.path.exists("screenshots/02_lesson_viewer.png"):
    s6.shapes.add_picture("screenshots/02_lesson_viewer.png", Inches(6.8), Inches(1.8), Inches(5.7), Inches(4.8))

# ==========================================
# SLIDE 7: SAFE PRACTICE SIMULATIONS
# ==========================================
s7 = prs.slides.add_slide(blank_layout)
set_slide_background(s7, WARM_CREAM)
add_header(s7, "Safe Practice Sandboxes: 5 Realistic Simulations")

sim_details = [
    ("💬 WhatsApp", "Text messages with double checkmarks, voice note audio simulation, photo picker, and full simulated video calling with call timer."),
    ("📞 Phone Dialer", "Accessible 3x4 keypad, autofill family contacts, active call screen with live duration, and speakerphone toggle."),
    ("💳 UPI Payments", "Simulated QR camera scan, verified merchant verification, safety warning box, mock PIN pad, and audio soundbox receipt."),
    ("🗺️ Google Maps", "Interactive offline map canvas, hospitals and pharmacy pins, route drawing, and spoken turn-by-turn voice navigation."),
    ("📧 Email Client", "Compose interface, family contact autofill, PDF attachment chip, sent folder, and received inbox messages.")
]

for idx, (sim_n, sim_d) in enumerate(sim_details):
    by = Inches(1.8 + idx * 0.98)
    add_card(s7, Inches(0.8), by, Inches(5.6), Inches(0.88), WHITE, MUTED_GOLD)
    tb = s7.shapes.add_textbox(Inches(1.0), by + Inches(0.08), Inches(5.2), Inches(0.72))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.paragraphs[0].text = sim_n
    tf.paragraphs[0].font.size = Pt(15)
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].font.color.rgb = FOREST_GREEN

    p = tf.add_paragraph()
    p.text = sim_d
    p.font.size = Pt(11)
    p.font.color.rgb = CHARCOAL

# Embed UPI Simulation Screenshot on Right
if os.path.exists("screenshots/05_practice_upi.png"):
    s7.shapes.add_picture("screenshots/05_practice_upi.png", Inches(6.8), Inches(1.8), Inches(5.7), Inches(4.8))

# ==========================================
# SLIDE 8: DIGITAL SAFETY & "IS THIS SAFE?"
# ==========================================
s8 = prs.slides.add_slide(blank_layout)
set_slide_background(s8, WARM_CREAM)
add_header(s8, "Digital Safety & \"Is This Safe?\" Scam Checker")

add_card(s8, Inches(0.8), Inches(1.8), Inches(5.6), Inches(4.8), WHITE, RGBColor(0xDC, 0x26, 0x26))
tb_s = s8.shapes.add_textbox(Inches(1.0), Inches(2.0), Inches(5.2), Inches(4.4))
tf_s = tb_s.text_frame
tf_s.word_wrap = True
tf_s.paragraphs[0].text = "🛡️ Educational Rule-Based Analyzer"
tf_s.paragraphs[0].font.size = Pt(19)
tf_s.paragraphs[0].font.bold = True
tf_s.paragraphs[0].font.color.rgb = RGBColor(0x99, 0x1B, 0x1B)

safety_bullets = [
    ("Local Pattern Matching Engine", "Evaluates keywords: OTP, UPI PIN, prize, lottery, urgent, power cut, KYC, AnyDesk, bit.ly, and TeamViewer without sending data to the cloud."),
    ("Granular Risk Classifications", "Categorizes messages into HIGH RISK (🔴), POSSIBLY SUSPICIOUS (🟡), or APPEARS SAFE (🟢) with a 0-100 danger score."),
    ("Clear Human Explanations", "Itemizes exact warning signs (e.g. 'Artificial Urgency', 'Requests Secret OTP', 'Remote Screen Sharing Tool')."),
    ("Prescriptive Actionable Advice", "Gives concrete next steps: 'Hang up caller', 'Never enter PIN', 'Verify with family or official branch'.")
]
for sb_t, sb_d in safety_bullets:
    p = tf_s.add_paragraph()
    p.text = "• " + sb_t + "\n   " + sb_d
    p.font.size = Pt(12)
    p.font.color.rgb = CHARCOAL
    p.space_before = Pt(8)

# Embed Safety Screenshot on Right
if os.path.exists("screenshots/07_safety_checker.png"):
    s8.shapes.add_picture("screenshots/07_safety_checker.png", Inches(6.8), Inches(1.8), Inches(5.7), Inches(4.8))

# ==========================================
# SLIDE 9: QUIZ & PROGRESS TRACKING
# ==========================================
s9 = prs.slides.add_slide(blank_layout)
set_slide_background(s9, WARM_CREAM)
add_header(s9, "Knowledge Retention: Quizzes & Achievements")

add_card(s9, Inches(0.8), Inches(1.8), Inches(5.6), Inches(4.8), WHITE, MUTED_GOLD)
tb_q = s9.shapes.add_textbox(Inches(1.0), Inches(2.0), Inches(5.2), Inches(4.4))
tf_q = tb_q.text_frame
tf_q.word_wrap = True
tf_q.paragraphs[0].text = "🎯 Reinforcement Architecture"
tf_q.paragraphs[0].font.size = Pt(19)
tf_q.paragraphs[0].font.bold = True
tf_q.paragraphs[0].font.color.rgb = FOREST_GREEN

quiz_points = [
    ("Senior-Friendly Quiz Questions", "Single question per screen with large touch-friendly buttons (A, B, C, D) and immediate encouraging feedback."),
    ("Instant Explanation", "Explains WHY an answer is correct or incorrect so learners build mental models, not rote memorization."),
    ("Learning Streak Tracking", "Counts consecutive learning days with a flame icon to motivate regular practice."),
    ("8 Unlockable Achievement Badges", "Milestones like 'First Steps', 'WhatsApp Explorer', 'Safety Champion', 'Quiz Champion', and 'Tech Champion' automatically unlock with fanfare.")
]
for q_t, q_d in quiz_points:
    p = tf_q.add_paragraph()
    p.text = "• " + q_t + "\n   " + q_d
    p.font.size = Pt(12)
    p.font.color.rgb = CHARCOAL
    p.space_before = Pt(10)

if os.path.exists("screenshots/08_progress_dashboard.png"):
    s9.shapes.add_picture("screenshots/08_progress_dashboard.png", Inches(6.8), Inches(1.8), Inches(5.7), Inches(4.8))

# ==========================================
# SLIDE 10: FAMILY / HELPER MODE
# ==========================================
s10 = prs.slides.add_slide(blank_layout)
set_slide_background(s10, WARM_CREAM)
add_header(s10, "Family Caregiver Dashboard & Recommendations")

add_card(s10, Inches(0.8), Inches(1.8), Inches(5.6), Inches(4.8), WHITE, FOREST_GREEN)
tb_fam = s10.shapes.add_textbox(Inches(1.0), Inches(2.0), Inches(5.2), Inches(4.4))
tf_fam = tb_fam.text_frame
tf_fam.word_wrap = True
tf_fam.paragraphs[0].text = "👨‍👩‍👧 Empowering the Caregiver"
tf_fam.paragraphs[0].font.size = Pt(19)
tf_fam.paragraphs[0].font.bold = True
tf_fam.paragraphs[0].font.color.rgb = FOREST_GREEN

fam_bullets = [
    ("Senior Performance Visibility", "Daughter/Son can review category completion percentages, quiz scores, and practice frequency."),
    ("Weak Topic Identification", "Automatically highlights high-risk areas needing review, such as UPI PIN Protection or Fake Call Avoidance."),
    ("Interpersonal Lesson Recommender", "Helper selects a lesson and attaches a personalized note ('Maa, please review this before our shopping trip!')."),
    ("Pinned Home Banner", "Recommendations appear pinned with high prominence on the senior's home dashboard upon launch.")
]
for fb_t, fb_d in fam_bullets:
    p = tf_fam.add_paragraph()
    p.text = "• " + fb_t + "\n   " + fb_d
    p.font.size = Pt(12)
    p.font.color.rgb = CHARCOAL
    p.space_before = Pt(10)

if os.path.exists("screenshots/10_family_helper_mode.png"):
    s10.shapes.add_picture("screenshots/10_family_helper_mode.png", Inches(6.8), Inches(1.8), Inches(5.7), Inches(4.8))

# ==========================================
# SLIDE 11: EMERGENCY ASSISTANCE & ACCESSIBILITY
# ==========================================
s11 = prs.slides.add_slide(blank_layout)
set_slide_background(s11, WARM_CREAM)
add_header(s11, "Emergency Assistance & Inclusive Ergonomics")

# Left Column: Emergency Help
add_card(s11, Inches(0.8), Inches(1.8), Inches(5.6), Inches(4.8), WHITE, TERRACOTTA)
tb_em = s11.shapes.add_textbox(Inches(1.0), Inches(2.0), Inches(5.2), Inches(4.4))
tf_em = tb_em.text_frame
tf_em.word_wrap = True
tf_em.paragraphs[0].text = "🆘 One-Touch Emergency Readiness"
tf_em.paragraphs[0].font.size = Pt(19)
tf_em.paragraphs[0].font.bold = True
tf_em.paragraphs[0].font.color.rgb = TERRACOTTA

em_points = [
    ("👨‍👩‍👧 Call Family", "Instant one-tap simulated dialing of primary caregiver with speakerphone alert."),
    ("🚑 Medical Ambulance (108)", "One-touch access to government paramedic and emergency dispatch."),
    ("🚓 Police Helpline (112)", "National unified emergency helpline simulation."),
    ("📍 Share GPS Location", "Instant simulated dispatch of home GPS coordinates to family contacts via SMS.")
]
for ep_t, ep_d in em_points:
    p = tf_em.add_paragraph()
    p.text = "• " + ep_t + ": " + ep_d
    p.font.size = Pt(12)
    p.font.color.rgb = CHARCOAL
    p.space_before = Pt(8)

# Right Column: Accessibility
add_card(s11, Inches(6.8), Inches(1.8), Inches(5.7), Inches(4.8), WHITE, FOREST_GREEN)
tb_acc = s11.shapes.add_textbox(Inches(7.0), Inches(2.0), Inches(5.3), Inches(4.4))
tf_acc = tb_acc.text_frame
tf_acc.word_wrap = True
tf_acc.paragraphs[0].text = "♿ Accessible By Design"
tf_acc.paragraphs[0].font.size = Pt(19)
tf_acc.paragraphs[0].font.bold = True
tf_acc.paragraphs[0].font.color.rgb = FOREST_GREEN

acc_points = [
    ("Font Scale Multiplier", "Instant A- / A+ scaling supporting 16px, 18px, and 22px text sizing across all views."),
    ("High Contrast Dark Mode", "High legibility dark contrast option for seniors with cataracts or low vision."),
    ("Voice Tutor Toggle", "Instant voice activation/deactivation from persistent top navigation bar."),
    ("Multilingual Support", "Localized interfaces in English, Hindi (हिंदी), and Marathi (मराठी)."),
    ("Tactile Audio Cues", "Synthesized acoustic chimes for button clicks, successes, and warnings.")
]
for ap_t, ap_d in acc_points:
    p = tf_acc.add_paragraph()
    p.text = "• " + ap_t + ": " + ap_d
    p.font.size = Pt(12)
    p.font.color.rgb = CHARCOAL
    p.space_before = Pt(8)

# ==========================================
# SLIDE 12: SYSTEM ARCHITECTURE
# ==========================================
s12 = prs.slides.add_slide(blank_layout)
set_slide_background(s12, WARM_CREAM)
add_header(s12, "System Architecture: Clean MVC & Offline-First")

arch_blocks = [
    ("1. PRESENTATION (JavaFX)", "MainLayout, NavigationBar, HomeView, LessonDetailView, PracticeHubView, SafetyHubView, ProgressView, FamilyCareView, EmergencyHelpView, SettingsView", FOREST_GREEN),
    ("2. BUSINESS LOGIC & SERVICES", "LessonService, QuizService, ProgressService, SafetyCheckerService, SearchService, FamilyHelperService, LocalizationService, WindowsSpeechService", TERRACOTTA),
    ("3. REPOSITORIES & DATA ACCESS", "CategoryRepository, LessonRepository, ProgressRepository, QuizRepository, AchievementRepository, SettingsRepository, UserRepository, RecommendationRepository", SOFT_SAGE),
    ("4. DATABASE & PERSISTENCE (SQLite)", "SQLite DB Engine via JDBC: users, categories, lessons, lesson_steps, quiz_questions, quiz_options, user_progress, achievements, safety_logs, settings", MUTED_GOLD)
]

for idx, (b_title, b_desc, b_color) in enumerate(arch_blocks):
    by = Inches(1.8 + idx * 1.25)
    add_card(s12, Inches(0.8), by, Inches(11.7), Inches(1.1), WHITE, b_color)
    tb = s12.shapes.add_textbox(Inches(1.0), by + Inches(0.12), Inches(11.3), Inches(0.9))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.paragraphs[0].text = b_title
    tf.paragraphs[0].font.size = Pt(16)
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].font.color.rgb = b_color

    p = tf.add_paragraph()
    p.text = b_desc
    p.font.size = Pt(12)
    p.font.color.rgb = CHARCOAL
    p.space_before = Pt(4)

# ==========================================
# SLIDE 13: TECHNOLOGY STACK & HIGHLIGHTS
# ==========================================
s13 = prs.slides.add_slide(blank_layout)
set_slide_background(s13, WARM_CREAM)
add_header(s13, "Technology Stack & Engineering Highlights")

tech_cards = [
    ("☕ Java 21+ LTS", "Strong typing, modern record-like patterns, modular architecture, and high performance."),
    ("🎨 OpenJFX 21", "Pure JavaFX desktop UI without any webview, HTML/JS, or Electron bloat. 60 FPS rendering."),
    ("🗄️ SQLite + JDBC", "Embedded zero-configuration relational database stored locally in database/seniortutor.db."),
    ("📦 Maven & Shade", "Automated dependency lifecycle, multi-stage compilation, and self-contained fat executable JAR."),
    ("🗣️ Offline TTS", "Windows SAPI speech synthesis invoked locally without external network or API keys."),
    ("♿ Ergonomic CSS", "Tailored styling palette with Warm Cream, Forest Green, Terracotta, and Muted Gold.")
]

for idx, (t_name, t_sub) in enumerate(tech_cards):
    r = idx // 2
    c = idx % 2
    bx = Inches(0.8 + c * 5.95)
    by = Inches(1.8 + r * 1.65)
    add_card(s13, bx, by, Inches(5.7), Inches(1.45), WHITE, None)

    tb = s13.shapes.add_textbox(bx + Inches(0.2), by + Inches(0.15), Inches(5.3), Inches(1.15))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.paragraphs[0].text = t_name
    tf.paragraphs[0].font.size = Pt(18)
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].font.color.rgb = FOREST_GREEN

    p = tf.add_paragraph()
    p.text = t_sub
    p.font.size = Pt(13)
    p.font.color.rgb = CHARCOAL
    p.space_before = Pt(6)

# ==========================================
# SLIDE 14: LIVE APPLICATION SCREENSHOTS GALLERY
# ==========================================
s14 = prs.slides.add_slide(blank_layout)
set_slide_background(s14, WARM_CREAM)
add_header(s14, "Live Application Demonstration Gallery")

# 4 Gallery Cards
shots = [
    ("screenshots/01_home_screen.png", "Home Screen & Pinned Lessons", Inches(0.8), Inches(1.8)),
    ("screenshots/04_practice_whatsapp.png", "WhatsApp Practice Sandbox", Inches(6.8), Inches(1.8)),
    ("screenshots/06_practice_maps.png", "Google Maps Simulation", Inches(0.8), Inches(4.5)),
    ("screenshots/11_emergency_assistance.png", "Emergency Assistance Screen", Inches(6.8), Inches(4.5))
]

for img_path, caption, ix, iy in shots:
    if os.path.exists(img_path):
        s14.shapes.add_picture(img_path, ix, iy, Inches(5.7), Inches(2.5))

# ==========================================
# SLIDE 15: CONCLUSION & FUTURE SCOPE
# ==========================================
s15 = prs.slides.add_slide(blank_layout)
set_slide_background(s15, FOREST_GREEN)

# Decorative Bar
acc_fin = s15.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(1.2), Inches(1.2), Inches(0.08))
acc_fin.fill.solid()
acc_fin.fill.fore_color.rgb = MUTED_GOLD
acc_fin.line.fill.background()

tb_fin_h = s15.shapes.add_textbox(Inches(0.8), Inches(1.4), Inches(11.7), Inches(0.8))
tf_fin_h = tb_fin_h.text_frame
tf_fin_h.paragraphs[0].text = "Conclusion & Future Innovations"
tf_fin_h.paragraphs[0].font.size = Pt(28)
tf_fin_h.paragraphs[0].font.bold = True
tf_fin_h.paragraphs[0].font.color.rgb = WARM_CREAM

# Future Scope Card
add_card(s15, Inches(0.8), Inches(2.3), Inches(5.6), Inches(4.5), WARM_CREAM, None)
tb_fut = s15.shapes.add_textbox(Inches(1.0), Inches(2.5), Inches(5.2), Inches(4.1))
tf_fut = tb_fut.text_frame
tf_fut.word_wrap = True
tf_fut.paragraphs[0].text = "🔮 Future Roadmap"
tf_fut.paragraphs[0].font.size = Pt(19)
tf_fut.paragraphs[0].font.bold = True
tf_fut.paragraphs[0].font.color.rgb = FOREST_GREEN

fut_items = [
    ("Full On-Device STT", "Integrating offline speech-to-text (Whisper/Vosk) for full bidirectional voice tutoring."),
    ("Companion Mobile Launcher", "Packaging as an ultra-simplified Android home screen launcher for seniors' smartphones."),
    ("AI Scam Reasoning", "Small offline quantized LLM (e.g. Gemma on-device) for multi-turn dialect scam explanation."),
    ("Community Senior Circles", "Local mesh peer-to-peer trivia quizzes and friendly peer learning groups.")
]
for fi_t, fi_d in fut_items:
    p = tf_fut.add_paragraph()
    p.text = "• " + fi_t + ": " + fi_d
    p.font.size = Pt(12)
    p.font.color.rgb = CHARCOAL
    p.space_before = Pt(8)

# Conclusion Card
add_card(s15, Inches(6.8), Inches(2.3), Inches(5.7), Inches(4.5), WARM_CREAM, None)
tb_con = s15.shapes.add_textbox(Inches(7.0), Inches(2.5), Inches(5.3), Inches(4.1))
tf_con = tb_con.text_frame
tf_con.word_wrap = True
tf_con.paragraphs[0].text = "🎓 Viva Conclusion"
tf_con.paragraphs[0].font.size = Pt(19)
tf_con.paragraphs[0].font.bold = True
tf_con.paragraphs[0].font.color.rgb = FOREST_GREEN

con_items = [
    ("Delivered Full Working System", "Built a comprehensive, standalone JavaFX desktop application with SQLite database and executable JAR deliverable."),
    ("Social Impact & Empathy", "Transforms digital anxiety into technological empowerment and safety for the elderly generation."),
    ("Zero Third-Party Cost", "Completely self-contained, offline-ready, requiring zero paid APIs, cloud backends, or web bloat."),
    ("Thank You & Open for Questions", "Demonstration ready for viva evaluation and jury questions.")
]
for ci_t, ci_d in con_items:
    p = tf_con.add_paragraph()
    p.text = "• " + ci_t + ": " + ci_d
    p.font.size = Pt(12)
    p.font.color.rgb = CHARCOAL
    p.space_before = Pt(8)

prs.save("Senior_Citizen_Digital_Tutor_Presentation.pptx")
print("SUCCESSFULLY GENERATED Senior_Citizen_Digital_Tutor_Presentation.pptx (15 Slides)!")
