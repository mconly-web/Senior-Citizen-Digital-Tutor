import os
import sys
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, KeepTogether, PageBreak, HRFlowable
)
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# ----------------------------------------------------------------------
# Font Registration
# ----------------------------------------------------------------------
FONTS_DIR = "C:/Windows/Fonts"
try:
    pdfmetrics.registerFont(TTFont("SegoeUI", os.path.join(FONTS_DIR, "segoeui.ttf")))
    pdfmetrics.registerFont(TTFont("SegoeUI-Bold", os.path.join(FONTS_DIR, "segoeuib.ttf")))
    pdfmetrics.registerFont(TTFont("SegoeUI-Italic", os.path.join(FONTS_DIR, "segoeuii.ttf")))
except Exception as e:
    print(f"Font registration warning: {e}. Falling back to Helvetica.")

# ----------------------------------------------------------------------
# Palette Definitions
# ----------------------------------------------------------------------
C_CREAM       = colors.HexColor("#F3EDE2")
C_FOREST      = colors.HexColor("#173F35")
C_SAGE        = colors.HexColor("#6F8068")
C_TERRACOTTA  = colors.HexColor("#C97855")
C_GOLD        = colors.HexColor("#D6A84F")
C_CHARCOAL    = colors.HexColor("#242424")
C_CARD_BG     = colors.HexColor("#FAF7F2")
C_BORDER      = colors.HexColor("#E2D8C7")
C_ALERT_BG    = colors.HexColor("#FFF8E1")
C_ALERT_BORDER= colors.HexColor("#FFA000")
C_DANGER_BG   = colors.HexColor("#FFEBEE")
C_DANGER_BORDER=colors.HexColor("#D32F2F")
C_WHITE       = colors.HexColor("#FFFFFF")

# ----------------------------------------------------------------------
# Numbered Canvas for Running Headers and Footers
# ----------------------------------------------------------------------
class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        super(NumberedCanvas, self).__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_decorations(num_pages)
            super(NumberedCanvas, self).showPage()
        super(NumberedCanvas, self).save()

    def draw_decorations(self, total_pages):
        if self._pageNumber == 1:
            # Cover page minimal footer
            self.saveState()
            self.setFont("SegoeUI", 8)
            self.setFillColor(C_SAGE)
            self.drawString(36, 25, "Senior Citizen Digital Tutor • Official Functional Handover Manual")
            self.drawRightString(576, 25, "Confidential & Proprietary Deliverable • Version 1.0.0")
            self.restoreState()
            return

        self.saveState()
        # Running Header
        self.setFont("SegoeUI", 8)
        self.setFillColor(C_SAGE)
        self.drawString(36, 762, "Senior Citizen Digital Tutor — Official Functional Handover & User Operations Manual")
        self.setStrokeColor(C_GOLD)
        self.setLineWidth(0.75)
        self.line(36, 756, 576, 756)

        # Running Footer
        self.setStrokeColor(C_BORDER)
        self.setLineWidth(0.5)
        self.line(36, 36, 576, 36)
        
        self.setFont("SegoeUI", 8)
        self.setFillColor(C_SAGE)
        self.drawString(36, 24, "Learn. Practice. Use. Stay Connected. • Offline Desktop Application")
        page_str = f"Page {self._pageNumber} of {total_pages}"
        self.drawRightString(576, 24, page_str)
        self.restoreState()

# ----------------------------------------------------------------------
# Styles Setup
# ----------------------------------------------------------------------
def setup_styles():
    styles = getSampleStyleSheet()
    
    font_normal = "SegoeUI"
    font_bold   = "SegoeUI-Bold"
    font_italic = "SegoeUI-Italic"
    
    styles.add(ParagraphStyle(
        name="DocTitle",
        fontName=font_bold,
        fontSize=24,
        leading=30,
        textColor=C_FOREST,
        spaceAfter=6
    ))
    styles.add(ParagraphStyle(
        name="DocSubTitle",
        fontName=font_normal,
        fontSize=13,
        leading=18,
        textColor=C_TERRACOTTA,
        spaceAfter=15
    ))
    styles.add(ParagraphStyle(
        name="MetaText",
        fontName=font_normal,
        fontSize=9,
        leading=14,
        textColor=C_CHARCOAL
    ))
    styles.add(ParagraphStyle(
        name="SecHeading1",
        fontName=font_bold,
        fontSize=15,
        leading=20,
        textColor=C_FOREST,
        spaceBefore=14,
        spaceAfter=8,
        keepWithNext=True
    ))
    styles.add(ParagraphStyle(
        name="SecHeading2",
        fontName=font_bold,
        fontSize=12,
        leading=16,
        textColor=C_TERRACOTTA,
        spaceBefore=10,
        spaceAfter=5,
        keepWithNext=True
    ))
    styles.add(ParagraphStyle(
        name="SecHeading3",
        fontName=font_bold,
        fontSize=10,
        leading=14,
        textColor=C_FOREST,
        spaceBefore=8,
        spaceAfter=4,
        keepWithNext=True
    ))
    styles.add(ParagraphStyle(
        name="ManualBody",
        fontName=font_normal,
        fontSize=9,
        leading=13.5,
        textColor=C_CHARCOAL,
        spaceAfter=5
    ))
    styles.add(ParagraphStyle(
        name="ManualBodyBold",
        fontName=font_bold,
        fontSize=9,
        leading=13.5,
        textColor=C_CHARCOAL,
        spaceAfter=4
    ))
    styles.add(ParagraphStyle(
        name="CodeBlock",
        fontName="Courier",
        fontSize=8,
        leading=11,
        textColor=C_CHARCOAL
    ))
    styles.add(ParagraphStyle(
        name="ImageCaption",
        fontName=font_italic,
        fontSize=8,
        leading=11,
        textColor=C_SAGE,
        alignment=1, # Center
        spaceBefore=4
    ))
    styles.add(ParagraphStyle(
        name="TableCell",
        fontName=font_normal,
        fontSize=7.5,
        leading=10.5,
        textColor=C_CHARCOAL
    ))
    styles.add(ParagraphStyle(
        name="TableCellBold",
        fontName=font_bold,
        fontSize=7.5,
        leading=10.5,
        textColor=C_CHARCOAL
    ))
    styles.add(ParagraphStyle(
        name="TableHead",
        fontName=font_bold,
        fontSize=8,
        leading=11,
        textColor=C_WHITE
    ))
    styles.add(ParagraphStyle(
        name="CalloutText",
        fontName=font_normal,
        fontSize=8.5,
        leading=12.5,
        textColor=C_CHARCOAL
    ))
    styles.add(ParagraphStyle(
        name="CalloutTitle",
        fontName=font_bold,
        fontSize=9.5,
        leading=13,
        textColor=C_FOREST,
        spaceAfter=3
    ))
    return styles

# ----------------------------------------------------------------------
# Helper Flowable Builders
# ----------------------------------------------------------------------
def build_callout(title, body_p_list, border_color=C_GOLD, bg_color=C_CARD_BG, width=540):
    content = []
    if title:
        content.append(Paragraph(f"<b>{title}</b>", ParagraphStyle(
            name="Ctitle", fontName="SegoeUI-Bold", fontSize=9.5, leading=13, textColor=C_FOREST, spaceAfter=4
        )))
    for p in body_p_list:
        content.append(p)
    
    t = Table([[content]], colWidths=[width])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), bg_color),
        ('BOX', (0,0), (-1,-1), 1.0, border_color),
        ('TOPPADDING', (0,0), (-1,-1), 8),
        ('BOTTOMPADDING', (0,0), (-1,-1), 8),
        ('LEFTPADDING', (0,0), (-1,-1), 12),
        ('RIGHTPADDING', (0,0), (-1,-1), 12),
    ]))
    return t

def build_image_card(img_path, caption_text, width=470, height=293, styles=None):
    if not os.path.exists(img_path):
        return Paragraph(f"[Image file not found: {img_path}]", styles["ManualBody"])
    
    img = Image(img_path, width=width, height=height)
    cap = Paragraph(f"<b>Figure:</b> {caption_text}", styles["ImageCaption"])
    
    card_table = Table([[img], [cap]], colWidths=[width + 10])
    card_table.setStyle(TableStyle([
        ('ALIGN', (0,0), (-1,-1), 'CENTER'),
        ('BACKGROUND', (0,0), (-1,-1), C_CARD_BG),
        ('BOX', (0,0), (-1,-1), 0.75, C_BORDER),
        ('TOPPADDING', (0,0), (-1,0), 5),
        ('BOTTOMPADDING', (0,0), (-1,0), 3),
        ('BOTTOMPADDING', (0,1), (-1,1), 6),
    ]))
    return card_table

# ----------------------------------------------------------------------
# Main PDF Document Generation
# ----------------------------------------------------------------------
def generate_pdf():
    pdf_filename = "PROJECT_USER_MANUAL.pdf"
    doc = SimpleDocTemplate(
        pdf_filename,
        pagesize=letter,
        leftMargin=36,
        rightMargin=36,
        topMargin=46,
        bottomMargin=46
    )
    
    styles = setup_styles()
    story = []
    
    # ------------------------------------------------------------------
    # COVER / HEADER BANNER
    # ------------------------------------------------------------------
    header_table = Table([
        [
            Paragraph("<b>SENIOR CITIZEN DIGITAL TUTOR</b>", styles["DocTitle"]),
        ],
        [
            Paragraph("<b>Official Functional Software Handover & User Operations Manual</b>", styles["DocSubTitle"])
        ]
    ], colWidths=[540])
    header_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), C_CREAM),
        ('BOX', (0,0), (-1,-1), 1.5, C_FOREST),
        ('TOPPADDING', (0,0), (-1,-1), 12),
        ('BOTTOMPADDING', (0,0), (-1,-1), 10),
        ('LEFTPADDING', (0,0), (-1,-1), 14),
        ('RIGHTPADDING', (0,0), (-1,-1), 14),
    ]))
    story.append(header_table)
    story.append(Spacer(1, 8))
    
    meta_p = Paragraph(
        "<b>Tagline:</b> <i>'Learn. Practice. Use. Stay Connected.'</i> &nbsp;|&nbsp; "
        "<b>Primary Deliverable:</b> <code>SeniorCitizenDigitalTutor.jar</code><br/>"
        "<b>Application Type:</b> Standalone Desktop Application (JavaFX 21 + SQLite) &nbsp;|&nbsp; "
        "<b>Target Resolution:</b> 1280x800 Responsive",
        styles["MetaText"]
    )
    story.append(meta_p)
    story.append(Spacer(1, 10))
    
    # ------------------------------------------------------------------
    # QUICK START BOX
    # ------------------------------------------------------------------
    quick_start_paragraphs = [
        Paragraph("<b>1. Ensure Java is installed:</b> Requires Java 21 LTS or compatible modern LTS (verify with <code>java -version</code>).", styles["CalloutText"]),
        Paragraph("<b>2. Locate Executable File:</b> Find <b><code>SeniorCitizenDigitalTutor.jar</code></b> in the root folder or extracted archive.", styles["CalloutText"]),
        Paragraph("<b>3. Launch Method 1 (Direct):</b> Double-click <b><code>SeniorCitizenDigitalTutor.jar</code></b>.", styles["CalloutText"]),
        Paragraph("<b>4. Launch Method 2 (Terminal):</b> Open Command Prompt or PowerShell in the project folder and run:<br/>"
                  "&nbsp;&nbsp;&nbsp;&nbsp;<b><code>java -jar SeniorCitizenDigitalTutor.jar</code></b>", styles["CalloutText"]),
        Paragraph("<b>5. Verify Window:</b> The 1280x800 desktop application window will open immediately with zero network setup required.", styles["CalloutText"]),
    ]
    story.append(build_callout("⚡ QUICK START INSTRUCTIONS (HOW TO RUN IN 30 SECONDS)", quick_start_paragraphs, border_color=C_GOLD, bg_color=C_CARD_BG))
    story.append(Spacer(1, 12))
    
    # ------------------------------------------------------------------
    # SECTION 1: SAFETY & EDUCATIONAL DISCLAIMER
    # ------------------------------------------------------------------
    story.append(Paragraph("1. Important Safety & Educational Disclaimer", styles["SecHeading1"]))
    story.append(HRFlowable(width="100%", thickness=1, color=C_GOLD, spaceBefore=1, spaceAfter=6))
    
    safety_disclaimer_p = [
        Paragraph("<b>CRITICAL BOUNDARY GUARANTEES:</b>", styles["CalloutTitle"]),
        Paragraph("<b>1. ALL SIMULATIONS ARE 100% LOCAL AND VIRTUAL:</b> The mock environments for <b>WhatsApp, Phone Dialer, UPI Payments, Google Maps, and Email</b> run entirely inside the standalone JavaFX application. "
                  "<b>NO REAL MONEY</b> is ever deducted, <b>NO REAL BANK ACCOUNTS</b> are accessed, <b>NO REAL CALLS</b> are dialed, and <b>NO OUTBOUND SMS/EMAILS</b> are transmitted across networks. Senior citizens can practice with zero financial or technical fear.", styles["CalloutText"]),
        Paragraph("<b>2. SCAM CHECKER IS AN EDUCATIONAL AID, NOT AN ORACLE:</b> The <i>'Is This Safe?'</i> message analyzer uses local heuristic pattern matching to teach seniors common fraud signatures (artificial panic, lottery lures, OTP requests, remote access tools). It does not guarantee 100% detection of all cyber threats. When in doubt, users should always verify directly with family members or bank branches.", styles["CalloutText"])
    ]
    story.append(build_callout("", safety_disclaimer_p, border_color=C_DANGER_BORDER, bg_color=C_DANGER_BG))
    story.append(Spacer(1, 10))
    
    # ------------------------------------------------------------------
    # SECTION 2: HOW TO RUN THE APPLICATION
    # ------------------------------------------------------------------
    story.append(Paragraph("2. How to Run the Application (Complete Beginner Guide)", styles["SecHeading1"]))
    story.append(HRFlowable(width="100%", thickness=1, color=C_GOLD, spaceBefore=1, spaceAfter=6))
    
    story.append(Paragraph("<b>Which File Do I Run?</b>", styles["SecHeading2"]))
    story.append(Paragraph("Always run <b><code>SeniorCitizenDigitalTutor.jar</code></b> located in the project root folder. Do NOT attempt to run source files (<code>.java</code>), the SQLite database (<code>database/seniortutor.db</code>), or build files directly.", styles["ManualBody"]))
    
    story.append(Paragraph("<b>Step 1: Check Java Installation</b>", styles["SecHeading3"]))
    story.append(Paragraph("Press <b>Windows Key + R</b>, type <code>cmd</code>, press Enter, then type <code>java -version</code>. You should see <code>java version \"21.0.x\"</code> or higher. If not found, download Java 21 LTS from <b>adoptium.net</b>.", styles["ManualBody"]))
    
    story.append(Paragraph("<b>Method 1: Double-Click the JAR</b>", styles["SecHeading3"]))
    story.append(Paragraph("Open the folder and double-click <code>SeniorCitizenDigitalTutor.jar</code>. The warm cream desktop window opens within 2–4 seconds.", styles["ManualBody"]))
    
    story.append(Paragraph("<b>Method 2: Run via Command Prompt / PowerShell (Recommended)</b>", styles["SecHeading3"]))
    story.append(Paragraph("Open PowerShell or Command Prompt in the project folder and type:<br/>"
                           "<code>java -jar SeniorCitizenDigitalTutor.jar</code>", styles["ManualBody"]))
    
    story.append(Paragraph("<b>Method 3: Build and Run from Source via Maven</b>", styles["SecHeading3"]))
    story.append(Paragraph("In the project directory, run: <code>.\\mvnw.cmd clean package</code> and then <code>java -jar target\\SeniorCitizenDigitalTutor.jar</code>.", styles["ManualBody"]))
    
    story.append(Spacer(1, 6))
    story.append(Paragraph("<b>Troubleshooting: 'The App Won't Open'</b>", styles["SecHeading2"]))
    
    run_err_data = [
        [Paragraph("What You See", styles["TableHead"]), Paragraph("Likely Cause", styles["TableHead"]), Paragraph("Exact Solution", styles["TableHead"])],
        [Paragraph("<code>'java' is not recognized</code>", styles["TableCellBold"]), Paragraph("Java not installed or not in system PATH", styles["TableCell"]), Paragraph("Install Java 21 LTS from adoptium.net; verify 'Add to PATH' is checked.", styles["TableCell"])],
        [Paragraph("Double-clicking opens WinRAR / 7-Zip", styles["TableCellBold"]), Paragraph("File association hijacked by archive tool", styles["TableCell"]), Paragraph("Right-click JAR -> Open With -> Java(TM) Platform SE Binary, or run via Command Prompt.", styles["TableCell"])],
        [Paragraph("<code>UnsupportedClassVersionError</code>", styles["TableCellBold"]), Paragraph("Obsolete Java runtime (e.g. Java 8 or 11) is active", styles["TableCell"]), Paragraph("Install Java 21 LTS or modern LTS. JavaFX 21 bytecode requires modern runtime.", styles["TableCell"])],
        [Paragraph("Window closes immediately", styles["TableCellBold"]), Paragraph("Missing write permissions for <code>database/</code>", styles["TableCell"]), Paragraph("Ensure folder is writable. Run Command Prompt as Administrator if in a restricted drive.", styles["TableCell"])],
        [Paragraph("No speech audio plays", styles["TableCellBold"]), Paragraph("PC volume muted or non-Windows OS", styles["TableCell"]), Paragraph("Check PC speaker volume. Narration uses Windows SAPI; falls back cleanly on other OS.", styles["TableCell"])],
    ]
    t_run_err = Table(run_err_data, colWidths=[120, 160, 260])
    t_run_err.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_FOREST),
        ('BOX', (0,0), (-1,-1), 0.75, C_BORDER),
        ('INNERGRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [C_CARD_BG, C_WHITE]),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('RIGHTPADDING', (0,0), (-1,-1), 6),
    ]))
    story.append(t_run_err)
    story.append(Spacer(1, 12))
    
    # ------------------------------------------------------------------
    # SECTION 3: SYSTEM OVERVIEW & PHILOSOPHY
    # ------------------------------------------------------------------
    story.append(Paragraph("3. System Overview & Operating Philosophy", styles["SecHeading1"]))
    story.append(HRFlowable(width="100%", thickness=1, color=C_GOLD, spaceBefore=1, spaceAfter=6))
    
    story.append(Paragraph("The software embodies the central philosophy: <b>'Learn technology without fear.'</b> Unlike standard corporate applications or LMS platforms, every interaction is engineered for accessibility, patience, and positive reinforcement.", styles["ManualBody"]))
    
    phil_data = [
        [Paragraph("Traditional Software Pattern (Impatient / Intimidating)", styles["TableHead"]), Paragraph("Senior Citizen Digital Tutor Design Pattern (Patient / Accessible)", styles["TableHead"])],
        [Paragraph("Tiny 12px grey text with low contrast", styles["TableCell"]), Paragraph("Large 16px–22px high-contrast typography in Warm Cream and Forest Green", styles["TableCellBold"])],
        [Paragraph("Small 30px touch targets prone to accidental mis-clicks", styles["TableCell"]), Paragraph("Minimum 52px rounded touch targets with clear icons and generous padding", styles["TableCellBold"])],
        [Paragraph("Fast, jarring animations causing cognitive disorientation", styles["TableCell"]), Paragraph("Calm, static, predictable layouts with smooth subtle transitions", styles["TableCellBold"])],
        [Paragraph("One-shot instructions that disappear upon scrolling", styles["TableCell"]), Paragraph("Persistent 'Listen' and unlimited 'Repeat' spoken voice guidance", styles["TableCellBold"])],
        [Paragraph("Fear of real financial loss or privacy leakage", styles["TableCell"]), Paragraph("100% sandboxed offline simulations (WhatsApp, UPI, Maps, Phone, Email)", styles["TableCellBold"])],
        [Paragraph("Complex multi-field login screens with passwords", styles["TableCell"]), Paragraph("One-click profile switcher between Senior Learner and Family Helper", styles["TableCellBold"])],
    ]
    t_phil = Table(phil_data, colWidths=[260, 280])
    t_phil.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_FOREST),
        ('BOX', (0,0), (-1,-1), 0.75, C_BORDER),
        ('INNERGRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [C_CARD_BG, C_WHITE]),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('RIGHTPADDING', (0,0), (-1,-1), 6),
    ]))
    story.append(t_phil)
    story.append(Spacer(1, 14))
    
    # ------------------------------------------------------------------
    # SECTION 4: MASTER FUNCTION MATRIX
    # ------------------------------------------------------------------
    story.append(PageBreak())
    story.append(Paragraph("4. Master Function Matrix", styles["SecHeading1"]))
    story.append(HRFlowable(width="100%", thickness=1, color=C_GOLD, spaceBefore=1, spaceAfter=6))
    story.append(Paragraph("The master functional matrix provides an exhaustive index of all major and minor interactive controls across the entire desktop application:", styles["ManualBody"]))
    
    matrix_raw = [
        ("Text Sizing (A-)", "Top Bar", "Click 'A-' button", "Decreases interface font scale by 15% (min 0.85x)", "Saved in settings DB", "Compact display for small screens"),
        ("Text Sizing (A+)", "Top Bar", "Click 'A+' button", "Increases interface font scale by 15% (max 1.4x)", "Saved in settings DB", "Assists low-vision & presbyopia"),
        ("Voice Toggle", "Top Bar", "Click Voice button", "Toggles automated spoken narration ON/OFF", "Saved in settings DB", "Silence audio in public spaces"),
        ("Profile Switcher", "Top Bar", "Click Profile pill", "Toggles between Senior and Caregiver Helper", "Switches active user state", "Caregiver & elder share workstation"),
        ("Navigation Sidebar", "Left Rail", "Click sidebar tab", "Switches active view (Home, Learn, Practice, etc.)", "None (UI state)", "Uncluttered predictable navigation"),
        ("Search Lessons", "Home Screen", "Type query + Search", "Searches titles, categories, and keywords", "None (UI state)", "Instant access to digital topics"),
        ("Voice Search Prompt", "Home Screen", "Click 'Speak'", "Demonstrates voice query and fills sample", "None (UI state)", "Demonstrates voice interaction"),
        ("Popular Search Chips", "Home Screen", "Click chip (e.g. QR)", "Fills search bar with topic and executes search", "None (UI state)", "One-tap access to frequent topics"),
        ("Clear Search", "Home Screen", "Click 'Clear'", "Dismisses search results card", "None (UI state)", "Maintains clean home dashboard"),
        ("Pinned Lesson Card", "Home Screen", "Click 'Open Lesson'", "Opens lesson assigned by caregiver", "None (Navigates)", "Highlights family priority lesson"),
        ("Resume Lesson", "Home Screen", "Click 'Resume'", "Re-opens unfinished lesson at exact step", "None (Navigates)", "Zero friction returning to study"),
        ("Category Card", "Home / Learn", "Click category card", "Opens full lesson list for chosen category", "None (Navigates)", "Explore curriculum by subject"),
        ("Start / Review Lesson", "Lesson List", "Click action button", "Opens Lesson Engine at Step 1 or last step", "Updates last_step in DB", "Launches step-by-step viewer"),
        ("Listen Instruction", "Lesson Engine", "Click 'Listen'", "Speaks current step instruction aloud via TTS", "None (Audio)", "Auditory reinforcement of text"),
        ("Repeat Instruction", "Lesson Engine", "Click 'Repeat'", "Replays spoken instruction from start", "None (Audio)", "Unlimited patient repetitions"),
        ("Next Step", "Lesson Engine", "Click 'Next Step'", "Advances to next instructional step", "Updates last_step in DB", "Sequential learning progression"),
        ("Previous Step", "Lesson Engine", "Click 'Previous'", "Returns to preceding step", "Updates last_step in DB", "Review earlier steps without reset"),
        ("Practice It Now", "Lesson Engine", "Click 'Practice'", "Launches linked sandbox simulation directly", "None (Navigates)", "Immediate hands-on muscle memory"),
        ("Take Quick Quiz", "Lesson Engine", "Click 'Quiz'", "Launches multiple-choice comprehension check", "None (Navigates)", "Validates retention"),
        ("Complete Lesson", "Lesson Engine", "Click 'Complete'", "Marks lesson completed, plays celebration chime", "Sets completed=1 in DB", "Updates progress & awards badges"),
        ("WhatsApp Chat Send", "Practice Hub", "Type text + Send", "Dispatches chat bubble with blue ticks & reply", "Awards achievement", "Safe messaging practice"),
        ("WhatsApp Photo Send", "Practice Hub", "Click Photo attach", "Sends garden photo bubble + auto-reply", "Awards achievement", "Teaches image attachment flow"),
        ("WhatsApp Location", "Practice Hub", "Click Location attach", "Sends home GPS coordinates bubble + reply", "Awards achievement", "Teaches safe location sharing"),
        ("WhatsApp Voice Note", "Practice Hub", "Click Voice note", "Sends simulated voice clip (0:12) + reply", "Awards achievement", "Teaches voice note recording"),
        ("WhatsApp Video Call", "Practice Hub", "Click Video Call", "Opens full video call screen with live timer", "Awards achievement", "Eliminates fear of video calling"),
        ("End Active Call", "Practice Hub", "Click 'End Call'", "Terminates call and logs call duration", "None (UI state)", "Teaches how to hang up cleanly"),
        ("Phone Dialpad", "Practice Hub", "Click digits (0-9)", "Appends typed digit to large display", "None (UI state)", "Accessible number dialing"),
        ("Phone Backspace", "Practice Hub", "Click backspace", "Deletes last typed digit", "None (UI state)", "Easy mistake correction"),
        ("Family Contact Chip", "Practice Hub", "Click contact chip", "Autofills phone number into dialer", "None (UI state)", "Demonstrates speed dial"),
        ("Speakerphone Toggle", "Practice Hub", "Click Speaker", "Toggles speakerphone mode ON/OFF", "None (UI state)", "Hands-free calling practice"),
        ("UPI QR Scan", "Practice Hub", "Click 'Scan QR'", "Simulates viewfinder scanning grocery QR stand", "None (UI state)", "Teaches counter QR payment flow"),
        ("UPI Amount Input", "Practice Hub", "Type amount or chip", "Sets payment amount (e.g. Rs 150)", "None (UI state)", "Teaches checking amount first"),
        ("UPI PIN Pad", "Practice Hub", "Enter PIN + Pay", "Simulates PIN entry, displays mock receipt", "Awards achievement", "PIN enters ONLY to send money"),
        ("Map Search Chip", "Practice Hub", "Click landmark chip", "Plots blue route line to hospital/chemist", "Awards achievement", "Finding medical care offline"),
        ("Voice Navigation", "Practice Hub", "Click 'Start Voice'", "Speaks turn-by-turn driving/walking prompt", "None (Audio)", "GPS navigation confidence"),
        ("Email Compose", "Practice Hub", "Enter To/Sub/Body", "Dispatches mock email to Sent folder", "Awards achievement", "Formal email practice"),
        ("Scam Analyzer", "Safety Hub", "Enter text + Analyze", "Evaluates message for fraud patterns (0-100)", "Logs check in DB", "Identifies scams & protects money"),
        ("Scam Sample Chip", "Safety Hub", "Click sample chip", "Autofills realistic scam scenario into input", "None (UI state)", "Instant testing of scam types"),
        ("Quiz Option Select", "Quiz View", "Click Option button", "Evaluates answer, shows green/red rationale", "Updates score tally", "Immediate educational feedback"),
        ("Caregiver Recommend", "Family Care", "Select lesson + Note", "Pins lesson banner to senior's home screen", "Saves in DB table", "Caregiver guides elder remotely"),
        ("Emergency Family", "Emergency", "Click 'Call Family'", "Speaks prompt, opens family speed dial dialog", "None (Simulation)", "One-touch reassurance"),
        ("Emergency Ambulance", "Emergency", "Click 'Ambulance'", "Plays alert chime, opens 108 dispatch dialog", "None (Simulation)", "Rapid medical assistance"),
        ("Emergency Police", "Emergency", "Click 'Police'", "Plays alert chime, opens 112 dispatch dialog", "None (Simulation)", "Rapid law enforcement contact"),
        ("High Contrast Toggle", "Settings", "Toggle checkbox", "Switches background to dark charcoal (#121212)", "Saved in settings DB", "Relieves eye strain & cataracts"),
        ("Language Switcher", "Settings", "Choose language", "Updates labels to English, Hindi, or Marathi", "Saved in settings DB", "Mother-tongue accessibility"),
        ("Reset All Progress", "Settings", "Click 'Reset Progress'", "Clears completed lessons, scores, and badges", "Deletes DB rows", "Allows fresh rehearsal"),
    ]
    
    matrix_table_data = [[
        Paragraph("Function Name", styles["TableHead"]),
        Paragraph("Location", styles["TableHead"]),
        Paragraph("User Action", styles["TableHead"]),
        Paragraph("What It Does", styles["TableHead"]),
        Paragraph("Persistent Effect", styles["TableHead"]),
        Paragraph("Purpose", styles["TableHead"])
    ]]
    for item in matrix_raw:
        matrix_table_data.append([
            Paragraph(f"<b>{item[0]}</b>", styles["TableCell"]),
            Paragraph(item[1], styles["TableCell"]),
            Paragraph(item[2], styles["TableCell"]),
            Paragraph(item[3], styles["TableCell"]),
            Paragraph(item[4], styles["TableCell"]),
            Paragraph(item[5], styles["TableCell"]),
        ])
        
    t_matrix = Table(matrix_table_data, colWidths=[85, 55, 75, 145, 95, 85], repeatRows=1)
    t_matrix.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_FOREST),
        ('BOX', (0,0), (-1,-1), 0.75, C_BORDER),
        ('INNERGRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [C_CARD_BG, C_WHITE]),
        ('TOPPADDING', (0,0), (-1,-1), 3),
        ('BOTTOMPADDING', (0,0), (-1,-1), 3),
        ('LEFTPADDING', (0,0), (-1,-1), 4),
        ('RIGHTPADDING', (0,0), (-1,-1), 4),
    ]))
    story.append(t_matrix)
    story.append(Spacer(1, 14))
    
    # ------------------------------------------------------------------
    # SECTION 5: SCREEN-BY-SCREEN FUNCTIONAL GUIDE
    # ------------------------------------------------------------------
    story.append(PageBreak())
    story.append(Paragraph("5. Screen-by-Screen Functional Guide", styles["SecHeading1"]))
    story.append(HRFlowable(width="100%", thickness=1, color=C_GOLD, spaceBefore=1, spaceAfter=6))
    
    # 5.1 Top Bar & Navigation
    story.append(Paragraph("5.1 Persistent Top Bar & Navigation Sidebar", styles["SecHeading2"]))
    story.append(build_image_card("screenshots/01_home_screen.png", "Home Dashboard Screen with Top Bar & Navigation Rail", styles=styles))
    story.append(Spacer(1, 6))
    story.append(Paragraph("The persistent Top Bar remains fixed across all application screens. It provides universal accessibility controls: "
                           "<b>A- / A+</b> adjusts global font scaling between 0.85x and 1.40x; <b>🔊 Voice ON / OFF</b> toggles spoken narration; "
                           "and the <b>👵 Shanti Sharma (SENIOR)</b> pill button instantly switches roles between Senior Learner and Family Helper.", styles["ManualBody"]))
    story.append(Paragraph("The left Navigation Sidebar features large touch-friendly buttons for instant one-click switching between <i>Home, Learn, Practice, Stay Safe, Progress, Badges, Family Care, Emergency (highlighted in Terracotta), and Settings</i>.", styles["ManualBody"]))
    story.append(Spacer(1, 10))
    
    # 5.2 Lesson Engine & Viewer
    story.append(PageBreak())
    story.append(Paragraph("5.2 Lesson Engine & Step-by-Step Viewer", styles["SecHeading2"]))
    story.append(build_image_card("screenshots/02_lesson_viewer.png", "Lesson Engine with Visual Smartphone Mockup and Audio Narration", styles=styles))
    story.append(Spacer(1, 6))
    story.append(Paragraph("The Lesson Engine provides structured, stress-free step-by-step guidance. Key interactive elements include:", styles["ManualBody"]))
    story.append(Paragraph("• <b>🔊 Listen:</b> Triggers offline text-to-speech to read the current step instruction aloud.<br/>"
                           "• <b>🔁 Repeat:</b> Re-reads the current instruction from the beginning. Never times out or penalizes the user.<br/>"
                           "• <b>Step Counter & Progress Bar:</b> Visually tracks the learner's journey (e.g. <i>Step 1 of 4</i>) with high-contrast gold fill.<br/>"
                           "• <b>StepIllustrationNode:</b> Dynamic visual component showing physical phone buttons, WhatsApp screens, QR viewfinders, or safety cards.<br/>"
                           "• <b>Navigation Controls:</b> <code>← Previous Step</code> and <code>Next Step →</code> buttons automatically update the user's progress in SQLite.", styles["ManualBody"]))
    story.append(Spacer(1, 10))
    
    # 5.3 Knowledge Check & Quiz
    story.append(Paragraph("5.3 Knowledge Check & Comprehension Quiz", styles["SecHeading2"]))
    story.append(build_image_card("screenshots/03_quiz_interface.png", "Multiple-Choice Knowledge Check with Instant Educational Feedback", styles=styles))
    story.append(Spacer(1, 6))
    story.append(Paragraph("Every lesson includes a companion multiple-choice quiz designed to build confidence rather than generate anxiety. "
                           "Selecting an answer immediately reveals a clear green or red feedback card explaining <b>why</b> that answer is correct, "
                           "reinforcing safety principles. Users can retake quizzes an unlimited number of times.", styles["ManualBody"]))
    story.append(Spacer(1, 10))
    
    # 5.4 WhatsApp Simulation
    story.append(PageBreak())
    story.append(Paragraph("5.4 Safe Practice Sandbox: WhatsApp Messaging & Video Calling", styles["SecHeading2"]))
    story.append(build_image_card("screenshots/04_practice_whatsapp.png", "Safe WhatsApp Simulation: Text, Photos, Location, Voice Notes & Video Calls", styles=styles))
    story.append(Spacer(1, 6))
    story.append(Paragraph("The WhatsApp sandbox simulates a realistic messaging experience with family member Anita Sharma. "
                           "Seniors can safely practice typing text messages, attaching simulated garden photos (<code>📎 -> Send Photo</code>), "
                           "sharing simulated home GPS locations (<code>📎 -> Share Location</code>), recording simulated voice notes (<code>🎤 Voice</code>), "
                           "and conducting simulated live video calls with a front-camera timer and end-call controls.", styles["ManualBody"]))
    story.append(Spacer(1, 10))
    
    # 5.5 UPI Payment Simulation
    story.append(Paragraph("5.5 Safe Practice Sandbox: UPI Payments & QR Scanning", styles["SecHeading2"]))
    story.append(build_image_card("screenshots/05_practice_upi.png", "Safe UPI Payment Simulation: QR Scan, Merchant Verification & Secret PIN Pad", styles=styles))
    story.append(Spacer(1, 6))
    story.append(Paragraph("The UPI sandbox teaches real-world payment flows with <b>zero financial risk</b>. "
                           "It emphasizes the cardinal rule of digital payments: <i>'Entering your PIN DEDUCTS money; NEVER enter PIN to receive money.'</i> "
                           "The 3-step workflow covers: 1) Scanning mock merchant QR codes; 2) Verifying merchant business name and entering amounts; "
                           "3) Entering the secret 4-digit PIN on a secure keypad. A realistic payment receipt and simulated shop soundbox voice announcement confirm completion.", styles["ManualBody"]))
    story.append(Spacer(1, 10))
    
    # 5.6 Google Maps Simulation
    story.append(PageBreak())
    story.append(Paragraph("5.6 Safe Practice Sandbox: Google Maps & Offline Navigation", styles["SecHeading2"]))
    story.append(build_image_card("screenshots/06_practice_maps.png", "Interactive Google Maps Simulation with Route Lines and Voice Navigation", styles=styles))
    story.append(Spacer(1, 6))
    story.append(Paragraph("The offline Maps simulation features an interactive vector map of the senior's local neighborhood. "
                           "Quick filter chips allow one-tap navigation to critical locations: <b>🏥 City Civil Hospital</b> (850m), "
                           "<b>💊 MedPlus Pharmacy</b> (350m), and <b>🥛 Mother Dairy</b> (500m). "
                           "Clicking any landmark plots a clear blue route line, calculates walking time, displays turn-by-turn instructions, "
                           "and provides spoken voice driving navigation prompts.", styles["ManualBody"]))
    story.append(Spacer(1, 10))
    
    # 5.7 Digital Safety & Scam Checker
    story.append(Paragraph("5.7 Digital Safety Hub & 'Is This Safe?' Scam Analyzer", styles["SecHeading2"]))
    story.append(build_image_card("screenshots/07_safety_checker.png", "Digital Safety Hub: 6 Golden Rules and Heuristic Message Scam Checker", styles=styles))
    story.append(Spacer(1, 6))
    story.append(Paragraph("The Digital Safety Hub frames the <b>6 Golden Rules of Digital Protection</b> (Never share OTP, Never enter PIN to receive money, Never share card CVV, Never install AnyDesk, Never believe fake lotteries, Never panic from electricity threats). "
                           "The interactive <i>'Is This Safe?'</i> tool analyzes pasted text messages against known cyber fraud patterns, calculating a 0–100 Danger Score, "
                           "listing detected red flags (e.g. artificial urgency, unverified links), and giving calm, actionable advice.", styles["ManualBody"]))
    story.append(Spacer(1, 10))
    
    # 5.8 Progress Dashboard & Badges
    story.append(PageBreak())
    story.append(Paragraph("5.8 Learning Progress Dashboard & Milestone Badges", styles["SecHeading2"]))
    story.append(build_image_card("screenshots/08_progress_dashboard.png", "Learning Progress Dashboard with Category Progress and Active Streak", styles=styles))
    story.append(Spacer(1, 6))
    story.append(build_image_card("screenshots/09_achievements_milestones.png", "Milestone Badges Screen: 8 Unlockable Digital Literacy Badges", styles=styles))
    story.append(Spacer(1, 6))
    story.append(Paragraph("The Progress Dashboard tracks metrics in real time: completed lesson counts, 3-day learning streaks, and quiz accuracy percentages. "
                           "The Badges screen rewards learners with 8 celebratory milestones (<i>First Steps, WhatsApp Explorer, Safety Champion, Digital Money Smart, Quiz Champion, Tech Champion, City Navigator, Daily Learner</i>) to encourage continuous practice.", styles["ManualBody"]))
    story.append(Spacer(1, 10))
    
    # 5.9 Family Caregiver & Emergency
    story.append(PageBreak())
    story.append(Paragraph("5.9 Family Caregiver Dashboard & One-Touch Emergency Help", styles["SecHeading2"]))
    story.append(build_image_card("screenshots/10_family_helper_mode.png", "Family Caregiver Dashboard with Weak Area Analysis and Remote Lesson Recommender", styles=styles))
    story.append(Spacer(1, 6))
    story.append(build_image_card("screenshots/11_emergency_assistance.png", "One-Touch Emergency Assistance Screen with Giant Helplines", styles=styles))
    story.append(Spacer(1, 6))
    story.append(Paragraph("The Family Caregiver Dashboard allows adult children to review their elder's progress remotely, view identified weak areas, and pin recommended lessons with custom notes directly to the elder's home screen. "
                           "The Emergency Assistance screen provides 4 giant high-visibility buttons (<i>👨‍👩‍👧 Call Family, 🚑 Medical Ambulance 108, 🚓 Police Helpline 112, 📍 Share GPS Location</i>) for zero-panic emergency muscle memory training.", styles["ManualBody"]))
    story.append(Spacer(1, 10))
    
    # 5.10 Settings & Accessibility
    story.append(Paragraph("5.10 Settings & Accessibility Customization", styles["SecHeading2"]))
    story.append(build_image_card("screenshots/12_accessibility_settings.png", "Settings Screen: Font Sizes, High Contrast Mode, Multilingual & Emergency Setup", styles=styles))
    story.append(Spacer(1, 6))
    story.append(Paragraph("The Settings screen enables full personalization: 3 base font sizes (Standard 16px, Large 18px, Extra Large 22px), High Contrast Mode (deep charcoal background for glare-free viewing), "
                           "Voice Tutor toggles, multilingual support (English, Hindi, Marathi), custom emergency contact numbers, and a progress reset tool.", styles["ManualBody"]))
    story.append(Spacer(1, 12))
    
    # ------------------------------------------------------------------
    # SECTION 6: COMPLETE OPERATIONAL WORKFLOWS
    # ------------------------------------------------------------------
    story.append(PageBreak())
    story.append(Paragraph("6. Complete Operational Workflows", styles["SecHeading1"]))
    story.append(HRFlowable(width="100%", thickness=1, color=C_GOLD, spaceBefore=1, spaceAfter=6))
    story.append(Paragraph("The following six step-by-step procedures illustrate complete user journeys through the application:", styles["ManualBody"]))
    
    workflows = [
        ("Workflow 1: Searching for and Launching a Digital Lesson", [
            "1. From the Home screen, click inside the <b>'🎤 Teach Me Anything'</b> search bar.",
            "2. Type <code>How do I make a video call?</code> and click <b>🔍 Search</b> (or tap the <b>Video call</b> chip).",
            "3. The Search Results card appears showing matched lessons.",
            "4. Locate <i>'How to Make a WhatsApp Video Call'</i> and click <b>Start Lesson →</b>.",
            "5. The Lesson Engine opens directly at Step 1 with visual phone illustrations."
        ]),
        ("Workflow 2: Completing a Lesson, Voice Narration, and Quiz", [
            "1. In the Lesson Engine, observe <b>STEP 1 OF 4</b> and the visual smartphone diagram.",
            "2. Click <b>🔊 Listen</b> to hear the instruction read aloud via offline speech.",
            "3. Click <b>🔁 Repeat</b> to hear the instruction again as many times as desired.",
            "4. Click <b>Next Step →</b> to advance sequentially through all 4 steps.",
            "5. On the final step, click <b>📝 Take Quick Quiz</b>.",
            "6. Read Question 1 and click option <b>B. The video camera icon 📹</b>.",
            "7. The instant feedback card displays <b>✅ Correct! Great Job!</b> with educational rationale.",
            "8. Click <b>See Final Score 🏆</b> to view the 100% score card, then click <b>Finish & Back to Lessons</b>.",
            "9. The lesson is saved as Completed in SQLite and progress updates across the application."
        ]),
        ("Workflow 3: Practicing a Safe UPI Grocery Payment", [
            "1. Click <b>🎮 Practice</b> in the left sidebar navigation.",
            "2. Click the <b>💳 UPI Payments</b> simulation card.",
            "3. Read the safety disclaimer: <i>'Entering your PIN DEDUCTS money...'</i>.",
            "4. Click <b>📷 Scan QR Code Now</b> to simulate scanning the shop's counter stand.",
            "5. Step 2 opens showing verified merchant: <i>'Sharma Fresh Groceries (Verified Business)'</i>.",
            "6. Type <code>150</code> in the amount box (or click the <b>₹150</b> chip) and click <b>Proceed to Safe PIN Entry →</b>.",
            "7. Step 3 opens showing the secret PIN pad. Enter <code>1 2 3 4</code> using the numeric keypad and click <b>✓ Pay</b>.",
            "8. The screen transitions to <b>✅ Payment Successful!</b> with a simulated transaction receipt and soundbox voice confirmation.",
            "9. Click <b>🔁 Practice Another Payment</b> to rehearse additional merchant transactions."
        ]),
        ("Workflow 4: Testing a Suspicious Message in the Scam Checker", [
            "1. Click <b>🔐 Stay Safe</b> in the left sidebar navigation.",
            "2. Scroll down to the <b>'Is This Safe?'</b> Educational Message Checker.",
            "3. Click the pre-filled sample chip <b>⚡ Electricity Threat</b>.",
            "4. The text box populates with: <i>'Dear consumer, your electricity will be disconnected tonight at 9:30 PM due to unpaid bill. Call 9876543210...'</i>.",
            "5. Click <b>Analyze Message Safety 🔍</b>.",
            "6. The results card renders in high-contrast red: <b>🔴 HIGH RISK / DANGER (Score: 70/100)</b>.",
            "7. Flags identified: <i>Artificial Panic & Urgency</i>, <i>Unverified Phone Number</i>.",
            "8. Advice: <i>'Scammers use panic so you don't call family. Genuine electricity boards give written notice. Do not call this number.'</i>"
        ]),
        ("Workflow 5: Caregiver Recommending a Pinned Lesson", [
            "1. In the top-right header, click the profile pill to switch to <b>👩 Anita Sharma (HELPER)</b>.",
            "2. The application navigates automatically to the <b>Family Caregiver Dashboard</b>.",
            "3. Review Shanti Ji's category mastery bars and identified weak areas.",
            "4. In the 'Recommend a Lesson' card, select <i>'NEVER Share Your UPI PIN - Crucial Rules'</i> from the dropdown.",
            "5. In the note field, type: <i>'Maa, please review this before our market visit this evening!'</i>.",
            "6. Click <b>Send Recommendation 🚀</b>.",
            "7. Switch the profile back to <b>👵 Shanti Sharma (SENIOR)</b>.",
            "8. On the Home screen, observe the new gold-bordered pinned recommendation card prominently displayed at the top of the dashboard."
        ]),
        ("Workflow 6: Adjusting Font Size and High Contrast", [
            "1. In the top-right header bar, click <b>A+</b> twice. Notice all text expands across the screen.",
            "2. Click <b>⚙️ Settings</b> in the left navigation sidebar.",
            "3. Under Display & Text Size, check <b>High Contrast Mode</b>.",
            "4. The background immediately transitions to deep charcoal (<code>#121212</code>) with high-contrast text, eliminating screen glare.",
            "5. Click <b>A-</b> to scale text down to standard size whenever desired."
        ]),
    ]
    
    for wf_title, steps in workflows:
        story.append(Paragraph(f"<b>{wf_title}</b>", styles["SecHeading2"]))
        p_list = [Paragraph(step, styles["ManualBody"]) for step in steps]
        story.append(build_callout("", p_list, border_color=C_BORDER, bg_color=C_CARD_BG))
        story.append(Spacer(1, 6))
        
    story.append(Spacer(1, 10))
    
    # ------------------------------------------------------------------
    # SECTION 7: SIMULATION VS REALITY
    # ------------------------------------------------------------------
    story.append(PageBreak())
    story.append(Paragraph("7. Simulation vs. Reality: Sandbox Boundary Guarantees", styles["SecHeading1"]))
    story.append(HRFlowable(width="100%", thickness=1, color=C_GOLD, spaceBefore=1, spaceAfter=6))
    story.append(Paragraph("The application strictly isolates educational simulations from the host machine and external networks:", styles["ManualBody"]))
    
    sim_data = [
        [Paragraph("Feature / Sandbox", styles["TableHead"]), Paragraph("What Is Simulated in the Tutor", styles["TableHead"]), Paragraph("What NEVER Happens (Real World Boundary)", styles["TableHead"])],
        [Paragraph("WhatsApp Messaging", styles["TableCellBold"]), Paragraph("Chat bubbles, simulated typing, auto-replies from daughter, simulated video call overlay with front camera timer.", styles["TableCell"]), Paragraph("Zero cellular or internet packets transmitted. No messages sent to real phone numbers. No contact list accessed.", styles["TableCell"])],
        [Paragraph("Phone Dialer", styles["TableCellBold"]), Paragraph("3x4 numeric keypad, large dial display, contact chips, simulated ringing, connected timer, speakerphone toggle.", styles["TableCell"]), Paragraph("No telephony hardware or cellular modem utilized. Zero phone calls placed. Zero carrier charges incurred.", styles["TableCell"])],
        [Paragraph("UPI Payments", styles["TableCellBold"]), Paragraph("Mock QR viewfinder, merchant name check, amount entry, simulated PIN pad, mock transaction receipt.", styles["TableCell"]), Paragraph("Zero money deducted. No banks, payment gateways, NPCI, or credit accounts touched. Safe practice guaranteed.", styles["TableCell"])],
        [Paragraph("Google Maps", styles["TableCellBold"]), Paragraph("Offline vector canvas, local landmark chips (Hospital, Chemist), route line calculation, turn-by-turn prompts.", styles["TableCell"]), Paragraph("No GPS hardware queries or Google Maps API calls. No personal location data transmitted outside the computer.", styles["TableCell"])],
        [Paragraph("Email Client", styles["TableCellBold"]), Paragraph("Mock inbox, composing emails, recipient chips, simulated PDF attachments, dispatched to Sent folder.", styles["TableCell"]), Paragraph("No SMTP/IMAP servers contacted. Zero outbound emails transmitted across the internet.", styles["TableCell"])],
        [Paragraph("Emergency Help", styles["TableCellBold"]), Paragraph("One-touch speed-dial simulation, ambulance 108 dialog, police 112 dialog, simulated SMS GPS dispatch.", styles["TableCell"]), Paragraph("No live emergency dispatches called. Designed exclusively for panic-free muscle memory training.", styles["TableCell"])],
    ]
    t_sim = Table(sim_data, colWidths=[100, 210, 230])
    t_sim.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_FOREST),
        ('BOX', (0,0), (-1,-1), 0.75, C_BORDER),
        ('INNERGRID', (0,0), (-1,-1), 0.5, C_BORDER),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [C_CARD_BG, C_WHITE]),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('RIGHTPADDING', (0,0), (-1,-1), 6),
    ]))
    story.append(t_sim)
    story.append(Spacer(1, 14))
    
    # ------------------------------------------------------------------
    # SECTION 8: DATA PERSISTENCE & SQLITE STORAGE
    # ------------------------------------------------------------------
    story.append(Paragraph("8. Data Persistence & SQLite Storage", styles["SecHeading1"]))
    story.append(HRFlowable(width="100%", thickness=1, color=C_GOLD, spaceBefore=1, spaceAfter=6))
    story.append(Paragraph("All application state is preserved locally in an embedded SQLite 3.45 database file located at <b><code>database/seniortutor.db</code></b>:", styles["ManualBody"]))
    
    db_items = [
        Paragraph("• <b><code>users</code> Table:</b> Profiles for Senior (ID 1) and Helper (ID 2), active streak counters, and assigned roles.", styles["ManualBody"]),
        Paragraph("• <b><code>categories</code> & <code>lessons</code> Tables:</b> 12 curriculum categories and 17 instructional lessons with metadata.", styles["ManualBody"]),
        Paragraph("• <b><code>lesson_steps</code> Table:</b> Step sequences, illustrated visual types (Phone UI, WhatsApp, UPI, Map, Warning), and voice narration scripts.", styles["ManualBody"]),
        Paragraph("• <b><code>quiz_questions</code> & <code>quiz_options</code> Tables:</b> Knowledge assessment questions, answer choices, and educational rationale.", styles["ManualBody"]),
        Paragraph("• <b><code>user_progress</code> Table:</b> Tracks completed lessons (<code>is_completed=1</code>), last step reached, and quiz scores per user.", styles["ManualBody"]),
        Paragraph("• <b><code>achievements</code> & <code>user_achievements</code> Tables:</b> Milestone badge criteria and unlock timestamps.", styles["ManualBody"]),
        Paragraph("• <b><code>recommendations</code> Table:</b> Caregiver recommendations with personalized encouragement notes.", styles["ManualBody"]),
        Paragraph("• <b><code>safety_logs</code> Table:</b> Historical messages evaluated in the scam checker, danger scores, and detected flags.", styles["ManualBody"]),
        Paragraph("• <b><code>settings</code> Table:</b> Font scale multiplier, high contrast mode flag, voice tutor flag, and emergency contacts.", styles["ManualBody"]),
    ]
    story.append(build_callout("DATABASE ARCHITECTURE (seniortutor.db)", db_items, border_color=C_GOLD, bg_color=C_CARD_BG))
    story.append(Spacer(1, 14))
    
    # ------------------------------------------------------------------
    # SECTION 9: TROUBLESHOOTING GUIDE
    # ------------------------------------------------------------------
    story.append(PageBreak())
    story.append(Paragraph("9. Comprehensive Troubleshooting Guide", styles["SecHeading1"]))
    story.append(HRFlowable(width="100%", thickness=1, color=C_GOLD, spaceBefore=1, spaceAfter=6))
    
    issues = [
        ("Issue 1: The application does not open when double-clicking the JAR file.",
         "Windows has associated .jar files with an archive utility (like WinRAR or 7-Zip), or Java is not installed in your PATH.\n"
         "Resolution: Open Command Prompt, navigate to the folder, and execute: java -jar SeniorCitizenDigitalTutor.jar. If Java is missing, install Java 21 LTS from adoptium.net."),
        ("Issue 2: Spoken voice audio does not play when clicking Listen or Repeat.",
         "Voice Tutor is toggled off, PC volume is muted, or the app is running on Linux/macOS.\n"
         "Resolution: Check the top header bar to ensure it displays 'Voice ON'. Check PC speaker volume. Speech uses local Windows SAPI; on macOS/Linux it gracefully falls back to visual step prompts and tone chimes."),
        ("Issue 3: I answered a quiz question incorrectly. Can I retake the quiz?",
         "User selected an incorrect answer option.\n"
         "Resolution: Complete the remaining quiz questions. On the final score card, click 'Retake Quiz'. The quiz resets to Question 1 immediately with zero penalties."),
        ("Issue 4: How do I switch between the Senior citizen view and Caregiver view?",
         "Caregiver wants to review progress and assign lessons.\n"
         "Resolution: Click the profile pill in the top-right corner ('👵 Shanti Sharma (SENIOR)'). It instantly toggles to '👩 Anita Sharma (HELPER)' and opens the Caregiver Dashboard. Click it again to return."),
        ("Issue 5: How do I start all lessons from scratch?",
         "User wants to reset all progress for a new learner.\n"
         "Resolution: Click 'Settings' in the left navigation sidebar. Scroll to the bottom card labeled 'Reset Learning Progress' and click 'Reset All Progress'. All completed lessons, quiz scores, and badges will be reset.")
    ]
    for issue_title, issue_desc in issues:
        story.append(Paragraph(f"<b>{issue_title}</b>", styles["SecHeading2"]))
        story.append(Paragraph(issue_desc.replace("\n", "<br/>"), styles["ManualBody"]))
        story.append(Spacer(1, 4))
        
    story.append(Spacer(1, 10))
    
    # ------------------------------------------------------------------
    # SECTION 10: FREQUENTLY ASKED QUESTIONS (FAQ)
    # ------------------------------------------------------------------
    story.append(Paragraph("10. Frequently Asked Questions (FAQ)", styles["SecHeading1"]))
    story.append(HRFlowable(width="100%", thickness=1, color=C_GOLD, spaceBefore=1, spaceAfter=6))
    
    faqs = [
        ("Q: Does this application require an active internet connection?",
         "A: No. The Senior Citizen Digital Tutor is an offline-first desktop application. All lessons, practice simulations, scam pattern evaluations, voice synthesis, and database operations run 100% locally on your computer with zero internet connectivity required."),
        ("Q: Can my real bank account lose money if I make a mistake in the UPI simulation?",
         "A: Absolutely not. The UPI simulation is an isolated, mock educational environment. It does not connect to any bank, payment gateway, or the internet. No real money can ever be transferred."),
        ("Q: Can I install this on a Windows tablet or touchscreen laptop?",
         "A: Yes. The application is optimized for standard 1280x800 desktop and tablet resolutions. All buttons feature generous 52px+ touch targets supporting both mouse clicks and touchscreen taps."),
        ("Q: Where are my learning records stored?",
         "A: All progress, scores, and settings are stored locally in an embedded file at database/seniortutor.db inside your project directory. No user data is ever sent to external cloud servers."),
        ("Q: Does the scam checker guarantee that a message is 100% safe?",
         "A: No software can guarantee 100% fraud detection. The 'Is This Safe?' tool is an educational analyzer that searches for known high-risk scam patterns to train elders in vigilance. Always consult a trusted family member if in doubt."),
        ("Q: Which languages are supported?",
         "A: The application supports English, Hindi (हिंदी), and Marathi (मराठी). You can switch languages at any time from the Settings screen.")
    ]
    for q, a in faqs:
        story.append(Paragraph(f"<b>{q}</b>", styles["SecHeading2"]))
        story.append(Paragraph(a, styles["ManualBody"]))
        story.append(Spacer(1, 4))
        
    # Build Document
    print("Building PDF document...")
    doc.build(story, canvasmaker=NumberedCanvas)
    print("PDF build completed successfully!")

if __name__ == "__main__":
    generate_pdf()
