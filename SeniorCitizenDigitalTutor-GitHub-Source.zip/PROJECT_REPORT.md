# Senior Citizen Digital Tutor
## "Learn. Practice. Use. Stay Connected."
### Comprehensive Academic Mini-Project Report

---

## 1. Title
**Senior Citizen Digital Tutor: An Offline-First Desktop Learning & Cyber Safety Environment for the Elderly**  
**Tagline:** *"Learn. Practice. Use. Stay Connected."*  
**Academic Degree:** Bachelor of Technology / Bachelor of Engineering in Computer Science & Information Technology  
**Project Category:** Desktop Application Development, Human-Computer Interaction (HCI), Accessible Computing, Cyber Literacy  

---

## 2. Abstract
As essential public services, healthcare, banking, and communications undergo rapid digitisation, a significant demographic—senior citizens—finds itself increasingly disenfranchised. Elders frequently experience technological anxiety, cognitive overload from cluttered interfaces, and acute fear of financial loss through ubiquitous cyber scams.

This project presents **Senior Citizen Digital Tutor**, an accessible, standalone desktop application built using **Java 21 LTS**, **JavaFX**, **SQLite**, and **JDBC**. Governed by the central philosophy *"Learn technology without fear"*, the system functions like a patient family member. It delivers a structured, 12-category digital curriculum supported by dynamic visual UI illustrations, offline spoken voice synthesis (Windows Speech SAPI), and unlimited repetition. Crucially, the platform incorporates five realistic, safe sandbox simulations (WhatsApp, Phone Dialer, UPI Payments, Google Maps, and Email) where learners can practice without real-world consequences, alongside a dedicated rule-based "Is This Safe?" scam detection analyzer. Evaluation across functional, accessibility, and architectural metrics confirms that the application operates 100% offline with zero external paid APIs, providing an empathetic, privacy-preserving educational tool for the elderly.

---

## 3. Introduction
The transition towards a digital society has transformed smartphones and digital services from conveniences into daily necessities. In developing and developed nations alike, essential tasks such as pension verification, utility payments, grocery acquisition, doctor consultations, and family communication rely heavily on mobile applications such as WhatsApp, UPI portals, and digital banking platforms.

However, modern user interface paradigms are largely optimized for young, tech-savvy demographics. They assume intuitive familiarity with abstract concepts like One-Time Passwords (OTPs), QR codes, hamburger menus, and multi-touch gestures. For elderly citizens (aged 60 and above), physiological factors—such as presbyopia, reduced fine-motor dexterity, and slower information processing—compound with psychological factors—such as fear of making irreparable mistakes and dread of fraud—leading to severe digital hesitation.

**Senior Citizen Digital Tutor** is engineered from the ground up to solve this social challenge. Rejecting generic corporate Learning Management System (LMS) structures and web application overhead, it delivers a calm, tablet-styled desktop interface built on a distinctive warm color palette (Warm Cream, Deep Forest Green, Muted Terracotta, Muted Gold, Soft Sage, and Charcoal). Through bite-sized interactive lessons, tactile acoustic feedback, safe practice sandboxes, and intergenerational caregiver tools, the application fosters digital independence among elderly citizens.

---

## 4. Problem Statement
The digital literacy gap among senior citizens is characterized by four interconnected problems:
1. **Hostile Visual & Interaction Design:** Standard mobile interfaces utilize tiny fonts (12–14px), dense padding, small touch targets (<40px), and complex multi-step navigation paths that trigger frequent accidental touches and cognitive fatigue.
2. **The Paralysis of Fear & Dependency:** Senior citizens fear draining their bank accounts, locking their devices, or transmitting erroneous messages. Because they hesitate to repeatedly ask busy children or caregivers for help, they often abandon digital services altogether.
3. **Severe Vulnerability to Social Engineering & Cyber Fraud:** Fraudsters disproportionately target senior citizens using social engineering tactics—including fake electricity disconnection threats, lottery prizes, spoofed bank KYC warnings, and deceptive requests to install remote-desktop applications (e.g., AnyDesk, TeamViewer).
4. **Absence of Risk-Free Practice Sandboxes:** In the real world, experimenting with a payment application or dialing an unfamiliar number carries real financial and personal consequences. No mainstream application provides a safe, offline, realistic simulation where elders can build muscle memory without stakes.

---

## 5. Motivation
Modern families are often geographically dispersed. Adult children frequently desire for their elderly parents to connect via WhatsApp video calls, navigate maps safely to medical clinics, and understand digital payments. However, teaching technology to elderly parents is frequently fraught with frustration, impatience, and generational miscommunication.

The motivation behind **Senior Citizen Digital Tutor** is to encode the persona of a **patient, loving family member** into software:
- Software that never tires of explaining how to make a video call for the tenth time.
- Software that speaks instructions aloud at a gentle, reassuring cadence.
- Software where pressing a simulated "Pay ₹150" button provides instant feedback without touching a single real rupee.
- Software that validates suspicious messages locally and reminds the elder: *"Take a deep breath; your bank will never ask for your OTP."*

---

## 6. Objectives
The primary objectives of this college mini-project are:
1. To design and implement a standalone, responsive, tablet-style desktop application using Java 21 LTS and JavaFX.
2. To create an accessible visual identity based on a calm, warm editorial color palette with large typography (minimum 16px to 22px) and generous interactive touch targets (>50px).
3. To develop a reusable, modular **Lesson Engine** supporting step counters, progress bars, visual UI illustrations, offline spoken voice narration (Windows Speech SAPI), and repetition controls.
4. To establish a comprehensive **12-Category Curriculum** covering Smartphone Basics, Calling, WhatsApp, Camera & Photos, Internet, Google Maps, Digital Payments, Banking, Online Services, Email, Digital Safety, and Emergency Help.
5. To implement five fully interactive, safe **Practice Sandboxes** (WhatsApp, Phone Dialer, UPI Payments, Google Maps, and Email) providing realistic feedback without real-world risk.
6. To build an educational, rule-based **"Is This Safe?" Scam Checker** that analyzes suspicious messages and provides risk ratings and clear guidance.
7. To provide an intergenerational **Family / Helper Mode** dashboard enabling caregivers to monitor progress, identify difficult topics, and recommend lessons.
8. To ensure complete **offline data persistence** using local SQLite via JDBC, packaging the final deliverable into a single self-contained executable JAR (`SeniorCitizenDigitalTutor.jar`).

---

## 7. Existing System
Current methods for senior digital education fall into three inadequate categories:

| Parameter | Traditional Books / Manuals | Generic LMS (Moodle, Coursera) | Web Tutorials / YouTube |
|---|---|---|---|
| **Interactivity** | None (Static paper) | Passive video / text | Passive video viewing |
| **Ergonomics** | Small print, no audio | Dense corporate layouts | Cluttered ads, autoplay |
| **Practice Environment** | None | Multiple-choice quizzes only | None |
| **Safety Training** | Theoretical warnings | General cybersecurity courses | Uncurated, scattered advice |
| **Offline Capability** | Yes (Physical) | No (Requires constant internet) | No (Requires streaming data) |
| **Caregiver Link** | None | Complex instructor portals | None |

### Drawbacks of Existing Approaches:
- Overwhelming technical jargon without contextual translation.
- Reliance on active cloud services, subscriptions, and fast internet connections.
- Fear barrier remains unaddressed because the user must still experiment on real, live apps.

---

## 8. Proposed System
The **Senior Citizen Digital Tutor** overcomes these limitations by uniting curriculum, voice narration, sandboxed practice, and scam detection into an offline-first desktop environment.

### Key Innovations in Proposed System:
- **Four-Pillar Educational Framework:** Learn $\rightarrow$ Practice $\rightarrow$ Verify (Quiz) $\rightarrow$ Protect (Safety Hub).
- **Realistic Local Simulations:** Custom JavaFX components that simulate mobile WhatsApp chats, phone dialers, UPI QR scanning, turn-by-turn navigation, and email composition.
- **Rule-Based Scam Detection:** High-speed, local heuristic parsing of message content for fraud markers (OTP, PIN, urgency, remote access tools) without sending user data to the cloud.
- **Intergenerational Caregiver Bridge:** Local profile switching allowing family members to view weak areas and pin tailored lessons with personal notes to the elder's dashboard.
- **Embedded SQLite Persistence:** Automatic database creation and seed generation on launch, ensuring zero configuration for evaluators and users.

---

## 9. Features

```
Senior Citizen Digital Tutor
 ├── 🏠 Welcoming Dashboard (Greeting, Search, Continue Learning, Categories, Pinned Recommendations)
 ├── 📚 Modular Lesson Engine (Step Tracker, Visual Mockups, Voice Narration, Repeat, Previous/Next)
 ├── 🎮 Safe Practice Sandbox (WhatsApp, Phone Dialer, UPI Payments, Google Maps, Email)
 ├── 🔐 Digital Safety Hub (6 Golden Rules, Scam Explanations, Rule-Based "Is This Safe?" Analyzer)
 ├── 📝 Knowledge Retention (Interactive Quizzes, Explanations, Score Tallies, Retakes)
 ├── 📊 Progress Tracking (Category % Bars, Daily Streak Counter, Average Accuracy)
 ├── 🏆 Achievements Engine (8 Auto-Unlockable Badges with Celebration Dialogs)
 ├── 👨‍👩‍👧 Family / Helper Mode (Caregiver Analytics, Weak Topic Highlighting, Lesson Recommendations)
 ├── 🆘 Emergency Assistance (One-Touch Giant Buttons: Family, Ambulance 108, Police 112, GPS Location)
 └── ⚙️ Accessibility & Settings (A-/A+ Sizing, High Contrast, Voice Toggle, Language Switching: EN/HI/MR)
```

---

## 10. Functional Requirements
- **FR-1 (Dashboard Display):** The application shall render a personalized greeting, a prominent "Teach Me Anything" search bar, a "Continue Learning" card for the latest unfinished lesson, and category cards.
- **FR-2 (Lesson Delivery):** The system shall navigate through lesson steps sequentially, updating a visual progress bar, displaying appropriate illustration mockups, and speaking step text aloud.
- **FR-3 (Voice Instruction):** The user shall be able to trigger and repeat voice audio for any step via prominent "Listen" and "Repeat" controls.
- **FR-4 (Simulated Practice):** The application shall provide sandboxed simulations for WhatsApp, Phone Dialer, UPI Payments, Google Maps, and Email that respond interactively to input without transmitting external network requests.
- **FR-5 (Scam Checking):** The system shall evaluate text entered into the safety checker against known fraud patterns and return a risk rating (HIGH RISK, SUSPICIOUS, APPEARS SAFE), numerical danger score (0–100), detected flags, and actionable advice.
- **FR-6 (Quiz Assessment):** The system shall present multiple-choice questions for completed lessons, evaluate answers immediately, display explanations, and record scores.
- **FR-7 (Progress & Achievement Tracking):** The application shall calculate category completion percentages, track learning streaks, and automatically award achievement badges when criteria are met.
- **FR-8 (Caregiver Management):** Family helpers shall be able to inspect the senior's performance metrics and assign recommended lessons with customized notes.
- **FR-9 (Emergency Dispatch Simulation):** The system shall provide mock emergency dispatch actions for Family Speed Dial, Medical Ambulance (108), Police (112), and Location Sharing.
- **FR-10 (Settings & Accessibility):** The user shall be able to scale font sizes (1.0x, 1.15x, 1.3x), toggle high contrast mode, toggle audio cues, switch languages (English, Hindi, Marathi), and reset progress.

---

## 11. Non-Functional Requirements
- **NFR-1 (Usability & Ergonomics):** All buttons must maintain a minimum height of 48px to 52px with clear padding and high-contrast labels. Typography must not drop below 14px anywhere in the application.
- **NFR-2 (Performance):** UI transitions and view switches must complete in under 100 milliseconds. Database queries must execute within 20 milliseconds.
- **NFR-3 (Reliability & Robustness):** The application must operate 100% offline without network connectivity or paid external services.
- **NFR-4 (Zero Configuration):** On first execution, the application must automatically verify, create, and seed its SQLite database without requiring manual SQL script execution.
- **NFR-5 (Portability):** The deliverable must execute on any modern 64-bit operating system supporting Java 21+ via `java -jar SeniorCitizenDigitalTutor.jar`.

---

## 12. Technology Stack

| Component | Technology | Rationale & Selection Criteria |
|---|---|---|
| **Programming Language** | Java 21 LTS | Strong static typing, modern LTS stability, robust concurrency for voice and UI threads. |
| **UI Framework** | OpenJFX 21 (JavaFX) | High-performance hardware-accelerated desktop rendering; eliminates webview/Electron memory bloat. |
| **Database Engine** | SQLite 3.45 | Serverless, zero-configuration, single-file embedded database ideal for desktop privacy. |
| **Database Driver** | SQLite JDBC (`org.xerial`) | Native driver enabling high-speed parameterized PreparedStatement execution. |
| **Build & Dependency Tool** | Apache Maven 3.9+ | Standardized dependency management and automated lifecycle build execution. |
| **Packaging Plugin** | Maven Shade Plugin 3.5 | Bundles JavaFX runtime modules, JDBC drivers, and assets into a single fat executable JAR. |
| **Styling** | JavaFX CSS | Declarative styling implementing the custom warm color palette and high-contrast modes. |
| **Speech Engine** | Windows Speech SAPI | High-quality, offline, zero-cost text-to-speech synthesis accessed locally via PowerShell. |

---

## 13. System Architecture

The application adopts a **Layered Model-View-Controller / Service-Repository Architecture**:

```mermaid
graph TD
    subgraph Presentation_Layer["Presentation Layer (JavaFX)"]
        UI_Main["MainLayout & NavigationBar"]
        UI_Views["HomeView | LearnCategoriesView | LessonDetailView | SafetyHubView | PracticeHubView | ProgressView | FamilyCareView | EmergencyHelpView | SettingsView"]
        UI_Sims["WhatsAppSimulation | PhoneDialerSimulation | UpiPaymentSimulation | MapsSimulation | EmailSimulation"]
        UI_Comp["StepIllustrationNode | CategoryCard | LessonCard"]
    end

    subgraph Service_Layer["Service Layer (Business Logic)"]
        S_Lesson["LessonService"]
        S_Quiz["QuizService"]
        S_Progress["ProgressService"]
        S_Safety["SafetyCheckerService"]
        S_Search["SearchService"]
        S_Family["FamilyHelperService"]
        S_Voice["WindowsSpeechService (TTS)"]
        S_Loc["LocalizationService"]
    end

    subgraph Repository_Layer["Repository Layer (Data Access)"]
        R_Cat["CategoryRepository"]
        R_Les["LessonRepository"]
        R_Prg["ProgressRepository"]
        R_Qz["QuizRepository"]
        R_Ach["AchievementRepository"]
        R_Set["SettingsRepository"]
        R_Usr["UserRepository"]
        R_Rec["RecommendationRepository"]
    end

    subgraph Persistence_Layer["Persistence Layer"]
        DB_Mgr["DatabaseManager (JDBC)"]
        DB_Seed["DatabaseSeeder"]
        DB_File[("SQLite: database/seniortutor.db")]
    end

    UI_Main --> UI_Views
    UI_Views --> UI_Comp
    UI_Views --> UI_Sims
    UI_Views --> S_Lesson & S_Quiz & S_Progress & S_Safety & S_Search & S_Family & S_Voice & S_Loc
    S_Lesson --> R_Cat & R_Les
    S_Quiz --> R_Qz & R_Prg
    S_Progress --> R_Prg & R_Ach
    S_Search --> R_Les
    S_Family --> R_Usr & R_Cat & R_Les & R_Rec
    R_Cat & R_Les & R_Prg & R_Qz & R_Ach & R_Set & R_Usr & R_Rec --> DB_Mgr
    DB_Mgr --> DB_Seed
    DB_Mgr --> DB_File
```

---

## 14. Module Description

### 14.1 Welcoming Dashboard Module (`HomeView.java`)
- Displays warm personalized greeting: *"Good Morning, Shanti Ji 👋"*.
- Prominent "🎤 Teach Me Anything" search bar with search button and voice query simulation.
- Displays "Continue Learning" banner showing current step and remaining estimated duration.
- Renders pinned family recommendations sent by caregivers.
- 12 category interactive cards with visual progress indicators.

### 14.2 Lesson Engine Module (`LessonDetailView.java`, `StepIllustrationNode.java`)
- Reusable engine displaying "Step X of Y", visual progress bar, title, and detailed explanation.
- Dynamic illustration node rendering responsive phone mockups, button highlights, QR viewfinders, and warning cards.
- Speech synthesis controls: "🔊 Listen" and "🔁 Repeat" allowing infinite repetitions.
- Seamless end-of-lesson transitions to Practice Sandboxes and Knowledge Quizzes.

### 14.3 Safe Practice Sandbox Module (`PracticeHubView.java`)
- **WhatsApp Simulation:** Active chat with daughter Anita, message bubbles with blue double-ticks, voice notes, photo sharing, and simulated video calling with call timer and end-call controls.
- **Phone Dialer Simulation:** 3x4 dialpad, backspace, family speed-dial chips, ringing and connected call screen, and speakerphone toggle.
- **UPI Payment Simulation:** Viewfinder QR scan, merchant verification, safety warning box, secret PIN pad, and audio soundbox receipt.
- **Google Maps Simulation:** Interactive map canvas, hospital/pharmacy pins, route drawing, and spoken turn-by-turn voice directions.
- **Email Simulation:** Senior-friendly Gmail composer, recipient autofill, PDF attachment chip, sent folder, and received inbox messages.

### 14.4 Digital Safety & Scam Detection Module (`SafetyHubView.java`, `SafetyCheckerService.java`)
- High-visibility banner displaying the **6 Golden Rules of Digital Safety**.
- Interactive "Is This Safe?" analyzer with text area and 5 real-world sample scenario buttons.
- Rule-based detection engine parsing keywords (OTP, PIN, prize, lottery, power cut, KYC, AnyDesk, bit.ly, etc.).
- Categorizes input into HIGH RISK, SUSPICIOUS, or APPEARS SAFE with a 0–100 score, itemized flags, and clear advice.

### 14.5 Knowledge Retention & Progress Module (`QuizView.java`, `ProgressView.java`, `AchievementsView.java`)
- Bite-sized multiple-choice quizzes with touch-friendly options (A, B, C, D) and immediate explanations.
- Dashboard tracking total lessons completed, category percentage bars, and learning streaks.
- 8 unlockable milestone badges celebrating user progress.

### 14.6 Family Caregiver Module (`FamilyCareView.java`, `FamilyHelperService.java`)
- Helper dashboard for caregivers (Anita Sharma) to view senior citizen progress and weak topics.
- Recommender tool enabling caregivers to pin specific lessons with encouraging notes to the elder's dashboard.

### 14.7 Emergency & Accessibility Module (`EmergencyHelpView.java`, `SettingsView.java`)
- Giant one-touch assistance buttons: Call Family, Ambulance (108), Police (112), and Share Location.
- Accessibility settings: A- / A+ text scaling (16px to 22px), high contrast mode, reduced motion, voice tutor toggle.
- Multilingual localization support: English, Hindi (हिंदी), and Marathi (मराठी).

---

## 15. Database Design

### Entity-Relationship Diagram (ERD):
```mermaid
erDiagram
    USERS ||--o{ USER_PROGRESS : tracks
    USERS ||--o{ USER_ACHIEVEMENTS : earns
    USERS ||--o{ RECOMMENDATIONS : receives
    USERS ||--o{ SAFETY_LOGS : performs
    USERS ||--|| SETTINGS : configures

    CATEGORIES ||--o{ LESSONS : contains
    LESSONS ||--o{ LESSON_STEPS : consists_of
    LESSONS ||--o{ QUIZ_QUESTIONS : evaluated_by
    QUIZ_QUESTIONS ||--o{ QUIZ_OPTIONS : offers
    LESSONS ||--o{ USER_PROGRESS : recorded_in
    LESSONS ||--o{ RECOMMENDATIONS : recommended_as
    ACHIEVEMENTS ||--o{ USER_ACHIEVEMENTS : unlocked_as

    USERS {
        int id PK
        string name
        string role
        string avatar
        int current_streak
        string created_at
    }

    CATEGORIES {
        int id PK
        string name
        string icon
        string description
        int display_order
    }

    LESSONS {
        int id PK
        int category_id FK
        string title
        string description
        string difficulty
        int estimated_minutes
        string practice_type
        int order_index
    }

    LESSON_STEPS {
        int id PK
        int lesson_id FK
        int step_number
        string title
        string explanation
        string visual_type
        string visual_data
        string voice_text
    }

    QUIZ_QUESTIONS {
        int id PK
        int lesson_id FK
        string question_text
        string explanation
    }

    QUIZ_OPTIONS {
        int id PK
        int question_id FK
        string option_text
        int is_correct
    }

    USER_PROGRESS {
        int id PK
        int user_id FK
        int lesson_id FK
        int is_completed
        int last_step
        int quiz_score
        int quiz_passed
        string completed_at
    }

    ACHIEVEMENTS {
        int id PK
        string code
        string title
        string description
        string icon
        string req_type
        int req_value
    }

    SETTINGS {
        int user_id PK, FK
        real font_scale
        int high_contrast
        int voice_enabled
        int sound_effects
        string language
        string contact1_name
        string contact1_phone
        string contact2_name
        string contact2_phone
        string doctor_name
        string doctor_phone
    }
```

---

## 16. Class Design

### Class Architecture Overview:
- `com.seniortutor.Main`: Executable fat JAR entry point.
- `com.seniortutor.SeniorTutorApp`: Extends `javafx.application.Application`; creates stage and scene.
- `com.seniortutor.ui.MainLayout`: Root container managing navigation, top bar, and view transitions.
- `com.seniortutor.ui.NavigationBar`: Left navigation rail with accessible button targets.
- `com.seniortutor.ui.component.StepIllustrationNode`: Custom JavaFX layout that renders phone frames and mock UI elements.
- `com.seniortutor.service.SafetyCheckerService`: Heuristic scam analyzer evaluating message risk.
- `com.seniortutor.service.WindowsSpeechService`: Implements `TextToSpeechService` using Windows SAPI via PowerShell.
- `com.seniortutor.database.DatabaseManager`: Singleton managing SQLite JDBC connection and table lifecycle.

---

## 17. User Flow

```mermaid
sequenceDiagram
    autonumber
    actor Senior as Senior Learner (Shanti Ji)
    participant UI as SeniorTutor Desktop UI
    participant Svc as Lesson & Safety Services
    participant DB as SQLite Database

    Senior->>UI: Launch Application
    UI->>DB: Fetch User State, In-Progress Lesson, & Recommendations
    DB-->>UI: Return Shanti Sharma, Lesson #5 (Step 2), Pinned Recommendation
    UI-->>Senior: Display Welcoming Home Screen & Continue Learning Card

    Senior->>UI: Click "Resume Lesson"
    UI->>Svc: Load Lesson Steps & Request Voice Instruction
    Svc-->>Senior: Speak: "Look at the top right corner and tap the video camera icon."
    UI-->>Senior: Render Phone Mockup with Highlighted Video Camera

    Senior->>UI: Click "Next Step" -> "Practice It Now"
    UI-->>Senior: Open WhatsApp Practice Sandbox
    Senior->>UI: Tap "📹 Video Call"
    UI-->>Senior: Connect Simulated Call Screen with Timer & End Call Button

    Senior->>UI: Navigate to "Stay Safe"
    Senior->>UI: Paste Message: "Electricity disconnected tonight! Call 9876..."
    UI->>Svc: analyzeMessage(text)
    Svc-->>UI: Return HIGH RISK (Score 70), "Urgency Threat", "Never Panic"
    UI-->>Senior: Display Red Danger Banner & Actionable Advice
```

---

## 18. Screenshots

| Screen | File | Description |
|---|---|---|
| **Home Dashboard** | `screenshots/01_home_screen.png` | Welcoming greeting, search bar, pinned family recommendation, continue learning card, and 12 category cards. |
| **Lesson Viewer** | `screenshots/02_lesson_viewer.png` | Step counter, visual illustration node with phone mockup, voice controls, and navigation buttons. |
| **Quiz Interface** | `screenshots/03_quiz_interface.png` | Multiple-choice question card with touch-friendly options and feedback. |
| **WhatsApp Sandbox** | `screenshots/04_practice_whatsapp.png` | Interactive messaging, voice notes, photo picker, and simulated video calling. |
| **UPI Sandbox** | `screenshots/05_practice_upi.png` | Simulated QR camera scan, amount verification, safety warning box, and mock PIN pad. |
| **Maps Sandbox** | `screenshots/06_practice_maps.png` | Interactive map canvas, hospital/pharmacy pins, route drawing, and spoken turn-by-turn navigation. |
| **Safety Hub** | `screenshots/07_safety_checker.png` | "Is This Safe?" scam analysis tool with risk score, detected warning signs, and advice. |
| **Progress Dashboard** | `screenshots/08_progress_dashboard.png` | Category completion progress bars, streak metrics, and average quiz accuracy. |
| **Badges & Milestones** | `screenshots/09_achievements_milestones.png` | Unlockable achievement badges with celebration status. |
| **Family Caregiver Mode** | `screenshots/10_family_helper_mode.png` | Caregiver analytics dashboard, weak topic identification, and lesson recommender tool. |
| **Emergency Assistance** | `screenshots/11_emergency_assistance.png` | Giant one-touch assistance buttons (Family, 108 Ambulance, 112 Police, Location Sharing). |
| **Accessibility Settings** | `screenshots/12_accessibility_settings.png` | Font scaling (16px to 22px), high contrast mode, voice tutor toggle, and language switching. |

---

## 19. Testing

The application was tested through automated verification suites and manual scenario testing:

```
========== RUNNING SENIOR TUTOR BACKEND & DB SMOKE TEST ==========
[PASS] Database connected and schema initialized.
[PASS] Users found: 2 (Shanti Sharma - SENIOR, Anita Sharma - HELPER)
[PASS] Categories found: 12
[PASS] Category 1 lessons found: 3
[PASS] Lesson 1 has 3 steps.
[PASS] Quiz questions for lesson 1: 1 (Options: 4)
[PASS] Lottery scam check verdict: HIGH_RISK (Score: 50)
[PASS] OTP scam check verdict: HIGH_RISK (Score: 70)
[PASS] Safe message check verdict: APPEARS_SAFE (Score: 0)
[PASS] Search for 'video call' found: 8 matches.
[PASS] Settings loaded for user 1: Anita (Daughter) (+91 98765 43210)
[PASS] Achievements found: 8
[PASS] Family recommendations for Senior: 1
========== ALL BACKEND & DATABASE TESTS PASSED SUCCESSFULLY! ==========
```

### Verification Matrix:
- **Build Verification:** `mvn clean package` succeeds in 6.4s, producing `target/SeniorCitizenDigitalTutor.jar` (24.2 MB).
- **Execution Verification:** Tested direct launch via `java -jar SeniorCitizenDigitalTutor.jar`.
- **Database Persistence:** Tested data creation, progress updates, and restart persistence on `database/seniortutor.db`.
- **UI & Accessibility:** All 12 views rendered and captured as full-resolution PNGs without JavaFX exceptions.

---

## 20. Limitations
1. **TTS Platform Integration:** The offline speech synthesis currently leverages Windows SAPI via PowerShell. On Linux or macOS, voice playback falls back to console audio logging and synthetic acoustic tones unless external speech engines (e.g. `espeak` or `say`) are configured.
2. **Simulated Sandboxes:** By explicit design and safety guidelines, the practice simulations (WhatsApp, UPI, Phone, Maps, Email) are completely local and simulated. They do not connect to live banking networks or real cellular towers.
3. **Rule-Based Safety Evaluation:** The "Is This Safe?" feature uses deterministic heuristic pattern matching. While effective for common fraud patterns, it does not use a cloud-connected machine learning model.

---

## 21. Future Scope
1. **On-Device Speech-to-Text (STT):** Integrating local, quantized speech-to-text models (such as Vosk or Whisper.cpp) to enable bidirectional voice dialogue, allowing seniors to speak natural queries directly to the tutor.
2. **Companion Android Launcher:** Porting the ergonomics and simplified interaction patterns into an accessible Android home-screen launcher for seniors' personal smartphones.
3. **Local Quantized LLM for Dialect Explanations:** Deploying a small on-device quantized model (e.g., Gemma 2B) to explain scam messages in local regional dialects.
4. **Community Peer Circles:** Adding local Wi-Fi mesh networking so senior citizens in housing communities can participate in friendly digital literacy quizzes together.

---

## 22. Conclusion
The **Senior Citizen Digital Tutor** demonstrates that thoughtful software engineering and accessible human-computer interaction can bridge the digital divide for the elderly generation. By replacing anxiety with guided steps, providing safe sandboxes for risk-free practice, and educating elders on cyber safety, the application empowers senior citizens to navigate modern technology with confidence.

The project fulfills all architectural and technical requirements: built strictly in Java and JavaFX, persistent across an embedded SQLite database, operating 100% offline without external costs, and distributed as a standalone executable JAR ready for college mini-project demonstration.
