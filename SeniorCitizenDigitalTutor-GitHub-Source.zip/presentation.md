# Senior Citizen Digital Tutor
## "Learn. Practice. Use. Stay Connected."
### College Mini-Project Presentation Deck

---

## Slide 1: Title
### Senior Citizen Digital Tutor
**Tagline:** *"Learn. Practice. Use. Stay Connected."*  
**Theme:** Standalone Desktop Literacy & Cyber Safety Companion for Elders  
**Technology Stack:** Java 21 LTS • JavaFX • SQLite • JDBC • Maven • Windows SAPI Voice  
**Presented by:** Final Year Computer Science / IT Engineering Students  

---

## Slide 2: Problem Statement
### The Senior Digital Divide & Technological Anxiety
- **Hostile Interface Complexity:** Modern applications feature microscopic fonts, hidden gesture menus, and lightning-fast animations that confuse elderly users with declining eyesight and motor agility.
- **The Paralysis of Fear:** Senior citizens experience persistent dread of losing bank life-savings, pressing the "wrong button", or breaking their devices.
- **Reluctance to Ask:** Elders frequently hesitate to burden busy children repeatedly for identical smartphone actions.
- **Target of Cyber Predators:** Fraudsters specifically prey on senior citizens using urgent threats ("Electricity disconnection tonight!", "KYC expired!", "Lottery prize!").

---

## Slide 3: Motivation & Core Philosophy
### "Learn Technology Without Fear"
- **The Patient Family Member Metaphor:**
  - Unlimited patient repetition without fatigue or judgment.
  - Spoken voice guidance in clear, measured speech.
  - Large tactile cards and high-contrast text.
- **Safe Practice Sandboxes:**
  - Realistic simulations of WhatsApp, UPI, and Phone dialer where **no real money** can ever be transferred and **no real messages** can be misdirected.
- **Privacy-First & Offline:**
  - Fully local SQLite storage; zero external server dependence; zero telemetry; zero paid APIs.

---

## Slide 4: Proposed Solution
### Comprehensive 4-Pillar Digital Literacy Model
1. **Pillar 1: Learn**  
   Structured, bite-sized lessons with visual UI mockups, step counters, and offline voice narration.
2. **Pillar 2: Practice**  
   Five sandboxed interactive simulators (WhatsApp, Phone Dialer, UPI Payments, Google Maps, Email).
3. **Pillar 3: Stay Safe**  
   Dedicated educational scam detection engine, 6 Golden Safety Rules, and message risk analyzer.
4. **Pillar 4: Stay Connected**  
   One-touch emergency help, family caregiver monitoring dashboard, and multilingual localization.

---

## Slide 5: Comprehensive 12-Category Curriculum
| # | Category | Core Topics Taught |
|---|---|---|
| 1 | 📱 Smartphone Basics | Power on/off, lock/unlock, volume buttons, screen brightness, Wi-Fi |
| 2 | 📞 Calling & Contacts | Dialpad, saving children's contacts, speakerphone mode, blocking spam |
| 3 | 💬 WhatsApp Mastery | Text messages, voice notes, photo sharing, live video calls, group chats |
| 4 | 📸 Camera & Photos | Steady photos, front selfie camera, gallery viewing, photo sharing |
| 5 | 🌐 Safe Internet | Google voice search, YouTube videos, identifying fake pop-up ads |
| 6 | 🗺️ Google Maps | Finding hospitals, chemist shops, route preview, spoken navigation |
| 7 | 💳 Digital Payments | What is UPI, QR code scanning, never entering PIN to receive money |
| 8 | 🏦 Banking Safety | Official SMS balance alerts, ATM security, spotting fake SMS threats |
| 9 | 🛒 Online Services | Booking cabs safely, ordering groceries, tracking deliveries |
| 10 | 📧 Email Communication | Composing Gmail, attaching medical reports, spotting phishing emails |
| 11 | 🔐 Digital Safety | The 6 Golden Rules, electricity cut scam, lottery fraud, remote apps |
| 12 | 🆘 Emergency & Help | One-touch 112, 108 ambulance, family speed-dial, live location sharing |

---

## Slide 6: Lesson Engine Architecture & Voice Tutor
- **Progress Tracker:** Displays "Step X of Y" with dynamic percentage progress bar.
- **Dynamic Visual Illustration Node:** Renders phone mockups, highlighted buttons, QR camera frames, or warning alert cards.
- **Offline Voice Narration:** Windows SAPI speech synthesis reads instructions aloud in a calm, clear tone.
- **Repetition Controls:** "🔊 Listen" and "🔁 Repeat" buttons allow unlimited review.
- **Seamless Milestone Transitions:** Automatically offers Practice Simulator, Knowledge Quiz, and SQLite progress updates upon lesson completion.

---

## Slide 7: Safe Practice Sandboxes (5 Realistic Simulations)
- **💬 WhatsApp Simulation:**
  - Chat screen with daughter Anita, message bubbles with blue double-ticks, voice note audio simulation, photo picker, and simulated video call with timer and end-call controls.
- **📞 Phone Dialer Simulation:**
  - 3x4 dialpad, backspace, family speed-dial chips, ringing and connected call screen, and speakerphone toggle.
- **💳 UPI Payment Simulation:**
  - Viewfinder QR scan, merchant verification, safety warning box, secret PIN pad, and audio soundbox receipt.
- **🗺️ Google Maps Simulation:**
  - Interactive map canvas, hospital/pharmacy pins, route drawing, and spoken turn-by-turn voice directions.
- **📧 Email Simulation:**
  - Senior-friendly Gmail composer, recipient autofill, PDF attachment chip, sent folder, and received inbox messages.

---

## Slide 8: Digital Safety & "Is This Safe?" Scam Checker
- **Dedicated Rule-Based Scam Analyzer:**
  - Evaluates message text for fraud triggers: `OTP`, `UPI PIN`, `prize`, `lottery`, `urgent`, `electricity disconnect`, `KYC`, `AnyDesk`, `TeamViewer`, `bit.ly`.
- **Verdict & Risk Score (0 - 100):**
  - 🔴 **HIGH RISK:** Imminent danger (OTP, PIN, remote tools).
  - 🟡 **POSSIBLY SUSPICIOUS:** Artificial urgency, unexpected prize, unverified links.
  - 🟢 **APPEARS SAFE:** Standard communication, no credential requests.
- **Clear Senior-Friendly Explanations:**
  - Explicit warning signs + concrete next steps ("Never share OTP", "Call your family to verify", "Visit branch").
- **The 6 Golden Rules:** High-visibility banner reinforcing essential cyber defense rules.

---

## Slide 9: Knowledge Retention — Quizzes & Achievements
- **Bite-Sized Quizzes:**
  - Multiple-choice questions for every lesson with large, accessible touch buttons (A, B, C, D).
  - Immediate feedback explaining *why* an answer is right or wrong.
- **Progress Metrics:**
  - Category completion percentage bars, total lessons completed, and average quiz accuracy.
  - Learning streak tracking (consecutive days of practice).
- **8 Unlockable Achievement Badges:**
  - 🌟 First Steps • 💬 WhatsApp Explorer • 🛡️ Safety Champion • 💳 Digital Money Smart
  - 🎯 Quiz Champion • 🏆 Tech Champion • 🗺️ City Navigator • 🔥 Daily Learner

---

## Slide 10: Family / Caregiver Mode
- **Intergenerational Caregiver Support:**
  - Separate helper dashboard for adult children (e.g., Anita Sharma).
  - Complete visibility into parent's learning journey, category progress, and quiz accuracy.
- **Weak Topic Detection:**
  - Highlights topics needing review (e.g., "UPI PIN Protection", "Electricity Bill Scams").
- **Caregiver Recommender Tool:**
  - Child selects a lesson and writes a personalized note (*"Maa, please review this before our shopping trip!"*).
  - Recommendation is pinned to the senior's Home screen on next launch.

---

## Slide 11: Emergency Assistance & Inclusive Ergonomics
- **One-Touch Giant Emergency Buttons:**
  - 👨‍👩‍👧 Call Family • 🚑 Medical Ambulance (108) • 🚓 Police (112) • 📍 Share GPS Location
- **Accessibility Customization:**
  - Dynamic Font Sizing: Standard (16px), Large (18px), Extra Large (22px).
  - High Contrast Mode: Dark high-legibility theme for low vision.
  - Voice Tutor Toggle: Persistent header button.
  - Multilingual Support: Localized in English, Hindi (हिंदी), and Marathi (मराठी).
  - Tactile Sound Feedback: Gentle audio chimes for clicks and completions.

---

## Slide 12: System Architecture
```
┌────────────────────────────────────────────────────────┐
│               JavaFX Presentation Layer                │
│  MainLayout  •  NavigationBar  •  HomeView  •  Views   │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│                    Service Layer                       │
│  LessonService   QuizService   SafetyCheckerService   │
│  ProgressService SearchService WindowsSpeechService   │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│                  Repository Layer                      │
│  LessonRepository CategoryRepository ProgressRepo...  │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│           SQLite Database via JDBC (Local)            │
│  users, categories, lessons, quiz, progress, settings  │
└────────────────────────────────────────────────────────┘
```

---

## Slide 13: Technology Stack & Engineering Highlights
- **Java 21 LTS:** Clean, modern, strongly typed desktop application core.
- **JavaFX 21:** High-performance hardware-accelerated UI; zero webview, HTML/JS, or Electron bloat.
- **SQLite 3.45:** Embedded ACID-compliant database stored in `database/seniortutor.db`.
- **JDBC Driver:** Direct, fast, secure parameterized SQL connectivity.
- **Maven & Maven Shade:** Automated dependency lifecycle and single standalone fat executable JAR (`SeniorCitizenDigitalTutor.jar`).
- **Windows SAPI Speech Synthesis:** High-quality offline spoken voice tutor.

---

## Slide 14: Demonstration Gallery
*(Live screenshots rendered from actual executable application)*
- 🏠 **Home Dashboard:** Welcoming greeting, search bar, and pinned family recommendations.
- 💬 **WhatsApp Simulation:** Interactive messaging, voice notes, and simulated video call.
- 💳 **UPI Payment Sandbox:** QR code viewfinder, PIN pad, and audio soundbox receipt.
- 🔐 **Safety Hub:** "Is This Safe?" scam analysis tool with danger scoring.
- 📊 **Progress View:** Category completion bars and streak metrics.
- 🆘 **Emergency Assistance:** Giant one-touch high-contrast assistance buttons.

---

## Slide 15: Conclusion & Future Scope
- **Project Achievements:**
  - Delivered a fully functional, offline-first desktop application for senior digital literacy.
  - Successfully bridged accessibility, educational simulation, and cyber protection.
  - Zero external operating costs; 100% self-contained executable JAR.
- **Future Roadmap:**
  - On-device speech-to-text (Whisper/Vosk) for two-way voice tutoring dialogue.
  - Companion Android home-screen launcher for elders' personal phones.
  - Local quantized LLM integration for multilingual conversational scam explanations.
- **Thank You! Open for Questions & Live Demonstration.**
