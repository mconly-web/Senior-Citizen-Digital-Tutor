# Senior Citizen Digital Tutor
## Official Functional Software Handover & User Operations Manual

**Project Name:** Senior Citizen Digital Tutor  
**Tagline:** *"Learn. Practice. Use. Stay Connected."*  
**Application Type:** Standalone Offline Desktop Application  
**Primary Deliverable File:** `SeniorCitizenDigitalTutor.jar`  
**Distribution Archive:** `SeniorCitizenDigitalTutor.zip`  
**Runtime Architecture:** Java 21 LTS (or compatible modern LTS) • OpenJFX 21 • SQLite 3.45 via JDBC  

---

```
========================================================================================
                              ⚡ QUICK START BOX ⚡
========================================================================================
1. Ensure Java (Version 21 or later) is installed on your computer.
2. Locate the project folder or extract "SeniorCitizenDigitalTutor.zip".
3. Inside the folder, locate the executable file:
   👉 SeniorCitizenDigitalTutor.jar
4. Double-click "SeniorCitizenDigitalTutor.jar" to start the application.
5. If double-clicking does not launch it:
   - Open Command Prompt or PowerShell in the project folder.
   - Run the exact command:
     java -jar SeniorCitizenDigitalTutor.jar
6. The application window will open immediately at 1280x800 resolution.
========================================================================================
```

---

## Table of Contents
1. [Important Safety & Educational Disclaimer](#1-important-safety--educational-disclaimer)
2. [How to Run the Application (Complete Beginner Guide)](#2-how-to-run-the-application-complete-beginner-guide)
   - [Which File Do I Run?](#which-file-do-i-run)
   - [Method 1: Double-Click the JAR](#method-1-double-click-the-jar)
   - [Method 2: Run via Command Prompt / Terminal](#method-2-run-via-command-prompt--terminal)
   - [Method 3: Run from Source with Maven](#method-3-run-from-source-with-maven)
   - [Troubleshooting: "The App Won't Open"](#troubleshooting-the-app-wont-open)
3. [System Overview & Operating Philosophy](#3-system-overview--operating-philosophy)
4. [Master Function Matrix](#4-master-function-matrix)
5. [Screen-by-Screen Functional Guide](#5-screen-by-screen-functional-guide)
   - [Persistent Top Bar & Profile Switcher](#51-persistent-top-bar--profile-switcher)
   - [Navigation Sidebar](#52-navigation-sidebar)
   - [Home Dashboard Screen](#53-home-dashboard-screen)
   - [Curriculum & Category Selection Screen](#54-curriculum--category-selection-screen)
   - [Lesson Engine & Step Viewer Screen](#55-lesson-engine--step-viewer-screen)
   - [Knowledge Check & Quiz Screen](#56-knowledge-check--quiz-screen)
   - [Safe Practice Sandbox Hub](#57-safe-practice-sandbox-hub)
     - [WhatsApp Simulation](#whatsapp-simulation)
     - [Phone Dialer Simulation](#phone-dialer-simulation)
     - [UPI Payment Simulation](#upi-payment-simulation)
     - [Google Maps Simulation](#google-maps-simulation)
     - [Email Simulation](#email-simulation)
   - [Digital Safety Hub & "Is This Safe?" Scam Checker](#58-digital-safety-hub--is-this-safe-scam-checker)
   - [Learning Progress Dashboard](#59-learning-progress-dashboard)
   - [Milestone Badges & Achievements Screen](#510-milestone-badges--achievements-screen)
   - [Family Caregiver / Helper Dashboard](#511-family-caregiver--helper-dashboard)
   - [One-Touch Emergency Assistance Screen](#512-one-touch-emergency-assistance-screen)
   - [Settings & Accessibility Customization Screen](#513-settings--accessibility-customization-screen)
6. [Complete Operational Workflows](#6-complete-operational-workflows)
   - [Workflow 1: Searching for and Launching a Lesson](#workflow-1-searching-for-and-launching-a-lesson)
   - [Workflow 2: Completing a Lesson, Voice Narration, and Quiz](#workflow-2-completing-a-lesson-voice-narration-and-quiz)
   - [Workflow 3: Practicing a Safe UPI Grocery Payment](#workflow-3-practicing-a-safe-upi-grocery-payment)
   - [Workflow 4: Testing a Suspicious Message in the Scam Checker](#workflow-4-testing-a-suspicious-message-in-the-scam-checker)
   - [Workflow 5: Caregiver Recommending a Pinned Lesson](#workflow-5-caregiver-recommending-a-pinned-lesson)
   - [Workflow 6: Adjusting Font Size and High Contrast](#workflow-6-adjusting-font-size-and-high-contrast)
7. [Simulation vs. Reality: Sandbox Boundary Guarantees](#7-simulation-vs-reality-sandbox-boundary-guarantees)
8. [Data Persistence & SQLite Storage](#8-data-persistence--sqlite-storage)
9. [Comprehensive Troubleshooting Guide](#9-comprehensive-troubleshooting-guide)
10. [Frequently Asked Questions (FAQ)](#10-frequently-asked-questions-faq)

---

## 1. Important Safety & Educational Disclaimer

> [!IMPORTANT]
> **CRITICAL BOUNDARY DEFINITION:**
> 1. **ALL SIMULATIONS ARE 100% LOCAL AND VIRTUAL:** The simulated environments for **WhatsApp**, **Phone Calling**, **UPI Payments**, **Google Maps**, and **Email** are sandboxed educational tools running entirely within the application.
>    - **NO REAL MONEY** is ever transferred.
>    - **NO REAL BANK ACCOUNTS** or payment gateways are accessed.
>    - **NO REAL PHONE CALLS** or emergency dispatches are executed.
>    - **NO REAL SMS** or emails are transmitted outside your computer.
> 2. **SCAM CHECKER IS AN EDUCATIONAL AID, NOT AN ORACLE:** The *"Is This Safe?"* feature uses local heuristic pattern matching to detect common deception indicators (e.g. artificial panic, lottery lures, OTP requests, remote access app names). It is designed to train vigilance. It does **not** guarantee 100% detection of all evolving cyber fraud. When in doubt, senior citizens must always verify directly with trusted family members or official branch offices.

---

## 2. How to Run the Application (Complete Beginner Guide)

This section assumes you have never run a Java application before. Follow these instructions step-by-step.

### Which File Do I Run?

```
🔥 RUN THIS FILE:
   SeniorCitizenDigitalTutor.jar   (Located in the project root folder)
   OR
   target/SeniorCitizenDigitalTutor.jar

❌ DO NOT RUN:
   - Any file ending in .java (These are source code files)
   - database/seniortutor.db  (This is the local database storage)
   - Any file in src/ or target/classes/
   - pom.xml
```

---

### Step 1: Check If Java Is Installed

1. On Windows, press the **Windows Key + R** on your keyboard.
2. In the small "Run" box that appears, type `cmd` and press **Enter**.
3. A black Command Prompt window will open.
4. Type the following command and press **Enter**:
   ```bash
   java -version
   ```
5. **What you should see:**
   You should see text mentioning Java 21, Java 25, or another modern runtime, similar to:
   ```text
   java version "21.0.6" LTS
   Java(TM) SE Runtime Environment ...
   ```
6. **If you see:**
   `'java' is not recognized as an internal or external command`
   👉 **Solution:** Download and install Java 21 LTS (or higher) from [Oracle Java Downloads](https://www.oracle.com/java/technologies/downloads/) or [Adoptium Eclipse Temurin](https://adoptium.net/). Run the installer, select the default options, and restart your computer.

---

### Method 1: Double-Click the JAR (Windows)

1. Open the project folder (`Senior Citizen Digitalizer`).
2. Find the file named **`SeniorCitizenDigitalTutor.jar`**.
3. **Double-click** the file.
4. **Expected Result:** Within 2 to 4 seconds, the application window titled *"Senior Citizen Digital Tutor — Learn. Practice. Use. Stay Connected."* will appear on your screen at 1280x800 resolution with the warm cream dashboard.
5. **If double-clicking opens WinRAR / 7-Zip instead:**
   Windows has associated `.jar` files with an archive extractor. Right-click `SeniorCitizenDigitalTutor.jar`, select **Open with** $\rightarrow$ **Choose another app** $\rightarrow$ select **Java(TM) Platform SE binary**. Or use Method 2 below.

---

### Method 2: Run via Command Prompt / Terminal

This is the most reliable method across all Windows, macOS, and Linux systems:

1. Open Command Prompt or Windows PowerShell.
2. Navigate to the project directory:
   ```powershell
   cd "d:\College\Senior Citizen Digitalizer"
   ```
3. Run the standalone executable JAR:
   ```powershell
   java -jar SeniorCitizenDigitalTutor.jar
   ```
4. **Expected Result:**
   The SQLite database initializes automatically, and the graphical desktop window launches immediately.

---

### Method 3: Run from Source with Maven

If you wish to compile and package the software from source code:

1. Open Command Prompt in the project folder:
   ```powershell
   cd "d:\College\Senior Citizen Digitalizer"
   ```
2. Build the project using the included Maven wrapper:
   ```powershell
   .\mvnw.cmd clean package
   ```
   *(On macOS / Linux, use: `./mvnw clean package` or `mvn clean package`)*
3. Once the build outputs `BUILD SUCCESS`, run the newly generated JAR:
   ```powershell
   java -jar target\SeniorCitizenDigitalTutor.jar
   ```

---

### Troubleshooting: "The App Won't Open"

| What You See | Likely Cause | Exact Solution |
|---|---|---|
| Command prompt says `'java' is not recognized` | Java is not installed or not in Windows PATH | Install Java 21 LTS from adoptium.net. Ensure "Add to PATH" is checked during setup. |
| Double-clicking opens WinRAR or 7-Zip | File association is set to archive manager | Use Command Prompt: `java -jar SeniorCitizenDigitalTutor.jar`, or right-click $\rightarrow$ Open With $\rightarrow$ Java. |
| `UnsupportedClassVersionError` | An outdated Java version (e.g. Java 8 or 11) is active | Upgrade to Java 21 LTS or newer. The application requires modern LTS bytecode. |
| Window opens then immediately closes | Missing write permissions for `database/` folder | Ensure the folder is not marked "Read-Only". Run Command Prompt as Administrator if in a restricted drive. |
| No voice sound plays during lessons | Windows Speech service is muted or running on non-Windows OS | Voice uses local Windows SAPI. Check PC volume slider. On non-Windows OS, speech logs to console. |

---

## 3. System Overview & Operating Philosophy

### The "Learn Technology Without Fear" Model
Traditional educational software treats technology education like an academic curriculum—punishing incorrect inputs, enforcing deadlines, and displaying dense walls of text. **Senior Citizen Digital Tutor** is built on a diametrically opposite philosophy:

```
┌────────────────────────────────────────────────────────────────────────┐
│                        SENIOR TUTOR PHILOSOPHY                         │
├────────────────────────────────┬───────────────────────────────────────┤
│ ❌ Traditional Software Pattern│ ✅ Senior Tutor Design Pattern        │
├────────────────────────────────┼───────────────────────────────────────┤
│ Microscopic 12px text          │ Large 16px–22px high-contrast fonts   │
│ Tiny 32px click targets        │ Minimum 52px rounded touch targets    │
│ Fast, disorienting transitions │ Calm, static, responsive layouts      │
│ Real financial consequences    │ Zero-risk sandboxed simulations       │
│ Single-chance instructions     │ Unlimited "Repeat" voice audio button │
│ Cryptic technical jargon       │ Plain language explanations           │
│ Impatient trial-and-error      │ The warmth of a patient family member │
└────────────────────────────────┴───────────────────────────────────────┘
```

---

## 4. Master Function Matrix

| Function Name | Location | User Action | What It Does | Persistent Effect | Purpose |
|---|---|---|---|---|---|
| **Text Sizing (A-)** | Top Bar | Click `A-` button | Decreases interface font scale by 15% (min 0.85x) | Saved in `settings` table | Adapts text for users who prefer compact density |
| **Text Sizing (A+)** | Top Bar | Click `A+` button | Increases interface font scale by 15% (max 1.4x) | Saved in `settings` table | Enables comfortable reading for presbyopia / low vision |
| **Voice Toggle** | Top Bar | Click Voice button | Toggles automated spoken instructions ON/OFF | Saved in `settings` table | Silences audio when in quiet public spaces |
| **Profile Switcher** | Top Bar | Click Profile pill | Toggles between Senior (`Shanti Sharma`) and Helper (`Anita Sharma`) | Updates active user state | Allows caregiver and elder to share one workstation |
| **Sidebar Navigation** | Left Rail | Click any tab | Switches central view (Home, Learn, Practice, Safety, etc.) | None (UI state) | Uncluttered, predictable navigation |
| **Search Lessons** | Home Screen | Type query + Click `Search` | Searches lesson titles, categories, and keywords | None (UI state) | Instant access to specific tasks (e.g. "video call") |
| **Voice Search Prompt**| Home Screen | Click `🎤 Speak` | Plays voice guidance, autofills sample search, runs query | None (UI state) | Demonstrates voice querying capability |
| **Popular Search Chip**| Home Screen | Click chip (e.g. `Scan QR UPI`) | Fills search box with topic and executes search | None (UI state) | One-tap access to frequently requested digital topics |
| **Clear Search** | Home Screen | Click `✕ Clear Results` | Clears search results card and returns to clean dashboard | None (UI state) | Prevents dashboard clutter |
| **Pinned Recommendation**| Home Screen| Click `Open Recommended Lesson`| Opens the specific lesson assigned by the caregiver | None (Navigates) | Keeps family-assigned priorities immediately visible |
| **Resume Lesson** | Home Screen | Click `Resume Lesson →` | Re-opens latest unfinished lesson at its exact step | None (Navigates) | Eliminates searching for where the user left off |
| **Category Card** | Home / Learn | Click card | Opens full lesson list for that category | None (Navigates) | Browse curriculum by interest area |
| **Start / Review Lesson**| Lesson List | Click button on card | Opens Lesson Engine at Step 1 or user's last step | Updates last step in DB | Launches guided learning experience |
| **Listen Instruction** | Lesson Viewer| Click `🔊 Listen` | Speaks current step instruction aloud via TTS | None (Audio) | Reinforces written text with spoken auditory learning |
| **Repeat Instruction** | Lesson Viewer| Click `🔁 Repeat` | Repeats current step instruction from the beginning | None (Audio) | Unlimited patient repetition without fatigue |
| **Next Step** | Lesson Viewer| Click `Next Step →` | Advances to the next instructional step | Updates `last_step` in DB | Step-by-step sequential comprehension |
| **Previous Step** | Lesson Viewer| Click `← Previous Step` | Returns to the preceding instructional step | Updates `last_step` in DB | Allows reviewing prior steps without resetting lesson |
| **Practice It Now** | Lesson Viewer| Click `🎮 Practice It Now` | Directly opens matching safe sandbox simulation | None (Navigates) | Immediate hands-on muscle memory reinforcement |
| **Take Quick Quiz** | Lesson Viewer| Click `📝 Take Quick Quiz`| Launches multiple-choice comprehension check | None (Navigates) | Validates understanding before moving on |
| **Complete Lesson** | Lesson Viewer| Click `✅ Complete Lesson`| Marks lesson completed, plays celebration chime | Sets `is_completed=1` in DB | Awards completion progress and checks achievements |
| **WhatsApp Chat Send** | Practice Hub | Type text + Click `➤ Send` | Adds chat bubble with blue ticks, triggers auto-reply | Awards achievement | Simulates real texting with reassuring feedback |
| **WhatsApp Photo Send**| Practice Hub | Click `📎` $\rightarrow$ `📸 Send Photo` | Sends garden photo bubble, triggers auto-reply | Awards achievement | Teaches photo attachment workflow safely |
| **WhatsApp Location** | Practice Hub | Click `📎` $\rightarrow$ `📍 Share Location` | Sends home GPS bubble, triggers daughter auto-reply | Awards achievement | Teaches safety location sharing safely |
| **WhatsApp Voice Note**| Practice Hub | Click `🎤 Voice` | Sends voice note bubble `(0:12) ▶`, triggers reply | Awards achievement | Teaches speech-to-text / voice messaging |
| **WhatsApp Video Call**| Practice Hub | Click `📹 Video Call` | Opens full video call screen with live timer | Awards achievement | Eliminates fear of video calling grandchildren |
| **End Active Call** | Practice Hub | Click `🔴 End Call` | Terminates active call simulation, returns to chat | None (UI state) | Teaches how to hang up cleanly |
| **Phone Dialpad** | Practice Hub | Click number keys (0–9) | Appends digit to large display | None (UI state) | Large accessible dialing practice |
| **Phone Backspace** | Practice Hub | Click `⌫` button | Deletes last typed digit | None (UI state) | Easy mistake correction without frustration |
| **Family Contact Chip**| Practice Hub | Click contact chip | Autofills 10-digit number into dialer display | None (UI state) | Teaches speed-dial concept |
| **Speakerphone Toggle** | Practice Hub | Click `Speaker` button | Toggles speaker mode ON/OFF with visual state | None (UI state) | Teaches hands-free calling on table |
| **UPI QR Scan** | Practice Hub | Click `📷 Scan QR Code` | Simulates camera viewfinder scanning shop stand | None (UI state) | Teaches store counter QR payment flow |
| **UPI Amount Input** | Practice Hub | Enter amount or click chip | Sets payment amount (₹50, ₹100, ₹150, ₹250) | None (UI state) | Verifies amount before entering PIN |
| **UPI PIN Pad** | Practice Hub | Enter 4 digits + Click `✓ Pay` | Validates simulated PIN entry, shows success receipt | Awards achievement | Teaches that PIN is only entered to send money |
| **Map Search Chip** | Practice Hub | Click `🏥 Hospital` or `💊 Chemist`| Centers map, draws route line, shows directions | Awards achievement | Finding medical help independently |
| **Voice Navigation** | Practice Hub | Click `▶ Start Voice Navigation`| Speaks spoken turn-by-turn driving/walking directions | None (Audio) | Teaches GPS navigation without fear |
| **Email Compose** | Practice Hub | Enter To/Subject/Body + Send | Dispatches mock email to Sent folder | Awards achievement | Teaches formal email communication |
| **Email Attachment** | Practice Hub | Click `📎 Attach Photo/File` | Adds `Medical_Report.pdf` chip to email | None (UI state) | Teaches document attachment |
| **Scam Analyzer** | Safety Hub | Enter message + Click `Analyze` | Evaluates message for fraud patterns, gives score | Logs check in DB | Identifies scam red flags and protects life savings |
| **Scam Sample Chip** | Safety Hub | Click chip (e.g. `Lottery Scam`)| Autofills real-world scam scenario into input box | None (UI state) | Instant testing of known scam formats |
| **Quiz Option Selection**| Quiz View | Click option button (A/B/C/D)| Evaluates answer, displays green/red explanation | Updates score tally | Teaches through immediate rationale |
| **Quiz Retake** | Quiz View | Click `Retake Quiz 🔁` | Resets quiz question index to 1 | None (UI state) | Unlimited low-stress practice |
| **Caregiver Recommend**| Family Care | Select lesson + Note + Send | Pins recommended lesson to elder's Home screen | Saves in `recommendations` DB| Allows family to guide learning remotely |
| **Emergency Family** | Emergency | Click `👨‍👩‍👧 Call Family` | Plays voice prompt, opens simulated speed dial dialog | None (Simulation) | One-touch emergency peace of mind |
| **Emergency Ambulance**| Emergency | Click `🚑 Ambulance` | Plays alert chime, opens simulated 108 dispatch dialog | None (Simulation) | Instant medical emergency access |
| **Emergency Police** | Emergency | Click `🚓 Police` | Plays alert chime, opens simulated 112 dispatch dialog | None (Simulation) | Instant police helpline access |
| **Share GPS Location** | Emergency | Click `📍 Share Location` | Simulates dispatching home coordinates via SMS | None (Simulation) | Fast location alert to family |
| **High Contrast Toggle**| Settings | Toggle checkbox | Switches to dark high-contrast mode (`#121212`) | Saved in `settings` table | Reduces glare for cataracts or photophobia |
| **Language Switcher** | Settings | Select English, Hindi, Marathi | Updates UI labels to selected language | Saved in `settings` table | Supports native mother-tongue learning |
| **Save Contacts** | Settings | Click `Save Emergency Contacts` | Persists edited family names and phone numbers | Updates `settings` DB | Customizes emergency speed-dial numbers |
| **Reset Progress** | Settings | Click `Reset All Progress 🗑️` | Clears all lesson completions, quiz scores, badges | Deletes user rows in DB | Allows starting fresh or testing from scratch |

---

## 5. Screen-by-Screen Functional Guide

### 5.1 Persistent Top Bar & Profile Switcher

![Home Screen Top Bar](screenshots/01_home_screen.png)

The Top Bar remains visible across every view in the application. It provides instant access to global accessibility settings and profile switching.

#### 1. Application Brand & Tagline
- **What it displays:** *"Senior Citizen Digital Tutor 🌿"* and *"Learn. Practice. Use. Stay Connected."*
- **Why it exists:** Provides consistent, comforting brand reinforcement that this is an educational environment.

#### 2. Font Size Shrink Button (`A-`)
- **Where it is:** Top-right accessibility controls group.
- **What it does:** Decreases global interface font scaling by 15% (down to a minimum of 0.85x).
- **How to use it:** Click `A-`.
- **What happens:** Text across all views immediately decreases in size. The setting is saved in the database.
- **Why it exists:** Allows users with smaller laptop screens to fit more content comfortably.

#### 3. Font Size Enlarge Button (`A+`)
- **Where it is:** Top-right accessibility controls group.
- **What it does:** Increases global interface font scaling by 15% (up to a maximum of 1.4x).
- **How to use it:** Click `A+`.
- **What happens:** Text across all views immediately scales up. The setting is saved in the database.
- **Why it exists:** Essential for senior citizens experiencing presbyopia or mild visual impairment.

#### 4. Voice Tutor Toggle Button (`🔊 Voice ON` / `🔇 Voice OFF`)
- **Where it is:** Top-right accessibility controls group.
- **What it does:** Globally toggles automated spoken narration of lesson steps.
- **How to use it:** Click the button to switch between `🔊 Voice ON` and `🔇 Voice OFF`.
- **What happens:** If toggled OFF, any currently speaking voice immediately halts. Steps will no longer speak automatically upon opening. The setting is saved in the database.
- **Why it exists:** Allows elders to silence spoken audio when resting, in hospital waiting rooms, or around sleeping family members.

#### 5. User Profile Switcher Button (`👵 Shanti Sharma (SENIOR)`)
- **Where it is:** Top-right corner of the application window.
- **What it does:** Displays the active profile name and role, and toggles between Senior Learner and Family Helper.
- **How to use it:** Click the button.
- **What happens:** Plays a pleasant click tone and switches the active user between `Shanti Sharma (SENIOR)` and `Anita Sharma (HELPER)`. If switched to Helper, the application automatically navigates to the Family Caregiver Dashboard.
- **Why it exists:** Eliminates complex login screens and password forms. Caregiver and elder can share one tablet or desktop seamlessly.

---

### 5.2 Navigation Sidebar

The Navigation Sidebar is positioned on the left edge of the screen. It features large, high-contrast, rounded buttons:

- **🏠 Home:** Navigates to the central dashboard.
- **📚 Learn:** Opens the 12-category curriculum browser.
- **🎮 Practice:** Opens the 5-simulation sandbox hub.
- **🔐 Stay Safe:** Opens the digital safety center and scam checker.
- **📊 Progress:** Displays category completion bars, streak metrics, and accuracy.
- **🏆 Badges:** Displays unlockable milestone achievements.
- **👨‍👩‍👧 Family Care:** Opens the caregiver analytics and recommendation dashboard.
- **🆘 Emergency:** Specially highlighted in Terracotta (`#C97855`); opens one-touch emergency assistance.
- **⚙️ Settings:** Opens accessibility, language, emergency contact, and reset controls.

---

### 5.3 Home Dashboard Screen

![Home Dashboard Screen](screenshots/01_home_screen.png)

#### 1. Personalized Greeting
- **Displays:** *"Good Morning, Shanti Ji 👋"* followed by *"What would you like to learn today? Remember: Learn technology without fear."*
- **Purpose:** Sets a warm, non-judgmental tone upon opening the software.

#### 2. "🎤 Teach Me Anything" Search Box
- **Where it is:** Prominently featured in the top card of the dashboard.
- **What it does:** Enables natural-language search across all lesson titles, step explanations, categories, and keywords.
- **How to use it:** Type a question (e.g., *"How do I video call?"* or *"Send a photo"*) and press `Enter` or click `🔍 Search`.
- **Smart Filter Behavior:** Automatically strips conversational filler phrases (*"how do i"*, *"how to"*, *"can you teach me"*) and extracts substantive keywords (*"video"*, *"call"*), matching relevant lessons accurately.
- **Popular Search Chips:** Clicking any chip (*Video call*, *Send photos*, *Scan QR UPI*, *Find hospital*, *Safety rules*) immediately autofills the search bar and runs the search.
- **Voice Search Prompt (`🎤 Speak`):** Plays an offline voice guidance prompt explaining search queries and demonstrates automatic search execution.

#### 3. Pinned Family Recommendation Banner
- **Where it is:** Displayed below the search bar whenever a caregiver recommendation is active.
- **What it displays:** Caregiver name, avatar, and personal encouraging note (e.g. *Anita: "Maa, please review this lesson before shopping this evening!"*).
- **Button (`Open Recommended Lesson →`):** Directly launches the specific recommended lesson in the Lesson Engine.

#### 4. "CONTINUE LEARNING" Card
- **Where it is:** Positioned above the category grid.
- **What it displays:** The user's latest unfinished lesson, its category icon, current step number, and remaining estimated minutes.
- **Button (`Resume Lesson →`):** Re-opens the lesson at the user's exact current step without requiring the user to search through categories.

#### 5. Category Cards Grid (12 Curriculum Cards)
- **What it displays:** 12 large interactive cards covering all curriculum topics.
- **Card Contents:** Category icon, title, description, progress bar, and completion fraction (e.g., *1 of 3 lessons • 33%*).
- **Action:** Clicking any card opens the lesson list for that category.

---

### 5.4 Curriculum & Category Selection Screen

- **Where it is:** Accessed via **"📚 Learn"** in the sidebar or by clicking any category on the Home dashboard.
- **What it displays:** When viewing all categories, displays a 3-column responsive grid. When a category is clicked, displays a list of comprehensive `LessonCard` components.
- **Controls on Each `LessonCard`:**
  - **Category Tag:** Displays category icon and name.
  - **Status Indicator:** Shows green `✅ Completed` or estimated duration `⏱️ 5 mins`.
  - **Simulation Badge:** Displays `🎮 Practice Mode Included` if a simulation is linked.
  - **Action Button:** Displays `Start Lesson →` for new lessons, or `Review Lesson 🔁` for previously completed lessons.

---

### 5.5 Lesson Engine & Step Viewer Screen

![Lesson Engine Screen](screenshots/02_lesson_viewer.png)

The Lesson Engine is the central instructional component of the software.

#### 1. Header Navigation Bar
- **`← Back to Lessons`:** Returns to the category lesson list.
- **Lesson Title & Category Tag:** Displays the active lesson title.
- **`🔊 Listen` Button:** Plays offline spoken voice audio for the current step.
- **`🔁 Repeat` Button:** Replays the spoken instruction from the beginning. Can be pressed an infinite number of times without penalty.

#### 2. Progress Tracker
- **Step Counter:** Displays *"STEP X OF Y"* (e.g., *STEP 2 OF 4*).
- **Progress Bar:** High-contrast gold progress bar visually representing completion percentage.

#### 3. Dynamic Visual Illustration Node (`StepIllustrationNode`)
- Renders an interactive, visually clear representation of what the user should look for on their phone:
  - **Phone UI:** Shows a smartphone bezel with the exact physical button (Power, Volume) or on-screen button highlighted.
  - **WhatsApp UI:** Shows a chat interface with the video camera icon or attachment paperclip highlighted in bright colors.
  - **UPI UI:** Shows a payment QR code target and shop counter stand.
  - **Maps UI:** Shows a route line with turn indicators.
  - **Warning Card:** Shows a high-contrast red alert box reinforcing critical safety rules.

#### 4. Step Explanation Text
- Written in large, clear, conversational language. Preserves clear formatting and generous line spacing.

#### 5. Bottom Navigation Bar
- **`← Previous Step`:** Moves back one step. Updates `last_step` in the database.
- **`Next Step →`:** Advances to the next step. Updates `last_step` in the database. Auto-speaks the next instruction if voice is enabled.
- **End-of-Lesson Controls (Appears on Final Step):**
  - **`🎮 Practice It Now`:** Directly launches the linked practice sandbox (e.g., WhatsApp Video Call).
  - **`📝 Take Quick Quiz`:** Launches the knowledge retention quiz for this lesson.
  - **`✅ Complete Lesson`:** Marks the lesson completed in SQLite, plays a celebratory success chime, displays a congratulatory modal dialog, and navigates to the curriculum view.

---

### 5.6 Knowledge Check & Quiz Screen

![Quiz Screen](screenshots/03_quiz_interface.png)

#### 1. Question Card
- **Question Counter:** Displays *"QUESTION 1 OF 1"* (or total count).
- **Question Title:** Written in large, clear typography (e.g., *"Which button makes a WhatsApp video call?"*).
- **Touch-Friendly Options (A, B, C, D):** Four large, rounded buttons with letters and clear option text.

#### 2. Instant Educational Feedback Card
- Immediately after selecting an answer, the view displays:
  - **Verdict:** `✅ Correct! Great Job!` in green, or `❌ Not Quite, But Keep Trying!` in red.
  - **Explanation Box:** Explains *why* the answer is correct or incorrect (e.g., *"The video camera icon connects you with live video so you can see your grandchildren."*).
  - **Button (`Next Question →` or `See Final Score 🏆`):** Advances through the quiz.

#### 3. Final Score Summary Card
- **Trophy Icon 🏆** and celebration banner.
- **Score Tally:** Displays correct count and percentage (e.g., *Your Score: 1 / 1 (100%)*).
- **Encouragement Message:** Positive, non-intimidating message reinforcing confidence.
- **`Retake Quiz 🔁`:** Resets the quiz for another attempt.
- **`Finish & Back to Lessons`:** Saves the score in SQLite, marks the lesson passed, and returns to the curriculum.

---

### 5.7 Safe Practice Sandbox Hub

The Practice Sandbox provides five fully functional, interactive mock environments where senior citizens can practice digital tasks with **zero real-world risk**.

---

#### WhatsApp Simulation

![WhatsApp Practice Simulation](screenshots/04_practice_whatsapp.png)

- **Yellow Safety Banner:** *"SAFE PRACTICE SIMULATION: Nothing here sends real messages or makes real calls. Practice fearlessly!"*
- **Chat Interface:** Pre-loaded with friendly conversation from daughter Anita (*"Good morning Maa! How are you feeling today?"*).
- **Text Messaging:** Type any message in the input box and click `➤ Send`. The message appears in a green chat bubble with blue double checkmarks (`✓✓`), plays a click sound, and triggers an automated reassuring reply from Anita after 1.4 seconds.
- **Photo Attachment (`📎` $\rightarrow$ `📸 Send Photo`):** Simulates choosing a photo from the gallery. Dispatches a photo bubble (`📷 [Sent Photo: Garden Flowers.jpg] 🌺`) and triggers daughter's reply (*"Such beautiful flowers Maa! You take such clear photos now!"*).
- **Live Location Sharing (`📎` $\rightarrow$ `📍 Share Location`):** Simulates sharing safe home location. Dispatches location bubble and triggers daughter's confirmation.
- **Voice Note Recording (`🎤 Voice`):** Simulates sending a spoken voice message bubble `(0:12) ▶ ılıılı` and triggers daughter's reply (*"I heard your voice message loud and clear Maa! ❤️"*).
- **Simulated Video Call (`📹 Video Call`):**
  - Opens a realistic video call overlay with avatar, caller name, and a live seconds timer (*Connected • 00:15*).
  - Displays senior tip: *"Look straight at your front camera so they can see your smile!"*
  - Includes `🎤 Mute` toggle and prominent red `🔴 End Call` button.
  - Ending the call returns to the chat and adds a call summary bubble (*"📞 Call ended (15 seconds)"*).

---

#### Phone Dialer Simulation

- **Keypad Grid:** Accessible 3x4 layout with large buttons (1, 2 ABC, 3 DEF ... *, 0 +, #).
- **Number Display:** Giant, high-contrast digits with a `⌫` backspace button for effortless correction.
- **Quick Contact Chips:** One-tap autofill for `👩 Anita (Daughter)`, `👨 Rohan (Son)`, and `🩺 Dr. Verma`.
- **Call Button (`📞 Call`):** Giant green button with subtle shadow. Initiates the call screen.
- **Active Call Screen:**
  - Shows contact avatar, name, and phone number.
  - Simulates ringing state (`Ringing... 📳`) for 2 seconds, then transitions to connected timer (`Call Connected • 00:08`).
  - **Speakerphone Toggle (`📢 Speaker OFF` / `🔊 Speaker ON`):** Toggles hands-free mode with tactile audio feedback and color highlight.
  - **End Call Button (`🔴 End Call`):** Giant red button that cleanly hangs up the call.

---

#### UPI Payment Simulation

![UPI Payment Practice Simulation](screenshots/05_practice_upi.png)

- **Red Safety Banner:** *"🚨 GOLDEN RULE: Entering your PIN DEDUCTS money from your bank account. NEVER enter your PIN to receive money!"*
- **Step 1: Scan QR Code:** Viewfinder display with mock QR stand for "Sharma Fresh Groceries (Verified Merchant)", `📷 Scan QR Code Now` button, or preset buttons (`💊 MedPlus Chemist`, `🥛 Mother Dairy Milk`).
- **Step 2: Verify Merchant & Enter Amount:** Displays verified merchant details card (Business Name, UPI ID, Verified Checkmark), large rupee amount input (defaults to ₹150), and quick preset chips (`₹50`, `₹100`, `₹250`, `₹500`).
- **Step 3: Enter Secret UPI PIN:**
  - High-visibility warning box: *"You are paying ₹150 to Sharma Fresh Groceries. Never speak your PIN out loud."*
  - Secret PIN display (`○ ○ ○ ○` transitions to `● ● ● ●`).
  - 3x4 numeric keypad with `⌫` backspace and green `✓ Pay` button.
- **Success Receipt Screen:**
  - Green checkmark ✅ and *"Payment Successful!"*.
  - Large amount display (*₹150.00*).
  - Detailed receipt card: Simulated UPI Transaction ID (`UPI/49204810294/P2M`), debited bank account note, and simulated merchant soundbox voice announcement: *"🔊 Shop Soundbox: 'PhonePe par 150 rupaye prapt hue!'"*.
  - Button `🔁 Practice Another Payment` resets the flow for repeated practice.

---

#### Google Maps Simulation

![Google Maps Practice Simulation](screenshots/06_practice_maps.png)

- **Green Safety Banner:** *"SAFE MAP SIMULATION: Simulated offline map. No GPS or API key needed..."*
- **Search Bar & Quick Filter Chips:**
  - `🏥 Hospital` (City Civil Hospital • 850m • 11 min walk).
  - `💊 Pharmacy` (MedPlus Pharmacy • 350m • 4 min walk).
  - `🥛 Grocery` (Mother Dairy • 500m • 6 min walk).
  - `🚆 Metro` (Central Metro • 1.4km • 18 min walk).
- **Interactive Map Canvas:** High-contrast road layout (MG Road, Cross Road, East Road), public gardens, "🏠 Your Home" pin, and interactive landmark pins.
- **Route Visualization:** Clicking any pin or filter chip draws an animated blue dashed route line from Home to the target landmark with a target highlight circle.
- **Turn-by-Turn Directions Panel:** Displays distance, travel time, and step-by-step turns (e.g. *1. Head north on MG Road (300m) ... 2. Turn right on Civil Lines ...*).
- **Spoken Voice Navigation (`▶ Start Voice Navigation`):** Triggers offline voice narration (*"Starting navigation to City Civil Hospital. In 300 meters turn right..."*) and opens an educational guidance dialog explaining how GPS works in real life.

---

#### Email Simulation

- **Blue Safety Banner:** *"SAFE EMAIL PRACTICE: Safe offline mock email client..."*
- **Folder Sidebar:** `✏️ Compose`, `📥 Inbox (2)`, and `📤 Sent`.
- **Compose Interface:**
  - Quick recipient chips: `👩 Anita (Daughter)`, `👨 Rohan (Son)`, `🩺 Dr. Verma`.
  - "To:" input field with autofill.
  - "Subject:" input field.
  - "Attach File / Photo (`📎`):" Adds `📄 Medical_Report_Sept.pdf` attachment chip with click-to-remove (`✕`).
  - Message body text area.
  - `➤ Send Email` button validates fields, dispatches the email to the Sent folder, plays a success chime, and displays an educational confirmation dialog.
- **Inbox Interface:** Pre-loaded with realistic emails from Dr. Verma (medical report) and State Bank of India (monthly statement). Clicking any email opens a full reading dialog explaining safe email reading habits.

---

#### Aadhaar & DigiLocker Download Simulation

![Aadhaar Practice Simulation](screenshots/13_practice_aadhaar.png)

- **Safety Banner:** *"🛡️ SAFE PRACTICE SIMULATION • NO REAL AADHAAR DATA IS STORED OR SENT"*
- **Step 1: Choose Document Type:** Practice selecting from `🪪 e-Aadhaar Card`, `💉 COVID-19 Vaccine Certificate`, `🚗 Driving License`, or `📜 PAN Verification Record`.
- **Step 2: Enter Aadhaar Number & Security Captcha:**
  - Masked 12-digit input field (`XXXX-XXXX-1234`).
  - Pre-fill button: `💡 Fill Demo Aadhaar Number (5489 2145 9012)`.
  - Captcha challenge (`7 K 2 M`) with refresh button.
  - Golden rule notice: Only enter real Aadhaar on official government domains ending in `.gov.in` or `.nic.in`.
- **Step 3: Simulated Mobile OTP Verification:**
  - Displays incoming simulated SMS from `VK-UIDAI` with OTP `482910`.
  - Auto-fill demo OTP button.
  - Safe error validation preventing invalid codes.
- **Step 4: Official Document Preview & e-Aadhaar PDF Password Key:**
  - Renders an official-looking DigiLocker verified document card with Emblem of India, photo placeholder, masked number (`XXXX XXXX 9012`), and address.
  - **Essential Password Formula Card:** Teaches elders the universal 8-character e-Aadhaar password rule:
    *First 4 letters of name in CAPITAL + 4-digit Year of Birth (e.g. RAME1952 for Rameshwar Sharma, born 1952).*
  - `Open Simulated PDF Viewer` button with confirmation dialog.

---

#### Online Bill Payment Simulation

![Online Bill Payment Simulation](screenshots/14_practice_bill.png)

- **Safety Banner:** *"🛡️ SAFE BILL PAYMENT SANDBOX • ZERO REAL MONEY USED • PRACTICE FREELY"*
- **Step 1: Select Bill Category:** Choose between `⚡ Electricity Bill` or `📱 Mobile Recharge / Postpaid`.
- **Step 2: Select Board & Account:**
  - Pre-loaded providers: Mahavitaran (MSEDCL), Tata Power, BSES Delhi, UPPCL, BESCOM, Jio, Airtel, Vi.
  - Consumer account number field with `💡 Fill Sample Consumer # (028491829012)`.
- **Step 3: Verified Bill Review & Scam Notice:**
  - Displays consumer name (*Smt. Sunita Devi*), account number, amount due (*₹840.00*), and due date (*15 days remaining*).
  - **Fraud Prevention Insight:** Teaches elders that genuine electricity boards give at least 15 days of calm notice, exposing urgent 1-hour SMS threats as complete fraud.
- **Step 4: Safe Payment Method Selection:**
  - Choose between UPI App (Google Pay / PhonePe / Paytm), Net Banking, or Debit Card.
  - Explicit warning: *"Entering your UPI PIN pays money out, never receives money."*
- **Step 5: Real-Time Payment Receipt:**
  - Green confirmation banner with Transaction Reference (`TXN-ELEC-2026-981240`).
  - `Download Receipt (Simulated PDF)` button saving proof of payment.

---

### 5.8 Digital Safety Hub, Scam Spotter Game & 1930 Helpline

![Digital Safety Hub](screenshots/07_safety_checker.png)

#### 1. Official 1930 Cyber Helpline & cybercrime.gov.in Card
- Prominent blue banner featuring India's official National Cybercrime Helpline **1930**.
- Direct guidance on reporting digital fraud within the "Golden Hour" to freeze stolen funds.
- Official reporting website: `https://cybercrime.gov.in` (Ministry of Home Affairs, Government of India).

#### 2. "Scam Spotter" Interactive Mini-Game

![Scam Spotter Game](screenshots/15_scam_spotter_game.png)

- Tap `Play Scam Spotter →` from the Safety Hub to launch the dedicated mini-game.
- 10 real-world Indian text scenarios (Electricity cut threats, KBC lottery, digital arrest Skype calls, OLX QR tricks, genuine family updates, gas cylinder bookings).
- Two large touch buttons: **🟢 SAFE (सुरक्षित)** and **🔴 SCAM (धोखाधड़ी)**.
- Instant educational verdict with badge scoring, audio chime, and detailed explanation of how fraudsters craft the deception.

#### 3. The 6 Golden Rules of Digital Safety
Prominently framed at the top of the hub in high-contrast red alert styling:
1. ❌ **NEVER** share your OTP with anyone under any circumstances.
2. ❌ **NEVER** enter or reveal your UPI PIN to receive money.
3. ❌ **NEVER** share your ATM PIN, netbanking password, or card CVV number.
4. ❌ **NEVER** install AnyDesk, TeamViewer, or QuickSupport on caller instructions.
5. ❌ **NEVER** believe you won a lottery or prize you never bought a ticket for.
6. ❌ **NEVER** panic from urgent "Electricity Disconnection Tonight" threats.

#### 4. "Is This Safe?" Interactive Message Analyzer
- **Input Text Area:** Paste or type any suspicious SMS, WhatsApp forward, or email.
- **Pre-Filled Real-World Sample Chips:**
  - `🎁 Lottery Scam:` *"Congratulations! You won ₹25,000 cash prize. Click bit.ly/claim-prize immediately..."*
  - `⚡ Electricity Threat:` *"Dear consumer, your electricity will be disconnected tonight at 9:30 PM due to unpaid bill. Call 9876543210..."*
  - `🔑 Bank OTP Trap:` *"Dear SBI customer, your debit card is blocked. Please share the 6-digit OTP sent to your phone..."*
  - `📱 Remote App Trap:` *"Your courier delivery has failed. Download AnyDesk to verify your address with our officer."*
  - `🟢 Safe Family Text:` *"Hi Mom, I am reaching home at 7:00 PM for dinner. Please keep hot tea ready!"*
- **Analyze Button (`Analyze Message Safety 🔍`):** Runs the weighted heuristic detection engine.
- **Analysis Results Card:**
  - **Risk Verdict Badge:**
    - 🔴 **HIGH RISK / DANGER:** Critical credentials (OTP, PIN), Digital Arrest, or screen sharing requested.
    - 🟡 **POSSIBLY SUSPICIOUS:** Artificial urgency, prize lures, or personal mobile numbers posing as toll-free help.
    - 🟢 **APPEARS SAFE:** Standard communication; no fraud signatures found.
  - **Risk Danger Score:** Numerical weighted score from 0 to 100.
  - **Itemized Warning Signs:** Specific flags detected with red warning bullets.
  - **"Why This Is Risky" Explanations:** Deep contextual breakdown of the psychological scam tactic.
  - **Actionable Senior Advice:** Concrete steps in the selected language (English, Hindi, Marathi).
- **Recent Safety Checks History:** Displays past analyzed messages, risk badges, timestamps, and scores.

---

### 5.9 Learning Progress Dashboard

![Progress Dashboard](screenshots/08_progress_dashboard.png)

- **Header Metrics Row:**
  - **🎯 Lessons Completed:** Displays fraction and percentage (e.g., *1 / 17 • 6% Complete*).
  - **🔥 Learning Streak:** Displays active streak (e.g., *3 Days • Practicing regularly!*).
  - **⭐ Quiz Accuracy:** Displays average percentage score across all completed quizzes.
- **Recommended Next Step Card:** Automatically identifies the user's next logical uncompleted lesson and provides a one-click `Resume Lesson →` button.
- **Category Mastery Breakdown:** Comprehensive grid displaying all 12 curriculum categories with lesson count fractions and colored percentage progress bars.

---

### 5.10 Milestone Badges & Achievements Screen

![Achievements Badges](screenshots/09_achievements_milestones.png)

- **Grid of 8 Milestone Badges:**
  1. 🌟 **First Steps:** Completed your very first digital lesson.
  2. 💬 **WhatsApp Explorer:** Learned how to connect with family on WhatsApp.
  3. 🛡️ **Safety Champion:** Mastered the Golden Rules of digital safety.
  4. 💳 **Digital Money Smart:** Practiced UPI payments safely without real money.
  5. 🎯 **Quiz Champion:** Scored 100% on a digital literacy quiz.
  6. 🏆 **Tech Champion:** Completed 10 digital tutor lessons.
  7. 🗺️ **City Navigator:** Learned to find nearby hospitals and directions.
  8. 🔥 **Daily Learner:** Practiced learning 3 days in a row.
- **Badge Status:** Unlocked badges display a warm gold border, celebration glow, and `🌟 UNLOCKED` badge. In-progress badges display a subtle greyed state with `🔒 IN PROGRESS`.

---

### 5.11 Family Caregiver / Helper Dashboard

![Family Caregiver Dashboard](screenshots/10_family_helper_mode.png)

- **Active Caregiver Banner:** Displays caregiver name (`Anita Sharma - Daughter`) and selected senior (`Shanti Sharma - 👵 Grandmother`).
- **Category Progress Matrix:** Enables family members to see exactly which categories their parent has mastered vs. where they need encouragement.
- **Suggested Topics Needing Practice:** Automatically flags high-priority topics requiring family reinforcement:
  - 💳 **UPI PIN Safety:** Reinforces that PIN is never needed to receive money.
  - ⚡ **Electricity Scams:** Prepares elder against predatory disconnection threats.
  - 📹 **WhatsApp Video Calls:** Encourages practicing answering incoming video calls.
- **Lesson Recommender Tool:**
  - Dropdown menu allows selecting any lesson from the curriculum.
  - Text input field allows typing an encouraging personal note (*"Maa, please review this before our market visit!"*).
  - Button `Send Recommendation 🚀` pins the lesson directly to the senior's Home screen.
- **Active Recommendations List:** Displays all currently pinned recommendations with a `Mark Done ✓` button to dismiss them once mastered.

---

### 5.12 One-Touch Emergency Assistance Screen

![Emergency Assistance Screen](screenshots/11_emergency_assistance.png)

- **4 Giant High-Visibility Buttons (480x140px):**
  1. **👨‍👩‍👧 Call Family:** Dial primary emergency family contact (`Anita Sharma • +91 98765 43210`). Triggers simulated speakerphone call dialog.
  2. **🚑 Medical Ambulance:** Dial government emergency ambulance helpline (`108`). Triggers simulated paramedic dispatch dialog.
  3. **🚓 Police Helpline:** Dial national universal emergency helpline (`112`). Triggers simulated police emergency dialog.
  4. **📍 Share My Location:** Dispatches current home GPS coordinates (`28.6139° N, 77.2090° E`) via simulated SMS to family contacts.
- **Emergency Contacts Overview:** Displays currently configured primary family, secondary family, and doctor contacts (editable in Settings).

---

### 5.13 Settings & Accessibility Customization Screen

![Settings and Accessibility Screen](screenshots/12_accessibility_settings.png)

- **Display & Text Size:**
  - Radio options: `Standard (16px)`, `Large (18px)`, `Extra Large (22px)`.
  - `High Contrast Mode` checkbox: Switches background to bold charcoal (`#121212`) for high-legibility low-vision reading.
  - `Reduced Motion / Minimal Animations` checkbox: Disables transition effects.
- **Voice Tutor & Sound Effects:**
  - `Enable Voice Instructions Aloud` checkbox: Toggles automated step speech narration.
  - `Play Click & Completion Chimes` checkbox: Toggles acoustic feedback.
- **Language Preference:**
  - Radio options: `English`, `हिंदी (Hindi)`, `मराठी (Marathi)`. Updates all navigation labels and prompts.
- **Emergency Numbers Configuration:**
  - Editable text fields for Primary Contact, Secondary Contact, and Family Doctor names and phone numbers.
  - Button `Save Emergency Contacts 💾` saves updates directly to SQLite.
- **Reset Learning Progress:**
  - Button `Reset All Progress 🗑️` opens a confirmation dialog. Confirming clears user progress, quiz scores, and achievements so lessons can be experienced afresh.

---

## 6. Complete Operational Workflows

### Workflow 1: Searching for and Launching a Lesson
1. From the Home screen, click inside the **"🎤 Teach Me Anything"** text field.
2. Type `How do I make a video call?` and click **`🔍 Search`** (or click the **`Video call`** chip).
3. The Search Results card appears showing matched lessons.
4. Locate *"How to Make a WhatsApp Video Call"* and click **`Start Lesson →`** (or `Review Lesson 🔁`).
5. The Lesson Engine opens directly at Step 1.

---

### Workflow 2: Completing a Lesson, Voice Narration, and Quiz
1. In the Lesson Engine, observe **STEP 1 OF 4** and the visual phone mockup.
2. Click **`🔊 Listen`** to hear the step instruction spoken aloud.
3. Click **`🔁 Repeat`** if you want to hear it a second time.
4. Click **`Next Step →`** to advance through Steps 2, 3, and 4.
5. On the final step, click **`📝 Take Quick Quiz`**.
6. The Quiz screen displays Question 1. Click option **`B. The video camera icon 📹`**.
7. The feedback card shows **`✅ Correct! Great Job!`** and explains why.
8. Click **`See Final Score 🏆`**.
9. The Results card displays **100% Score**. Click **`Finish & Back to Lessons`**.
10. The lesson is marked **Completed**, and progress increments on your dashboard.

---

### Workflow 3: Practicing a Safe UPI Grocery Payment
1. Click **`🎮 Practice`** in the left sidebar navigation.
2. Click the **`💳 UPI Payments`** simulation button.
3. Observe the red safety disclaimer: *"Entering your PIN DEDUCTS money..."*.
4. Click **`📷 Scan QR Code Now`** to simulate scanning the shop's QR stand.
5. Step 2 opens showing *"Paying to: Sharma Fresh Groceries (Verified Business)"*.
6. Type `150` in the amount box (or click the `₹150` chip) and click **`Proceed to Safe PIN Entry →`**.
7. Step 3 opens showing the secret PIN pad. Enter `1 2 3 4` using the numeric buttons and click **`✓ Pay`**.
8. The screen transitions to **`✅ Payment Successful!`** with a simulated transaction receipt and soundbox voice confirmation.
9. Click **`🔁 Practice Another Payment`** to try another merchant.

---

### Workflow 4: Testing a Suspicious Message in the Scam Checker
1. Click **`🔐 Stay Safe`** in the left sidebar navigation.
2. Scroll to the **"Is This Safe?" Educational Message Checker**.
3. Click the sample button **`⚡ Electricity Threat`**.
4. The text box fills with: *"Dear consumer, your electricity will be disconnected tonight at 9:30 PM due to unpaid bill. Call 9876543210..."*.
5. Click **`Analyze Message Safety 🔍`**.
6. The analysis card renders in high-contrast red:
   - **Verdict:** `🔴 HIGH RISK / DANGER` (Score: 70/100).
   - **Flags:** Artificial Panic & Urgency, Unverified Phone Number.
   - **Advice:** *"Scammers use fear so you don't call your family. Genuine electricity boards give weeks of written notice. Do not call this number."*

---

### Workflow 5: Caregiver Recommending a Pinned Lesson
1. In the top-right header, click the profile button to switch to **`👩 Anita Sharma (HELPER)`**.
2. The application navigates to the **Family Caregiver Dashboard**.
3. Review Shanti Ji's category progress and weak areas.
4. In the "Recommend a Lesson" card, select **"NEVER Share Your UPI PIN - Crucial Rules"** from the dropdown.
5. In the note field, type: *"Maa, please review this before shopping this evening!"*.
6. Click **`Send Recommendation 🚀`**.
7. A confirmation dialog appears. Switch the profile back to **`👵 Shanti Sharma`**.
8. On the Home screen, notice the new gold-bordered pinned recommendation card prominently displayed at the top of the dashboard.

---

### Workflow 6: Adjusting Font Size and High Contrast
1. In the top-right header bar, click **`A+`** twice. Notice the text throughout the dashboard expands to Extra Large size.
2. Click **`⚙️ Settings`** in the left sidebar navigation.
3. Under Display & Text Size, check **`High Contrast Mode`**.
4. The background immediately transitions to deep charcoal (`#121212`) with bright cream and gold elements, eliminating screen glare.
5. Click **`A-`** to return text to standard scale whenever desired.

---

## 7. Simulation vs. Reality: Sandbox Boundary Guarantees

| Feature | What Is Simulated in the Tutor | What NEVER Happens (Real World) |
|---|---|---|
| **WhatsApp Messaging** | Typing text, sending photos, receiving automatic replies, simulated video call screen | No real WhatsApp messages are dispatched; no cellular or data connection is utilized. |
| **Phone Dialer** | 3x4 dialpad typing, speed-dial autofill, ringing screen, connected timer, speakerphone | No actual telephone calls are placed; no SIM card or cellular network is accessed. |
| **UPI Payments** | Mock QR viewfinder, merchant name check, amount entry, simulated PIN pad, mock receipt | **Zero real money is deducted.** No bank accounts, UPI IDs, or financial switches are touched. |
| **Google Maps** | Offline vector map canvas, landmark pins, route line calculation, voice turn guidance | No GPS hardware or Google Maps API key is accessed; no live location is transmitted externally. |
| **Email Client** | Composing email, recipient chips, PDF attachment chip, sent folder archive | No real emails are dispatched across SMTP; no external mail servers are contacted. |
| **Emergency Help** | Speed-dial simulation, ambulance 108 dialog, police 112 dialog, SMS location dispatch | No real emergency dispatches are called. Designed solely for panic-free muscle memory training. |

---

## 8. Data Persistence & SQLite Storage

### Data Storage Architecture
- **Database Engine:** Embedded SQLite 3.45.
- **Physical File Location:** `database/seniortutor.db` (Located inside the project directory).
- **Access Protocol:** Java Database Connectivity (JDBC) using parameterized SQL statements (`PreparedStatement`) to ensure database security.

### What Is Stored:
1. **User Profiles (`users`):** Senior user (ID 1) and Helper user (ID 2), current streak count, and roles.
2. **Curriculum (`categories`, `lessons`, `lesson_steps`):** 12 categories, 17 detailed lessons, instructional steps, visual types, and voice narration scripts.
3. **Assessment (`quiz_questions`, `quiz_options`):** Multiple-choice questions, option texts, correct answers, and explanations.
4. **Learning State (`user_progress`):** Lessons completed, last step reached per lesson, quiz scores, and pass status.
5. **Achievements (`achievements`, `user_achievements`):** Badge definitions and user unlock timestamps.
6. **Caregiver Bridge (`recommendations`):** Active lesson recommendations, personalized notes, and completion flags.
7. **Safety Logs (`safety_logs`):** Historical inputs analyzed in the scam checker, risk scores, and flags.
8. **Settings (`settings`):** Font scale multiplier, high contrast flag, voice tutor enabled flag, sound effects flag, language code, and emergency contact details.

### How Data Persists:
- All progress, settings, and badge unlocks are written immediately to `database/seniortutor.db`.
- Closing the application or restarting your computer preserves 100% of your progress.
- To reset progress completely, open **Settings** $\rightarrow$ click **`Reset All Progress 🗑️`**.

---

## 9. Comprehensive Troubleshooting Guide

### Issue 1: "The application window does not open when I double-click the JAR."
- **Likely Cause:** Windows has associated `.jar` files with an archive utility (like WinRAR, 7-Zip, or WinZip), or Java is not installed in your system PATH.
- **Resolution:**
  1. Open Command Prompt.
  2. Navigate to the project folder: `cd "d:\College\Senior Citizen Digitalizer"`.
  3. Execute: `java -jar SeniorCitizenDigitalTutor.jar`.
  4. If Java is missing, download Java 21 LTS from [adoptium.net](https://adoptium.net) and install it.

---

### Issue 2: "Voice audio does not speak when I click Listen or Repeat."
- **Likely Cause:** Voice tutor is muted in settings, PC master volume is turned down, or you are running on a non-Windows operating system.
- **Resolution:**
  1. Check the top header bar: verify it says `🔊 Voice ON`. If it says `🔇 Voice OFF`, click it to re-enable voice.
  2. Check your computer speaker volume.
  3. Note: Offline voice uses Windows SAPI via PowerShell. On Linux or macOS, voice narration falls back to visual step prompts and acoustic tone chimes.

---

### Issue 3: "I made a mistake in a quiz. Can I retake it?"
- **Likely Cause:** User selected an incorrect answer.
- **Resolution:**
  1. Complete the quiz questions.
  2. On the score summary card, click **`Retake Quiz 🔁`**.
  3. The quiz resets to Question 1 immediately, allowing unlimited practice.

---

### Issue 4: "How do I switch between the Senior citizen view and Family Caregiver view?"
- **Resolution:**
  - Click the profile pill in the very top-right corner of the window (`👵 Shanti Sharma (SENIOR)`).
  - It will immediately toggle to `👩 Anita Sharma (HELPER)` and open the Family Caregiver Dashboard. Click it again to return to the Senior view.

---

### Issue 5: "I want to start the tutorial from the very beginning."
- **Resolution:**
  1. Click **`⚙️ Settings`** in the left sidebar.
  2. Scroll to the bottom card labeled **⚠️ Reset Learning Progress**.
  3. Click **`Reset All Progress 🗑️`** and confirm **Yes**.
  4. All completed lessons, quiz scores, and badges will be reset to zero.

---

## 10. Frequently Asked Questions (FAQ)

#### Q: Does this application require an active internet connection?
**A:** No. The Senior Citizen Digital Tutor is an **offline-first application**. All lessons, practice simulations, scam pattern evaluations, voice synthesis, and database operations run 100% locally on your computer.

#### Q: Can my real bank account lose money if I make a mistake in the UPI simulation?
**A:** **Absolutely not.** The UPI simulation is an isolated, mock educational environment. It does not connect to any bank, payment gateway, or the internet. No real money can ever be transferred.

#### Q: Can I install this on a Windows tablet or laptop?
**A:** Yes. The application is optimized for standard 1280x800 desktop and tablet resolutions. It supports mouse clicks and touchscreen taps.

#### Q: Where are my learning records stored?
**A:** Records are stored in a single embedded file located at `database/seniortutor.db` inside your project directory. No user data is ever sent to external cloud servers.

#### Q: Does the scam checker guarantee that a message is 100% safe?
**A:** No software can guarantee 100% fraud detection. The *"Is This Safe?"* tool is an educational analyzer that searches for known high-risk scam patterns (urgency, OTP requests, lottery claims) to teach elders vigilance. Always consult a family member if in doubt.

#### Q: Which languages are supported?
**A:** The application supports **English**, **Hindi (हिंदी)**, and **Marathi (मराठी)**. You can switch languages at any time from the Settings screen.
